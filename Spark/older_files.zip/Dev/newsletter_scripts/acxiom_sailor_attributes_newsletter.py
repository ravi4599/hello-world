##  spark-submit --name Acxiom_Sailor_Attributes --conf spark.executor.memoryOverhead=10240 --jars /home/ec2-user/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/ec2-user/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/sailor_attributes/acxiom_sailor_attributes.py seaware_id 99999,1234

from pyspark.sql import SparkSession
import pyspark.sql.functions as F

import logging, traceback, sys


def to_long(df, by):
    # Filter dtypes and split into column names and type description
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in by))
    # Spark SQL supports only homogeneous columns
    assert len(set(dtypes)) == 1, "All columns have to be of the same type"

    # Create and explode an array of (column_name, column_value) structs
    kvs = F.explode(F.array([
        F.struct(F.lit(c).alias("key"), F.col(c).alias("val")) for c in cols
    ])).alias("kvs")

    return df.select(by + [kvs]).select(by + ["kvs.key", "kvs.val"])



def sailor_attributes_acxiom(log, spark, col_to_select, id_to_select, acxioms_columns, attributes_mapping_query, hbase_table_name, hbase_ip):

    try:
        ## Read data

        ## NOTE: Where does this column data come from? How will this file be created? Should we externalize this to the processdriver table?
        #log.info("Read Columns List")
        #df_AcxiomRawData_colums = spark.read.csv(acxioms_columns, header=True)
        #df_AcxiomRawData_colums.cache()


        ## NOTE: Where does this data come from? How will this file be created?
        log.info("Read Mapping List")
        df_attributes_mapping = spark.sql(attributes_mapping_query)
        # df_attributes_mapping = spark.read.csv(attributes_mapping, header=True)
        df_attributes_mapping.cache()


        acxioms_columns.append(col_to_select)
        #var_StringColumns.append(col_to_select)

        # id_list = ["CLIENT_ID", "CRM_ID", "C360_ID"]
        # cols_to_remove = [item for item in id_list if item not in id_to_select]
        log.info("Load data from HBase")
        df_AcxiomRawData = spark.read\
            .format("org.apache.phoenix.spark")\
            .option("table", hbase_table_name)\
            .option("zkUrl", hbase_ip)\
            .load()\
            .select(acxioms_columns)\
            .withColumnRenamed(col_to_select, "CLIENT_ID") #\
            # .where(F.col(col_to_select).isin(id_to_select))
            # .where(F.col(col_to_select) == id_to_select)
        df_AcxiomRawData.cache()
        df_AcxiomRawData.show()

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 2: Error reading data.")


    try:
        ## NOTE: It would probably be better to externalize the list of columns. That way we don't have to do a collect.
        ## Select only those columns which are matching to our Acxiom master mapping list bundles
        #var_StringColumns = [item[0] for item in df_AcxiomRawData_colums.select('SpecificColumnsTobeSelected').collect()]


        ## NOTE: We need to check if "id_to_select" is one of the expected ids
        ## NOTE: As above, if we externalize the list, we can just select those columns and eliminate this and the above.
        ## NOTE: Can we just include 'CLIENT_ID' in the list of columns?
        ## Unique key column to be added instead of document_id
        # var_StringColumns.append("CLIENT_ID")
        # acxioms_columns.append(col_to_select)
        # #var_StringColumns.append(col_to_select)
        # df_AcxiomRawStringData = df_AcxiomRawData.select(acxioms_columns)\
        #     .withColumnRenamed(col_to_select, "CLIENT_ID")


        ## Identify the boolean columns and get the attribute
        df_boolColmns = df_attributes_mapping.select("Values_From_Data", "IsBooleanColumn")\
            .where(F.col("IsBooleanColumn") != "NONE")


        log.info("Replacing boolean values with their affinities")
        ## Replacing boolean values with their affinities
        for item in df_boolColmns.collect():
            # print(item)
            colname = item[1]
            value = item[0]
            df_AcxiomRawStringData = df_AcxiomRawData\
                .withColumn(colname + "_", F.when(F.col(colname) == True, value)).drop(colname)


        log.info("Transpose the data")
        ## NOTE: Can these 2 regexp_replace be combined?
        ## Transpose the data
        # df_AcxiomRawData_Transposed_NonBin_Split = to_long(df_AcxiomRawStringData, ["CLIENT_ID"])\
        df_AcxiomRawData_Transposed_NonBin_Split = to_long(df_AcxiomRawStringData, ["CLIENT_ID"])\
            .withColumn("val1", (F.regexp_replace(F.col("val"), "\\[", "")).alias("topic_no_syn")) \
            .withColumn("val3", (F.regexp_replace(F.col("val1"), "\\]", ""))).filter(F.col('val3') != "NULL") \
            .withColumn("SplitColumnValues", F.split(F.col("val3"), "\\|"))
        df_AcxiomRawData_Transposed_NonBin_Split.show()


        ## Generating the master list of client and affinity mapping
        df_distinct_client = df_AcxiomRawData_Transposed_NonBin_Split\
            .select("CLIENT_ID").withColumnRenamed("CLIENT_ID", "main_client_id").distinct()
            # .select("CLIENT_ID").withColumnRenamed("CLIENT_ID", "main_client_id").distinct()

        ## NOTE: Can we make it so the attribute mapping document is already distinct?
        ## NOTE: Why the orderBy()?
        df_distinct_affinities = df_attributes_mapping.select("alternate").distinct().orderBy("alternate")


        ## NOTE: Try to broadcast df_distinct_affinities?
        log.info("Cross Join")
        df_client_affinities_master = df_distinct_client.crossJoin(df_distinct_affinities) \
            .withColumn("MainAcxiomAffinity", F.concat(F.col('alternate'), F.lit("_acxiom"))) \
            .withColumn("newvalue", F.lit(0.0)).drop("alternate")
        df_client_affinities_master.show()


        ## NOTE: Why is 'columnname' created here? It seems to have no function
        log.info("Explode the array into rows")
        ## Explode the Array into Rows
        df_AcxiomRawData_Transposed_NonBin_Exploded = df_AcxiomRawData_Transposed_NonBin_Split\
            .withColumn("ExplodedValues", F.explode(F.col('SplitColumnValues')))\
            .withColumnRenamed("ExplodedValues", "columnname1") \
            .withColumn("columnname", F.concat(F.col('key'), F.lit("_"), F.col('columnname1')))


        ## NOTE: broadcast df_attributes_mapping?
        df_attributes_acxiom_join = df_AcxiomRawData_Transposed_NonBin_Exploded \
            .join(df_attributes_mapping,
                  df_AcxiomRawData_Transposed_NonBin_Exploded.columnname1 == df_attributes_mapping.Values_From_Data,
                  how='left')


        ## NOTE: Why the order bys?
        # .select("CLIENT_ID", "alternate", "columnname1", "Values_From_data") \
        df_affinities_join = df_attributes_acxiom_join\
            .select("CLIENT_ID", "alternate", "columnname1", "Values_From_data")\
            .orderBy("alternate").where(F.col("Values_From_data").isNotNull()) \
            .withColumn("AcxiomAffinity", F.concat(F.col('alternate'), F.lit("_acxiom"))) \
            .withColumn("value", F.lit(1.0)) \
            .select("CLIENT_ID", "AcxiomAffinity", "value")
        df_affinities_join.show()


        log.info("Joining the actual affinities with the master list and get the final df ready for pivoting")
        conditions = ((df_affinities_join.CLIENT_ID == df_client_affinities_master.main_client_id) &
                      (df_affinities_join.AcxiomAffinity == df_client_affinities_master.MainAcxiomAffinity))

        df_final_acxiom = df_client_affinities_master.join(df_affinities_join, conditions, how="left") \
            .withColumn("TotalValueMatched", F.when(F.col("AcxiomAffinity").isNotNull(), F.col("value"))
                        .otherwise(F.lit(0))).drop("AcxiomAffinity", "value", "newvalue", "CLIENT_ID")


        log.info("Pivot Data")
        ## Pivot the dataset
        df_Acxiom_Joined_Affinity = df_final_acxiom\
            .groupBy(['main_client_id'])\
            .pivot('MainAcxiomAffinity').avg('TotalValueMatched') \
            .where(F.col("main_client_id") != "0.0") \
            .withColumnRenamed("main_client_id", "client_id")

        return df_Acxiom_Joined_Affinity

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 2: Please review the hive table.")


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='Sailor_Attributes_Acxiom_Newsletter'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log, col_to_select, id_to_select):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        acxioms_columns = processController.get("cols_to_select").split(",")
        attributes_mapping_query = processController.get("attributes_mapping_query")
        #acxioms_columns = processController.get("acxioms_columns")
        #attributes_mapping = processController.get("attributes_mapping")
        hbase_table_name = processController.get("hbase_table_name")
        hbase_ip = processController.get("hbase_ip")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, spark, col_to_select, id_to_select, acxioms_columns, attributes_mapping_query, hbase_table_name, hbase_ip)

def process(log, spark, col_to_select, id_to_select, acxioms_columns, attributes_mapping_query, hbase_table_name, hbase_ip):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :return                     : Spark Dataframe with columns : [].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting Sailor Attributes Processing...")
    return sailor_attributes_acxiom(log, spark, col_to_select, id_to_select, acxioms_columns, attributes_mapping_query, hbase_table_name, hbase_ip)


def store(processController, log, data):
    """
    Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param data                 : Spark Dataframe.
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    try:
        path_sailor_attributes = processController.get("path_sailor_attributes")
        check_tbl_exists = processController.get("check_tbl_exists")
        drop_table_query = processController.get("drop_table_query")
        create_table_query = processController.get("create_table_query")

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 1: Please verify process driver query execution")


    try:
        log.info("Save the results in Hive as %s" % path_sailor_attributes)
        data.write.mode('append').format("parquet").save(path_sailor_attributes)

    except:
        log.info("Save the results in Hive as %s" % path_sailor_attributes)
        data.write.mode('overwrite').format("parquet").save(path_sailor_attributes)


    try:
        spark.sql(check_tbl_exists)
        log.info("Table Already Exist, No Need to Create One.")

    except:
        log.info("Table Does Not Exist!")
        log.info("Creating Table from file...")
        spark.sql(drop_table_query)
        spark.sql(create_table_query.format(path_sailor_attributes))
        log.info("Finished saving results into HBase")


def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":

    spark = initSparkSession("Sailor_Attributes_Acxiom")
    log = get_logger()

    ## Make sure correct number of arguments
    if not len(sys.argv) == 3:
        log.info("Incorrect number of arguments! There should be 3 arguments Shutting down!")
        log.info("Arguments: ")
        log.info(sys.argv)
        stopSparkSession(log, spark)
        exit()

    if sys.argv[1].lower() != "client_id":
        log.info("The first argument is not correct! It should be 'CLIENT_ID'! Shutting down!")
        log.info("Arguments: ")
        log.info(sys.argv)
        stopSparkSession(log, spark)
        exit()

    col_to_select = sys.argv[1]

    ## Make sure the list of ids is supplied to the script
    try:
        sys.argv[2].split(",")

    except:
        log.info("The second argument is not correct! Shutting down!")
        log.info("Arguments: ")
        log.info(sys.argv)
        stopSparkSession(log, spark)
        exit()

    id_to_select = sys.argv[2].split(",")
    #id_to_select = [i.split('-', 1)[-1] for i in id]
    log.info(id_to_select)

    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    data = initProcess(spark, processController, log, col_to_select, id_to_select)
    data.show()
    # store(processController, log, data)
    stopSparkSession(log, spark)
