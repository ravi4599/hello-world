import unittest

import pytest

import os, sys, re, traceback, logging, time
sys.path.insert(0, "/usr/lib/spark/python/lib")
sys.path.insert(0, "/usr/lib/spark/python/")
import pyspark
from pyspark.sql import SparkSession, Row
from pyspark.sql.types import *
from pyspark.sql.functions import udf, col, explode, lit, regexp_replace, from_unixtime

import nltk


spark = SparkSession \
    .builder \
    .appName("Calculate_Activity_synonyms") \
    .enableHiveSupport() \
    .getOrCreate()
# spark.conf.set("spark.sql.shuffle.partitions", "50")

@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark



##########################
#                  		 #
#    Define Functions    #
# 						 #
##########################


def special_char(x):
    """ Replace non-alphanumeric characters with a ' '

    :param x    : input string
    :return     : string with only alphanumeric characters
    """

    return re.sub('[^A-Za-z0-9]+', ' ', x)

# Create UDF for special_char function
udf_special_char = udf(special_char, StringType())


# Tokenize words - Break a string into individual elements based on spaces
# Ex: "Cat sat on the mat" => ['Cat', 'sat', 'on', 'the', 'mat']
udf_tokenize_keyword = udf(lambda x: nltk.tokenize.word_tokenize(x), ArrayType(StringType()))


# Stem words - Remove affixes from words, leaving only the stem
# Ex: "Having" => "Have", "Waned" => "Want", "Quickly" => "Quick"
udf_stemming_func = udf(lambda x: nltk.stem.snowball.SnowballStemmer("english").stem(x), StringType())


def stop_words(word):
    """ Remove stops words - If a word is in nltk's list of English stop words, remove it
        Ex: ['Cat', 'sat', 'on', 'the', 'mat'] => ['Cat', 'sat', '', '', 'mat']

    :param word : Tokenized word
    :return     : If the word is a stop word, return None, else return the input word
    """

    return word.lower() if word.lower() not in nltk.corpus.stopwords.words("english") else None

# Create UDF for stop_words function
udf_stop_words = udf(stop_words, StringType())


def synonyms_fnc(word):
    """ Collects all synonyms for the input word into a list.
        If no synonyms exist, the input word is returned in a list.

    :param word : Tokenized word
    :return     : A list of all the synonyms available for the given word.
                  If no synonyms exist, the input word is returned in a list.
    """

    a = []
    synset = nltk.corpus.wordnet.synsets(word)
    # If there are synonyms...
    if len(synset) > 0:
        for syn in synset:
            for syn_lemma in syn.lemma_names():
                a.append(syn_lemma)
    # If no synonyms, keep the original word
    else:
        a.append(word)
    return list(a)

udf_synonyms_fnc = udf(synonyms_fnc, ArrayType(StringType()))


def prepare_data():
    """ Prepares the input into a form that can be consumed by the get_synonyms function. The intention is to keep
    all get_synonym functions identical.

    NOTE - We do not as of yet know what the input activity data will look like, so this function will most
           likely change

    :param log              : current logger
    :param spark            : current SparkSession
    :param input_location   : name of activity data table
    :param testing_limit    : limit to use for testing
    :param attributes       : relevant columns to select from activity data table
    :return                 : Spark Dataframe with columns : [id, keywords]
    """
    try:
		preparded_data = spark.sparkContext.parallelize([(1, '2')]).toDF(["sequence", "quick"])

        data = spark.sql("select {} from {} where sequence is not null LIMIT {}".format(attributes, input_location, testing_limit))
		data = spark.read.csv("functional_test_input_data_sailor.csv")
        data = data.withColumnRenamed("sequence", "id_seaware")


        log.info("Filling Data with NAs")
        # Fill NAs
        data = data.na.fill(0, data.columns[1:])


        log.info("Creating key,value pairs out of the column's name and value" )
        # Create key,value pairs out of the column's name and value
        data_transpose = to_long(data, ["id_seaware"])


        log.info("Only select the columns with a value of 1")
        # Only select the columns with a value of 1
        data_transpose_1s = data_transpose.where(data_transpose.val == 1)


        log.info("Group all the keywords together")
        # Group all the keywords together
        # data_transpose_1s_final = data_transpose_1s.groupby("id_seaware").agg(F.concat_ws(", ", F.collect_list(data_transpose_1s.key)).alias("listofkeys"))


        log.info("Select and rename appropriate columns")
        # Group all the keywords together
        data_transpose_1s_final_1 = data_transpose_1s.select("id_seaware", col("keys").alias("keywords"))

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code : Error preparing data. Please review (attributes|input_location|testing_limit) for errors. ".format(input_location))

    return data_transpose_1s_final_1



def get_synonyms(df_prepared_data):
    """

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param df_prepared_data     : Spark Dataframe with columns : [id, keywords]
    :return                     : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_activity is the activity's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    try:
        df_input = df_prepared_data


        # Replace Special Characters with ' '
        df_no_special_chars = df_input.withColumn('keywords_no_special_chars', regexp_replace(col("keywords"), '[^A-Za-z0-9]+', " "))


        ############################################
        ##                                        ##
        ##        Start 1st Step - Synonym        ##
        ##                                        ##
        ############################################


        df_tokenized_keywords = df_no_special_chars.withColumn('tokenized_keywords', explode(udf_tokenize_keyword(df_no_special_chars.keywords_no_special_chars)))


        # Stemming words
        df_stemmed_keywords = df_tokenized_keywords.withColumn('stemmed_keywords', udf_stemming_func(df_tokenized_keywords.tokenized_keywords))


        # Remove stop works.
        df_removed_stop_words = df_stemmed_keywords.withColumn('removed_stop_words', udf_stop_words(df_stemmed_keywords.stemmed_keywords)).where(col('removed_stop_words').isNotNull())


        # Get synonyms
        df_synonyms = df_removed_stop_words.withColumn('synonyms', explode(udf_synonyms_fnc(df_removed_stop_words.removed_stop_words)))


        ##########################################
        ##                                      ##
        ##        End 1st Step - Synonym        ##
        ##                                      ##
        ##########################################


        # Remove Dupes
        df_synonyms = df_synonyms.select("id_activity", "synonyms").distinct()


        ############################################
        ##                                        ##
        ##        Start 2nd Step - Synonym        ##
        ##                                        ##
        ############################################


        df_syns_tokenized_keywords = df_synonyms.withColumn('tokenized_keywords2', explode(udf_tokenize_keyword(df_synonyms.synonyms)))


        # Stemming words
        df_syns_stemmed_keywords = df_syns_tokenized_keywords.withColumn('stemmed_keywords2', udf_stemming_func(df_syns_tokenized_keywords.tokenized_keywords2))


        # Remove stop works
        df_syns_removed_stop_words = df_syns_stemmed_keywords.withColumn('removed_stop_words2', udf_stop_words(df_syns_stemmed_keywords.stemmed_keywords2)).where(col('removed_stop_words2').isNotNull())


        # Get synonyms
        df_syns_synonyms = df_syns_removed_stop_words.withColumn('synonyms', explode(udf_synonyms_fnc(df_syns_removed_stop_words.removed_stop_words2)))


        ##########################################
        ##                                      ##
        ##        End 2nd Step - Synonym        ##
        ##                                      ##
        ##########################################


        # Remove Dupes
        df_syns_synonyms = df_syns_synonyms.select("id_activity", "synonyms").distinct() \
            .withColumn("time_stamp", lit(str(time.time()))) \
            .withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss')) \
            .select(["id_activity", "synonyms", "time_stamp", col("date_stamp").cast(TimestampType())])

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the input data to ensure it is proper.")

    return df_syns_synonyms

def test_2_step_synonyms():
    expected_results = [Row(synonyms='tight'), Row(synonyms='fli'), Row(synonyms='quickly'), Row(synonyms='instigate'), Row(synonyms='cue'), Row(synonyms='strong'), Row(synonyms='propel'), Row(synonyms='fast'), Row(synonyms='tender'), Row(synonyms='straight'), Row(synonyms='immedi'), Row(synonyms='speedy'), Row(synonyms='spri'), Row(synonyms='debauched'), Row(synonyms='fasting'), Row(synonyms='instantly'), Row(synonyms='remind'), Row(synonyms='affectionate'), Row(synonyms='warm'), Row(synonyms='move'), Row(synonyms='promptly'), Row(synonyms='like_a_shot'), Row(synonyms='forthwith'), Row(synonyms='profligate'), Row(synonyms='degraded'), Row(synonyms='spry'), Row(synonyms='truehearted'), Row(synonyms='nimbl'), Row(synonyms='warmly'), Row(synonyms='agile'), Row(synonyms='riotous'), Row(synonyms='quick'), Row(synonyms='straightaway'), Row(synonyms='right_away'), Row(synonyms='command_prompt'), Row(synonyms='nimble'), Row(synonyms='ardent'), Row(synonyms='agil'), Row(synonyms='immediate'), Row(synonyms='at_once'), Row(synonyms='prompting'), Row(synonyms='directly'), Row(synonyms='now'), Row(synonyms='immobile'), Row(synonyms='straight_off'), Row(synonyms='motivate'), Row(synonyms='immediately'), Row(synonyms='dissipated'), Row(synonyms='actuate'), Row(synonyms='inspire'), Row(synonyms='prompt'), Row(synonyms='dissolute'), Row(synonyms='firm'), Row(synonyms='speedi'), Row(synonyms='flying'), Row(synonyms='degenerate'), Row(synonyms='libertine'), Row(synonyms='loyal'), Row(synonyms='lovesome'), Row(synonyms='readi'), Row(synonyms='fond'), Row(synonyms='ready'), Row(synonyms='warm_up'), Row(synonyms='incite')]
    
    results = get_synonyms(prepare_data()).select('synonyms').collect()
    
    assert  results == expected_results


pytestmark = pytest.mark.usefixtures("spark_context")


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


if __name__ == '__main__':
    unittest.main()
    #log = get_logger()
    #df_prepared_data = get_synonyms(prepare_data())
    #log.info(df_prepared_data.select('synonyms').collect())
