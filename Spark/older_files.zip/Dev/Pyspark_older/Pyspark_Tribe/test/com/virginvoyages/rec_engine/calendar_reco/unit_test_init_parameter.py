import pytest
from pyspark.sql import SparkSession
import logging

from query_driver_process import Driver_Process


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    global driver_process_dictionary, config_properties_value
    driver_process_object = Driver_Process(spark,get_logger())
    driver_process_dictionary = driver_process_object.get_driver_process_data()
    config_properties_value = driver_process_object.get_config_properties_value()
    request.addfinalizer(lambda: spark.stop())
    return spark


def get_logger():
    log = logging.getLogger('Spark')
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
    log.addHandler(_h)
    log.setLevel(logging.DEBUG)
    log.info("module imported and logger initialized")
    return log


pytestmark = pytest.mark.usefixtures("spark_context")


################################
##    Test Activity Script    ##
################################

# 1 Total Rows in Table
def test_table_count_is_34():
    assert len(driver_process_dictionary) == 34


# 2 input_location value
def test_activity_synonyms_input_location_table_value():
    assert driver_process_dictionary.get("ActivitySynonyms", "input_location") == config_properties_value\
        .get("ActivitySynonyms", "activity_synonyms_input_location")


# 3 input_location type
def test_activity_synonyms_input_location_table_type():
    assert isinstance(driver_process_dictionary.get("input_location"), basestring)


# 4 path_activity_synonyms value
def test_path_activity_synonyms_value():
    assert driver_process_dictionary.get("path_activity_synonyms") == config_properties_value\
        .get("ActivitySynonyms", "path_activity_synonyms")

# 5 path_activity_synonyms type
def test_path_activity_synonyms_type():
    assert isinstance(driver_process_dictionary.get("path_activity_synonyms"), basestring)


# 6 path_activity_synonyms value
def test_path_activity_synonyms_staging_value():
    assert driver_process_dictionary.get("path_activity_synonyms_staging") == config_properties_value\
        .get("ActivitySynonyms", "path_activity_synonyms_staging")

# 7 path_activity_synonyms type
def test_path_activity_synonyms_staging_type():
    assert isinstance(driver_process_dictionary.get("path_activity_synonyms_staging"), basestring)


##############################
##    Test Sailor Script    ##
##############################


# 8 input_location value
def test_sailor_synonyms_input_location_table_value():
    assert driver_process_dictionary.get("SailorSynonyms", "input_location") == config_properties_value\
        .get("SailorSynonyms", "sailor_synonym_input_location")


# 9 input_location type
def test_sailor_synonyms_input_location_table_type():
    assert isinstance(driver_process_dictionary.get("input_location"), basestring)


# 10 path_activity_synonyms values
def test_path_sailor_synonyms_value():
    assert driver_process_dictionary.get("path_sailor_synonyms") == config_properties_value\
        .get("SailorSynonyms", "path_sailor_synonyms")


# 11 path_activity_synonyms type
def test_path_sailor_synonyms_type():
    assert isinstance(driver_process_dictionary.get("path_sailor_synonyms"), basestring)


# 12 path_activity_synonyms value
def test_path_sailor_synonyms_staging_value():
    assert driver_process_dictionary.get("path_sailor_synonyms_staging") == config_properties_value\
        .get("ActivitySynonyms", "path_activity_synonyms_staging")


# 13 path_activity_synonyms type
def test_path_sailor_synonyms_staging_type():
    assert isinstance(driver_process_dictionary.get("path_sailor_synonyms_staging"), basestring)


####################################
##    Test Match Scores Script    ##
####################################


# 14 input_location value
def test_activity_synonyms_location_table_value():
    assert driver_process_dictionary.get("activity_synonyms_location") == config_properties_value\
        .get("MatchScores", "activity_synonyms_location")


# 15 input_location type
def test_activity_synonyms_location_table_type():
    assert isinstance(driver_process_dictionary.get("activity_synonyms_location"), basestring)


# 16 path_activity_synonyms value
def test_sailor_synonyms_location_table_value():
    assert driver_process_dictionary.get("sailor_synonyms_location") == config_properties_value\
        .get("MatchScores", "sailor_synonyms_location")


# 17 path_activity_synonyms type
def test_sailor_synonyms_location_table_type():
    assert isinstance(driver_process_dictionary.get("sailor_synonyms_location"), basestring)


# 18 path_activity_synonyms value
def test_activity_synonyms_fields_value():
    assert driver_process_dictionary.get("activity_synonyms_fields") == config_properties_value\
        .get("MatchScores", "activity_synonyms_fields")


# 19 path_activity_synonyms type
def test_activity_synonyms_fields_type():
    assert isinstance(driver_process_dictionary.get("activity_synonyms_fields"), basestring)


# 20 path_activity_synonyms value
def test_sailor_synonyms_fields_value():
    assert driver_process_dictionary.get("sailor_synonyms_fields") == config_properties_value\
        .get("MatchScores", "sailor_synonyms_fields")


# 21 path_activity_synonyms type
def test_sailor_synonyms_fields_type():
    assert isinstance(driver_process_dictionary.get("sailor_synonyms_fields"), basestring)


# 22 path_activity_synonyms value
def test_path_match_scores_value():
    assert driver_process_dictionary.get("path_match_scores") == config_properties_value\
        .get("MatchScores", "path_match_scores")


# 23 path_activity_synonyms type
def test_path_match_scores_type():
    assert isinstance(driver_process_dictionary.get("path_match_scores"), basestring)


# 24 path_activity_synonyms value
def test_path_match_scores_staging_value():
    assert driver_process_dictionary.get("path_match_scores_staging") == config_properties_value\
        .get("MatchScores", "path_match_scores_staging")


# 25 path_activity_synonyms type
def test_path_match_scores_staging_type():
    assert isinstance(driver_process_dictionary.get("path_match_scores_staging"), basestring)
