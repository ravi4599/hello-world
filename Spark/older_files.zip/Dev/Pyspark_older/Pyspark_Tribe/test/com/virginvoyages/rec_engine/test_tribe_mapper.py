import unittest

import pytest
from pyspark.sql import SparkSession

from src.com.virginvoyages.rec_engine.tribe.tribeMapper import loadProcessDriver, initProcess


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


pytestmark = pytest.mark.usefixtures("spark_context")


def test_table_count(spark_context):
    try:
        processController = loadProcessDriver(spark_context)
        tribeSeg = initProcess(processController)
        tribeSeg.take(1)
    except Exception:
        raise AssertionError("Query raised ExceptionType unexpectedly!")


if __name__ == '__main__':
    unittest.main()
