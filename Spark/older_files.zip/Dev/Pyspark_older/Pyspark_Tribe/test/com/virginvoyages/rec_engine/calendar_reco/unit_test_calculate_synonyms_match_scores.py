import unittest

import pytest

import os, sys, time, datetime, traceback, re
sys.path.insert(0, "/usr/lib/spark/python/lib")
sys.path.insert(0, "/usr/lib/spark/python/")
import pyspark
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import col, lit, from_unixtime, concat, collect_list, regexp_replace, split
from pyspark.sql.types import *


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .getOrCreate()


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


process_driver = "vv_db.processdriver"
id_seaware = "id_seaware"
data_science_col_1 = "probability"
data_science_col_2 = "rev_per_act"
data_science_col_3 = "rev_scores"
data_science_col_4 = "aff_rev_new_rank"


def get_match_scores():
    """ For each sailor and for each activity, count how many synonyms match between vv_synonyms_sailor_affinities
    and vv_synonyms_activity_affinities. Then transform the data into a JSON in the format of :
    [sailor_1, {"seawareid": [{"activityid":1, "score":10}, ...].

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param database             : which database to use when executing match_scores_query
    :return                     : Spark Dataframe with columns : [id_seaware, activity_sailor_scores, time_stamp,
                                  date_stamp, probability, rev_per_act, rev_scores, aff_rev_new_rank].
                                  id_seaware is the sailor's id, activity_sailor_scores is the formatted JSON,
                                  time_stamp and date_stamp are time/date stamps, respectively, etc...
    """

    df_sail = spark.sparkContext.parallelize([(1, "gourmet"), (1, "foodie"), (1, "epicure"), (1, "cook"), (1, "make"), (1, "fix"), (1, "prepare"), (1, "travel"), (2, "taste"), (2, "cook"), (2, "make"), (2, "prepare"), (2, "travel")]).toDF(["id_seaware", "synonyms"])
    df_sail.registerTempTable("tmp_tbl_sail")
    
    
    df_act = spark.sparkContext.parallelize([(1, "gourmet"), (1, "foodie"), (2, "cook"), (2, "make"), (2, "prepare"), (3, "travel")]).toDF(["id_activity", "synonyms"])
    df_act.registerTempTable("tmp_tbl_act")
    
    
    match_scores_query = "SELECT id_seaware, id_activity, count(synonyms) as activity_nlp_scores \
         FROM ( \
           SELECT df_sail.id_seaware, df_sail.synonyms, id_activity \
           FROM ( \
             SELECT id_seaware, synonyms \
             FROM tmp_tbl_sail \
             ) df_sail \
           JOIN ( \
             SELECT id_activity, synonyms \
             FROM tmp_tbl_act \
             ) df_act \
           WHERE df_sail.synonyms IN (df_act.synonyms) \
           ) b \
         GROUP BY id_seaware, id_activity"

    df_matches = spark.sql(match_scores_query)

    return df_matches


def test_get_match_scores():

    # No Duplicates?
    assert len(get_match_scores().collect()) == len(set(get_match_scores().collect()))


def format_match_scores(df_matches):
    """ For each sailor and for each activity, count how many synonyms match between vv_synonyms_sailor_affinities
    and vv_synonyms_activity_affinities. Then transform the data into a JSON in the format of :
    [sailor_1, {"seawareid": [{"activityid":1, "score":10}, ...].

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param database             : which database to use when executing match_scores_query
    :return                     : Spark Dataframe with columns : [id_seaware, activity_sailor_scores, time_stamp,
                                  date_stamp, probability, rev_per_act, rev_scores, aff_rev_new_rank].
                                  id_seaware is the sailor's id, activity_sailor_scores is the formatted JSON,
                                  time_stamp and date_stamp are time/date stamps, respectively, etc...
    """

    # Creates output in the form: [sailor_1, {"seawareid": [{"activityid":1, "score":10}, ...]
    df_json_w_timestamps = df_matches.orderBy(col("activity_nlp_scores").desc()) \
        .coalesce(1) \
        .select(col(id_seaware),
                concat(
                    lit("{\"activityid\":"),
                    df_matches.id_activity,
                    lit(", \"score\":"),
                    df_matches.activity_nlp_scores,
                    lit("}")
                ).alias('tmp_activity_sailor_scores')) \
        .groupby(col(id_seaware)) \
        .agg(collect_list("tmp_activity_sailor_scores").cast(StringType()).alias("test")) \
        .withColumn("reg_ex_1", regexp_replace(col("test"), "\[\{\"", "{\"seawareid\": [{\"")) \
        .withColumn("activity_sailor_scores", regexp_replace(col("reg_ex_1"), "\}\]", "}]}")) \
        .drop(col("test")) \
        .drop(col("reg_ex_1")) \
        .withColumn("time_stamp", lit(str(time.time()))) \
        .withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss').cast(TimestampType())) \
        .withColumn(data_science_col_1, lit(str(1.0))) \
        .withColumn(data_science_col_2, lit(str(1.0))) \
        .withColumn(data_science_col_3, lit(str(1.0))) \
        .withColumn(data_science_col_4, lit(str(1.0)))

    return df_json_w_timestamps


def test_format_match_scores():
    expected_results = [Row(activity_sailor_scores='{"seawareid": [{"activityid":2, "score":3},{"activityid":1, "score":2},{"activityid":3, "score":1}]}'), Row(activity_sailor_scores='{"seawareid": [{"activityid":2, "score":3},{"activityid":3, "score":1}]}')]

    # expected results?
    assert format_match_scores(get_match_scores()).select("activity_sailor_scores").collect() == expected_results
    
    # In order?
    str_test = str(format_match_scores(get_match_scores()).select("activity_sailor_scores").withColumn('a', regexp_replace(col('activity_sailor_scores'), '[^0-9,]+', '')).withColumn('b', split(col('a'), ',')).collect())
    
    f = []
    for item in str_test:
        f.append(re.sub('[^0-9,]', '', item))
    h = f[0].split(',')[1::2]
    g = f[1].split(',')[1::2]

    assert h == sorted(h, reverse=True)
    assert g == sorted(g, reverse=True)


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()

