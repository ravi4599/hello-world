#####################################
#                                   #
# Inputs:                           #
#   3rd Party Datazapp Data         #
#      Format:                      #
#         id_seaware  :STRING       #
#         attr1       :STRING       #
#         attr2       :STRING       #
#          ..         :...          #
#         attr160     :STRING       #
#                                   #
#                                   #
# Spark Submit Script:              #
#   spark-submit --name             #
# Calculate_sailor_synonyms         #
# --num-executors 4                 #
# --executor-memory 4G              #
# --driver-memory 4G                #
# --executor-cores 8                #
# --master yarn                     #
# --deploy-mode cluster             #
# /tmp/py_scripts/calculate_        #
# synonyms_sailor_data.py           #
#                                   #
#####################################

from pyspark.sql.functions import col, explode, lit, regexp_replace, array, struct, split
from pyspark.sql import SparkSession

import traceback, logging, time


seconds_in_day = 86400  # Seconds in a day
days = 7 # How many days are we getting from the Feedback and History Tables?

spark = SparkSession.builder \
    .appName("Feedback Loop") \
    .enableHiveSupport() \
    .getOrCreate()
spark.conf.set("spark.sql.shuffle.partitions", "50")


##########################
#                        #
#    Define Functions    #
#                        #
##########################


def to_long(df, by):
    # Filter dtypes and split into column names and type description
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in by))
    # Spark SQL supports only homogeneous columns
    assert len(set(dtypes)) == 1, "All columns have to be of the same type"

    # Create and explode an array of (column_name, column_value) structs
    kvs = explode(array([
        struct(lit(c).alias("key"), col(c).alias("val")) for c in cols
    ])).alias("kvs")

    return df.select(by + [kvs]).select(by + ["kvs.key", "kvs.val"])


def feedback_loop(log, spark, hbase_ip, attributes, input_location):
    """ Read the sailor ids and nbxKeys from the Sailor Feedback Table. This will tell us which activities a sailor
    has booked. We must also take the Sailor Recommendation History Table into account. We get which activities these
    sailor's have booked and their descriptions (which we will use as affinities). We then join the Feedback Table to
    the Recommendation History Table (based on nbxKeys) to find which which activities were booked by which sailors.
    We finally join that data to the Datazapp Data.

    :param log              : logger, used for logging execution details
    :param spark            : current SparkSession
    :param hbase_ip         : current ip of the hbase tables
    :param input_location   : name of datazapp data table
    :return: df_union_tbl   : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                              affinity is an attribute describing the sailor.
    """

    try:

        ############################################################################################################################################
        ##    Query Feedback Table (Sailor_Feedback) for nbxKey and SailorID based on Timestamp (day? week?)  {SailID_VoyageID_DateTime:nbxKey}   ##
        ############################################################################################################################################

        log.info("Getting Data from Sailor Feedback Table")
        df_feedback_table = spark.read \
            .format("org.apache.phoenix.spark") \
            .option("table", "SAILOR_FEEDBACK") \
            .option("zkUrl", hbase_ip) \
            .load()

        log.info("Get only the Booked Activities from within the past week.")
        df_feedback_table2 = df_feedback_table \
            .where((col("STATUS") == "Booked") & (col("LAST_UPDATE_TIMESTAMP") > (time.time()-(days*seconds_in_day))))

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 2: Please review the hbase table or the hbase connection to the Sailor Feedback Table.")


        ################################################################
        ##    Parse out nbxKey(s) () and SailorID    {SailID:nbxKey}  ##
        ################################################################
    try:

        log.info("Parse out nbxKeys and SailorIDs.")
        df_feedback_table3 = df_feedback_table2 \
            .withColumn("id_seaware", split(df_feedback_table2.SAILORID_VOYAGEID_DATETIME, "_").getItem(0)) \
            .withColumn("NBXUNIQUEKEY", explode(split(df_feedback_table2.NBXUNIQUEKEY, "\|"))) \
            .select("id_seaware", "NBXUNIQUEKEY")


        #############################################################################################################################
        ##    Query HBase History Table (Sailor_Recommendations_History) for Activity ID/Name based on nbxKey  {nbx:ActID/Name}    ##
        #############################################################################################################################

        log.info("Getting Data from Sailor Recommendations History Table.")
        df_history_table = spark.read \
            .format("org.apache.phoenix.spark") \
            .option("table", "SAILOR_RECOMMENDATIONS_HISTORY") \
            .option("zkUrl", hbase_ip) \
            .load()

        df_history_table = df_history_table.select(col("NBXUNIQUEKEY"), col("DESCRIPTION")) \
            .withColumnRenamed("DESCRIPTION", "Affinity")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the hbase table or the hbase connection to the Sailor Recommendations Table.")


        # ######################################################################
        # ##    Join/Union Feedback w/ History on nbxKey  {SailID:ActName}    ##
        # ######################################################################
    try:
        log.info("Joining the Feedback and History Tables based on nbxKeys")
        df_sails_acts = df_history_table.join(df_feedback_table3, "NBXUNIQUEKEY") \
            .drop("NBXUNIQUEKEY") \
            .drop("ACTIVITYID") \
            .select("id_seaware", "Affinity")


        #################################
        ##    Reading DataZapp Data    ##
        #################################

        log.info("Reading Datazapp Data.")
        data = spark.sql("select {} from {} where sequence is not null".format(attributes, input_location))

        data = data.na.fill(0, data.columns[1:])
        data_transpose = to_long(data, ["id_seaware"])
        data_transpose_n = data_transpose.where(data_transpose.val == 1)
        df_sailor_affinities = data_transpose_n \
            .select("id_seaware", (regexp_replace(col("key"), "_", " ")).alias("Affinity"))


        #######################################################
        ##    Union Difference of above and Datazapp Data    ##
        #######################################################
        log.info("Unioning Joined Table with Datazapp Data.")
        df_union_tbl = df_sailor_affinities.union(df_sails_acts.subtract(df_sailor_affinities))


    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 2: Please review the input data to ensure it is proper.")

    return df_union_tbl


def initSparkSession(appName):
    """ Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """ Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='FeedbackLoop'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """ Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        hbase_ip = processController.get("hbase_ip")
        attributes = processController.get("attributes")
        input_location = processController.get("input_location")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (input_location_test|hbase_ip|attributes)")

    return process(log, spark, hbase_ip, attributes, input_location)


def process(log, spark, hbase_ip, attributes, input_location):
    """ Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting Feedback Loop...")
    return feedback_loop(log, spark, hbase_ip, attributes, input_location)


def store(processController, log, feedback):
    """ Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param feedback             : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    try:
        path_core = processController.get("path_feedback_loop")
        path_staging = processController.get("path_feedback_loop_staging")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")

    try:
        log.info("Save the results in hive as %s" % path_core)
        feedback.write.mode('overwrite').format("parquet").save(path_core)

        # log.info("Save the results in hive as %s" % path_staging)
        # feedback.write.mode('overwrite').format("parquet").save(path_staging)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}|{}) ".format(path_core, path_staging))


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Feedback Loop")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    feedback = initProcess(spark, processController, log)
    # store(processController, log, feedback)
    stopSparkSession(log, spark)


###############################################
#                                             #
# Outputs:                                    #
#    Intermediate Table:                      #
#                                             #
#       vv_db.vv_synonyms_sailor_affinities   #
#          Format:                            #
#             id_seaware        :STRING       #
#             sailor_synonyms   :STRING       #
#             time_stamp        :STRING       #
#             date_stamp        :TIMESTAMP    #
#                                             #
###############################################

