import logging

from pyspark.sql import SparkSession
import sys, traceback


def query_process_table(spark, log, db_name):
    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='TribeSegmentation'".format(db_name)
    log.info(query_string)
    dic = {}
    try:
        out = spark.sql(query_string).collect()
        m = map(lambda x: (x[0], x[1]), out)
        dic = dict(m)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return dic


def get_parameters(log, processController):
    selectedVar = processController.get("selectedVar").split("~")
    selectExpr = list(
        map(lambda x: "cast(case when " + x + " is NULL then 0 else " + x + " end as float) as " + x, selectedVar))
    try:
        queryTable = processController.get("qryTable")
        distillTable = processController.get("distillTable")
        gIncome = processController.get("gIncome")
        ageLow = int(processController.get("ageLow"))
        ageHigh = int(processController.get("ageHigh"))
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please verify driver variable initialization (qryTable|distillTable|gIncome|ageLow) ")
    return (selectExpr, queryTable, gIncome, ageLow, ageHigh, distillTable)


def create_temp_veiw_on_process_table(spark, log, processControllerDF):
    log.info("Fetch Parameters from Processor Driver")
    parameters = get_parameters(log, processControllerDF)
    sql_query = "select %s from %s where gincome not in %s AND age_txt BETWEEN %s And %s" % (
        ','.join(parameters[0]), parameters[1], parameters[2], parameters[3], parameters[4])
    log.info(sql_query)
    customerData = spark.sql(sql_query)
    log.info("Create Temp View for Customer Data")
    customerData.createOrReplaceTempView("customerData")
    return parameters[5]


def query_processor(spark, log, db_name):
    log.info("Running Query Processor")
    processControllerDF = query_process_table(spark, log, db_name)
    distillTable = create_temp_veiw_on_process_table(spark, log, processControllerDF)
    return (processControllerDF, distillTable)


def get_logger():
    log = logging.getLogger('Spark')
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
    log.addHandler(_h)
    log.setLevel(logging.DEBUG)
    log.info("module imported and logger initialized")
    return log


def store(distillTable_path, spark, log):
    log.info("Save the results in hive as %s" % distillTable_path)
    tribeSeg=spark.sql("select * from customerData")
    tribeSeg.show()
    tribeSeg.write.mode('overwrite').format("parquet").save(distillTable_path)


def stopSparkSession(spark, log):
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = SparkSession.builder.appName("TribeSegmentation_DataPrep").enableHiveSupport().getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", "50")
    log = get_logger()
    processController = query_processor(spark, log, "vv_db.processdriver")
    distillTable = processController[1]
    store(distillTable,spark, log)
    stopSparkSession(spark, log)
