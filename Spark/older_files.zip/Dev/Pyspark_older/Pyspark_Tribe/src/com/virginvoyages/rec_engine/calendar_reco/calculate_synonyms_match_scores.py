###############################################
#                                             #
# Inputs:                                     #
#    Intermediate Table:                      #
#       vv_db.vv_sailor_affinity_synonyms     #
#          Format:                            #
#             id_seaware        :STRING       #
#             sailor_synonyms   :STRING       #
#                                             #
#    Intermediate Table:                      #
#       vv_db.vv_activity_affinity_synonyms   #
#          Format:                            #
#             id_activity           :STRING   #
#             activity_synonyms     :STRING   #
#                                             #
# Spark Submit Script:                        #
#   spark-submit                              #
# --name Calculate_match_scores               #
# --num-executors 4 --executor-memory 4G      #
# --driver-memory 4G --executor-cores 8       #
# --master yarn --deploy-mode cluster         #
# /tmp/py_scripts/calculate_synonyms_         #
# match_scores.py                             #
#                                             #
###############################################

from pyspark.sql.functions import col, lit, from_unixtime, concat, collect_list, regexp_replace, round
from pyspark.sql.types import *
from pyspark.sql import SparkSession

import time, traceback, logging

spark = SparkSession \
    .builder \
    .appName("Calculate_Synonym_match_scores") \
    .enableHiveSupport() \
    .getOrCreate()

process_driver = "vv_db.processdriver"
id_seaware = "id_seaware"
data_science_col_1 = "probability"
data_science_col_2 = "rev_per_act"
data_science_col_3 = "rev_scores"
data_science_col_4 = "aff_rev_new_rank"


def get_match_scores(log, spark, database, path_activities, path_feedback, match_scores_query):
    """ For each sailor and for each activity, count how many synonyms match between vv_synonyms_sailor_affinities
    and vv_synonyms_activity_affinities. Then transform the data into a JSON in the format of :
    [sailor_1, {"seawareid": [{"activityid":1, "score":10}, ...].

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param database             : which database to use when executing match_scores_query
    :param match_scores_query   : HQL query to count synonym matches
    :return                     : Spark Dataframe with columns : [id_seaware, activity_sailor_scores, time_stamp,
                                  date_stamp, probability, rev_per_act, rev_scores, aff_rev_new_rank].
                                  id_seaware is the sailor's id, activity_sailor_scores is the formatted JSON,
                                  time_stamp and date_stamp are time/date stamps, respectively, etc...
    """

    try:
        log.info("Execute query to get match-scores...")

        spark.sql("use {}".format(database))

        df_activity = spark.read.parquet(path_activities)
        df_feedback = spark.read.parquet(path_feedback)

        df_activity = spark.sql("select id_activity,synonyms from vv_db.vv_synonyms_activity_affinities")
        df_feedback = spark.sql("select id_activity,synonyms from vv_db.vv_synonyms_feedback")

        df_pre_recommendation_list = df_feedback\
            .join(df_activity, 'synonyms', 'inner')\
            .select(["sequence", "id_activity", "synonyms",round("UpdatedWeightPercentages", 4).alias("UpdatedWeightPercentages")])

        df_updated_recommendation_list = df_pre_recommendation_list\
            .groupby(["sequence", "id_activity"])\
            .agg({"UpdatedWeightPercentages": "sum"})\
            .withColumnRenamed("sum(UpdatedWeightPercentages)", "TotalUpdatedWeightPercentages")\
            .select(["sequence", "id_activity", round("TotalUpdatedWeightPercentages", 4).alias("TotalUpdatedWeightPercentages")])

        # # match_scores_querty is as follows:
        # #"SELECT id_seaware, id_activity, count(synonyms) as activity_nlp_scores
        # #     FROM ( \
        # #       SELECT df_sail.id_seaware, df_sail.synonyms, id_activity \
        # #       FROM ( \
        # #         SELECT id_seaware, synonyms \
        # #         FROM vv_synonyms_sailor_affinities \
        # #         ) df_sail \
        # #       JOIN ( \
        # #         SELECT id_activity, synonyms \
        # #         FROM vv_synonyms_activity_affinities \
        # #         ) df_act \
        # #       WHERE df_sail.synonyms IN (df_act.synonyms) \
        # #       ) b \
        # #     GROUP BY id_seaware, id_activity"
        # df_matches = spark.sql(match_scores_query)


        # Creates output in the form: [sailor_1, {"seawareid": [{"activityid":1, "score":10}, ...]

        df_json_w_timestamps = df_updated_recommendation_list.orderBy(col("TotalUpdatedWeightPercentages").desc()) \
            .coalesce(1) \
            .select(col(id_seaware),
                    concat(
                        lit("{\"activityid\":"),
                        df_matches.id_activity,
                        lit(", \"score\":"),
                        df_matches.activity_nlp_scores,
                        lit("}")
                    ).alias('tmp_activity_sailor_scores')) \
            .groupby(id_seaware) \
            .agg(collect_list("tmp_activity_sailor_scores").cast(StringType()).alias("test")) \
            .withColumn("reg_ex_1", regexp_replace(col("test"), "\[\{\"", "{\"seawareid\": [{\"")) \
            .withColumn("activity_sailor_scores", regexp_replace(col("reg_ex_1"), "\}\]", "}]}")) \
            .drop(col("test")) \
            .drop(col("reg_ex_1")) \
            .withColumn("time_stamp", lit(str(time.time()))) \
            .withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss').cast(TimestampType())) \
            .withColumn(data_science_col_1, lit(str(1.0))) \
            .withColumn(data_science_col_2, lit(str(1.0))) \
            .withColumn(data_science_col_3, lit(str(1.0))) \
            .withColumn(data_science_col_4, lit(str(1.0)))

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please verify database and/or match_scores_query")

    log.info("Return Dataframe")
    return df_json_w_timestamps


def initSparkSession(appName):
    """ Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """ Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='MatchScores'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, log, processController):
    """ Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, activity_sailor_scores, time_stamp,
                                  date_stamp, probability, rev_per_act, rev_scores, aff_rev_new_rank].
                                  id_seaware is the sailor's id, activity_sailor_scores is the formatted JSON,
                                  time_stamp and date_stamp are time/date stamps, respectively, etc...
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        database = processController.get("database")
        path_activities = processController.get("path_activities")
        path_feedback = processController.get("path_feedback")
        match_scores_query = processController.get("match_scores_query")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization: (database|match_scores_query)")

    return process(log, spark, database, path_activities, path_feedback, match_scores_query)


def process(log, spark, database, path_activities, path_feedback, match_scores_query):
    """ Runs get_match_scores function

    :param log                  : current logger
    :param spark                : current SparkSession
    :param database             : which database to use when executing match_scores_query
    :param match_scores_query   : HQL query to count synonym matches
    :return                     : Spark Dataframe with columns : [id_seaware, activity_sailor_scores, time_stamp,
                                  date_stamp, probability, rev_per_act, rev_scores, aff_rev_new_rank].
                                  id_seaware is the sailor's id, activity_sailor_scores is the formatted JSON,
                                  time_stamp and date_stamp are time/date stamps, respectively, etc...
    """

    log.info("Get Match Scores...")
    return get_match_scores(log, spark, database, path_activities, path_feedback, match_scores_query)


def store(processController, log, match_scores):
    """ Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param match_scores         : Spark Dataframe with columns : [id_seaware, activity_sailor_scores, time_stamp,
                                  date_stamp, probability, rev_per_act, rev_scores, aff_rev_new_rank].
                                  id_seaware is the sailor's id, activity_sailor_scores is the formatted JSON,
                                  time_stamp and date_stamp are time/date stamps, respectively, etc...
    :return                     : N/A
    """
    try:
        path_core = processController.get("path_match_scores")
        path_staging = processController.get("path_match_scores_staging")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")

    try:
        log.info("Save the results in hive as %s" % path_core)
        match_scores.write.mode('overwrite').format("parquet").save(path_core)

        log.info("Save the results in hive as %s" % path_staging)
        match_scores.write.mode('overwrite').format("parquet").save(path_staging)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}|{}) ".format(path_core, path_staging))


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calculate_Match_Scores")
    log = get_logger()
    processController = loadProcessDriver(spark, log, process_driver)
    match_scores = initProcess(spark, log, processController)
    store(processController, log, match_scores)
    stopSparkSession(log, spark)


####################################################
#                                                  #
# Outputs:                                         #
#    Intermediate Table:                           #
#       vv_db.vv_synonyms_match_scores             #
#          Format:                                 #
#             id_seaware              :STRING      #
#             activity_sailor_scores  :STRING      #
#             time_stamp              :STRING      #
#             date_stamp              :TIMESTAMP   #
#             probability             :STRING      #
#             rev_per_act             :STRING      #
#             rev_scores              :STRING      #
#             aff_rev_new_rank        :STRING      #
#                                                  #
####################################################

