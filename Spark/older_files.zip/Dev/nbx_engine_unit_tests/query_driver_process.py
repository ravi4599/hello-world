import os
import sys
import ConfigParser
sys.path.insert(0, "/usr/lib/spark/python/lib")
sys.path.insert(0, "/usr/lib/spark/python/")
from pyspark.sql import SparkSession



class Driver_Process(object):
    def __init__(self, spark_session, Logger):
        self.spark_session = spark_session
        self.Logger = Logger
    def get_logger(self):
        log4jLogger = self.spark_session.sparkContext._jvm.org.apache.log4j
        return log4jLogger.LogManager.getLogger(__name__)
    def get_driver_process_data(self):
        self.Logger.info("Loading Driver Process data")
        # df = self.spark_session.read.format("csv").option("header", "true").load(
        #     "Pyspark/Pyspark_Tribe/test/driver_process.csv")
        select_query_op = self.spark_session.sql("select VariableName,Value from vv_db.processdriver")
        # df.createOrReplaceTempView("Driver")
        # select_query_op = self.spark_session.sql("select VariableName,Value from Driver")
        # out = select_query_op.collect()
        out = select_query_op.collect()
        dic = {}
        m = map(lambda x: (x[0], x[1]), out)
        dic = dict(m)
        return dic
    def get_config_properties_value(self):
        config = ConfigParser.RawConfigParser()
        properties = "/home/ec2-user/py_scripts/tests/ConfigFile.properties"
        # properties = "Pyspark/Pyspark_Tribe/test/ConfigFile.properties"
        self.Logger.info("Reading Properties : %s  " % properties)
        config.read(properties)
        return config