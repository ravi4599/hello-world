import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .getOrCreate()


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1").collect()

    assert prepared_data is not None


# 2 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Apriori'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    brand_details = processController.get("brand_details")
    attribute_mapping = processController.get("attribute_mapping")
    attribute_mapping_old = processController.get("attribute_mapping_old")
    attribute_mapping_May17 = processController.get("attribute_mapping_May17")
    tweets_data_query = processController.get("tweets_data_query")
    minSupport = processController.get("minSupport")
    minConfidence = processController.get("minConfidence")
    path_apriori = processController.get("path_apriori")
    path_apriori_staging = processController.get("path_apriori_staging")
    check_tbl_exists = processController.get("check_tbl_exists")
    drop_table_sql = processController.get("drop_table_sql")
    create_table_sql = processController.get("create_table_sql")
    gnip_data = processController.get("gnip_data")

    assert brand_details == "s3a://vv-dev-emr-cluster/data/staging/social-media/twitter/bd_db/gnip_tribe_brand_details/"
    assert attribute_mapping == "s3a://vv-dev-emr-cluster/data/twitter/axiom_master_mapping_sample.csv"
    assert attribute_mapping_old == "s3a://vv-dev-emr-cluster/data/twitter/tribe_subtribe_and_affinity_master_list_v3.csv"
    assert attribute_mapping_May17 == "s3a://vv-dev-emr-cluster/data/twitter/MasterAcxiomMapping_May17.csv"
    assert tweets_data_query == "select id AS id_seaware,topics_list AS Keywords from ds_db.my_tweetsDataDF_exploded"
    assert minSupport == "0.02"
    assert minConfidence == "0.2"
    assert path_apriori == "s3a://vv-dev-emr-cluster/data/core/gnip_apriori"
    assert path_apriori_staging == "s3a://vv-dev-emr-cluster/data/staging/gnip_apriori"
    assert check_tbl_exists == "select * from vv_db.gnip_apriori LIMIT 1"
    assert drop_table_sql == "drop table IF EXISTS vv_db.gnip_apriori"
    assert create_table_sql == "CREATE EXTERNAL TABLE IF NOT EXISTS vv_db.gnip_apriori(antecedent_exp string, consequent array<string>, confidence double) STORED AS PARQUET LOCATION '{}'"
    assert gnip_data == "select displayname, favoritescount, followerscount, friendscount, id, languages, listedcount, actor_location_displayname, preferredusername, statusescount, twittertimezone, body, generator_displayname, generator_link, klout_user_id, klout_score, topics_displayname, topics_id, topics_link, topics_score, topic_type, country, countrycode, profilelocations_locality, region, profilelocations_subregion, profilelocation_displayname, profilelocation_coordinates, load_data_timestamp, epoch, year, month, day, brand_name, filename from bd_db.stg_gnip_brand_tweets_feb18_new"


# 3 Test Read Write from S3
def test_read_and_write_to_s3():
    test_save_loc = "s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv"
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite")\
        .csv(test_save_loc)

    prepared_data = spark.read.csv(test_save_loc)
    assert prepared_data.collect() is not None


# 4 Test Brand Details File Exists
def test_brand_details_file_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Apriori'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    brand_details = processController.get("brand_details")
    df_brand_details = spark.read.option("header", "true").csv(brand_details).limit(1)
    assert df_brand_details.collect() is not None


# 5 Test GNIP Data Table Exists
def test_gnip_data_table_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Apriori'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    gnip_data = processController.get("gnip_data")
    df_twitter_data = spark.sql(gnip_data).limit(1)
    assert df_twitter_data.collect() is not None


# 6 Test Attribute Mappling List Exists
def test_attribute_mapping_list_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Apriori'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    attribute_mapping = processController.get("attribute_mapping")
    df_attrs_list = spark.read.option("header", "True").csv(attribute_mapping).limit(1)
    assert df_attrs_list.collect() is not None


# 7 Test Tweets Data Table Exists
def test_tweets_data_table_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Apriori'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    tweets_data_query = processController.get("tweets_data_query")
    df_attrs_topics = spark.sql(tweets_data_query).limit(1)
    assert df_attrs_topics.collect() is not None


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
