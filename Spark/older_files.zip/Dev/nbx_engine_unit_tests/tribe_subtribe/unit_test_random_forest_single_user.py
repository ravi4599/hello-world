import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession



spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
	.config("spark.jars", "/home/jenkins/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/jenkins/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar,/home/jenkins/phoenix_jars/mysql-connector-java-5.1.45-bin.jar,/home/jenkins/phoenix_jars/phoenix-core-4.11.0-HBase-1.3.jar") \
    .getOrCreate()

@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1").collect()
    assert prepared_data is not None


# 2 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='RandomForest'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    random_forest_hbase_table = processController.get("random_forest_hbase_table")
    hbase_ip = processController.get("hbase_ip")
    bootstrap_servers = processController.get("bootstrap_servers")
    schema_registry_url = processController.get("schema_registry_url")
    topic = processController.get("topic")
    hbase_reservation_table = processController.get("hbase_reservation_table")

    assert random_forest_hbase_table == "hbtb_nbx_sailor_tribes"
    assert hbase_ip == "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase"
    assert bootstrap_servers == "10.9.100.174:9092,10.9.100.142:9092,10.9.100.37:9092"
    assert schema_registry_url == "http://10.9.100.157:8081/"
    assert topic == "dev-shore-bigdata.tribe-data-refresh-info"
    assert hbase_reservation_table == "HBTB_NBX_SEAWARE_RESERVATION"


# 3 Test Read Write from S3
def test_read_and_write_to_s3():
    test_save_loc = "s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv"
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite").csv(test_save_loc)

    prepared_data = spark.read.csv(test_save_loc)
    assert prepared_data.collect() is not None


# 4 Test HBase Acxiom Reservation Data Exists
def test_hbase_acxiom_reservation_data_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='RandomForest'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    hbase_reservation_table = processController.get("hbase_reservation_table")
    hbase_ip = processController.get("hbase_ip")

    df_acxiom_data = spark.read \
        .format("org.apache.phoenix.spark") \
        .option("table", hbase_reservation_table) \
        .option("zkUrl", hbase_ip) \
        .load()

    assert df_acxiom_data.collect() is not None


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
