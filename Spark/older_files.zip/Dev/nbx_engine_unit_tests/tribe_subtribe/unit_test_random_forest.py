import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")

import pyspark
from pyspark.sql import SparkSession


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .getOrCreate()


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1").collect()
    assert prepared_data is not None


# 2 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='RandomForest'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    gnip_data = processController.get("gnip_data")
    min_max_prob_query = processController.get("min_max_prob_query")
    train_test_split = processController.get("train_test_split")
    seed_split = int(processController.get("seed_split"))
    numTrees = int(processController.get("numTrees"))
    seed_train = int(processController.get("seed_train"))
    prob_inc = float(processController.get("prob_inc"))
    acxiom_query = processController.get("acxiom_query")
    acxiom_query_single_user = processController.get("acxiom_query_single_user")
    input_dict_adv = processController.get("input_dict_Adventure")
    input_dict_mystery = processController.get("input_dict_Mystery")
    input_dict_quirk = processController.get("input_dict_Quirk")
    input_dict_glamorous = processController.get("input_dict_Glamorous")
    input_dict_party = processController.get("input_dict_Party")
    input_dict_chill = processController.get("input_dict_Chill")
    input_dict_cool = processController.get("input_dict_Cool")
    adventure_predictions = processController.get("tribe_predictions_Adventure")
    mystery_predictions = processController.get("tribe_predictions_Mystery")
    quirk_predictions = processController.get("tribe_predictions_Quirk")
    glamorous_predictions = processController.get("tribe_predictions_Glamorous")
    party_predictions = processController.get("tribe_predictions_Party")
    chill_predictions = processController.get("tribe_predictions_Chill")
    cool_predictions = processController.get("tribe_predictions_Cool")
    adventure_score = processController.get("tribe_score_Adventure")
    mystery_score = processController.get("tribe_score_Mystery")
    quirk_score = processController.get("tribe_score_Quirk")
    glamorous_score = processController.get("tribe_score_Glamorous")
    party_score = processController.get("tribe_score_Party")
    chill_score = processController.get("tribe_score_Chill")
    cool_score = processController.get("tribe_score_Cool")
    adventure_predicted_label = processController.get("tribe_predicted_label_Adventure")
    mystery_predicted_label = processController.get("tribe_predicted_label_Mystery")
    quirk_predicted_label = processController.get("tribe_predicted_label_Quirk")
    glamorous_predicted_label = processController.get("tribe_predicted_label_Glamorous")
    party_predicted_label = processController.get("tribe_predicted_label_Party")
    chill_predicted_label = processController.get("tribe_predicted_label_Chill")
    cool_predicted_label = processController.get("tribe_predicted_label_Cool")
    adventure_threshold = float(processController.get("adventure_threshold"))
    mystery_threshold = float(processController.get("mystery_threshold"))
    quirk_threshold = float(processController.get("quirk_threshold"))
    glamorous_threshold = float(processController.get("glamorous_threshold"))
    party_threshold = float(processController.get("party_threshold"))
    chill_threshold = float(processController.get("chill_threshold"))
    cool_threshold = float(processController.get("cool_threshold"))
    adv_min_prob = float(processController.get("adv_min_prob"))
    adv_max_prob = float(processController.get("adv_max_prob"))
    mystery_min_prob = float(processController.get("mystery_min_prob"))
    mystery_max_prob = float(processController.get("mystery_max_prob"))
    quirk_min_prob = float(processController.get("quirk_min_prob"))
    quirk_max_prob = float(processController.get("quirk_max_prob"))
    glamorous_min_prob = float(processController.get("glamorous_min_prob"))
    glamorous_max_prob = float(processController.get("glamorous_max_prob"))
    party_min_prob = float(processController.get("party_min_prob"))
    party_max_prob = float(processController.get("party_max_prob"))
    chill_min_prob = float(processController.get("chill_min_prob"))
    chill_max_prob = float(processController.get("chill_max_prob"))
    cool_min_prob = float(processController.get("cool_min_prob"))
    cool_max_prob = float(processController.get("cool_max_prob"))
    hbase_ip = processController.get("hbase_ip")
    random_forest_hbase_table = processController.get("random_forest_hbase_table")
    path_random_forest = processController.get("path_random_forest")
    path_model = processController.get("path_random_forest_models")
    path_random_forest_metrics_log = processController.get("path_random_forest_metrics_log")
    path_random_forest_metrics = processController.get("path_random_forest_metrics")
    path_random_forest_single_user = processController.get("path_random_forest_single_user")
    check_tbl_exists_rf = processController.get("check_tbl_exists_rf")
    drop_table_query_rf = processController.get("drop_table_query_rf")
    create_table_query_rf = processController.get("create_table_query_rf")
    check_tbl_exists_metrics = processController.get("check_tbl_exists_metrics")
    drop_table_query_metrics = processController.get("drop_table_query_metrics")
    create_table_query_metrics = processController.get("create_table_query_metrics")
    check_tbl_exists_metrics_log = processController.get("check_tbl_exists_metrics_log")
    drop_table_query_metrics_log = processController.get("drop_table_query_metrics_log")
    create_table_query_metrics_log = processController.get("create_table_query_metrics_log")


    assert gnip_data == "select id as klout_user_id, final_subtribe, tweet_count, synonyms_list, subtribe from vv_db.hvtb_nbx_core_gnip_gnipprocessing"
    assert min_max_prob_query == "SELECT Adventure_minProbability, Adventure_maxProbability, Mystery_minProbability, Mystery_maxProbability, Quirk_minProbability, Quirk_maxProbability, Glamorous_minProbability, Glamorous_maxProbability, Party_minProbability, Party_maxProbability, Chill_minProbability, Chill_maxProbability, Cool_minProbability, Cool_maxProbability FROM vv_db.hvtb_nbx_core_subtribe_metrics WHERE `timestamp` == "
    assert train_test_split == "0.6, 0.4"
    assert seed_split == 12345
    assert numTrees == 100
    assert seed_train == 42
    assert prob_inc == 0.01
    assert acxiom_query == "select seaware_id as Sequence,0.0 as label,%s from vv_db.hvtb_nbx_core_sailorattributes_acxiom"
    assert acxiom_query_single_user == "select Sequence,0.0 as label,%s from vv_db.hvtb_nbx_core_subtribe_sailorattributes LIMIT 1"
    assert input_dict_adv == "Glamorous: 0.0, Mystery: 0.0, Adventure: 1.0, Party: 0.0, Chill: 0.0, Cool: 0.0, Quirk: 0.0, Mixed: 0.0"
    assert input_dict_mystery == "Glamorous: 0.0, Mystery: 1.0, Adventure: 0.0, Party: 0.0, Chill: 0.0, Cool: 0.0, Quirk: 0.0, Mixed: 0.0"
    assert input_dict_quirk == "Glamorous: 0.0, Mystery: 0.0, Adventure: 0.0, Party: 0.0, Chill: 0.0, Cool: 0.0, Quirk: 1.0, Mixed: 0.0"
    assert input_dict_glamorous == "Glamorous: 1.0, Mystery: 0.0, Adventure: 0.0, Party: 0.0, Chill: 0.0, Cool: 0.0, Quirk: 0.0, Mixed: 0.0"
    assert input_dict_party == "Glamorous: 0.0, Mystery: 0.0, Adventure: 0.0, Party: 1.0, Chill: 0.0, Cool: 0.0, Quirk: 0.0, Mixed: 0.0"
    assert input_dict_chill == "Glamorous: 0.0, Mystery: 0.0, Adventure: 0.0, Party: 0.0, Chill: 1.0, Cool: 0.0, Quirk: 0.0, Mixed: 0.0"
    assert input_dict_cool == "Glamorous: 0.0, Mystery: 0.0, Adventure: 0.0, Party: 0.0, Chill: 0.0, Cool: 1.0, Quirk: 0.0, Mixed: 0.0"
    assert adventure_predictions == "Adventure_Predictions"
    assert mystery_predictions == "Mystery_Predictions"
    assert quirk_predictions == "Quirk_Predictions"
    assert glamorous_predictions == "Glamorous_Predictions"
    assert party_predictions == "Party_Predictions"
    assert chill_predictions == "Chill_Predictions"
    assert cool_predictions == "Cool_Predictions"
    assert adventure_score == "Adventure_Score"
    assert mystery_score == "Mystery_Score"
    assert quirk_score == "Quirk_Score"
    assert glamorous_score == "Glamorous_Score"
    assert party_score == "Party_Score"
    assert chill_score == "Chill_Score"
    assert cool_score == "Cool_Score"
    assert adventure_predicted_label == "AdvPredictedLabel"
    assert mystery_predicted_label == "MysteryPredictedLabel"
    assert quirk_predicted_label == "QuirkPredictedLabel"
    assert glamorous_predicted_label == "GlamorousPredictedLabel"
    assert party_predicted_label == "PartyPredictedLabel"
    assert chill_predicted_label == "ChillPredictedLabel"
    assert cool_predicted_label == "CoolPredictedLabel"
    assert adventure_threshold == 0.06976958476006985
    assert mystery_threshold == 0.09615796484053135
    assert quirk_threshold == 0.01423082383349538
    assert glamorous_threshold == 0.25
    assert party_threshold == 0.5
    assert chill_threshold == 0.07
    assert cool_threshold == 0.205
    assert adv_min_prob == 0.019769584760069847
    assert adv_max_prob == 0.23420855402946472
    assert mystery_min_prob == 0.03115796484053135
    assert mystery_max_prob == 0.5586455464363098
    assert quirk_min_prob == 0.0042308238334953785
    assert quirk_max_prob == 0.1472902148962021
    assert glamorous_min_prob == 0.11794610321521759
    assert glamorous_max_prob == 0.39169958233833313
    assert party_min_prob == 0.21499747037887573
    assert party_max_prob == 0.5649977922439575
    assert chill_min_prob == 0.007760923821479082
    assert chill_max_prob == 0.17930670082569122
    assert cool_min_prob == 0.09441519528627396
    assert cool_max_prob == 0.3352276086807251
    assert hbase_ip == "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase"
    assert random_forest_hbase_table == "hbtb_nbx_core_sailor_tribes"
    assert path_random_forest == "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/random_forest_classifier"
    assert path_model == "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/"
    assert path_random_forest_metrics_log == "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Metrics_Log"
    assert path_random_forest_metrics == "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Metrics"
    assert path_random_forest_single_user == "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/random_forest_classifier_single"
    assert check_tbl_exists_rf == "select * from vv_db.hvtb_nbx_core_subtribe_sailorclassification LIMIT 1"
    assert drop_table_query_rf == "drop table IF EXISTS vv_db.hvtb_nbx_core_subtribe_sailorclassification"
    assert create_table_query_rf == "CREATE EXTERNAL TABLE IF NOT EXISTS vv_db.hvtb_nbx_core_subtribe_sailorclassification(id string, subtribe string) STORED AS PARQUET LOCATION '{}'"
    assert check_tbl_exists_metrics == "select * from vv_db.hvtb_nbx_core_subtribe_metrics LIMIT 1"
    assert drop_table_query_metrics == "drop table IF EXISTS vv_db.hvtb_nbx_core_subtribe_metrics"
    assert create_table_query_metrics == "CREATE EXTERNAL TABLE IF NOT EXISTS vv_db.hvtb_nbx_core_subtribe_metrics(Adventure_TP int, Adventure_TN int, Adventure_FP int, Adventure_FN int, Adventure_Accuracy double, Adventure_Recall double, Adventure_Precision double, Adventure_F1Score double, Adventure_minScore double, Adventure_maxScore double, Adventure_minProbability double, Adventure_maxProbability double, Adventure_automatedTreshold double, Adventure_manualThreshold double, Adventure_trainRepresentation double, Adventure_testRepresentation double, Adventure_threshold_is_ok boolean, Adventure_AuC double, Adventure_test_split_count int, Mystery_TP int, Mystery_TN int, Mystery_FP int, Mystery_FN int, Mystery_Accuracy double, Mystery_Recall double, Mystery_Precision double, Mystery_F1Score double, Mystery_minScore double, Mystery_maxScore double, Mystery_minProbability double, Mystery_maxProbability double, Mystery_automatedTreshold double, Mystery_manualThreshold double, Mystery_trainRepresentation double, Mystery_testRepresentation double, Mystery_threshold_is_ok boolean, Mystery_AuC double, Mystery_test_split_count int, Quirk_TP int, Quirk_TN int, Quirk_FP int, Quirk_FN int, Quirk_Accuracy double, Quirk_Recall double, Quirk_Precision double, Quirk_F1Score double, Quirk_minScore double, Quirk_maxScore double, Quirk_minProbability double, Quirk_maxProbability double, Quirk_automatedTreshold double, Quirk_manualThreshold double, Quirk_trainRepresentation double, Quirk_testRepresentation double, Quirk_threshold_is_ok boolean, Quirk_AuC double, Quirk_test_split_count int, Glamorous_TP int, Glamorous_TN int, Glamorous_FP int, Glamorous_FN int, Glamorous_Accuracy double, Glamorous_Recall double, Glamorous_Precision double, Glamorous_F1Score double, Glamorous_minScore double, Glamorous_maxScore double, Glamorous_minProbability double, Glamorous_maxProbability double, Glamorous_automatedTreshold double, Glamorous_manualThreshold double, Glamorous_trainRepresentation double, Glamorous_testRepresentation double, Glamorous_threshold_is_ok boolean, Glamorous_AuC double, Glamorous_test_split_count int, Party_TP int, Party_TN int, Party_FP int, Party_FN int, Party_Accuracy double, Party_Recall double, Party_Precision double, Party_F1Score double, Party_minScore double, Party_maxScore double, Party_minProbability double, Party_maxProbability double, Party_automatedTreshold double, Party_manualThreshold double, Party_trainRepresentation double, Party_testRepresentation double, Party_threshold_is_ok boolean, Party_AuC double, Party_test_split_count int, Chill_TP int, Chill_TN int, Chill_FP int, Chill_FN int, Chill_Accuracy double, Chill_Recall double, Chill_Precision double, Chill_F1Score double, Chill_minScore double, Chill_maxScore double, Chill_minProbability double, Chill_maxProbability double, Chill_automatedTreshold double, Chill_manualThreshold double, Chill_trainRepresentation double, Chill_testRepresentation double, Chill_threshold_is_ok boolean, Chill_AuC double, Chill_test_split_count int, Cool_TP int, Cool_TN int, Cool_FP int, Cool_FN int, Cool_Accuracy double, Cool_Recall double, Cool_Precision double, Cool_F1Score double, Cool_minScore double, Cool_maxScore double, Cool_minProbability double, Cool_maxProbability double, Cool_automatedTreshold double, Cool_manualThreshold double, Cool_trainRepresentation double, Cool_testRepresentation double, Cool_threshold_is_ok boolean, Cool_AuC double, Cool_test_split_count int, timestamp int) STORED AS PARQUET LOCATION '{}'"
    assert check_tbl_exists_metrics_log == "select * from vv_db.hvtb_nbx_core_subtribe_metrics_log LIMIT 1"
    assert drop_table_query_metrics_log == "drop table IF EXISTS vv_db.hvtb_nbx_core_subtribe_metrics_log"
    assert create_table_query_metrics_log == "CREATE EXTERNAL TABLE IF NOT EXISTS vv_db.hvtb_nbx_core_subtribe_metrics_log(Adventure_TP int, Adventure_TN int, Adventure_FP int, Adventure_FN int, Adventure_Accuracy double, Adventure_Recall double, Adventure_Precision double, Adventure_F1Score double, Adventure_minScore double, Adventure_maxScore double, Adventure_minProbability double, Adventure_maxProbability double, Adventure_automatedTreshold double, Adventure_manualThreshold double, Adventure_trainRepresentation double, Adventure_testRepresentation double, Adventure_threshold_is_ok boolean, Adventure_AuC double, Adventure_test_split_count int, Mystery_TP int, Mystery_TN int, Mystery_FP int, Mystery_FN int, Mystery_Accuracy double, Mystery_Recall double, Mystery_Precision double, Mystery_F1Score double, Mystery_minScore double, Mystery_maxScore double, Mystery_minProbability double, Mystery_maxProbability double, Mystery_automatedTreshold double, Mystery_manualThreshold double, Mystery_trainRepresentation double, Mystery_testRepresentation double, Mystery_threshold_is_ok boolean, Mystery_AuC double, Mystery_test_split_count int, Quirk_TP int, Quirk_TN int, Quirk_FP int, Quirk_FN int, Quirk_Accuracy double, Quirk_Recall double, Quirk_Precision double, Quirk_F1Score double, Quirk_minScore double, Quirk_maxScore double, Quirk_minProbability double, Quirk_maxProbability double, Quirk_automatedTreshold double, Quirk_manualThreshold double, Quirk_trainRepresentation double, Quirk_testRepresentation double, Quirk_threshold_is_ok boolean, Quirk_AuC double, Quirk_test_split_count int, Glamorous_TP int, Glamorous_TN int, Glamorous_FP int, Glamorous_FN int, Glamorous_Accuracy double, Glamorous_Recall double, Glamorous_Precision double, Glamorous_F1Score double, Glamorous_minScore double, Glamorous_maxScore double, Glamorous_minProbability double, Glamorous_maxProbability double, Glamorous_automatedTreshold double, Glamorous_manualThreshold double, Glamorous_trainRepresentation double, Glamorous_testRepresentation double, Glamorous_threshold_is_ok boolean, Glamorous_AuC double, Glamorous_test_split_count int, Party_TP int, Party_TN int, Party_FP int, Party_FN int, Party_Accuracy double, Party_Recall double, Party_Precision double, Party_F1Score double, Party_minScore double, Party_maxScore double, Party_minProbability double, Party_maxProbability double, Party_automatedTreshold double, Party_manualThreshold double, Party_trainRepresentation double, Party_testRepresentation double, Party_threshold_is_ok boolean, Party_AuC double, Party_test_split_count int, Chill_TP int, Chill_TN int, Chill_FP int, Chill_FN int, Chill_Accuracy double, Chill_Recall double, Chill_Precision double, Chill_F1Score double, Chill_minScore double, Chill_maxScore double, Chill_minProbability double, Chill_maxProbability double, Chill_automatedTreshold double, Chill_manualThreshold double, Chill_trainRepresentation double, Chill_testRepresentation double, Chill_threshold_is_ok boolean, Chill_AuC double, Chill_test_split_count int, Cool_TP int, Cool_TN int, Cool_FP int, Cool_FN int, Cool_Accuracy double, Cool_Recall double, Cool_Precision double, Cool_F1Score double, Cool_minScore double, Cool_maxScore double, Cool_minProbability double, Cool_maxProbability double, Cool_automatedTreshold double, Cool_manualThreshold double, Cool_trainRepresentation double, Cool_testRepresentation double, Cool_threshold_is_ok boolean, Cool_AuC double, Cool_test_split_count int, timestamp int) STORED AS PARQUET  LOCATION '{}'"



# 3 Test Read Write from S3
def test_read_and_write_to_s3():
    test_save_loc = "s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv"
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite").csv(test_save_loc)

    prepared_data = spark.read.csv(test_save_loc)
    assert prepared_data.collect() is not None


# 4 Test GNIP Data Exists
def test_gnip_data_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='RandomForest'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    gnip_data = processController.get("gnip_data")
    df_brand_details = spark.sql(gnip_data).limit(1)
    assert df_brand_details.collect() is not None


# 5 Test Sailor Attributes Table
def test_sailor_attributes_table_exists():
    axiom_data = "select Sequence from vv_db.hvtb_nbx_core_subtribe_sailorattributes LIMIT 1"
    df_attrs_list = spark.sql(axiom_data)
    assert df_attrs_list.collect() is not None


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
