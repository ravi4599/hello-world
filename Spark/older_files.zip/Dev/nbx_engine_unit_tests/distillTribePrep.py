import unittest

import pytest
from pyspark.sql import SparkSession

from src.com.virginvoyages.rec_engine.tribe.distillTribePrep import query_process_table, \
    create_temp_veiw_on_process_table, query_processor
from test.com.virginvoyages.rec_engine.test_init_parameter import spark_context


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


pytestmark = pytest.mark.usefixtures("spark_context")


def test_table_count(spark_context):
    try:
        processController = query_processor(spark_context, "vv_db.processdriver")
        pub = spark_context.sql("select * from customerData limit 1")
    except Exception:
        raise AssertionError("Query raised ExceptionType unexpectedly!")


if __name__ == '__main__':
    unittest.main()
