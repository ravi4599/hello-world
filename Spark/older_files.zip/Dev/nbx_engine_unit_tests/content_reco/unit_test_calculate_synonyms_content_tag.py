import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")

import pyspark
from pyspark.sql import SparkSession


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .getOrCreate()


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1").collect()

    assert prepared_data is not None


# 2 Test Read Write from S3
def test_read_and_write_to_s3():
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite")\
        .csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")
    prepared_data = spark.read.csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")

    assert prepared_data is not None


# 3 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql(
        "select VariableName,Value from vv_db.processdriver where processName='TagSynonyms_Content'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    sql_query = processController.get("sql_query")
    id = processController.get("id")
    path_core = processController.get("path_tag_synonyms")
    path_staging = processController.get("path_tag_synonyms_staging")

    assert sql_query == "SELECT tagid AS id_tag, tagdescription AS title FROM bd_db.cms_tags WHERE tagdescription IS NOT NULL"
    assert id == "id_tag"
    assert path_core == "s3a://vv-dev-emr-cluster/data/core/content_rec_files/content_tag_affinities"
    assert path_staging == "s3a://vv-dev-emr-cluster/data/staging/content_rec_files/content_tag_affinities"


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
