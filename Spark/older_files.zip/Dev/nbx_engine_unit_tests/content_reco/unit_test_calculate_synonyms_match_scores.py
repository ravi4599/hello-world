import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")

import pyspark
from pyspark.sql import SparkSession


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .config("spark.jars", "/home/jenkins/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar,/home/jenkins/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/jenkins/phoenix_jars/phoenix-core-4.11.0-HBase-1.3.jar")\
    .getOrCreate()


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1").collect()
    assert prepared_data is not None


# 2 Test Match Scores Query
def test_match_scores_query():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='MatchScores_Content'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    database = processController.get("database")
    sail_db = "{}.vv_synonyms_sailor_affinities".format(database)
    acts_db = "{}.vv_synonyms_content_tag_affinities".format(database)
    df_sail = spark.sql("select * from {} LIMIT 1".format(sail_db))
    df_acts = spark.sql("select * from {} LIMIT 1".format(acts_db))
    assert df_sail.collect() is not None
    assert df_acts.collect() is not None


# 3 Test HBase Connection
def test_hbase_connection():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='MatchScores_Content'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    match_scores_content_hbase_tbl = processController.get("match_scores_content_hbase_tbl")
    hbase_ip = processController.get("hbase_ip")
    prepared_data = spark.read \
        .format("org.apache.phoenix.spark") \
        .option("table", match_scores_content_hbase_tbl) \
        .option("zkUrl", hbase_ip) \
        .load()\
        .limit(1)\
        .collect()
    assert prepared_data is not None


# 4 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql(
        "select VariableName,Value from vv_db.processdriver where processName='MatchScores_Content'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    database = processController.get("database")
    match_scores_query = processController.get("match_scores_query")
    path_core = processController.get("path_match_scores")
    path_staging = processController.get("path_match_scores_staging")
    match_scores_content_hbase_tbl = processController.get("match_scores_content_hbase_tbl")
    hbase_ip = processController.get("hbase_ip")

    assert database == "vv_db"
    assert match_scores_query == "SELECT id_seaware, id_tag, count(synonyms) as tag_nlp_scores FROM ( SELECT df_sail.id_seaware, df_sail.synonyms, id_tag FROM ( SELECT id_seaware, synonyms FROM vv_synonyms_sailor_affinities ) df_sail JOIN ( SELECT id_tag, synonyms FROM vv_synonyms_content_tag_affinities ) df_tag WHERE df_sail.synonyms IN (df_tag.synonyms) ) b GROUP BY id_seaware, id_tag"
    assert path_core == "s3a://vv-dev-emr-cluster/data/core/content_rec_files/match_scores"
    assert path_staging == "s3a://vv-dev-emr-cluster/data/staging/content_rec_files/match_scores"
    assert match_scores_content_hbase_tbl == "VV_MATCH_SCORES_CONTENT"
    assert hbase_ip == "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase"


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
