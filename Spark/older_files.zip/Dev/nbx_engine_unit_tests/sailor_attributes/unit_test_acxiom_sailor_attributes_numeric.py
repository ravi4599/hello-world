import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession



spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
	.config("spark.jars", "/home/jenkins/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/jenkins/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar,/home/jenkins/phoenix_jars/mysql-connector-java-5.1.45-bin.jar,/home/jenkins/phoenix_jars/phoenix-core-4.11.0-HBase-1.3.jar") \
    .getOrCreate()

@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1").collect()
    assert prepared_data is not None


# 2 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Sailor_Attributes_Acxiom_Numeric'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    spending_cols = processController.get("spending_cols")
    hbase_table_name = processController.get("hbase_table_name")
    hbase_ip = processController.get("hbase_ip")
    spending_updated_cols = processController.get("spending_updated_cols")
    mapping_list = processController.get("mapping_list")
    path_sailor_attributes = processController.get("path_sailor_attributes")
    check_tbl_exists = processController.get("check_tbl_exists")
    drop_table_query = processController.get("drop_table_query")
    create_table_query = processController.get("create_table_query")

    assert spending_cols == "s3a://vv-dev-emr-cluster/sailor_affinity/spending_selected_columns.csv"
    assert hbase_table_name == "HBTB_NBX_ACXIOM_RESERVATION"
    assert hbase_ip == "ip-10-3-100-117.office.virginvoyages.ad:2181:/hbase"
    assert spending_updated_cols == "s3a://vv-dev-emr-cluster/sailor_affinity/Spending_updated_columns.csv"
    assert mapping_list == "s3a://vv-dev-emr-cluster/sailor_affinity/Acxiom_Master_MappingList_v3.csv"
    assert path_sailor_attributes == "s3a://vv-dev-emr-cluster/data/core/sailor_attributes/acxiom_sailor_attributes_numeric"
    assert check_tbl_exists == "SELECT * FROM vv_db.hvtb_nbx_core_sailorattributes_acxiom_numeric"
    assert drop_table_query == "DROP TABLE IF EXISTS vv_db.hvtb_nbx_core_sailorattributes_acxiom_numeric"
    assert create_table_query == "CREATE EXTERNAL TABLE IF NOT EXISTS vv_db.hvtb_nbx_core_sailorattributes_acxiom_numeric(seaware_id string, Art_acxiom double, Automotive_acxiom double, Beauty_acxiom double, Books_acxiom double, Children_acxiom double, Collectibles_acxiom double, Computers_acxiom double, Crafts_acxiom double, Fashion_acxiom double, Gardening_acxiom double, Gifts_acxiom double, Gourmet_cooking_acxiom double, Health_acxiom double, Holidays_acxiom double, Home_decor_acxiom double, Home_furnishings_acxiom double, Jewelry_acxiom double, Music_acxiom double, Pets_acxiom double, Photography_acxiom double, Sports_and_leisure_acxiom double, Stationary_acxiom double, Travel_acxiom double, Videos_acxiom double) STORED AS PARQUET LOCATION '{}'"

# 3 Test Read Write from S3
def test_read_and_write_to_s3():
    test_save_loc = "s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv"
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite").csv(test_save_loc)

    prepared_data = spark.read.csv(test_save_loc)
    assert prepared_data.collect() is not None


# 4 Test HBase Acxiom Reservation Data Exists
def test_hbase_acxiom_reservation_data_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Sailor_Attributes_Acxiom_Numeric'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    hbase_table_name = processController.get("hbase_table_name")
    hbase_ip = processController.get("hbase_ip")

    df_acxiom_data = spark.read \
        .format("org.apache.phoenix.spark") \
        .option("table", hbase_table_name) \
        .option("zkUrl", hbase_ip) \
        .load()

    assert df_acxiom_data.collect() is not None

# 5 Test Sailor Attributes Table
def test_dependant_csv_files_exist():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Sailor_Attributes_Acxiom_Numeric'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    spending_cols = processController.get("spending_cols")
    spending_updated_cols = processController.get("spending_updated_cols")
    mapping_list = processController.get("mapping_list")

    df_spending_cols = spark.read.csv(spending_cols)
    df_spending_updated_cols = spark.read.csv(spending_updated_cols)
    df_mapping_list = spark.read.csv(mapping_list)

    assert df_spending_cols.collect() is not None
    assert df_spending_updated_cols.collect() is not None
    assert df_mapping_list.collect() is not None


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
