import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession



spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
	.config("spark.jars", "/home/jenkins/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/jenkins/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar,/home/jenkins/phoenix_jars/mysql-connector-java-5.1.45-bin.jar,/home/jenkins/phoenix_jars/phoenix-core-4.11.0-HBase-1.3.jar") \
    .getOrCreate()

@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1").collect()
    assert prepared_data is not None


# 2 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Sailor_Attributes_Acxiom'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    acxioms_columns = processController.get("acxioms_columns")
    attributes_mapping = processController.get("attributes_mapping")
    hbase_table_name = processController.get("hbase_table_name")
    hbase_ip = processController.get("hbase_ip")
    path_sailor_attributes = processController.get("path_sailor_attributes")
    check_tbl_exists = processController.get("check_tbl_exists")
    drop_table_query = processController.get("drop_table_query")
    create_table_query = processController.get("create_table_query")

    assert acxioms_columns == "s3a://vv-dev-emr-cluster/tmp/Acxiom/acxiom_selected_columns_matching_to_bundles.csv"
    assert attributes_mapping == "s3a://vv-dev-emr-cluster/data/twitter/Acxiom_Master_MappingList_v2.csv"
    assert hbase_table_name == "HBTB_NBX_ACXIOM_RESERVATION"
    assert hbase_ip == "ip-10-3-100-117.office.virginvoyages.ad:2181:/hbase"
    assert path_sailor_attributes == "s3a://vv-dev-emr-cluster/data/core/sailor_attributes/acxiom_sailor_attributes"
    assert check_tbl_exists == "SELECT * FROM vv_db.hvtb_nbx_core_sailorattributes_acxiom"
    assert drop_table_query == "DROP TABLE IF EXISTS vv_db.hvtb_nbx_core_sailorattributes_acxiom"
    assert create_table_query == "CREATE EXTERNAL TABLE IF NOT EXISTS vv_db.hvtb_nbx_core_sailorattributes_acxiom(seaware_id string, Accessories_acxiom double, Aerobic_acxiom double, AffairsAndPolitics_acxiom double, American_History_acxiom double, Animal_welfare_acxiom double, Antiques_acxiom double, Appliances_acxiom double, Art_acxiom double, Artistic_living_acxiom double, Audio_books_acxiom double, Auto_work_acxiom double, Automotive_acxiom double, Aviation_acxiom double, Avid_music_listener_acxiom double, Baseball_acxiom double, Basketball_acxiom double, Beauty_acxiom double, BestSellers_acxiom double, Biking_acxiom double, Board_games_acxiom double, BoatOwner_acxiom double, Boating_acxiom double, Books_acxiom double, Broader_living_acxiom double, Buddhist_acxiom double, Budget_Watchers_acxiom double, Cable_TV_acxiom double, Camping_acxiom double, Career_improvement_acxiom double, Casino_acxiom double, Cat_owner_acxiom double, Catholic_acxiom double, Celebrities_acxiom double, Charities_acxiom double, Children_acxiom double, Chiphead_acxiom double, Coins_acxiom double, Collectibles_acxiom double, Common_living_acxiom double, Computer_games_acxiom double, Computers_acxiom double, Conservative_acxiom double, Consumer_electronics_acxiom double, Contest_acxiom double, Cooking_acxiom double, Cosmetics_acxiom double, Costume_jewelry_acxiom double, Crafts_acxiom double, Creatures_of_Comfort_acxiom double, Cruise_acxiom double, Cultural_acxiom double, DIY_living_acxiom double, Decorating_acxiom double, Democratic_acxiom double, Dieting_acxiom double, Dog_owner_acxiom double, Domestic_acxiom double, Eastern_Orthodox_acxiom double, Education_online_acxiom double, Environment_or_wildlife_acxiom double, Environmental_home_care_acxiom double, Equestrian_acxiom double, Ethiopian_Orthodox_acxiom double, Exercise_acxiom double, Family_vacations_acxiom double, Fashion_acxiom double, Financial_acxiom double, First_Coasters_acxiom double, Fishing_acxiom double, Flowers_acxiom double, Football_acxiom double, Gardening_acxiom double, General_acxiom double, Gifts_acxiom double, Golf_acxiom double, Gourmet_cooking_acxiom double, Grandchildren_acxiom double, Greek_Orthodox_acxiom double, Green_Activist_acxiom double, Green_Investors_acxiom double, Guns_and_ammunition_acxiom double, Hands_On_Believers_acxiom double, Health_acxiom double, High_Tech_living_acxiom double, High_end_appliances_acxiom double, Highbrow_acxiom double, Hiking_acxiom double, Hindu_acxiom double, Hockey_acxiom double, Holidays_acxiom double, Home_decor_acxiom double, Home_furnishings_acxiom double, Home_improvement_acxiom double, Homeopathic_acxiom double, House_plants_acxiom double, Hunting_acxiom double, Inspirational_acxiom double, Internet_TV_acxiom double, Jewelry_acxiom double, Jewish_acxiom double, Jogging_acxiom double, Knitting_acxiom double, Laptop_acxiom double, Learning_and_activity_toys_acxiom double, Liberal_acxiom double, Living_in_the_Now_acxiom double, Lottery_acxiom double, Low_fat_cooking_acxiom double, Luggage_acxiom double, Lutheran_acxiom double, Magazines_acxiom double, Membership_clubs_acxiom double, Military_acxiom double, Mormon_acxiom double, MotorcycleRacing_acxiom double, Motorcycling_acxiom double, Mountain_biking_acxiom double, Movie_collector_acxiom double, Movies_acxiom double, Music_acxiom double, Music_collector_acxiom double, Music_player_acxiom double, Musical_instruments_acxiom double, Muslim_acxiom double, NASCAR_acxiom double, Natural_foods_acxiom double, Needlework_acxiom double, No_party_acxiom double, Organic_acxiom double, Outdoors_acxiom double, PackageVacations_acxiom double, Parenting_acxiom double, Performing_Arts_acxiom double, Pets_acxiom double, Photography_acxiom double, Political_acxiom double, Power_boating_acxiom double, Pragmatists_acxiom double, Professional_living_acxiom double, Protestant_acxiom double, Puzzles_acxiom double, RV_acxiom double, Reading_acxiom double, Religious_acxiom double, Republican_acxiom double, Running_acxiom double, Sailing_acxiom double, Science_fiction_acxiom double, Scuba_diving_acxiom double, Self_improvement_acxiom double, Senior_needs_acxiom double, Sewing_acxiom double, Shinto_acxiom double, Shooting_acxiom double, Sikh_acxiom double, Snow_skiing_acxiom double, Soccer_acxiom double, Space_acxiom double, Sports_acxiom double, Sports_and_leisure_acxiom double, Sports_memorabilia_acxiom double, Sporty_living_acxiom double, Stamps_acxiom double, Stationary_acxiom double, Strange_and_unusual_acxiom double, Sweepstakes_acxiom double, Tech_acxiom double, Telecommunications_acxiom double, Tennis_acxiom double, Theater_acxiom double, Tobacco_acxiom double, Toys_acxiom double, Travel_acxiom double, Unplugged_acxiom double, Upscale_living_acxiom double, Value_priced_general_merchandise_acxiom double, Vegetarian_foods_acxiom double, Veteran_acxiom double, Video_games_acxiom double, Videos_acxiom double, Walking_acxiom double, Water_sports_acxiom double, Weaponry_acxiom double, WeightLoss_acxiom double, Wine_acxiom double, Woodworking_acxiom double, Yoga_acxiom double) STORED AS PARQUET LOCATION '{}'"


# 3 Test Read Write from S3
def test_read_and_write_to_s3():
    test_save_loc = "s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv"
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite").csv(test_save_loc)

    prepared_data = spark.read.csv(test_save_loc)
    assert prepared_data.collect() is not None


# 4 Test HBase Acxiom Reservation Data Exists
def test_hbase_acxiom_reservation_data_exists():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Sailor_Attributes_Acxiom'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    hbase_table_name = processController.get("hbase_table_name")
    hbase_ip = processController.get("hbase_ip")

    df_acxiom_data = spark.read \
        .format("org.apache.phoenix.spark") \
        .option("table", hbase_table_name) \
        .option("zkUrl", hbase_ip) \
        .load()

    assert df_acxiom_data.collect() is not None

# 5 Test Sailor Attributes Table
def test_dependant_csv_files_exist():
    raw_data = spark.sql("select VariableName,Value from vv_db.processdriver where processName='Sailor_Attributes_Acxiom'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    acxioms_columns = processController.get("attributes_mapping")
    attributes_mapping = processController.get("hbase_ip")

    df_acxioms_columns = spark.read.csv(acxioms_columns)
    df_attributes_mapping = spark.read.csv(attributes_mapping)

    assert df_acxioms_columns.collect() is not None
    assert df_attributes_mapping.collect() is not None


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
