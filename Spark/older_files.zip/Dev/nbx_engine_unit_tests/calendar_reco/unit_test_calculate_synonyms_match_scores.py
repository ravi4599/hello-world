import unittest

import pytest

import os, sys, time, datetime, traceback
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import col, lit, from_unixtime, concat, collect_list, regexp_replace
from pyspark.sql.types import *


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .config("spark.jars", "/home/jenkins/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar,/home/jenkins/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/jenkins/phoenix_jars/phoenix-core-4.11.0-HBase-1.3.jar")\
    .getOrCreate()

@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1")
    assert prepared_data is not None


# 2 Test Hive Feedback Table
def test_hive_connection_to_vv_db_vv_synonyms_feedback():
    prepared_data = spark.sql("select id_seaware, synonyms, UpdatedWeight, TotalUpdatedWeight, UpdatedWeightPercentages from vv_db.HVTB_NBX_CORE_CALRECO_feedback LIMIT 1")
    assert prepared_data is not None


# 3 Test Hive Activity Table
def test_hive_connection_to_vv_db_vv_synonyms_activity_affinities():
    prepared_data = spark.sql("SELECT id_activity, synonyms FROM vv_db.HVTB_NBX_CORE_CALRECO_activity LIMIT 1")
    assert prepared_data is not None


# 4 Test HBase Connection
def test_hbase_connection():
    prepared_data = spark.read \
        .format("org.apache.phoenix.spark") \
        .option("table", "VV_MATCH_SCORES_NEW") \
        .option("zkUrl", "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase") \
        .load()
    assert prepared_data is not None


# 5 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql(
        "select VariableName,Value from vv_db.processdriver where processName='MatchScores'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    activity_query = processController.get("activity_query")
    feedback_query = processController.get("feedback_query")
    sailor_query = processController.get("sailor_query")
    feedback_location = processController.get("feedback_location")
    path_match_scores = processController.get("path_match_scores")
    path_sailor_synonyms = processController.get("path_sailor_synonyms")
    match_scores_hbase_tbl = processController.get("match_scores_calendar_hbase")
    hbase_ip = processController.get("hbase_ip")

    assert activity_query == "select id_activity, synonyms from vv_db.HVTB_NBX_CORE_CALRECO_activity"
    assert feedback_query == "select id_seaware, synonyms, UpdatedWeight, TotalUpdatedWeight, UpdatedWeightPercentages from vv_db.HVTB_NBX_CORE_CALRECO_feedback"
    assert sailor_query == "select id_seaware, synonyms from vv_db.HVTB_NBX_CORE_CALRECO_sailor"
    assert feedback_location == "s3a://vv-dev-emr-cluster/data/core/calendar_reco/feedback"
    assert path_match_scores == "s3a://vv-dev-emr-cluster/data/core/calendar_reco/match_scores"
    assert path_sailor_synonyms == "s3a://vv-dev-emr-cluster/data/core/calendar_reco/sailor_affinities"
    assert match_scores_hbase_tbl == "VV_MATCH_SCORES_NEW"
    assert hbase_ip == "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase"


pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()

