import unittest
import pytest
import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .getOrCreate()


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.processdriver LIMIT 1")

    assert prepared_data is not None


# 2 Test Read Write from S3
def test_read_and_write_to_s3():
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite").csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")
    prepared_data = spark.read.csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")

    assert prepared_data is not None


# 3 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql(
        "select VariableName,Value from vv_db.hvtb_nbx_core_processdriver where processName='SailorSynonyms'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    input_location = processController.get("input_location")
    path_sailor_synonyms = processController.get("path_sailor_synonyms")
    path_sailor_synonyms_staging = processController.get("path_sailor_synonyms_staging")
    attributes = processController.get("attributes")

    assert input_location == "vv_db.HVTB_NBX_CORE_CALRECO_seawaremapping"
    assert path_sailor_synonyms == "s3a://vv-dev-emr-cluster/data/core/calendar_reco/sailor_affinities"
    #assert attributes == "id_seaware,aerobics,art_craft,auto_motorcycle_racing,auto_work,avid_readers,baseball,basketball,boating_or_sailing,camping_or_hiking,career_minded,cars,casino_gambling,children_interests,collector_antiques,collector_coins,collector_dolls,collector_figurines,collector_fine_arts,collector_plates,collector_sports_memorabilia,collector_stamps,collectors,consumer_electronics,contribute_animal,contribute_childrens,contribute_environm,contribute_health,contribute_political,contribute_political_conservative,contribute_political_liberal,contribute_religious,contribute_veterans,contributors,cultural_artistic,current_affairs_politics,diet_weight_loss,doit_yourselfer,donor_arts_or_cultural,entertainment_enth,family,fishing,fitness,food,football,hobby_video_games,hobby_board_games,hobby_computer_games,gardening,genre_musictype_christian_or_gospel,genre_musictype_classical,genre_musictype_country,genre_musictype_jazz,genre_musictype_rhythm_and_blues,genre_musictype_rock_n_roll,genre_musictype_soft_rock_or_easy_listen,golf,great_outdoors,health_beauty,health_living,hobby_bird_watching,hobby_cigar_smoking,hobby_cooking,hobby_cooking_gourmet,hobby_crafts,hobby_home_study_courses,hobby_knitting_or_needlework,hobby_photography,hobby_quilting,hobby_self_improvement_courses,hobby_sewing,hobby_wine_appreciation,hobby_woodworking,Hobbyists,hockey,home_decor,home_improvement,hunting,internet_buyer,investments,investments_own_mutual_funds_cds,investments_own_stocks_or_bonds,luxury_life,magazine,mail_buyer,mail_donor,mail_responder,membership_warehouse,mo_books,mo_books_or_mag,mo_children_s_products,mo_clothing,mo_cosmetics,mo_dvd,mo_gifts,mo_home_furnishing,mo_jewelry,mo_plus_size_clothing,motor_cycle,movie,music,collector_music,musical_instruments,music_player,nascar,online_education,opportunity_seeker,own_swimming_pool,owns_satellite_tv,pets,pets_own_at_least_one_cat,pets_own_at_least_one_dog,reading_news_finance,reading_astrology,reading_best_selling_fiction,reading_bible_or_devotional,reading_books_on_tape,reading_children_s,reading_computer,reading_cooking_or_culinary,reading_country_lifestyle,reading_fashion,reading_history,reading_interior_decorating,reading_medical_or_health,reading_military,reading_mystery,reading_natural_health_remedies,reading_people_or_entertainment,reading_romance,reading_science_fiction,reading_science_or_technology,reading_sports,reading_world_news_or_politics,religious_inspirational,running,rv_own,science_space,scuba_diving,self_improvement,snow_skiing,soho_business,sporting_life,sports,sports_betting,sweepstakes_contest,tennis,toys,travel,travel_business,travel_card,travel_cruises,travel_international,travel_personal,travel_vacation,truck_owner,tv_sports,walking,weight_lifting,soccer"
    assert attributes == "sequence, Accessories_acxiom,Aerobic_acxiom,AffairsAndPolitics_acxiom,American_History_acxiom,Animal_welfare_acxiom,Antiques_acxiom,Appliances_acxiom,Art_acxiom,Artistic_living_acxiom,Audio_books_acxiom,Auto_work_acxiom,Automotive_acxiom,Aviation_acxiom,Avid_music_listener_acxiom,Baseball_acxiom,Basketball_acxiom,Beauty_acxiom,BestSellers_acxiom,Biking_acxiom,Board_games_acxiom,BoatOwner_acxiom,Boating_acxiom,Books_acxiom,Broader_living_acxiom,Buddhist_acxiom,Budget_Watchers_acxiom,Cable_TV_acxiom,Camping_acxiom,Career_improvement_acxiom,Casino_acxiom,Cat_owner_acxiom,Catholic_acxiom,Celebrities_acxiom,Charities_acxiom,Children_acxiom,Chiphead_acxiom,Coins_acxiom,Collectibles_acxiom,Common_living_acxiom,Computer_games_acxiom,Computers_acxiom,Conservative_acxiom,Consumer_electronics_acxiom,Contest_acxiom,Cooking_acxiom,Cosmetics_acxiom,Costume_jewelry_acxiom,Crafts_acxiom,Creatures_of_Comfort_acxiom,Cruise_acxiom,Cultural_acxiom,DIY_living_acxiom,Decorating_acxiom,Democratic_acxiom,Dieting_acxiom,Dog_owner_acxiom,Domestic_acxiom,Eastern_Orthodox_acxiom,Education_online_acxiom,Environment_or_wildlife_acxiom,Environmental_home_care_acxiom,Equestrian_acxiom,Ethiopian_Orthodox_acxiom,Exercise_acxiom,Family_vacations_acxiom,Fashion_acxiom,Financial_acxiom,First_Coasters_acxiom,Fishing_acxiom,Flowers_acxiom,Football_acxiom,Gardening_acxiom,General_acxiom,Gifts_acxiom,Golf_acxiom,Gourmet_cooking_acxiom,Grandchildren_acxiom,Greek_Orthodox_acxiom,Green_Activist_acxiom,Green_Investors_acxiom,Guns_and_ammunition_acxiom,Hands-On_Believers_acxiom,Health_acxiom,High-Tech_living_acxiom,High_end_appliances_acxiom,Highbrow_acxiom,Hiking_acxiom,Hindu_acxiom,Hockey_acxiom,Holidays_acxiom,Home_decor_acxiom,Home_furnishings_acxiom,Home_improvement_acxiom,Homeopathic_acxiom,House_plants_acxiom,Hunting_acxiom,Inspirational_acxiom,Internet_TV_acxiom,Jewelry_acxiom,Jewish_acxiom,Jogging_acxiom,Knitting_acxiom,Laptop_acxiom,Learning_and_activity_toys_acxiom,Liberal_acxiom,Living_in_the_Now_acxiom,Lottery_acxiom,Low_fat_cooking_acxiom,Luggage_acxiom,Lutheran_acxiom,Magazines_acxiom,Membership_clubs_acxiom,Military_acxiom,Mormon_acxiom,MotorcycleRacing_acxiom,Motorcycling_acxiom,Mountain_biking_acxiom,Movie_collector_acxiom,Movies_acxiom,Music_acxiom,Music_collector_acxiom,Music_player_acxiom,Musical_instruments_acxiom,Muslim_acxiom,NASCAR_acxiom,Natural_foods_acxiom,Needlework_acxiom,No_party_acxiom,Organic_acxiom,Outdoors_acxiom,PackageVacations_acxiom,Parenting_acxiom,Performing_Arts_acxiom,Pets_acxiom,Photography_acxiom,Political_acxiom,Power_boating_acxiom,Pragmatists_acxiom,Professional_living_acxiom,Protestant_acxiom,Puzzles_acxiom,RV_acxiom,Reading_acxiom,Religious_acxiom,Republican_acxiom,Running_acxiom,Sailing_acxiom,Science_fiction_acxiom,Scuba_diving_acxiom,Self_improvement_acxiom,Senior_needs_acxiom,Sewing_acxiom,Shinto_acxiom,Shooting_acxiom,Sikh_acxiom,Snow_skiing_acxiom,Soccer_acxiom,Space_acxiom,Sports_acxiom,Sports_and_leisure_acxiom,Sports_memorabilia_acxiom,Sporty_living_acxiom,Stamps_acxiom,Stationary_acxiom,Strange_and_unusual_acxiom,Sweepstakes_acxiom,Tech_acxiom,Telecommunications_acxiom,Tennis_acxiom,Theater_acxiom,Tobacco_acxiom,Toys_acxiom,Travel_acxiom,Unplugged_acxiom,Upscale_living_acxiom,Value-priced_general_merchandise_acxiom,Vegetarian_foods_acxiom,Veteran_acxiom,Video_games_acxiom,Videos_acxiom,Walking_acxiom,Water_sports_acxiom,Weaponry_acxiom,WeightLoss_acxiom,Wine_acxiom,Woodworking_acxiom,Yoga_acxiom"

##############################################
#                                            #
#    Start Test Special Character Removal    #
#                                            #
##############################################

import re

def special_car(x):
    # remove the special character and replace them with the stop word " " (space)
    return re.sub('[^A-Za-z0-9]+', ' ', x)

def test_special_char():
    x = "ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz-0)1!2@3#4$5%6^7&8*9(10=11+12~13`14,15<16.17>18/19?20[21{22]23}24\\25|26:27;28'29\"30"
    assert special_car(x) == "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30"

############################################
#                                          #
#    End Test Special Character Removal    #
#                                          #
############################################




###################################
#                                 #
#    Start Test Tokenize Words    #
#                                 #
###################################

import nltk

def tokenize_words(x):
    return nltk.tokenize.word_tokenize(x)

def test_tokenize_words():
    x = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30"

    assert tokenize_words(x) == ['ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz', '0', '1', '2', '3', '4',
                                 '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19',
                                 '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30']
    assert len(tokenize_words(x)) == 33

#################################
#                               #
#    End Test Tokenize Words    #
#                               #
#################################




###############################
#                             #
#    Start Test Stem Words    #
#                             #
###############################

import nltk

def test_stem_words():
    assert nltk.stem.snowball.SnowballStemmer("english").stem("consistency") == "consist"
    assert nltk.stem.snowball.SnowballStemmer("english").stem("generously") == "generous"
    assert nltk.stem.snowball.SnowballStemmer("english").stem("knocked") == "knock"
    assert nltk.stem.snowball.SnowballStemmer("english").stem("having") == "have"

#############################
#                           #
#    End Test Stem Words    #
#                           #
#############################




######################################
#                                    #
#    Start Test Remove Stop Words    #
#                                    #
######################################

import nltk

def stop_words(word):
    return word.lower() if word.lower() not in nltk.corpus.stopwords.words("english") else None

def test_stop_words():
    y = ['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog', '.', 'All', 'work', 'and', 'no', 'play', 'makes', 'Jack', 'a', 'dull', 'boy', '.']
    assert list(map(lambda x: stop_words(x), y)) == [None, 'quick', 'brown', 'fox', 'jumps', None, None, 'lazy', 'dog', '.', None, 'work', None, None, 'play', 'makes', 'jack', None, 'dull', 'boy', '.']
    assert stop_words('The') == None
    assert stop_words('quick') == "quick"
    assert stop_words('brown') == "brown"
    assert stop_words('fox') == "fox"
    assert stop_words('jumps') == "jumps"
    assert stop_words('over') == None
    assert stop_words('the') == None
    assert stop_words('lazy') == "lazy"
    assert stop_words('dog') == "dog"

####################################
#                                  #
#    End Test Remove Stop Words    #
#                                  #
####################################




######################################
#                                    #
#    Start Test Synonyms Function    #
#                                    #
######################################

import nltk

def synonyms_fnc(word):
    a = []
    synset = nltk.corpus.wordnet.synsets(word)
    # If there are synonyms...
    if len(synset) > 0:
        for syn in synset:
            for syn_lemma in syn.lemma_names():
                a.append(syn_lemma)
    # If no synonyms, keep the original word
    else:
        a.append(word)
    return list(a)

def test_synonyms_fnc():
    x = "zipline"
    assert synonyms_fnc(x) == ["zipline"]

    y = "quick"
    assert synonyms_fnc(y) == ['quick', 'quick', 'speedy', 'flying', 'quick', 'fast', 'agile', 'nimble', 'quick', 'spry', 'quick', 'ready', 'immediate', 'prompt', 'quick', 'straightaway', 'quick', 'warm', 'promptly', 'quickly', 'quick']

####################################
#                                  #
#    End Test Synonyms Function    #
#                                  #
####################################




##############################################
#                                            #
#    Start Test tranpose_df_func Function    #
#                                            #
##############################################

from pyspark.sql.functions import explode, array, struct, lit, col
from pyspark.sql import DataFrame, Row

def tranpose_df_func(df, by):
    # Filter dtypes and split into column names and type description
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in by))
    # Spark SQL supports only homogeneous columns
    assert len(set(dtypes)) == 1, "All columns have to be of the same type"
    # Create and explode an array of (column_name, column_value) structs
    kvs = explode(array([
        struct(lit(c).alias("keys"), col(c).alias("val")) for c in cols
    ])).alias("kvs")
    return df.select(by + [kvs]).select(by + ["kvs.keys", "kvs.val"])

def test_tranpose_df_func():
    x = spark.sparkContext.parallelize([(1, 0.0, 0.6), (1, 0.6, 0.7), (1, 0.3, 0.1), (1, 0.3, 0.9)]).toDF(["A", "col_1", "col_2"])
    assert tranpose_df_func(x, ['A']).dtypes == [('A', 'bigint'), ('keys', 'string'), ('val', 'double')]
    assert tranpose_df_func(x, ['A']).count() == 8
    assert tranpose_df_func(x, ['A']).collect() == [Row(A=1, keys='col_1', val=0.0), Row(A=1, keys='col_2', val=0.6),
                                           Row(A=1, keys='col_1', val=0.6), Row(A=1, keys='col_2', val=0.7),
                                           Row(A=1, keys='col_1', val=0.3), Row(A=1, keys='col_2', val=0.1),
                                           Row(A=1, keys='col_1', val=0.3), Row(A=1, keys='col_2', val=0.9)]

####################################
#                                  #
#    End Test Synonyms Function    #
#                                  #
####################################

pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
