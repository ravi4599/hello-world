import unittest
import pytest
import logging
import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession

spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
	.config("spark.jars", "/home/jenkins/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/jenkins/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar,/home/jenkins/phoenix_jars/mysql-connector-java-5.1.45-bin.jar,/home/jenkins/phoenix_jars/phoenix-core-4.11.0-HBase-1.3.jar") \
    .getOrCreate()

pytestmark = pytest.mark.usefixtures("spark_context")

@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


################################
##    Test Activity Script    ##
################################

# 1 Test Sailor Feedback Table
def test_hbase_connection_to_feedback_table():
    df_feedback_table = spark.read \
        .format("org.apache.phoenix.spark") \
        .option("table", "SAILOR_FEEDBACK") \
        .option("zkUrl", "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase") \
        .load()
    assert df_feedback_table.collect() is not None

# 2 Test Sailor Recommendations History Table
def test_hbase_connection_to_history_table():
    df_history_table = spark.read \
        .format("org.apache.phoenix.spark") \
        .option("table", "SAILOR_RECOMMENDATIONS_HISTORY") \
        .option("zkUrl", "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase") \
        .load()
    assert df_history_table.collect() is not None


# 3 Test Read Hue Timestamp Table
def test_hue_connection_to_timestamp():
    last_update_timestamp = spark.read \
        .format("jdbc").options(
        url="jdbc:mysql://dev-emr-hue-metastore.cluster-cbduemg5i5w8.us-east-1.rds.amazonaws.com",
        driver="com.mysql.jdbc.Driver",
        dbtable="vv_metadata.last_run_timestamp_tbl",
        user="admin",
        password="Adm1n!2017"
        ).load()
    assert last_update_timestamp.collect() is not None


# 4 Test Hive 3rd Party Data Table
def test_hive_connection_to_vv_db_vv_synonyms_sailor_affinities():
    prepared_data = spark.sql("SELECT id_seaware, synonyms, 1 as weight FROM vv_db.HVTB_NBX_CORE_CALRECO_sailor LIMIT 1")

    assert prepared_data is not None


# 5 Test Read Write from S3
def test_read_and_write_to_s3():
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite").csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")

    prepared_data = spark.read.csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")

    assert prepared_data is not None


# 6 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql(
        "select VariableName,Value from vv_db.processdriver where processName='FeedbackLoop'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)

    hbase_ip = processController.get("hbase_ip")
    sailor_syns_query = processController.get("sailor_syns_query")
    seaware_activity_data = processController.get("seaware_activity_data")
    sailor_calendar_new = processController.get("sailor_calendar_new")
    hue_tbl_details = processController.get("hue_tbl_details")
    feedback_location = processController.get("feedback_location")
    path_feedback_loop = processController.get("path_feedback_loop")

    assert hbase_ip == "ip-10-3-100-117.shoreside.virginvoyages.com:2181:/hbase"
    assert sailor_syns_query == "SELECT id_seaware, synonyms, 1 as weight FROM vv_db.HVTB_NBX_CORE_CALRECO_sailor"
    assert seaware_activity_data == "seaware_activity_data"
    assert sailor_calendar_new == "SAILOR_CALENDAR_NEW"
    assert hue_tbl_details == "[jdbc:mysql://dev-emr-hue-metastore.cluster-cbduemg5i5w8.us-east-1.rds.amazonaws.com,vv_metadata.last_run_timestamp_tbl,admin,Adm1n!2017]"
    assert feedback_location == "s3a://vv-dev-emr-cluster/data/core/calendar_reco/feedback"
    assert path_feedback_loop == "s3a://vv-dev-emr-cluster/data/core/calendar_reco/feedback"

