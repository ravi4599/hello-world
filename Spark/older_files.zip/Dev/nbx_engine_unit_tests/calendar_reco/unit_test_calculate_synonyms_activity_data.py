import unittest

import pytest

import os, sys
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/lib")
sys.path.insert(0, "/opt/spark-2.3.0-bin-hadoop2.7/python/")
import pyspark
from pyspark.sql import SparkSession


spark = SparkSession \
    .builder \
    .appName("test") \
    .enableHiveSupport() \
    .getOrCreate()


@pytest.fixture(scope="session")
def spark_context(request):
    spark = SparkSession.builder.appName("Python").getOrCreate()
    request.addfinalizer(lambda: spark.stop())
    return spark


# 1 Test Hive Process Driver Table
def test_hive_connection_to_vv_db_processdriver():
    prepared_data = spark.sql("SELECT * FROM vv_db.hvtb_nbx_core_processdriver LIMIT 1")

    assert prepared_data is not None


# 2 Make sure all parameters are present in process driver table
def test_processdriver_entries():
    raw_data = spark.sql("select VariableName,Value from vv_db.hvtb_nbx_core_processdriver where processName='ActivitySynonyms'").collect()
    data = map(lambda x: (x[0], x[1]), raw_data)
    processController = dict(data)
    
    input_location = processController.get("input_location")
    attributes = processController.get("attributes")
    path_activity_synonyms = processController.get("path_activity_synonyms")

    assert input_location == "vv_db.HVTB_NBX_CORE_CALRECO_shipactivities"
    assert attributes == "activity_id as id_activity, activity_title as title"
    assert path_activity_synonyms == "s3a://vv-dev-emr-cluster/data/core/calendar_reco/activity_affinities"


# 3 Test Read Write from S3
def test_read_and_write_to_s3():
    spark.createDataFrame([(1, 'Test')]).write.mode("overwrite").csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")
    prepared_data = spark.read.csv("s3a://vv-dev-emr-cluster/data/core/test_files/test_s3_connection.csv")

    assert prepared_data is not None


##############################################
#                                            #
#    Start Test Special Character Removal    #
#                                            #
##############################################

import re

def special_car(x):
    # remove the special character and replace them with the stop word " " (space)
    return re.sub('[^A-Za-z0-9]+', ' ', x)

def test_special_char():
    x = "ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz-0)1!2@3#4$5%6^7&8*9(10=11+12~13`14,15<16.17>18/19?20[21{22]23}24\\25|26:27;28'29\"30"
    assert special_car(x) == "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30"

############################################
#                                          #
#    End Test Special Character Removal    #
#                                          #
############################################




###################################
#                                 #
#    Start Test Tokenize Words    #
#                                 #
###################################

import nltk

def tokenize_words(x):
    return nltk.tokenize.word_tokenize(x)

def test_tokenize_words():
    x = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30"

    assert tokenize_words(x) == ['ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz', '0', '1', '2', '3', '4',
                                 '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19',
                                 '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30']
    assert len(tokenize_words(x)) == 33

#################################
#                               #
#    End Test Tokenize Words    #
#                               #
#################################




###############################
#                             #
#    Start Test Stem Words    #
#                             #
###############################

import nltk

def test_stem_words():
    assert nltk.stem.snowball.SnowballStemmer("english").stem("consistency") == "consist"
    assert nltk.stem.snowball.SnowballStemmer("english").stem("generously") == "generous"
    assert nltk.stem.snowball.SnowballStemmer("english").stem("knocked") == "knock"
    assert nltk.stem.snowball.SnowballStemmer("english").stem("having") == "have"

#############################
#                           #
#    End Test Stem Words    #
#                           #
#############################




######################################
#                                    #
#    Start Test Remove Stop Words    #
#                                    #
######################################

import nltk

def stop_words(word):
    return word.lower() if word.lower() not in nltk.corpus.stopwords.words("english") else None

def test_stop_words():
    y = ['The', 'quick', 'brown', 'fox', 'jumps', 'over', 'the', 'lazy', 'dog', '.', 'All', 'work', 'and', 'no', 'play', 'makes', 'Jack', 'a', 'dull', 'boy', '.']
    assert list(map(lambda x: stop_words(x), y)) == [None, 'quick', 'brown', 'fox', 'jumps', None, None, 'lazy', 'dog', '.', None, 'work', None, None, 'play', 'makes', 'jack', None, 'dull', 'boy', '.']
    assert stop_words('The') == None
    assert stop_words('quick') == "quick"
    assert stop_words('brown') == "brown"
    assert stop_words('fox') == "fox"
    assert stop_words('jumps') == "jumps"
    assert stop_words('over') == None
    assert stop_words('the') == None
    assert stop_words('lazy') == "lazy"
    assert stop_words('dog') == "dog"

####################################
#                                  #
#    End Test Remove Stop Words    #
#                                  #
####################################




######################################
#                                    #
#    Start Test Synonyms Function    #
#                                    #
######################################

import nltk

def synonyms_fnc(word):
    a = []
    synset = nltk.corpus.wordnet.synsets(word)
    # If there are synonyms...
    if len(synset) > 0:
        for syn in synset:
            for syn_lemma in syn.lemma_names():
                a.append(syn_lemma)
    # If no synonyms, keep the original word
    else:
        a.append(word)
    return list(a)

def test_synonyms_fnc():
    x = "zipline"
    assert synonyms_fnc(x) == ["zipline"]

    y = "quick"
    assert synonyms_fnc(y) == ['quick', 'quick', 'speedy', 'flying', 'quick', 'fast', 'agile', 'nimble', 'quick', 'spry', 'quick', 'ready', 'immediate', 'prompt', 'quick', 'straightaway', 'quick', 'warm', 'promptly', 'quickly', 'quick']

####################################
#                                  #
#    End Test Synonyms Function    #
#                                  #
####################################

pytestmark = pytest.mark.usefixtures("spark_context")


if __name__ == '__main__':
    unittest.main()
