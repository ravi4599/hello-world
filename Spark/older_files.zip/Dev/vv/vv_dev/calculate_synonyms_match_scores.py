###############################################
#                                             #
# Inputs:                                     #
#    Intermediate Table:                      #
#       vv_db.vv_sailor_affinity_synonyms     #
#          Format:                            #
#             id_seaware        :STRING       #
#             sailor_synonyms   :STRING       #
#                                             #
#    Intermediate Table:                      #
#       vv_db.vv_activity_affinity_synonyms   #
#          Format:                            #
#             id_activity           :STRING   #
#             activity_synonyms     :STRING   #
#                                             #
# Spark Submit Script:                        #
#   spark-submit                              #
# --name Calculate_match_scores               #
# --num-executors 4 --executor-memory 4G      #
# --driver-memory 4G --executor-cores 8       #
# --master yarn --deploy-mode cluster         #
# /tmp/py_scripts/calculate_synonyms_         #
# match_scores.py                             #
#                                             #
###############################################

from pyspark.sql.functions import col, lit, from_unixtime, concat, collect_list, regexp_replace
from pyspark.sql.types import *
from pyspark.sql import SparkSession

import time, re, traceback, logging

spark = SparkSession \
    .builder \
    .appName("Calculate_Synonym_match_scores") \
    .enableHiveSupport() \
    .getOrCreate()


def get_match_scores(log, spark):

    log.info("Execute query to get match-scores...")

    # Externalize
    spark.sql("use vv_db")

    # Externalize
    df_matches = spark.sql("SELECT id_seaware, id_activity, count(synonyms) as activity_nlp_scores \
    FROM ( \
      SELECT df_sail.id_seaware, df_sail.synonyms, id_activity \
      FROM ( \
        SELECT id_seaware, synonyms \
        FROM vv_synonyms_sailor_affinities \
        ) df_sail \
      JOIN ( \
        SELECT id_activity, synonyms \
        FROM vv_synonyms_activity_affinities \
        ) df_act \
      WHERE df_sail.synonyms IN (df_act.synonyms) \
      ) b \
    GROUP BY id_seaware, id_activity \
    ORDER BY id_seaware, CAST(id_activity AS INT)")

    # Creates output in the form: [sailor_1, {"seawareid": [{"activityid":1, "score":10}, ...]
    df_json_w_timestamps = df_matches.orderBy(col("activity_nlp_scores").desc()) \
        .coalesce(1) \
        .select(col("id_seaware"),
                concat(
                    lit("{\"activityid\":"),
                    df_matches.id_activity,
                    lit(", \"score\":"),
                    df_matches.activity_nlp_scores,
                    lit("}")
                ).alias('tmp_activity_sailor_scores')) \
        .groupby("id_seaware") \
        .agg(collect_list("tmp_activity_sailor_scores").cast(StringType()).alias("test")) \
        .withColumn("reg_ex_1", regexp_replace(col("test"), "\[\{\"", "{\"seawareid\": [{\"")) \
        .withColumn("activity_sailor_scores", regexp_replace(col("reg_ex_1"), "\}\]", "}]}")) \
        .drop(col("test")) \
        .drop(col("reg_ex_1")) \
        .withColumn("time_stamp", lit(str(time.time()))) \
        .withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss').cast(TimestampType())) \
        .withColumn("probability", lit(str(1.0))) \
        .withColumn("rev_per_act", lit(str(1.0))) \
        .withColumn("rev_scores", lit(str(1.0))) \
        .withColumn("aff_rev_new_rank", lit(str(1.0)))

    log.info("Return Dataframe")
    return df_json_w_timestamps


def initSparkSession(appName):
    spark = SparkSession \
        .builder \
        .appName(appName) \
        .enableHiveSupport() \
        .getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", "50")
    return spark


def get_logger():
    log = logging.getLogger('Spark')
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
    log.addHandler(_h)
    log.setLevel(logging.DEBUG)
    log.info("module imported and logger initialized")
    return log


def loadProcessDriver(spark, log, db_name):
    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='MatchScores'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


# Get variables to run main function
def initProcess(spark, processController, log):
    log.info("Fetch Parameters from Processor Driver")
    try:
        act_syn_loc = processController.get("activity_synonyms_location")  # vv_db.vv_activity_affinity_synonyms
        sail_syn_loc = processController.get("sailor_synonyms_location")  # vv_db.vv_sailor_affinity_synonyms_tmp
        act_syn_fields = processController.get("activity_synonyms_fields")  # id_activity,activity_synonyms
        sail_syn_fields = processController.get("sailor_synonyms_fields")  # id_seaware,sailor_synonyms
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (act_syn_loc|sail_syn_loc|act_syn_fields|sail_syn_fields) ")
    return process(spark, log)


def process(spark, log):
    log.info("Get Match Scores...")
    return get_match_scores(log, spark)


def store(processController, match_scores, log):
    path_core = processController.get("path_match_scores")
    log.info("Save the results in hive as %s" % path_core)
    match_scores.write.mode('overwrite').format("parquet").save(path_core)

    path_staging = processController.get("path_match_scores_staging")
    log.info("Save the results in hive as %s" % path_staging)
    match_scores.write.mode('overwrite').format("parquet").save(path_staging)


def stopSparkSession(spark, log):
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calculate_Match_Scores")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    match_scores = initProcess(spark, processController, log)
    store(processController, match_scores, log)
    stopSparkSession(spark, log)


####################################################
#                                                  #
# Outputs:                                         #
#    Intermediate Table:                           #
#       vv_db.vv_synonyms_match_scores             #
#          Format:                                 #
#             id_seaware              :STRING      #
#             activity_sailor_scores  :STRING      #
#             time_stamp              :STRING      #
#             date_stamp              :TIMESTAMP   #
#             probability             :STRING      #
#             rev_per_act             :STRING      #
#             rev_scores              :STRING      #
#             aff_rev_new_rank        :STRING      #
#                                                  #
####################################################

