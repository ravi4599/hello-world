#####################################
#                                   #
# Inputs:                           #
#   3rd Party Datazapp Data         #
#      Format:                      #
#         id_seaware  :STRING       #
#         attr1       :STRING       #
#         attr2       :STRING       #
#          ..         :...          #
#         attr160     :STRING       #
#                                   #
#                                   #
# Spark Submit Script:              #
#   spark-submit --name             #
# Calculate_sailor_synonyms         #
# --num-executors 4                 #
# --executor-memory 4G              #
# --driver-memory 4G                #
# --executor-cores 8                #
# --master yarn                     #
# --deploy-mode cluster             #
# /tmp/py_scripts/calculate_        #
# synonyms_sailor_data.py           #
#                                   #
#####################################

from pyspark.sql.types import *
from pyspark.sql.functions import udf, col, explode, lit, regexp_replace, from_unixtime
from pyspark.sql import SparkSession

import nltk

import re, traceback, logging, time


spark = SparkSession \
    .builder \
    .appName("Calculate_Sailor_synonyms") \
    .enableHiveSupport() \
    .getOrCreate()
spark.conf.set("spark.sql.shuffle.partitions", "50")


##########################
#                        #
#    Define Functions    #
#                        #
##########################


# Remove stopwords
def special_car(x):
    # remove the special character and replace them with the stop word " " (space)
    return re.sub('[^A-Za-z0-9]+', ' ', x)

# Create UDF from function
udf_special_car = udf(special_car, StringType())


udf_tokenize_keyword = udf(lambda x: nltk.tokenize.word_tokenize(x), ArrayType(StringType()))


udf_stemming_func = udf(lambda x: nltk.stem.snowball.SnowballStemmer("english").stem(x), StringType())


# Function to remove stops words
def stop_words(word):
    return word.lower() if word.lower() not in nltk.corpus.stopwords.words("english") else None

# Create UDF from function
udf_stop_words = udf(stop_words, StringType())


def synonyms_fnc(word):
    a = []
    synset = nltk.corpus.wordnet.synsets(word)
    # If there are synonyms...
    if len(synset) > 0:
        for syn in synset:
            for syn_lemma in syn.lemma_names():
                a.append(syn_lemma)
    # If no synonyms, keep the original word
    else:
        a.append(word)
    return list(a)

udf_synonyms_fnc = udf(synonyms_fnc, ArrayType(StringType()))


# Convert column names to attributes
def to_long(df, by):
    # Filter dtypes and split into column names and type description
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in by))
    # Spark SQL supports only homogeneous columns
    assert len(set(dtypes)) == 1, "All columns have to be of the same type"

    # Create and explode an array of (column_name, column_value) structs
    kvs = explode(array([
        struct(lit(c).alias("keys"), col(c).alias("val")) for c in cols
    ])).alias("kvs")

    return df.select(by + [kvs]).select(by + ["kvs.keys", "kvs.val"])


def sailor_attributes_to_affinities(input_location, testing_limit, attributes):
    #########################################
    #                                       #
    #    Create Sailor Attributes Table     #
    #                                       #
    #########################################


    log.info("Importing data from %s" % input_location)
    # Load Data
    data = spark.sql("select %s from {} where sequence is not null LIMIT {}".format(input_location,testing_limit) % (attributes))
    data = data.withColumnRenamed("sequence", "id_seaware")


    log.info("Filling Data with NAs")
    # Fill NAs
    data = data.na.fill(0,data.columns[1:])


    log.info("Creating key,value pairs out of the column's name and value" )
    # Create key,value pairs out of the column's name and value
    data_transpose = to_long(data, ["id_seaware"])


    log.info("Only select the columns with a value of 1")
    # Only select the columns with a value of 1
    data_transpose_1s = data_transpose.where(data_transpose.val == 1)


    log.info("Group all the keywords together")
    # Group all the keywords together
    # data_transpose_1s_final = data_transpose_1s.groupby("id_seaware").agg(F.concat_ws(", ", F.collect_list(data_transpose_1s.key)).alias("listofkeys"))


    log.info("Select and rename appropriate columns")
    # Group all the keywords together
    data_transpose_1s_final_1 = data_transpose_1s.select("id_seaware", col("keys").alias("Keywords"))


    return data_transpose_1s_final_1


def get_synonyms(log, spark, df_attrs):


    log.info("Removing special characters")
    # Remove special characters
    df_no_special_chars = df_attrs.withColumn('keywords_no_special_chars', regexp_replace(col("Keywords"), '[^A-Za-z0-9]+', " "))


    ############################################
    ##                                        ##
    ##        Start 1st Step - Synonym        ##
    ##                                        ##
    ############################################
    log.info("Starting 1st Step Synonyms...")


    log.info("Tokenizing Keywords")
    df_tokenized_keywords = df_no_special_chars.withColumn('tokenized_keywords', explode(udf_tokenize_keyword(df_no_special_chars.keywords_no_special_chars)))


    log.info("Stemming words")
    # Stemming words
    df_stemmed_keywords = df_tokenized_keywords.withColumn('stemmed_keywords', udf_stemming_func(df_tokenized_keywords.tokenized_keywords))


    log.info("Remove Stop words & Nulls")
    # Remove stop works.
    df_removed_stop_words = df_stemmed_keywords.withColumn('removed_stop_words', udf_stop_words(df_stemmed_keywords.stemmed_keywords)).where(col('removed_stop_words').isNotNull()) #.select("keywords_with_nulls", "id_seaware")


    log.info("Getting Synonyms...")
    # Get synonyms
    df_synonyms = df_removed_stop_words.withColumn('synonyms', explode(udf_synonyms_fnc(df_removed_stop_words.removed_stop_words)))

    log.info("Ending 1st Step Synonyms...")

    ##########################################
    ##                                      ##
    ##        End 1st Step - Synonym        ##
    ##                                      ##
    ##########################################
    log.info("Starting 2nd Step Synonyms...")


    log.info("Removing Duplicates...")
    # Remove Dupes
    df_synonyms = df_synonyms.select("id_seaware", "synonyms").distinct()


    ############################################
    ##                                        ##
    ##        Start 2nd Step - Synonym        ##
    ##                                        ##
    ############################################


    log.info("Tokenizing Keywords")
    df_syns_tokenized_keywords = df_synonyms.withColumn('tokenized_keywords2', explode(udf_tokenize_keyword(df_synonyms.synonyms)))


    log.info("Stemming words")
    # Stemming words
    df_syns_stemmed_keywords = df_syns_tokenized_keywords.withColumn('stemmed_keywords2', udf_stemming_func(df_syns_tokenized_keywords.tokenized_keywords2))


    log.info("Remove Stop words & Nulls")
    # Remove stop works
    df_syns_removed_stop_words = df_syns_stemmed_keywords.withColumn('removed_stop_words2', udf_stop_words(df_syns_stemmed_keywords.stemmed_keywords2)).where(col('removed_stop_words2').isNotNull()) #.select("keywords_with_nulls", "id_seaware")


    log.info("Getting Synonyms...")
    # Get synonyms
    df_syns_synonyms = df_syns_removed_stop_words.withColumn('synonyms', explode(udf_synonyms_fnc(df_syns_removed_stop_words.removed_stop_words2)))


    log.info("Ending 2nd Step Synonyms...")

    ##########################################
    ##                                      ##
    ##        End 2nd Step - Synonym        ##
    ##                                      ##
    ##########################################


    log.info("Removing Duplicates...")
    # Remove Dupes
    df_syns_synonyms = df_syns_synonyms.select("id_seaware", "synonyms").distinct() \
        .withColumn("time_stamp", lit(str(time.time()))) \
        .withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss')) \
        .select(["id_seaware", "synonyms", "time_stamp", col("date_stamp").cast(TimestampType())])


    return df_syns_synonyms


# Initialize Spark Session
def initSparkSession(appName):
    spark = SparkSession \
        .builder \
        .appName(appName) \
        .enableHiveSupport() \
        .getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", "50")
    return spark


def get_logger():
    log = logging.getLogger('Spark')
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
    log.addHandler(_h)
    log.setLevel(logging.DEBUG)
    log.info("module imported and logger initialized")
    return log


def loadProcessDriver(spark, log, db_name):
    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='SailorSynonyms'".format(db_name)
    log.info(query_string)
    dic = {}
    try:
        out = spark.sql(query_string).collect()
        m = map(lambda x: (x[0], x[1]), out)
        dic = dict(m)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return dic


# Get variables to run main function
def initProcess(spark, processController, log):
    log.info("Fetch Parameters from Processor Driver")
    try:
        input_location = processController.get("input_location")
        testing_limit = int(processController.get("testing_limit")) # 100K? 1M? For testing
        attributes = processController.get("attributes")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (input_location_test|testing_limit|attributes)")

    return process(spark, log, input_location, testing_limit, attributes)


def process(spark, log, input_location, testing_limit, attributes):
    log.info("Calculating Sailor Synonyms")
    df_attrs = sailor_attributes_to_affinities(input_location, testing_limit, attributes)
    return get_synonyms(log, spark, df_attrs)


def store(processController, sailor_synonyms, log):
    path_core = processController.get("path_sailor_synonyms")
    log.info("Save the results in hive as %s" % path_core)
    print("Saving to core path: ", path_core)
    sailor_synonyms.write.mode('overwrite').format("parquet").save(path_core)

    path_staging = processController.get("path_sailor_synonyms_staging")
    log.info("Save the results in hive as %s" % path_staging)
    print("Saving to staging path: ", path_staging)
    sailor_synonyms.write.mode('overwrite').format("parquet").save(path_staging)


def stopSparkSession(spark, log):
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calculate_Sailor_synonyms")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    sailor_synonyms = initProcess(spark, processController, log)
    store(processController, sailor_synonyms, log)
    stopSparkSession(spark, log)


###############################################
#                                             #
# Outputs:                                    #
#    Intermediate Table:                      #
#                                             #
#       vv_db.vv_synonyms_sailor_affinities   #
#          Format:                            #
#             id_seaware        :STRING       #
#             sailor_synonyms   :STRING       #
#             time_stamp        :STRING       #
#             date_stamp        :TIMESTAMP    #
#                                             #
###############################################

