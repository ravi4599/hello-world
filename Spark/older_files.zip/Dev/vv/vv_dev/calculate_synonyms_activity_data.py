###################################################
#                                                 #
# Inputs:                                         #
#   Activity Data from Seaware (JSON or XML)      #
#   This will most likely be acquired             #
#    through an OTA call.                         #
#      Format:                                    #
#          Title                    :STRING       #
#          Short description        :STRING       #
#          Long description         :STRING       #
#          Start date/time          :STRING       #
#          End date/time            :STRING       #
#          Capacity                 :STRING       #
#          Activity Type            :STRING       #
#          Price                    :STRING       #
#          VoyageID                 :STRING       #
#          Package Type             :STRING       #
#          Package Code             :STRING       #
#          Destination/Port         :STRING       #
#          Status                   :STRING       #
#          Internal Comments        :STRING       #
#          Tribe(s) Categorization  :STRING       #
#          Invitation Only          :STRING       #
#          Signature Event          :STRING       #
#                                                 #
#                                                 #
# Spark Submit Script:                            #
#   spark-submit --name Calculate_activity_       #
# synonyms                                        #
#  --num-executors 4 --executor-memory 4G         #
# --driver-memory 4G --executor-cores 8           #
# --master yarn --deploy-mode cluster             #
# /tmp/py_scripts/calculate_synonyms_             #
# activity_data.py                                #
###################################################


from pyspark.sql.types import *
from pyspark.sql.functions import udf, col, explode, lit, regexp_replace, from_unixtime
from pyspark.sql import SparkSession

import nltk

import re, traceback, logging, time


spark = SparkSession \
    .builder \
    .appName("Calculate_Activity_synonyms") \
    .enableHiveSupport() \
    .getOrCreate()
spark.conf.set("spark.sql.shuffle.partitions", "50")


##########################
#                  		 #
#    Define Functions    #
# 						 #
##########################


# Remove stopwords
def special_car(x):
    # remove the special character and replace them with the stop word " " (space)
    return re.sub('[^A-Za-z0-9]+', ' ', x)

# Create UDF from function
udf_special_car = udf(special_car, StringType())


udf_tokenize_keyword = udf(lambda x: nltk.tokenize.word_tokenize(x), ArrayType(StringType()))


udf_stemming_func = udf(lambda x: nltk.stem.snowball.SnowballStemmer("english").stem(x), StringType())


# Function to remove stops words
def stop_words(word):
    return word.lower() if word.lower() not in nltk.corpus.stopwords.words("english") else None

# Create UDF from function
udf_stop_words = udf(stop_words, StringType())


def synonyms_fnc(word):
    a = []
    synset = nltk.corpus.wordnet.synsets(word)
    # If there are synonyms...
    if len(synset) > 0:
        for syn in synset:
            for syn_lemma in syn.lemma_names():
                a.append(syn_lemma)
    # If no synonyms, keep the original word
    else:
        a.append(word)
    return list(a)

udf_synonyms_fnc = udf(synonyms_fnc, ArrayType(StringType()))


def get_synonyms(log, spark, input_location, testing_limit, attributes):


    df_input = spark.sql("SELECT {} FROM {} LIMIT {}".format(attributes, input_location, testing_limit))


    log.info("Removing special characters")
    # Remove special characters
    df_no_special_chars = df_input.withColumn('keywords_no_special_chars', regexp_replace(col("title"), '[^A-Za-z0-9]+', " "))


    ############################################
    ##                                        ##
    ##        Start 1st Step - Synonym        ##
    ##                                        ##
    ############################################
    log.info("Starting 1st Step Synonyms...")


    log.info("Tokenizing Keywords")
    df_tokenized_keywords = df_no_special_chars.withColumn('tokenized_keywords', explode(udf_tokenize_keyword(df_no_special_chars.keywords_no_special_chars)))


    log.info("Stemming words")
    # Stemming words
    df_stemmed_keywords = df_tokenized_keywords.withColumn('stemmed_keywords', udf_stemming_func(df_tokenized_keywords.tokenized_keywords))


    log.info("Remove Stop words & Nulls")
    # Remove stop works.
    df_removed_stop_words = df_stemmed_keywords.withColumn('removed_stop_words', udf_stop_words(df_stemmed_keywords.stemmed_keywords)).where(col('removed_stop_words').isNotNull()) #.select("keywords_with_nulls", "id_seaware")


    log.info("Getting Synonyms...")
    # Get synonyms
    df_synonyms = df_removed_stop_words.withColumn('synonyms', explode(udf_synonyms_fnc(df_removed_stop_words.removed_stop_words)))

    log.info("Ending 1st Step Synonyms...")

    ##########################################
    ##                                      ##
    ##        End 1st Step - Synonym        ##
    ##                                      ##
    ##########################################
    log.info("Starting 2nd Step Synonyms...")


    log.info("Removing Duplicates...")
    # Remove Dupes
    df_synonyms = df_synonyms.select("id_activity", "synonyms").distinct()


    ############################################
    ##                                        ##
    ##        Start 2nd Step - Synonym        ##
    ##                                        ##
    ############################################


    log.info("Tokenizing Keywords")
    df_syns_tokenized_keywords = df_synonyms.withColumn('tokenized_keywords2', explode(udf_tokenize_keyword(df_synonyms.synonyms)))


    log.info("Stemming words")
    # Stemming words
    df_syns_stemmed_keywords = df_syns_tokenized_keywords.withColumn('stemmed_keywords2', udf_stemming_func(df_syns_tokenized_keywords.tokenized_keywords2))


    log.info("Remove Stop words & Nulls")
    # Remove stop works
    df_syns_removed_stop_words = df_syns_stemmed_keywords.withColumn('removed_stop_words2', udf_stop_words(df_syns_stemmed_keywords.stemmed_keywords2)).where(col('removed_stop_words2').isNotNull())


    log.info("Getting Synonyms...")
    # Get synonyms
    df_syns_synonyms = df_syns_removed_stop_words.withColumn('synonyms', explode(udf_synonyms_fnc(df_syns_removed_stop_words.removed_stop_words2)))


    log.info("Ending 2nd Step Synonyms...")

    ##########################################
    ##                                      ##
    ##        End 2nd Step - Synonym        ##
    ##                                      ##
    ##########################################


    log.info("Removing Duplicates...")
    # Remove Dupes
    df_syns_synonyms = df_syns_synonyms.select("id_activity", "synonyms").distinct() \
        .withColumn("time_stamp", lit(str(time.time()))) \
        .withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss')) \
        .select(["id_activity", "synonyms", "time_stamp", col("date_stamp").cast(TimestampType())])

    return df_syns_synonyms


# Initialize Spark Session
def initSparkSession(appName):
    spark = SparkSession \
        .builder \
        .appName(appName) \
        .enableHiveSupport() \
        .getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", "50")
    return spark


def get_logger():
    log = logging.getLogger('Spark')
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
    log.addHandler(_h)
    log.setLevel(logging.DEBUG)
    log.info("module imported and logger initialized")
    return log


def loadProcessDriver(spark, log, db_name):
    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='ActivitySynonyms'".format(db_name)
    log.info(query_string)
    dic = {}
    try:
        out = spark.sql(query_string).collect()
        m = map(lambda x: (x[0], x[1]), out)
        dic = dict(m)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return dic


# Get variables to run main function
def initProcess(spark, processController, log):
    log.info("Fetch Parameters from Processor Driver")
    try:
        input_location = processController.get("input_location")  # vv_db.dummy_activity_data
        testing_limit = int(processController.get("testing_limit"))  # 100K? 1M? For testing
        attributes = processController.get("attributes")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (input_location|testing_limit|) ")
    return process(spark, log, input_location, testing_limit, attributes)


def process(spark, log, input_location, testing_limit, attributes):
    log.info("Calculating input_location")
    return get_synonyms(log, spark, input_location, testing_limit, attributes)


def store(processController, activity_synonyms, log):
    path_core = processController.get("path_activity_synonyms")
    log.info("Save the results in hive as %s" % path_core)
    print("Saving to core path: ", path_core)
    activity_synonyms.write.mode('overwrite').format("parquet").save(path_core)

    path_staging = processController.get("path_activity_synonyms_staging")
    log.info("Save the results in hive as %s" % path_staging)
    print("Saving to staging path: ", path_staging)
    activity_synonyms.write.mode('overwrite').format("parquet").save(path_staging)


def stopSparkSession(spark, log):
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calculate_Activity_synonyms")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    activity_synonyms = initProcess(spark, processController, log)
    store(processController, activity_synonyms, log)
    stopSparkSession(spark, log)


################################################
#                                              #
# Outputs:                                     #
#    Intermediate Table:                       #
#       vv_db.vv_synonyms_activity_affinities  #
#          Format:                             #
#             id_activity         :STRING      #
#             activity_synonyms   :STRING      #
#             time_stamp          :STRING      #
#             date_stamp          :TIMESTAMP   #
#                                              #
################################################
