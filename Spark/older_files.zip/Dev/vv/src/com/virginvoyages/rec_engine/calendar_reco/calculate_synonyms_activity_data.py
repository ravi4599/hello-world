###################################################
#                                                 #
# Inputs:                                         #
#   Activity Data from Seaware (JSON or XML)      #
#   This will most likely be acquired             #
#    through an OTA call.                         #
#      Format:                                    #
#          Title                    :STRING       #
#          Short description        :STRING       #
#          Long description         :STRING       #
#          Start date/time          :STRING       #
#          End date/time            :STRING       #
#          Capacity                 :STRING       #
#          Activity Type            :STRING       #
#          Price                    :STRING       #
#          VoyageID                 :STRING       #
#          Package Type             :STRING       #
#          Package Code             :STRING       #
#          Destination/Port         :STRING       #
#          Status                   :STRING       #
#          Internal Comments        :STRING       #
#          Tribe(s) Categorization  :STRING       #
#          Invitation Only          :STRING       #
#          Signature Event          :STRING       #
#                                                 #
#                                                 #
# Spark Submit Script:                            #
#   spark-submit --name Calculate_activity_       #
# synonyms                                        #
#  --num-executors 4 --executor-memory 4G         #
# --driver-memory 4G --executor-cores 8           #
# --master yarn --deploy-mode cluster             #
# /tmp/py_scripts/calculate_synonyms_             #
# activity_data.py                                #
###################################################


from pyspark.sql.types import *
from pyspark.sql.functions import udf, col, explode, lit, regexp_replace, from_unixtime, split
from pyspark.sql import SparkSession

import nltk

import re, traceback, logging, time
from itertools import chain

spark = SparkSession \
    .builder \
    .appName("Calculate_Activity_synonyms") \
    .enableHiveSupport() \
    .getOrCreate()
spark.conf.set("spark.sql.shuffle.partitions", "50")


##########################
#                                #
#    Define Functions    #
#                                                #
##########################


# Remove stopwords
def special_car(x):
    """ Replace non-alphanumeric characters with a ' '

    :param x    : input string
    :return     : string with only alphanumeric characters
    """

    # remove the special character and replace them with the stop word " " (space)
    return list(re.sub('[^A-Za-z0-9]+', ' ', x))

# Create UDF from function
udf_special_car = udf(special_car, ArrayType(StringType()))


def tokenize_keyword(word_list):
    # if(len(word_list) >1):
    lst = []
    for word in word_list:
        lst.append(nltk.tokenize.word_tokenize(word))
    flat_list = [item for sublist in lst for item in sublist]
    return flat_list

udf_tokenize_keyword = udf(tokenize_keyword, ArrayType(StringType()))


def stemming_func(word_list):
    return list(nltk.stem.snowball.SnowballStemmer("english").stem(word) for word in word_list)

udf_stemming_func = udf(stemming_func, ArrayType(StringType()))


# Function to remove stops words
def stop_words(words):
    """ Remove stops words - If a word is in nltk's list of English stop words, remove it
        Ex: ['Cat', 'sat', 'on', 'the', 'mat'] => ['Cat', 'sat', '', '', 'mat']

    :param word : Tokenized word
    :return     : If the word is a stop word, return None, else return the input word
    """

    stop_words_list = nltk.corpus.stopwords.words("english")
    # return list(word.lower() if word.lower() not in stop_words_list)
    # return list(word.lower() for words in word_list for word in words if word.lower() not in stop_words_list)
    return list(word.lower() for word in words if word.lower() not in stop_words_list)

# Create UDF from function
udf_stop_words = udf(lambda x: stop_words(x), ArrayType(StringType()))


def synonyms_fnc(word_list):
    """ Collects all synonyms for the input word into a list.
        If no synonyms exist, the input word is returned in a list.

    :param word : Tokenized word
    :return     : A list of all the synonyms available for the given word.
                  If no synonyms exist, the input word is returned in a list.
    """

    a = []
    for word in word_list:
        synset = nltk.corpus.wordnet.synsets(word)
        # If there are synonyms...
        if len(synset) > 0:
            a.append(list(chain.from_iterable((syn.lemma_names() for syn in synset))))
    # If no synonyms, keep the original word
        else:
            a.append([word])
    flat_list = [item for sublist in a for item in sublist]
    return list(set(flat_list))

udf_synonyms_fnc = udf(synonyms_fnc, ArrayType(StringType()))


def prepare_data(log, spark, input_location, testing_limit, attributes):
    """ Prepares the input into a form that can be consumed by the get_synonyms function. The intention is to keep
    all get_synonym functions identical.

    NOTE - We do not as of yet know what the input activity data will look like, so this function will most
           likely change

    :param log              : current logger
    :param spark            : current SparkSession
    :param input_location   : name of activity data table
    :param testing_limit    : limit to use for testing
    :param attributes       : relevant columns to select from activity data table
    :return                 : Spark Dataframe with columns : [id, keywords]
    """
    try:
        log.info("Importing data from {}".format(input_location))
        prepared_data = spark.sql("SELECT {} FROM {} LIMIT {}".format(attributes, input_location, testing_limit))
        prepared_data = prepared_data.withColumnRenamed("title", "keywords")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code : Error reading data from {}. Please review (attributes|input_location|testing_limit) for errors. ".format(input_location))

    return prepared_data


def get_synonyms(log, spark, df_prepared_data):
    """

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param df_prepared_data     : Spark Dataframe with columns : [id, keywords]
    :return                     : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_activity is the activity's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

	try:
        df_input = df_prepared_data


        log.info("Replace Special Characters with ' '")
        # Replace Special Characters with ' '
        df_no_special_chars = df_input.withColumn('keywords_no_special_chars', regexp_replace(col("keywords"), '[^A-Za-z0-9]+', " "))


		############################################
		##                                        ##
		##        Start 1st Step - Synonym        ##
		##                                        ##
		############################################
		log.info("Starting 1st Step Synonyms...")


		log.info("Tokenizing Keywords")
		df_tokenized_keywords = df_no_special_chars.withColumn('tokenized_keywords', udf_tokenize_keyword(df_no_special_chars.keywords_no_special_chars))
		# df_tokenized_keywords.show(20, truncate=False)

		log.info("Stemming words")
		# Stemming words
		df_stemmed_keywords = df_tokenized_keywords.withColumn('stemmed_keywords', udf_stemming_func(df_tokenized_keywords.tokenized_keywords))
		# df_stemmed_keywords.show(20, truncate=False)

		log.info("Remove Stop words & Nulls")
		# Remove stop works.
		df_removed_stop_words = df_stemmed_keywords.withColumn('removed_stop_words', udf_stop_words(df_stemmed_keywords.stemmed_keywords)).where(col('removed_stop_words').isNotNull()) #.select("keywords_with_nulls", "id_seaware")
		# df_removed_stop_words.show(20, truncate=False)

		log.info("Getting Synonyms...")
		# Get synonyms
		df_synonyms = df_removed_stop_words.withColumn('synonyms', udf_synonyms_fnc(df_removed_stop_words.removed_stop_words))
		# df_synonyms.show(20, truncate=False)
		log.info("Ending 1st Step Synonyms...")

		##########################################
		##                                      ##
		##        End 1st Step - Synonym        ##
		##                                      ##
		##########################################
		log.info("Starting 2nd Step Synonyms...")


		log.info("Removing Duplicates...")
		# Remove Dupes
		df_synonyms = df_synonyms.select("id_activity", "synonyms").distinct()
		# df_synonyms.show(20, truncate = False)

		############################################
		##                                        ##
		##        Start 2nd Step - Synonym        ##
		##                                        ##
		############################################


		log.info("Tokenizing Keywords")
		df_syns_tokenized_keywords = df_synonyms.withColumn('tokenized_keywords2', udf_tokenize_keyword(df_synonyms.synonyms))
		# df_syns_tokenized_keywords.show()

		log.info("Stemming words")
		# Stemming words
		df_syns_stemmed_keywords = df_syns_tokenized_keywords.withColumn('stemmed_keywords2', udf_stemming_func(df_syns_tokenized_keywords.tokenized_keywords2))
		# df_syns_stemmed_keywords.show()

		log.info("Remove Stop words & Nulls")
		# Remove stop works
		df_syns_removed_stop_words = df_syns_stemmed_keywords.withColumn('removed_stop_words2', udf_stop_words(df_syns_stemmed_keywords.stemmed_keywords2)).where(col('removed_stop_words2').isNotNull())
		# df_syns_removed_stop_words.show()

		log.info("Getting Synonyms...")
		# Get synonyms
		df_syns_synonyms = df_syns_removed_stop_words.withColumn('synonyms', explode(udf_synonyms_fnc(df_syns_removed_stop_words.removed_stop_words2)))
		# df_syns_synonyms.show()

		log.info("Ending 2nd Step Synonyms...")

		##########################################
		##                                      ##
		##        End 2nd Step - Synonym        ##
		##                                      ##
		##########################################


		log.info("Removing Duplicates...")
		# Remove Dupes
		df_syns_synonyms = df_syns_synonyms.select("id_activity", "synonyms").distinct() \
			.withColumn("time_stamp", lit(str(time.time()))) \
			.withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss')) \
			.select(["id_activity", "synonyms", "time_stamp", col("date_stamp").cast(TimestampType())])

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the input data to ensure it is proper.")

    return df_syns_synonyms


# Initialize Spark Session
def initSparkSession(appName):
    """ Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """ Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='ActivitySynonyms'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


# Get variables to run main function
def initProcess(spark, processController, log):
    """ Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_activity is the activity's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        input_location = processController.get("input_location")  # vv_db.dummy_activity_data
        testing_limit = int(processController.get("testing_limit"))  # 100K? 1M? For testing
        attributes = processController.get("attributes")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (input_location|testing_limit|attributes) ")

    return process(log, spark, input_location, testing_limit, attributes)


def process(log, spark, input_location, testing_limit, attributes):
    """ Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param input_location       : name of activity data table
    :param testing_limit        : limit to use for testing
    :param attributes           : Relevant columns to select from activity data table
    :return                     : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_activity is the activity's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Calculating input_location")
    df_prepared_data = prepare_data(input_location, testing_limit, attributes)
    return get_synonyms(log, spark, df_prepared_data)


def store(processController, log, activity_synonyms):
    """ Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param activity_synonyms    : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    :return                     : N/A
    """

    try:
        path_core = processController.get("path_activity_synonyms")
        path_staging = processController.get("path_activity_synonyms_staging")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")

    try:
        log.info("Save the results in hive as %s" % path_core)
        activity_synonyms.write.mode('overwrite').format("parquet").save(path_core)

        log.info("Save the results in hive as %s" % path_staging)
        activity_synonyms.write.mode('overwrite').format("parquet").save(path_staging)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}|{}) ".format(path_core, path_staging))


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calculate_Activity_synonyms")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    activity_synonyms = initProcess(spark, processController, log)
    store(processController, log, activity_synonyms)
    stopSparkSession(log, spark)


################################################
#                                              #
# Outputs:                                     #
#    Intermediate Table:                       #
#       vv_db.vv_synonyms_activity_affinities  #
#          Format:                             #
#             id_activity         :STRING      #
#             activity_synonyms   :STRING      #
#             time_stamp          :STRING      #
#             date_stamp          :TIMESTAMP   #
#                                              #
################################################

