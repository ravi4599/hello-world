
from pyspark.sql.types import *
from pyspark.sql.functions import udf, col, explode, lit, regexp_replace, from_unixtime, split

import nltk
# from nltk.corpus import wordnet
# from nltk.stem.wordnet import WordNetLemmatizer


import re, traceback, time
from itertools import chain

##########################
#                        #
#    Define Functions    #
#                        #
##########################


# Remove stopwords
def special_car(x):
    """ Replace non-alphanumeric characters with a ' '

    :param x    : input string
    :return     : string with only alphanumeric characters
    """

    # remove the special character and replace them with the stop word " " (space)
    return list(re.sub('[^A-Za-z0-9]+', ' ', x))

# Create UDF from function
udf_special_car = udf(special_car, ArrayType(StringType()))


# Tokenize words - Break a string into individual elements based on spaces
# Ex: "Cat sat on the mat" => ['Cat', 'sat', 'on', 'the', 'mat']
def tokenize_keyword(word_list):
    """ Split a group of words into a list of individual words (tokens) where there are spaces

    :param word_list    : a group of words as a string
    :return             : a list of words
    """
    lst = list(map(lambda x: nltk.tokenize.word_tokenize(x), word_list))
    flat_list = [item for sublist in lst for item in sublist]
    return flat_list

udf_tokenize_keyword = udf(tokenize_keyword, ArrayType(StringType()))


lmtzr = nltk.stem.wordnet.WordNetLemmatizer()

def lemming_verb_func(lst):
    return list(map(lambda x: lmtzr.lemmatize(x, 'v'), lst))
udf_lemming_verb_func = udf(lemming_verb_func, ArrayType(StringType()))


def lemming_noun_func(lst):
    return list(map(lambda x: lmtzr.lemmatize(x, 'n'), lst))
udf_lemming_noun_func = udf(lemming_noun_func, ArrayType(StringType()))


# Stem words - Remove affixes from words, leaving only the stem
# Ex: "Having" => "Have", "Wanted" => "Want", "Quickly" => "Quick"
def stemming_func(word_list):
    """ Remove affixes from words, leaving only the stem/root word

    :param word_list    : a list of words
    :return             : a stemmed list of words
    """
    return list(nltk.stem.snowball.SnowballStemmer("english").stem(word) for word in word_list)

udf_stemming_func = udf(stemming_func, ArrayType(StringType()))


# Function to remove stops words
def stop_words(words):
    """ Remove stops words - If a word is in nltk's list of English stop words, remove it
        Ex: ['Cat', 'sat', 'on', 'the', 'mat'] => ['Cat', 'sat', '', '', 'mat']

    :param word : Tokenized word
    :return     : If the word is a stop word, return None, else return the input word
    """

    stop_words_list = nltk.corpus.stopwords.words("english")
    return list(word.lower() for word in words if word.lower() not in stop_words_list)

# Create UDF from function
udf_stop_words = udf(lambda x: stop_words(x), ArrayType(StringType()))


def synonyms_fnc(word_list):
    """ Collects all synonyms for the input word into a list.
        If no synonyms exist, the input word is returned in a list.

    :param word : Tokenized word
    :return     : A list of all the synonyms available for the given word.
                  If no synonyms exist, the input word is returned in a list.
    """

    a = []
    for word in word_list:
        synset = nltk.corpus.wordnet.synsets(word)
        # If there are synonyms...
        if len(synset) > 0:
            a.append(list(chain.from_iterable((syn.lemma_names() for syn in synset))))
    # If no synonyms, keep the original word
        else:
            a.append([word])
    flat_list = [item for sublist in a for item in sublist]
    return list(set(flat_list))

udf_synonyms_fnc = udf(synonyms_fnc, ArrayType(StringType()))


def get_synonyms(log, spark, df_input, id):
    """

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param df_prepared_data     : Spark Dataframe with columns : [id, keywords]
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the activity's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    try:
        log.info("Replace Special Characters with ' '")
        # Replace Special Characters with ' '
        df_no_special_chars = df_input \
            .withColumn('keywords_no_special_chars', split(regexp_replace(col("keywords"), '[^A-Za-z0-9]+', " "), '-'))


        ############################################
        ##                                        ##
        ##        Start 1st Step - Synonym        ##
        ##                                        ##
        ############################################
        log.info("Starting 1st Step Synonyms...")

        log.info("Tokenizing Keywords")
        df_tokenized_keywords = df_no_special_chars \
            .withColumn('tokenized_keywords', udf_tokenize_keyword(df_no_special_chars.keywords_no_special_chars))
        

        log.info("Lemming words - Verbs")
        # Lemmatizing Verbs
        df_lemmed_verbs = df_tokenized_keywords.withColumn('lemmed_keywords_verbs', udf_lemming_verb_func(df_tokenized_keywords.tokenized_keywords))


        log.info("Lemming words - Nouns")
        # Lemmatizing Nouns
        df_lemmed_nouns = df_lemmed_verbs.withColumn('lemmed_keywords_nouns', udf_lemming_noun_func(df_lemmed_verbs.lemmed_keywords_verbs))
        
        
        log.info("Remove Stop words & Nulls")
        # Remove stop works.
        df_removed_stop_words = df_lemmed_nouns \
            .withColumn('removed_stop_words', udf_stop_words(df_lemmed_nouns.lemmed_keywords_nouns)) \
            .where(col('removed_stop_words').isNotNull())

        log.info("Getting Synonyms...")
        # Get synonyms
        df_synonyms = df_removed_stop_words \
            .withColumn('synonyms', udf_synonyms_fnc(df_removed_stop_words.removed_stop_words))

        log.info("Ending 1st Step Synonyms...")
        ##########################################
        ##                                      ##
        ##        End 1st Step - Synonym        ##
        ##                                      ##
        ##########################################


        log.info("Removing Duplicates...")
        # Remove Dupes
        df_synonyms = df_synonyms.select(id, "synonyms", "keywords").distinct()


        log.info("Starting 2nd Step Synonyms...")
        ############################################
        ##                                        ##
        ##        Start 2nd Step - Synonym        ##
        ##                                        ##
        ############################################


        log.info("Tokenizing Keywords")
        df_syns_tokenized_keywords = df_synonyms \
            .withColumn('tokenized_keywords2', udf_tokenize_keyword(df_synonyms.synonyms))

        log.info("Stemming words")
        # Stemming words
        df_syns_stemmed_keywords = df_syns_tokenized_keywords \
            .withColumn('stemmed_keywords2', udf_stemming_func(df_syns_tokenized_keywords.tokenized_keywords2))

        log.info("Remove Stop words & Nulls")
        # Remove stop works
        df_syns_removed_stop_words = df_syns_stemmed_keywords \
            .withColumn('removed_stop_words2', udf_stop_words(df_syns_stemmed_keywords.stemmed_keywords2)) \
            .where(col('removed_stop_words2').isNotNull())

        log.info("Getting Synonyms...")
        # Get synonyms
        df_syns_synonyms = df_syns_removed_stop_words \
            .withColumn('synonyms', explode(udf_synonyms_fnc(df_syns_removed_stop_words.removed_stop_words2)))
        log.info("Ending 2nd Step Synonyms...")

        ##########################################
        ##                                      ##
        ##        End 2nd Step - Synonym        ##
        ##                                      ##
        ##########################################


        log.info("Removing Duplicates...")
        # Remove Dupes
        df_syns_synonyms = df_syns_synonyms \
            .withColumn("time_stamp", lit(str(time.time()))) \
            .withColumn("date_stamp", from_unixtime("time_stamp", 'yyyy-MM-dd HH:mm:ss')) \
            .dropDuplicates([id, "synonyms"])\
            .select([id, "keywords", "synonyms", "time_stamp", col("date_stamp").cast(TimestampType())])

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the input data to ensure it is proper.")

    return df_syns_synonyms
