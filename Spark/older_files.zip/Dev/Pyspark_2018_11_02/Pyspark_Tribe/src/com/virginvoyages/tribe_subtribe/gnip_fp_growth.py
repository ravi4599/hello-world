##  spark-submit --name Apriori --conf spark.executor.memoryOverhead=10240 --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/apriori_algorithm/apriori_cleaned_up.py

from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.types import *
from geotext import GeoText
from itertools import chain
import nltk
import re, traceback, logging
from pyspark.ml.fpm import FPGrowth


def remove_from_wrapped_array(wrapped_array):
    """
    Converts a wrapped array to an array

    :param wrapped_array    : input wrapped array of items
    :return                 : a list of items
    """
    out_array = []
    for lst in wrapped_array:
        for item in lst:
            if item != '':
                out_array.append(item.replace(" ", ""))
    return out_array

udf_remove_from_wrapped_array = F.udf(remove_from_wrapped_array, ArrayType(StringType()))


def add_pos_tag(word):
    """
    Finds and returns the Part of Speech of in the input word.

    :param word    : input word for which we want to find the Part of Speech Tag
    :return        : the part of speech of the input word
    """
    try:
        return nltk.pos_tag(nltk.word_tokenize(word))[0][1]
    except Exception as e:
        return "null"

udf_add_pos_tag = F.udf(add_pos_tag, StringType())


def loc_tag(word):
    """
    Finds and returns the locatoin tag for the input word

    :param word    : input word for which we want to find the location tag
    :return        : the location tag for the input word
    """
    a = dict(GeoText(word).country_mentions)
    b = {}
    if a != {}:
        return a
    else:
        return None

udf_loc_tag = F.udf(loc_tag, MapType(StringType(),StringType()))


def to_list(word):
    """
    Converts a string to a list of strings

    :param word    : Converts a single string to a list of strings
    :return        : a list of strings
    """
    return [word]

udf_to_list = F.udf(to_list, ArrayType(StringType()))


def synonyms_fnc(word_list):
    """
    Collects all synonyms for the input word into a list.
    If no synonyms exist, the input word is returned in a list.

    :param word : Tokenized word
    :return     : A list of all the synonyms available for the given word.
                  If no synonyms exist, the input word is returned in a list.
    """
    a = []
    for word in word_list:
        synset = nltk.corpus.wordnet.synsets(word)
        # If there are synonyms...
        if len(synset) > 0:
            a.append(list(chain.from_iterable((syn.lemma_names() for syn in synset))))
    # If no synonyms, keep the original word
        else:
            a.append([word])
    flat_list = [item for sublist in a for item in sublist]
    return list(set(flat_list))

udf_synonyms_fnc = F.udf(synonyms_fnc, ArrayType(StringType()))


def filter_syns_func(topic, topic_pos_tag):
    """
    Filters out certain pos tags before finding synonyms for the words

    :param topic_list        : the topic to find synonyms for
    :param topic_pos_tag     : the pos tag for the input topic
    :return                  :
    """
    if(topic_pos_tag not in ["VBN", "CD", "DT", "FW", "PRP$", "PRP", "MD"]):
        return synonyms_fnc(topic)
    else:
        return topic

udf_filter_syns_func = F.udf(filter_syns_func, ArrayType(StringType()))


def string_to_list_of_strings(in_string):
    """
    Converts a list-of-strings which has been converted to a string, back to a list-of-strings

    :param in_string    : input string which used be a list-of-strings but has been converted into a string
    :return             : a list of strings
    """

    list_of_strings = []
    for y in in_string:
        list_of_strings.append(re.sub('[\[,\"\]]+','',y))
    return list_of_strings

udf_string_to_list_of_strings = F.udf(string_to_list_of_strings, ArrayType(StringType()))


def apriori_processing(log, spark, gnip_data, brand_details, attribute_mapping, tweets_data_query, minSupport, minConfidence):
    """

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param gnip_data            : location of the gnip data
    :param brand_details        : location of the brand details document
    :param attribute_mapping    : location of the attribute mapping document
    :return:
    """

    try:
        log.info("Read Vrishalli's table")
        df_twitter_data = spark.sql(gnip_data)\
            .where(F.col("klout_user_id").isNotNull())\
            .withColumnRenamed("topics_displayName", "topic_display_name")\
            .withColumnRenamed("topics_score", "topic_score")\
            .withColumn("prepared_topic_display_name", udf_string_to_list_of_strings(F.split(F.col("topic_display_name"), ",")))

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the Hive table or the connection to Hive.")


    try:
        log.info("Read brand details table")
        df_brand_details = spark\
            .read\
            .option("header", "true")\
            .csv(brand_details)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the Hive table or the connection to Hive.")

    try:
        log.info("Select only brand_name, handle_details, and subtribe")
        df_brand_details_distinct = df_brand_details.select("brand_name", "Handle Details", "SubTribe")\
            .withColumnRenamed("Handle Details", "handle_details")\
            .distinct()


        conditions = ((df_twitter_data.brand_name == df_brand_details_distinct.brand_name) |
                      (df_twitter_data.brand_name == df_brand_details_distinct.handle_details))


        log.info("Group By klout_user_id and collect details for each user")
        df_twitter_data_joined = df_twitter_data \
            .groupBy("klout_user_id", "brand_name") \
            .agg(F.count(F.lit(1)).alias("tweet_count"),
                 F.collect_list('prepared_topic_display_name').alias('prepared_topic_display_name'),
                 F.collect_list('topic_score').alias('topic_score'),
                 F.collect_list('topic_type').alias('topic_type')) \
            .join(F.broadcast(df_brand_details_distinct), conditions) \
            .drop(df_brand_details_distinct.brand_name).drop(df_brand_details_distinct.handle_details) \
            .groupBy("klout_user_id") \
            .agg(F.collect_list("brand_name").alias("brand_name"),
                 F.collect_list("SubTribe").alias("SubTribe"),
                 F.collect_list("tweet_count").alias("tweet_count"),
                 F.collect_list('prepared_topic_display_name')[0].alias('prepared_topic_display_name'),
                 F.collect_list('topic_score')[0].alias('topic_score'),
                 F.collect_list('topic_type')[0].alias('topic_type'))


        log.info("Select only klout_user_id and topics")
        df_topics = df_twitter_data_joined.select("klout_user_id", F.col("prepared_topic_display_name").alias("topics"))


        log.info("Prepare topic data")
        df_exp_topics_not_null = df_topics.withColumn("topic", F.explode(udf_remove_from_wrapped_array(F.col("topics"))))\
            .drop('topics')\
            .where(F.col("topic") != '')\
            .where(F.col("topic").isNotNull())


        log.info("Add Part of Speech Tag")
        df_pos_tag = df_exp_topics_not_null.withColumn("topic_pos_tag", udf_add_pos_tag("topic"))


        log.info("Add country information")
        df_country_info = df_pos_tag.withColumn("country_count",
                             F.when(((F.col("topic_pos_tag") == "NNP") | (F.col("topic_pos_tag") == "NN")),
                                  udf_loc_tag(F.col("topic"))))


        log.info("Prepare Topic data and generate synonyms")
        df_topic_synonyms = df_country_info.withColumn("topic_list", udf_to_list(F.col("topic")))\
            .withColumn("synonyms", udf_filter_syns_func(F.col("topic_list"), F.col("topic_pos_tag")))\
            .withColumn("synonyms2", udf_filter_syns_func(F.col("synonyms"), F.col("topic_pos_tag")))


        log.info("Read Attribute Mappling list")
        df_attrs_list = spark\
            .read\
            .option("header", "True")\
            .csv(attribute_mapping)\
            .select(F.col("Attribute").alias("attribute_value"), F.col("Alternate").alias("alternate"))


        log.info("Explode list of synonyms")
        df_exp_syns = df_topic_synonyms.withColumn("exploded_syns", F.explode(F.col("synonyms2")))


        log.info("Get where there is only 1 synonym")
        df_NoSynonyms = df_exp_syns.filter(F.size(F.col('synonyms2')) == 1)
        df_NoSynonyms_1 = df_NoSynonyms\
            .select("klout_user_id", (F.regexp_replace(F.col("topic"), "~", " ")).alias("topic_no_syn"))


        log.info("Get my tweets data")
        df_attrs_topics = spark.sql(tweets_data_query)
        df_attrs_topics_1 = df_attrs_topics\
            .select("id_seaware", (F.regexp_replace(F.col("Keywords"), "\"", "")).alias("Keywords"))


        log.info("Collate Keywords at a Klout Id Level")
        data_transpose_1s_final = df_attrs_topics_1.groupby("id_seaware").agg(
            F.collect_set(F.col("Keywords")).alias("listofkeywords"))


        log.info("Run the FP Growth Model")
        fpGrowth = FPGrowth(itemsCol="listofkeywords", minSupport=float(minSupport),
                            minConfidence=float(minConfidence))
        model = fpGrowth.fit(data_transpose_1s_final)


        log.info("Display generated association rules")
        df_apriori_results = model.associationRules


        log.info("Choose only the rules which have only one word in the antecent - predominantly the brands")
        df_apriori_results_filtered = df_apriori_results\
            .withColumn("Count_Antecedent", F.size(F.col('antecedent')))\
            .withColumn("Count_Consequent", F.size(F.col('consequent')))\
            .filter(F.col('Count_Antecedent') == 1)


        log.info("Explode Antecedents")
        df_apriori_1 = df_apriori_results_filtered\
            .orderBy(F.col('confidence').desc())\
            .withColumn("antecedent_exp", F.explode(F.col('antecedent')))
        # df_apriori_1.show()

        log.info("Joining results with those with no synonyms")
        df_apriori_final = df_apriori_1\
            .join(df_NoSynonyms_1, df_apriori_1.antecedent_exp == df_NoSynonyms_1.topic_no_syn)\
            .select('antecedent_exp','consequent', 'confidence')\
            .distinct()
        # df_apriori_final.show()


    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the Hive table or the connection to Hive.")

    return df_apriori_final


def initSparkSession(appName):
    """ Initializes the SparkSession
    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='Apriori'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        gnip_data = processController.get("gnip_data")
        brand_details = processController.get("brand_details")
        attribute_mapping = processController.get("attribute_mapping")
        tweets_data_query = processController.get("tweets_data_query")
        minSupport = processController.get("minSupport")
        minConfidence = processController.get("minConfidence")


    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, spark, gnip_data, brand_details, attribute_mapping, tweets_data_query, minSupport, minConfidence)


def process(log, spark, gnip_data, brand_details, attribute_mapping, tweets_data_query, minSupport, minConfidence):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting GNIP Processing...")
    return apriori_processing(log, spark, gnip_data, brand_details, attribute_mapping, tweets_data_query, minSupport, minConfidence)


def store(jn_rule, spark, processController):
    """ Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param activity_synonyms    : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    :return                     : N/A
    """

    try:
        path_core = processController.get("path_apriori")
        path_staging = processController.get("path_apriori_staging")
        drop_table_query = processController.get("drop_table_sql")
        create_table_query = processController.get("create_table_sql")
        check_tbl_exists = processController.get("check_tbl_exists")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")


    try:
        log.info("Save the results in hive as %s" % path_core)
        jn_rule.write.mode('overwrite').format("parquet").save(path_core)

        log.info("Save the results in hive as %s" % path_staging)
        spark.read.parquet(path_core).write.mode('overwrite').format("parquet").save(path_staging)

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 3: Please verify connection to Hive and S3")


    try:
        spark.sql(check_tbl_exists)
        log.info("Table Already Exist, No Need to Create One.")

    except:
        log.info("Table Does Not Exist!")
        log.info("Creating Table from file...")
        log.info(drop_table_query)
        spark.sql(drop_table_query)
        log.info(create_table_query.format(path_core))
        spark.sql(create_table_query.format(path_core))


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Apriori_algorithm")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    jn_rule = initProcess(spark, processController, log)
    store(jn_rule, spark, processController)
    stopSparkSession(log, spark)

