################################################################
#                                                              #
# Inputs:                                                      #
#   Activity Data from Seaware (JSON or XML)                   #
#   This will most likely be acquired                          #
#    through an OTA call.                                      #
#      Format:                                                 #
#          Title                    :STRING                    #
#          Short description        :STRING                    #
#          Long description         :STRING                    #
#          Start date/time          :STRING                    #
#          End date/time            :STRING                    #
#          Capacity                 :STRING                    #
#          Activity Type            :STRING                    #
#          Price                    :STRING                    #
#          VoyageID                 :STRING                    #
#          Package Type             :STRING                    #
#          Package Code             :STRING                    #
#          Destination/Port         :STRING                    #
#          Status                   :STRING                    #
#          Internal Comments        :STRING                    #
#          Tribe(s) Categorization  :STRING                    #
#          Invitation Only          :STRING                    #
#          Signature Event          :STRING                    #
#                                                              #
#                                                              #
# Spark Submit Script:                                         #
#   spark-submit --name Calculate_Content_Activity_Synonyms    #
#   --py-files affinity_synonym_generator.py                   #
#   --conf spark.yarn.executor.memoryOverhead=10240            #
#   --num-executors 20                                         #
#   --executor-memory 8G                                       #
#   --executor-cores 4                                         #
#   --master yarn                                              #
#   --deploy-mode cluster                                      #
#   /tmp/py_scripts/calculate_synonyms_activity_data.py        #
#                                                              #
################################################################


from pyspark.sql import SparkSession
import affinity_synonym_generator

import traceback, logging


##########################
#                        #
#    Define Functions    #
#                        #
##########################


def prepare_data(log, spark, input_location, testing_limit, attributes):
    """ Prepares the input into a form that can be consumed by the get_synonyms function. The intention is to keep
    all get_synonym functions identical.

    NOTE - We do not as of yet know what the input activity data will look like, so this function will most
           likely change

    :param log              : current logger
    :param spark            : current SparkSession
    :param input_location   : name of activity data table
    :param testing_limit    : limit to use for testing
    :param attributes       : relevant columns to select from activity data table
    :return                 : Spark Dataframe with columns : [id, keywords]
    """
    try:
        log.info("Importing data from {}".format(input_location))
        prepared_data = spark.sql("SELECT {} FROM {} LIMIT {}".format(attributes, input_location, testing_limit))
        prepared_data = prepared_data.withColumnRenamed("title", "keywords")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code : Error reading data from {}. Please review (attributes|input_location|testing_limit)"
            "testing_limit) for errors. ".format(input_location))

    return prepared_data


# Initialize Spark Session
def initSparkSession(appName):
    """ Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """ Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='ActivitySynonyms'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


# Get variables to run main function
def initProcess(spark, processController, log):
    """ Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_activity is the activity's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        input_location = processController.get("input_location")  # vv_db.dummy_activity_data
        testing_limit = int(processController.get("testing_limit"))  # 100K? 1M? For testing
        attributes = processController.get("attributes")
        id = processController.get("id")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (input_location|testing_limit|attributes)")

    return process(log, spark, input_location, testing_limit, attributes, id)


def process(log, spark, input_location, testing_limit, attributes, id):
    """ Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param input_location       : name of activity data table
    :param testing_limit        : limit to use for testing
    :param attributes           : Relevant columns to select from activity data table
    :return                     : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_activity is the activity's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Preparing Data")
    df_prepared_data = prepare_data(log, spark, input_location, testing_limit, attributes)
    log.info("Calculating Activity Synonyms")
    return affinity_synonym_generator.get_synonyms(log, spark, df_prepared_data, id).drop("keywords")


def store(processController, log, activity_synonyms):
    """ Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param activity_synonyms    : Spark Dataframe with columns : [id_activity, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the activity,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    :return                     : N/A
    """

    try:
        path_core = processController.get("path_activity_synonyms")
        path_staging = processController.get("path_activity_synonyms_staging")

        drop_table_query = processController.get("drop_table_query")
        check_tbl_exists = processController.get("check_tbl_exists")
        create_table_query = processController.get("create_table_query")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")

    try:
        log.info("Save the results in hive as %s" % path_core)
        activity_synonyms.write.mode('append').format("parquet").save(path_core)

        log.info("Save the results in hive as %s" % path_staging)
        spark.read.parquet(path_core).write.mode('append').format("parquet").save(path_staging)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}|{}) ".format(path_core, path_staging))


    except Exception as e:

        log.info("Path does not exist. Creating it.")
        try:
            log.info("Save the results in hive as %s" % path_core)
            activity_synonyms.write.mode("overwrite").format("parquet").save(path_core)

        except Exception as e:
            traceback.print_exc()
            raise TypeError("Error Code 3: Please verify connection to Hive and S3")

    try:
        spark.sql(check_tbl_exists)
        log.info("Table Already Exist, No Need to Create One.")

    except:
        log.info("Table Does Not Exist!")
        log.info("Creating Table from file...")
        spark.sql(drop_table_query)
        spark.sql(create_table_query.format(path_core))


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calculate_Calendar_Activity_synonyms")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    activity_synonyms = initProcess(spark, processController, log)
    store(processController, log, activity_synonyms)
    stopSparkSession(log, spark)


################################################
#                                              #
# Outputs:                                     #
#    Intermediate Table:                       #
#       vv_db.vv_synonyms_activity_affinities  #
#          Format:                             #
#             id_activity         :STRING      #
#             activity_synonyms   :STRING      #
#             time_stamp          :STRING      #
#             date_stamp          :TIMESTAMP   #
#                                              #
################################################

