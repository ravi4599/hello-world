##  spark-submit --name GNIP_Transpose --conf spark.executor.memoryOverhead=10240 --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/gnip_processing/gnip_transpose.py

import pyspark.sql.functions as F

from pyspark.sql import SparkSession
import traceback, logging


##########################
#                        #
#    Define Functions    #
#                        #
##########################


def gnip_transpose(log, spark, gnip_data):
    """

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param gnip_data            : location of the gnip data
    :param brand_details        : location of the brand details document
    :param attribute_mapping    : location of the attribute mapping document
    :return:
    """

    try:
        log.info("Loading Data from {}".format(gnip_data))
        # gnip_data = "s3a://vv-dev-emr-cluster/data/twitter/gnip_processing_output_spark_submit_25MM_records_core"
        df_gnip_data = spark.read.parquet(gnip_data)

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 2: Please review the hive or S3 connection")

    try:
        log.info("Select only needed columns, explode synonyms list, and get those only with 1 tweet...")
        df_gnip_exp_syns = df_gnip_data.select(F.col("klout_user_id"), F.col("max_tribe").alias("subtribe"),
                                               F.col("tweet_count"), F.col("synonyms_list"))\
            .withColumn("topicsdistinct", F.explode(F.col("synonyms_list")))\
            .withColumn("value", F.lit(1)).drop(F.col("synonyms_list"))\
            .filter(F.size(F.col('tweet_count')) == 1)


        log.info("Pivoting Dataframe...")
        df_gnip_pivoted = df_gnip_exp_syns.select("klout_user_id", "subtribe", "topicsdistinct", "value")\
            .groupBy("klout_user_id", "subtribe").pivot("topicsdistinct").avg("value")


        myDict_None = {None: 0.0}
        broadcastNoneVar = spark.sparkContext.broadcast(myDict_None)

        def lookup_None(x):
            if broadcastNoneVar.value.get(x) is None:
                return x
            else:
                return broadcastNoneVar.value.get(x)

        lookupNone_udf = F.udf(lookup_None)


        log.info("Removing blank columns...")
        df_gnip = df_gnip_pivoted.select(*(lookupNone_udf(F.col(c)).alias(c) for c in df_gnip_pivoted.columns))


    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the hive table or the hbase connection to the Sailor Recommendations Table.")

    return df_gnip


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='GNIP_Transpose'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        gnip_data = processController.get("gnip_data")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, spark, gnip_data)


def process(log, spark, gnip_data):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting GNIP Transpose...")
    return gnip_transpose(log, spark, gnip_data)


def store(processController, log, data):
    """
    Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param data                 : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    try:
        path_core = processController.get("gnip_transpose_core")
        path_staging = processController.get("gnip_transpose_staging")
        drop_table_query = processController.get("drop_table_query")
        create_table_query = processController.get("create_table_query")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")


    try:
        # path_core = "s3a://vv-dev-emr-cluster/data/twitter/gnip_transposed"
        # path_staging = "s3a://vv-dev-emr-cluster/data/twitter/gnip_transposed_staging"

        log.info("Save the results in hive as %s" % path_staging)
        data.write.mode('overwrite').format("parquet").save(path_staging)

        log.info("Save the results in hive as %s" % path_core)
        spark.read.parquet(path_staging).write.mode('overwrite').format("parquet").save(path_core)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}|{}) ".format(path_core, path_staging))


    try:
        log.info("Dropping old table...")
        log.info(drop_table_query)
        spark.sql(drop_table_query)

        log.info("Creating Table from file...")
        log.info(create_table_query)
        spark.sql(create_table_query.format(path_core))

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 3: Please verify connection to Hive and S3")



def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("GNIP_Transpose")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    data = initProcess(spark, processController, log)
    store(processController, log, data)
    stopSparkSession(log, spark)
