import logging

import numpy
from pyspark.ml.clustering import KMeans
from pyspark.ml.feature import VectorAssembler
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import sys, traceback


def initSparkSession(appName):
    spark = SparkSession \
        .builder \
        .appName(appName) \
        .enableHiveSupport() \
        .getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", "50")
    return spark


def loadProcessDriver(spark, log, db_name):
    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='TribeSegmentation'".format(db_name)
    log.info(query_string)
    dic = {}
    try:
        out = spark.sql(query_string).collect()
        m = map(lambda x: (x[0], x[1]), out)
        dic = dict(m)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")

    return dic


def initProcess(spark, processController, log):
    log.info("Fetch Parameters from Processor Driver")
    try:
        distillTable = processController.get("distillTable")
        numOfClusters = int(processController.get("numOfClusters"))
        kmeansMaxIter = int(processController.get("kmeansMaxIter"))
        kmeansSeed = int(processController.get("numVarToSelect"))
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (distillTable|numOfClusters|kmeansMaxIter|kmeansSeed) ")

    return process(spark, log, numOfClusters, kmeansMaxIter, kmeansSeed, distillTable)


def kmeansVarLoad(spark, log):
    ## Reading the KMEANS clustering variable list from HIVE table
    log.info("Reading the KMEANS clustering variable list from HIVE table")
    kmeansVar = spark.sql("select kmeans_var from vv_db.kmeans_variables").collect()[0][0].split(",")
    return kmeansVar


def distillLoad(spark, log, distillTable):
    ## Reading the cleansed data for Tribe calculation from HIVE table
    # customerData = spark.sql("select * from vv_db.TribeSegData")
    log.info("Reading the cleansed data for Tribe calculation from HIVE table")
    customerData = spark.sql("select * from %s " % (distillTable))
    return customerData


def checkRecordCluster(log, customerData, model, vdf_exp):
    ## Check how our records are distributed across the five clusters, if not as expected process exits
    log.info("Check how our records are distributed across the five clusters, if not as expected process exits")
    predictionValues = list(model.transform(vdf_exp).select("prediction").rdd.countByValue().values())
    dataCount = customerData.count()
    max_percent = numpy.amax(predictionValues) / dataCount
    min_percent = numpy.amin(predictionValues) / dataCount
    # if max_percent > 0.85 or min_percent < 0.05:
    #   print("The distribution of clusters are not healthy, exiting the process")
    #   appId = spark.applicationId
    #   call(["yarn", "application", "-kill", appId])


def clusterMapping(log, model, numOfClusters, vdf_exp):
    ## Mapping the clusters to four main tribes. We will get None_index, Explorer_index, Bask_index, Revel_index and Luxurist_index for mapping clusters to tribes.
    # We use "great_outdoors" and "luxury_life" to do the mapping. Except for putting the cluster which is 0 in every attribute as "None", the cluster which
    # is highest in "great_outdoors" is assigned as "Explorer", lowest in "great_outdoors" as "Bask". For the rest, the highest in "luxurist_life" is mapped to "luxurist", the one left will be mapped to "Revel".
    log.info("Mapping the clusters to four main tribes")
    centers = model.clusterCenters()
    dist_to_none = [numpy.linalg.norm([0, 0] - centers[x][0:2]) for x in range(numOfClusters)]
    None_index = numpy.argmin(dist_to_none)
    mean_in_outdoors = [centers[x][0] for x in range(numOfClusters)]
    Explorer_index = numpy.argmax(mean_in_outdoors)
    Bask_index = mean_in_outdoors.index(
        numpy.amin(numpy.array(mean_in_outdoors)[mean_in_outdoors != mean_in_outdoors[None_index]]))
    mean_in_luxurist = [centers[x][1] for x in range(numOfClusters)]
    left_index = [x for x in range(numOfClusters) if x not in [None_index, Explorer_index, Bask_index]]
    Luxurist_index = mean_in_luxurist.index(numpy.amax([mean_in_luxurist[i] for i in left_index]))
    Revel_index = [x for x in left_index if x != Luxurist_index][0]

    ## Replace prediction with Tribe Names
    df = model.transform(vdf_exp)
    tribeSegDF = df.withColumn("Tribe", F.when(df["prediction"] == int(Explorer_index), "Explorer").when(
        df["prediction"] == int(Bask_index), "Bask").when(df["prediction"] == int(Luxurist_index), "Luxurist").when(
        df["prediction"] == int(Revel_index), "Revel").otherwise("None")).drop("prediction").drop("features")
    return tribeSegDF


def process(spark, log, numOfClusters, kmeansMaxIter, kmeansSeed, distillTable):
    log.info("Calculating Kmeans")
    kmeansVar = kmeansVarLoad(spark, log)
    customerData = distillLoad(spark, log, distillTable)
    ## Run Kmeans with selected variables.
    vectorAssembler = VectorAssembler(inputCols=kmeansVar, outputCol="features")
    vdf_exp = vectorAssembler.transform(customerData)
    kmeans = KMeans(k=numOfClusters, maxIter=kmeansMaxIter, seed=kmeansSeed)
    model = kmeans.fit(vdf_exp)
    checkRecordCluster(log, customerData, model, vdf_exp)
    return clusterMapping(log, model, numOfClusters, vdf_exp)


def store(processController, tribeSeg, log):
    path = processController.get("path_mainclusters")
    log.info("Save the results in hive as %s" % path)
    tribeSeg.show(10)
    tribeSeg.write.mode('overwrite').format("parquet").save(path)


def stopSparkSession(spark, log):
    log.info("Shutting Down")
    spark.stop()


def get_logger():
    log = logging.getLogger('Spark')
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
    log.addHandler(_h)
    log.setLevel(logging.DEBUG)
    log.info("module imported and logger initialized")
    return log


if __name__ == "__main__":
    ''' Design Flow of Tribe segmentation/clustering'''
    spark = initSparkSession("Tribe_Mapper")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    tribeSeg = initProcess(spark, processController, log)
    store(processController, tribeSeg, log)
    stopSparkSession(spark, log)
