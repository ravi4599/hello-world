##  spark-submit --name Random_Forest --conf spark.executor.memoryOverhead=10240 --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/random_forest/random_forest.py

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pyspark.sql.functions as F
# from pyspark.sql.functions import col, when, udf, explode, lit, array, struct, row_number

from pyspark.mllib.evaluation import BinaryClassificationMetrics

from pyspark.ml import Pipeline
from pyspark.ml.feature import IndexToString, StringIndexer, VectorIndexer, VectorAssembler
from pyspark.ml.classification import RandomForestClassifier

import math, logging, traceback, datetime, time
import numpy as np


def to_long(df, by):
    # Filter dtypes and split into column names and type description
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in by))
    # Spark SQL supports only homogeneous columns
    assert len(set(dtypes)) == 1, "All columns have to be of the same type"

    # Create and explode an array of (column_name, column_value) structs
    kvs = F.explode(F.array([
        F.struct(F.lit(c).alias("key"), F.col(c).alias("val")) for c in cols
    ])).alias("kvs")

    return df.select(by + [kvs]).select(by + ["kvs.key", "kvs.val"])


def safe_div(x, y):
    if y == 0:
        return 0
    return x / y


def random_forest_func(log, df_input, input_dict, train_test_split, seed_split, numTrees, seed_train, prob_inc,
                       threshold_input, tribe_predictions, tribe_score, tribe_predicted_label, datazapp_query):

    def dict_lookup(x):
        if broadcastVar.value.get(x) is None:
            return x
        else:
            return broadcastVar.value.get(x)
    udf_dict_lookup = F.udf(dict_lookup)


    myDict = dict([[b[0].strip(), float(b[1])] for b in map(lambda x: x.split(":"), input_dict.split(","))])
    broadcastVar = spark.sparkContext.broadcast(myDict)


    log.info("Get Columns")
    table1 = df_input.select(*(udf_dict_lookup(F.col(c)).alias(c) for c in df_input.columns))\
        .withColumnRenamed("subtribe", "label")
    val_ls = table1.columns


    # UDF to convert the columns into float -- Klout should not be Float
    expr1 = [F.col(c).cast("float").alias(c) for c in val_ls if c not in ['klout_user_id', 'klout_user_id']]
    expr1.append("klout_user_id")
    table1 = table1.select(*expr1)


    # Columns to exclude from Vectorizing
    var_selected = ['klout_user_id', 'label']


    # Final list of columns to be vectorized
    var_ls_final = [item for item in val_ls if item not in var_selected]


    # Convert into Vector format
    vectorAssembler = VectorAssembler(inputCols=var_ls_final, outputCol="features")
    vdf = vectorAssembler.transform(table1)


    # Get the dataset in a format before training
    selectedcols = ["klout_user_id", "label", "features"]
    dataset = vdf.select(selectedcols)


    train_split = float(train_test_split.split(",")[0])
    test_split = float(train_test_split.split(",")[1])


    log.info("Split Datasets")
    train_dataset, test_dataset = dataset.randomSplit([train_split, test_split], seed=seed_split)


    # Index labels, adding metadata to the label column.
    # Fit on whole dataset to include all labels in index.
    log.info("Label Indexing")
    labelIndexer = StringIndexer(inputCol="label", outputCol="indexedLabel").fit(train_dataset)


    # Automatically identify categorical features, and index them.
    # Set maxCategories so features with > 4 distinct values are treated as continuous.
    log.info("Train Feature Indexer")
    featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=2).fit(train_dataset)


    # Build a RandomForest model.
    log.info("Train Random Forest Model")
    rf = RandomForestClassifier(labelCol="indexedLabel", featuresCol="indexedFeatures", numTrees=numTrees,
                                seed=seed_train)

    # Convert indexed labels back to original labels.
    log.info("Convert Indexes back")
    labelConverter = IndexToString(inputCol="prediction", outputCol="predictedLabel", labels=labelIndexer.labels)


    # Chain indexers and forest in a Pipeline
    log.info("Create Pipeline")
    pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf, labelConverter])


    # Train model.  This also runs the indexers.
    log.info("Train the model on the pipeline")
    model = pipeline.fit(train_dataset)


    # Test on testing dataset
    log.info("Test the model")
    predictions_test = model.transform(test_dataset)


    # For J Stats Model on the Training Dataset
    log.info("Training Dataset")
    predictions_train = model.transform(train_dataset)


    log.info("Getting AUC")
    ###################
    ##    Get AUC    ##
    ###################
    results = predictions_train.select(['probability', 'label'])


    ## prepare score-label set
    log.info("Collect Results")
    results_collect = results.collect()
    results_list = [(float(i[0][0]), 1.0 - float(i[1])) for i in results_collect]
    scoreAndLabels = spark.sparkContext.parallelize(results_list)


    metrics = BinaryClassificationMetrics(scoreAndLabels)
    log.info("The AUC is (@numTrees=100): {}".format(metrics.areaUnderROC))
    log.info("Split Probabilities")
    split0_udf = F.udf(lambda value: value[0].item(), FloatType())
    split1_udf = F.udf(lambda value: value[1].item(), FloatType())
    output2_train = predictions_train \
        .withColumn("prediction_0", split0_udf(F.col("probability"))) \
        .withColumn("prediction_1", split1_udf(F.col("probability")))

    output2_train.persist()


    log.info("Get the predictions")
    ## Get max(p(thing is 1)) and min(p(thing is 0))
    MaxProbability = output2_train.select("prediction_1").agg({"prediction_1": "max"}).collect().pop()['max(prediction_1)']
    MinProbability = output2_train.select("prediction_1").agg({"prediction_1": "min"}).collect().pop()['min(prediction_1)']


    # Get the range of the interval
    log.info("Get the model range")
    min = MinProbability
    max = MaxProbability


    ProbabilityIncrement = prob_inc
    log.info("ProbabilityIncrement: {}".format(ProbabilityIncrement))
    length = math.ceil((max - min) / ProbabilityIncrement)


    # Get the initial CM values
    log.info("Get the CM values")
    TP = output2_train.filter((F.col("predictedLabel") == F.col("label")) & (F.col("label") == 1.0)).count()
    TN = output2_train.filter((F.col("predictedLabel") == F.col("label")) & (F.col("label") == 0.0)).count()
    FP = output2_train.filter((F.col("predictedLabel") != F.col("label")) & (F.col("label") == 0.0)).count()
    FN = output2_train.filter((F.col("predictedLabel") != F.col("label")) & (F.col("label") == 1.0)).count()


    log.info("TP: {}".format(TP))
    log.info("TN: {}".format(TN))
    log.info("FP: {}".format(FP))
    log.info("FN: {}".format(FN))


    # Initialize Sensitivity and Specificity
    SensitivityArr = []
    SpecificityArr = []
    Prob = []


    ## Loop through the probability interval, from min to max
    log.info("Get the CM values at each increment...")
    log.info("Probability Range: {}".format(length))
    for i in range(int(length) + 1):
        prob = min + (i) * ProbabilityIncrement
        Prob.append(prob)
        new_column_2 = F.when(F.col("prediction_1") > prob, 1.0).otherwise(0.0)
        output2_train = output2_train.withColumn("updatedpredictions", new_column_2)
        TPU = output2_train.filter((F.col("updatedpredictions") == F.col("label")) & (F.col("label") == 1.0)).count()
        TNU = output2_train.filter((F.col("updatedpredictions") == F.col("label")) & (F.col("label") == 0.0)).count()
        FPU = output2_train.filter((F.col("updatedpredictions") != F.col("label")) & (F.col("label") == 0.0)).count()
        FNU = output2_train.filter((F.col("updatedpredictions") != F.col("label")) & (F.col("label") == 1.0)).count()
        Sensitivity = TPU / (TPU + FNU)
        SensitivityArr.append(Sensitivity)
        Specificity = TNU / (TNU + FPU)
        SpecificityArr.append(Specificity)


    log.info("Get the Max CM Values")
    SensitivityArrNp = np.array(SensitivityArr)
    SpecificityArrNp = np.array(SpecificityArr)


    PreJStat = []
    PreJStat = SensitivityArrNp + SpecificityArrNp
    PreJStat[:] = [x - 1 for x in PreJStat]

    # Find the position of the maximum J Statitics in the array
    JStatMaxValuePosition = np.argmax(PreJStat)

    # Assign the Probability with Maximum JStatistic
    ProbThreshold = Prob[JStatMaxValuePosition]

    log.info("ProbThreshold : {}".format(ProbThreshold))
    log.info("MinProbability: {}".format(MinProbability))
    log.info("MaxProbability: {}".format(MaxProbability))

    ########################
    ##    End Training    ##
    ########################


    #########################
    ##    Start Scoring    ##
    #########################

    ## Reference Scoring Dataset
    # Treat the columns for NULL values
    log.info("Scoring data...")
    var_all_string_Score = var_ls_final


    var_all_score = list(map(lambda x: "cast(case when " + x + " is NULL then 0 else " + x + " end as float) as " + x,
                             var_all_string_Score))


    ## Query Datazapp data
    log.info("Gettin Datazapp Data...")
    table_all_score = spark.sql(datazapp_query % (','.join(var_all_score)))


    ##########################################
    ##    Can't we take this from above?    ##
    ##########################################
    # Choose the columns to be taken for converting into Vector Assembler
    val_ls_score = table_all_score.columns

    # Remove the 16 that are not there in the DataZapp Dataset as well
    var_selected_score = ['Sequence', 'label']
    var_ls_final_score = [item for item in val_ls_score if item not in var_selected_score]


    # Convert into Vector Assembler
    log.info("Convert into Vector Assembler")
    vectorAssembler_score = VectorAssembler(inputCols=var_ls_final_score, outputCol="features")
    vdf_score = vectorAssembler_score.transform(table_all_score)


    selectedcols_score = ["Sequence", "label", "features"]
    dataset_score = vdf_score.select(selectedcols_score)


    # Make predictions.
    log.info("Making Predictions...")
    predictions_score = model.transform(dataset_score)


    threshold = threshold_input
    new_column_2 = F.when(F.col("prediction_1") > threshold, 1.0).otherwise(0.0)


    log.info("Score Alignment")
    # Score Alignment
    output2_score = predictions_score \
        .withColumn("prediction_0", split0_udf(F.col("probability"))) \
        .withColumn("prediction_1", split1_udf(F.col("probability")))

    output2_score = output2_score \
        .withColumn(tribe_predictions, new_column_2) \
        .withColumn(tribe_score,
                    ((F.col("prediction_1") - MinProbability) * 100) / (MaxProbability - MinProbability))

    output2_score = output2_score.withColumnRenamed("predictedLabel", tribe_predicted_label)

    df_random_forest = output2_score.select(["Sequence", tribe_predictions, tribe_score, tribe_predicted_label])

    df_random_forest.groupby(tribe_predictions).agg({tribe_predictions: "count"}).show()


    # output2_train.unpersist()


    log.info("Getting Confusion Matrix")
    ################################
    ##    Get Confusion Matrix    ##
    ################################

    output2_test = predictions_test\
        .withColumn("prediction_0", split0_udf(F.col("probability")))\
        .withColumn("prediction_1", split1_udf(F.col("probability"))) \
        .withColumn(tribe_predictions, new_column_2)\
        .withColumn(tribe_score, ((F.col("prediction_1") - MinProbability) * 100) / (MaxProbability - MinProbability))


    output2_test.persist()

    output2_test.show()


    # ## 1. Check if the Aligned Scores are within 0-100
    output2_test.orderBy(F.col(tribe_score).asc()).show(1)
    output2_test.orderBy(F.col(tribe_score).desc()).show(1)


    ## 2. Confusion Matrix
    log.info("Confusion Matrix...")
    TruePositive = output2_test \
        .filter((F.col(tribe_predictions) == F.col("label")) & (F.col("label") == 1.0)).count()

    TrueNegative = output2_test \
        .filter((F.col(tribe_predictions) == F.col("label")) & (F.col("label") == 0.0)).count()

    FalsePositive = output2_test \
        .filter((F.col(tribe_predictions) != F.col("label")) & (F.col("label") == 0.0)).count()

    FalseNegative = output2_test \
        .filter((F.col(tribe_predictions) != F.col("label")) & (F.col("label") == 1.0)).count()

    Accuracy = (output2_test.filter(F.col("label") == F.col(tribe_predictions)).count()) / output2_test.count()

    Recall = safe_div(TruePositive, (TruePositive + FalseNegative))
    Precision = safe_div(TruePositive, (TruePositive + FalsePositive))
    F1Score = 2 * safe_div((Precision * Recall), (Precision + Recall))


    log.info("TruePositive: {}".format(str(TruePositive)))
    log.info("TrueNegative: {}".format(str(TrueNegative)))
    log.info("FalsePositive: {}".format(str(FalsePositive)))
    log.info("FalseNegative: {}".format(str(FalseNegative)))
    log.info("Accuracy: {}".format(str(Accuracy)))
    log.info("Recall: {}".format(str(Recall)))
    log.info("Precision: {}".format(str(Precision)))
    log.info("F1Score: {}".format(str(F1Score)))


    ### 3. Confusion Matrix Before
    log.info("Confusion Matrix Before...")
    TruePositive_old = output2_test.filter(
        (F.col("predictedLabel") == F.col("label")) & (F.col("label") == 1.0)).count()
    TrueNegative_old = output2_test.filter(
        (F.col("predictedLabel") == F.col("label")) & (F.col("label") == 0.0)).count()
    FalsePositive_old = output2_test.filter(
        (F.col("predictedLabel") != F.col("label")) & (F.col("label") == 0.0)).count()
    FalseNegative_old = output2_test.filter(
        (F.col("predictedLabel") != F.col("label")) & (F.col("label") == 1.0)).count()
    Accuracy_old = (output2_test.filter(
        F.col("label") == F.col("predictedLabel")).count()) / output2_test.count()
    Recall_old = safe_div(TruePositive_old, (TruePositive_old + FalseNegative_old))
    Precision_old = safe_div(TruePositive_old, (TruePositive_old + FalsePositive_old))
    F1Score_old = 2 * safe_div((Precision_old * Recall_old), (Precision_old + Recall_old))


    log.info("TruePositive_old: {}".format(str(TruePositive_old)))
    log.info("TrueNegative_old: {}".format(str(TrueNegative_old)))
    log.info("FalsePositive_old: {}".format(str(FalsePositive_old)))
    log.info("FalseNegative_old: {}".format(str(FalseNegative_old)))
    log.info("Accuracy_old: {}".format(str(Accuracy_old)))
    log.info("Recall_old: {}".format(str(Recall_old)))
    log.info("Precision_old: {}".format(str(Precision_old)))
    log.info("F1Score_old: {}".format(str(F1Score_old)))


    ## Create Metrics Dataframe
    log.info("Creating Metrics Dataframe")
    min_score = output2_test.orderBy(F.col(tribe_score).asc()).take(1)[0][0]
    max_score = output2_test.orderBy(F.col(tribe_score).desc()).take(1)[0][0]
    sub_tribe = tribe_predictions.split("_")[0]


    test_dataset_count = test_dataset.count()
    train_dataset_count = train_dataset.count()

    ## Calculate Representation
    train_representation = (train_dataset.where(F.col("label") == '1.0').count() / train_dataset_count) * 100
    test_representation = (test_dataset.where(F.col("label") == '1.0').count() / test_dataset_count) * 100
    threshold_is_ok = ((threshold > MinProbability) & (threshold < MaxProbability))

    values_list = [(str(TruePositive), str(TrueNegative), str(FalsePositive), str(FalseNegative), str(Accuracy),
                    str(Recall), str(Precision), str(F1Score), str(min_score), str(max_score), str(MinProbability),
                    str(MaxProbability), str(ProbThreshold), str(threshold_input), str(train_representation),
                    str(test_representation), str(threshold_is_ok), metrics.areaUnderROC, test_dataset_count, str(1))]

    columns_list = ["{}_TP".format(sub_tribe), "{}_TN".format(sub_tribe), "{}_FP".format(sub_tribe),
                    "{}_FN".format(sub_tribe), "{}_Accuracy".format(sub_tribe), "{}_Recall".format(sub_tribe),
                    "{}_Precision".format(sub_tribe), "{}_F1Score".format(sub_tribe), "{}_minScore".format(sub_tribe),
                    "{}_maxScore".format(sub_tribe), "{}_minProbability".format(sub_tribe),
                    "{}_maxProbability".format(sub_tribe), "{}_automatedTreshold".format(sub_tribe),
                    "{}_manualThreshold".format(sub_tribe), "{}_trainRepresentation".format(sub_tribe),
                    "{}_testRepresentation".format(sub_tribe), "{}_threshold_is_ok".format(sub_tribe),
                    "{}_AuC".format(sub_tribe), "{}_test_split_count".format(sub_tribe), "row_number"]

    df_metrics = spark.createDataFrame(values_list, columns_list)

    df_metrics.show()

    output2_train.unpersist()
    # output2_test.unpersist()
    log.info("Returning Dataframe")
    return df_random_forest, model, df_metrics


def assemble_tribes(log, spark, processController, sql_query, train_test_split, seed_split, numTrees, seed_train,
                    prob_inc, datazapp_query):

    def dict_lookup(x):
        if broadcastVar.value.get(x) is None:
            return x
        else:
            return broadcastVar.value.get(x)

    udf_dict_lookup = F.udf(dict_lookup)


    log.info("Querying Table...")
    df_input = spark.sql(sql_query).sample(False, 0.3)


    #####################
    ##    Adventure    ##
    #####################
    input_dict_adv = processController.get("input_dict_Adventure")
    adventure_predictions = processController.get("tribe_predictions_Adventure")
    adventure_score = processController.get("tribe_score_Adventure")
    adventure_predicted_label = processController.get("tribe_predicted_label_Adventure")
    adventure_threshold = float(processController.get("adventure_threshold"))

    df_adventure, model_adventure, metrics_adventure = random_forest_func(log, df_input, input_dict_adv, train_test_split, seed_split, numTrees, seed_train, prob_inc, adventure_threshold, adventure_predictions, adventure_score, adventure_predicted_label, datazapp_query)


    ###################
    ##    Mystery    ##
    ###################
    input_dict_mystery = processController.get("input_dict_Mystery")
    mystery_predictions = processController.get("tribe_predictions_Mystery")
    mystery_score = processController.get("tribe_score_Mystery")
    mystery_predicted_label = processController.get("tribe_predicted_label_Mystery")
    mystery_threshold = float(processController.get("mystery_threshold"))

    df_mystery, model_mystery, metrics_mystery = random_forest_func(log, df_input, input_dict_mystery, train_test_split, seed_split, numTrees, seed_train, prob_inc, mystery_threshold, mystery_predictions, mystery_score, mystery_predicted_label, datazapp_query)


    #################
    ##    Quirk    ##
    #################
    input_dict_quirk = processController.get("input_dict_Quirk")
    quirk_predictions = processController.get("tribe_predictions_Quirk")
    quirk_score = processController.get("tribe_score_Quirk")
    quirk_predicted_label = processController.get("tribe_predicted_label_Quirk")
    quirk_threshold = float(processController.get("quirk_threshold"))

    df_quirk, model_quirk, metrics_quirk = random_forest_func(log, df_input, input_dict_quirk, train_test_split, seed_split, numTrees, seed_train,  prob_inc, quirk_threshold, quirk_predictions, quirk_score, quirk_predicted_label, datazapp_query)


    #####################
    ##    Glamorous    ##
    #####################
    input_dict_glamorous = processController.get("input_dict_Glamorous")
    glamorous_predictions = processController.get("tribe_predictions_Glamorous")
    glamorous_score = processController.get("tribe_score_Glamorous")
    glamorous_predicted_label = processController.get("tribe_predicted_label_Glamorous")
    glamorous_threshold = float(processController.get("glamorous_threshold"))

    df_glamorous, model_glamorous, metrics_glamorous = random_forest_func(log, df_input, input_dict_glamorous, train_test_split, seed_split, numTrees, seed_train, prob_inc, glamorous_threshold, glamorous_predictions, glamorous_score, glamorous_predicted_label, datazapp_query)


    #################
    ##    Party    ##
    #################
    input_dict_party = processController.get("input_dict_Party")
    party_predictions = processController.get("tribe_predictions_Party")
    party_score = processController.get("tribe_score_Party")
    party_predicted_label = processController.get("tribe_predicted_label_Party")
    party_threshold = float(processController.get("party_threshold"))

    df_party, model_party, metrics_party = random_forest_func(log, df_input, input_dict_party, train_test_split, seed_split, numTrees, seed_train, prob_inc, party_threshold, party_predictions, party_score, party_predicted_label, datazapp_query)


    #################
    ##    Chill    ##
    #################
    input_dict_chill = processController.get("input_dict_Chill")
    chill_predictions = processController.get("tribe_predictions_Chill")
    chill_score = processController.get("tribe_score_Chill")
    chill_predicted_label = processController.get("tribe_predicted_label_Chill")
    chill_threshold = float(processController.get("chill_threshold"))

    df_chill, model_chill, metrics_chill = random_forest_func(log, df_input, input_dict_chill, train_test_split, seed_split, numTrees, seed_train, prob_inc, chill_threshold, chill_predictions, chill_score, chill_predicted_label, datazapp_query)


    ################
    ##    Cool    ##
    ################
    input_dict_cool = processController.get("input_dict_Cool")
    cool_predictions = processController.get("tribe_predictions_Cool")
    cool_score = processController.get("tribe_score_Cool")
    cool_predicted_label = processController.get("tribe_predicted_label_Cool")
    cool_threshold = float(processController.get("cool_threshold"))

    df_cool, model_cool, metrics_cool = random_forest_func(log, df_input, input_dict_cool, train_test_split, seed_split, numTrees, seed_train, prob_inc, cool_threshold, cool_predictions, cool_score, cool_predicted_label, datazapp_query)


    ## Join all the tribes together
    df_all_tribes_joined = df_adventure \
        .join(df_mystery, 'Sequence', 'outer') \
        .join(df_quirk, 'Sequence', 'outer') \
        .join(df_glamorous, 'Sequence', 'outer') \
        .join(df_party, 'Sequence', 'outer') \
        .join(df_cool, 'Sequence', 'outer') \
        .join(df_chill, 'Sequence', 'outer')


    ## Join all the metrics together
    df_all_metrics_joined = metrics_adventure\
        .join(metrics_mystery, "row_number", "outer")\
        .join(metrics_quirk, "row_number", "outer")\
        .join(metrics_glamorous, "row_number", "outer")\
        .join(metrics_party, "row_number", "outer")\
        .join(metrics_chill, "row_number", "outer")\
        .join(metrics_cool, "row_number", "outer")\
        .drop("row_number")

    # df_all_metrics_joined.show()


    #####################
    ##    Transpose    ##
    #####################
    # Add the predictions together
    Data_All = df_all_tribes_joined \
        .withColumn("Total_Predictions", F.col('Adventure_Predictions') + F.col('Mystery_Predictions') + F.col(
        'Quirk_Predictions') + F.col('Glamorous_Predictions') + F.col('Chill_Predictions') + F.col('Cool_Predictions') + F.col(
        'Party_Predictions'))

    # Get the list of sequences where there are no multiple predictions
    Data_All_One = Data_All.filter(F.col('Total_Predictions') == 1.0).select(
        ["Sequence", "Adventure_Predictions", "Mystery_Predictions", "Quirk_Predictions", "Glamorous_Predictions",
         "Chill_Predictions", "Cool_Predictions", "Party_Predictions"])

    # Get the list of sequences where there are multiple predictions
    Data_All_Multi = Data_All.filter(F.col('Total_Predictions') != 1.0).select(
        ["Sequence", "Adventure_Score", "Mystery_Score", "Quirk_Score", "Glamorous_Score", "Chill_Score", "Cool_Score",
         "Party_Score"])


    # Transpose the Dataset with Multiple Predictions
    Data_All_Multi_Transposed = to_long(Data_All_Multi, ["Sequence"])
    # Transpose the Dataset with Only One Predictions
    Data_All_One_Transposed = to_long(Data_All_One, ["Sequence"])


    ##############################################
    ##    Max for Multiple Predicted Records    ##
    ##############################################
    def dict_lookup(x):
        if broadcastVar.value.get(x) is None:
            return x
        else:
            return broadcastVar.value.get(x)
    udf_dict_lookup = F.udf(dict_lookup)


    window = Window.partitionBy(Data_All_Multi_Transposed['Sequence']).orderBy(Data_All_Multi_Transposed['val'].desc())
    Data_All_Multi_Transposed_Max = Data_All_Multi_Transposed.select(F.col('*'), F.row_number().over(window).alias(
        'row_number')).where(F.col('row_number') <= 1).select(["Sequence", "key", "val"])

    myDict = {"Quirk_Score": "Quirk", "Adventure_Score": "Adventure", "Mystery_Score": "Mystery",
              "Glamorous_Score": "Glamorous", "Party_Score": "Party", "Cool_Score": "Cool",
              "Chill_Score": "Chill"}
    broadcastVar = spark.sparkContext.broadcast(myDict)

    Data_All_Multi_Transposed_Max = Data_All_Multi_Transposed_Max \
        .select(*(udf_dict_lookup(F.col(c)).alias(c) for c in Data_All_Multi_Transposed_Max.columns))

    ############################################
    ##    Max for Single Predicted Records    ##
    ############################################
    def dict_lookup(x):
        if broadcastVar.value.get(x) is None:
            return x
        else:
            return broadcastVar.value.get(x)
    udf_dict_lookup = F.udf(dict_lookup)


    myDict = {"Quirk_Predictions": "Quirk", "Adventure_Predictions": "Adventure", "Mystery_Predictions": "Mystery", "Glamorous_Predictions": "Glamorous", "Party_Predictions": "Party", "Cool_Predictions": "Cool", "Chill_Predictions": "Chill"}
    broadcastVar = spark.sparkContext.broadcast(myDict)

    Data_All_One_Transposed_Max = Data_All_One_Transposed \
        .select(*(udf_dict_lookup(F.col(c)).alias(c) for c in Data_All_One_Transposed.columns))
    Data_All_One_Transposed_Max = Data_All_One_Transposed_Max.where(Data_All_One_Transposed_Max.val == 1.0)


    #######################################
    ##    Union Both Single and Multi    ##
    #######################################
    Data_All_Transposed_Max = Data_All_One_Transposed_Max \
        .select(["Sequence", "key"]) \
        .union(Data_All_Multi_Transposed_Max.select(["Sequence", "key"]))
    Data_All_Transposed_Max.show()
    Data_All_Transposed_Max.groupby(["key"]).agg({"Sequence": "count"}).show()

    model_list = [model_adventure, model_mystery, model_quirk, model_glamorous, model_party, model_chill, model_cool]

    return Data_All_Transposed_Max, model_list, df_all_metrics_joined


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='RandomForest'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        sql_query = processController.get("sql_query")
        train_test_split = processController.get("train_test_split")
        seed_split = int(processController.get("seed_split"))
        numTrees = int(processController.get("numTrees"))
        seed_train = int(processController.get("seed_train"))
        prob_inc = float(processController.get("prob_inc"))
        datazapp_query = processController.get("datazapp_query")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, spark, processController, sql_query, train_test_split, seed_split, numTrees, seed_train,
                   prob_inc, datazapp_query)


def process(log, spark, processController, sql_query, train_test_split, seed_split, numTrees, seed_train, prob_inc, datazapp_query):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting Random Forest Processing...")
    return assemble_tribes(log, spark, processController, sql_query, train_test_split, seed_split, numTrees, seed_train,
                           prob_inc, datazapp_query)


def store(processController, log, data, model_list, df_all_metrics_joined):
    """
    Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param data                 : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    try:
        path_core = processController.get("path_random_forest")
        path_staging = processController.get("path_random_forest_staging")
        path_model = processController.get("path_random_forest_models")
        path_metrics_base = processController.get("path_random_forest_metrics_base")
        path_metrics_new = processController.get("path_random_forest_metrics_new")

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 1: Please verify process driver query execution")


    try:
        log.info("Save the results in hive as %s" % path_staging)
        data.write.mode("overwrite").format("parquet").save(path_staging)

        log.info("Save the results in hive as %s" % path_core)
        spark.read.parquet(path_staging).write.mode('overwrite').format("parquet").save(path_core)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}|{}) ".format(path_core, path_staging))


    try:
        log.info("Saving Model to {}...".format(path_model))
        timestamp = str(datetime.datetime.now()).replace(" ", "_").replace(":", "_").replace(".", "_")
        model_list_order = ["Adventure", "Mystery", "Quirk", "Glamorous", "Party", "Chill", "Cool"]
        for model, order in zip(model_list, model_list_order):
            file_path = path_model + order + timestamp
            model.write().overwrite().save(file_path)

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 4: Please verify correct storage location(s) ({}) ".format(path_model))


    ## Check to see if Base Metrics file exists,
    ##    If it does, append to it and save to
    try:
        df_metrics_table = spark.read.parquet(path_metrics_base)

        log.info("Base Metrics File Exists. Joining New Metrics to old: {}".format(path_metrics_base))
        timestamp = int(time.time())
        df_all_metrics_new = df_all_metrics_joined.withColumn("timestamp", F.lit(timestamp).cast(StringType())).union(
            df_metrics_table)

        log.info("Save the results in hive as {}".format(path_metrics_new))
        df_all_metrics_new.write.mode("overwrite").format("parquet").save(path_metrics_new)

        log.info("Save the results in hive as {}".format(path_metrics_base))
        spark.read.parquet(path_metrics_new).write.mode("overwrite").format("parquet").save(path_metrics_base)


    ##    If it does not, create it.
    except:
        log.info("Base Metrics File Does Not Exist. Saving Metrics as Base Metrics...")
        df_all_metrics_joined.show()
        df_all_metrics_joined \
            .withColumn("timestamp", F.lit(0).cast(StringType())) \
            .write.mode("overwrite").format("parquet").save(path_metrics_base)


def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Random_Forest")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    data, model_list, df_all_metrics_joined = initProcess(spark, processController, log)
    data.show()
    store(processController, log, data, model_list, df_all_metrics_joined)
    stopSparkSession(log, spark)

