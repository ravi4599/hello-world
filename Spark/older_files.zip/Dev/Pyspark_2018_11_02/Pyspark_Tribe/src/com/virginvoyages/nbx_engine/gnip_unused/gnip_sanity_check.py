##  spark-submit --name GNIP_Sanity_Check --conf spark.yarn.executor.memoryOverhead=10240 --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/gnip_processing/sanity_check.py

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

import logging, traceback


# 3
## Presenece of all 7 Sub-Tribes
def check_all_subtribes_present_pre_agg(log, gnip_data, subtribe_list, brand_details):

    df_twitter_data = spark.sql(gnip_data)\
        .where(F.col("klout_user_id").isNotNull())\
        .select("klout_user_id", "brand_name")

    df_brand_details = spark.read.option("header", "true").csv(brand_details)\
        .select("brand_name", "Handle Details", "SubTribe")\
        .withColumnRenamed("Handle Details", "handle_details")\
        .distinct()

    conditions = ((df_twitter_data.brand_name == df_brand_details.brand_name) |
                  (df_twitter_data.brand_name == df_brand_details.handle_details))

    df_subtribe_counts = df_twitter_data.join(df_brand_details, conditions).select("SubTribe")

    ## Check if all records have a sub-tribe assigned
    non_subtribe_list = df_subtribe_counts\
        .where(F.col("SubTribe").isin(subtribe_list) == False)\
        .collect()

    if non_subtribe_list != []:
        log.info("Some records do NOT have an appropriate subtribe assigned.")
    else:
        log.info("All records have appropriate subtribes assigned.")


# 4
## Klout_user_id
def check_null_klout_user_id_percentage(log, gnip_data, threshold_percent):

    gnip_data = "select displayname, favoritescount, followerscount, friendscount, id, languages, listedcount, actor_location_displayname, preferredusername, statusescount, twittertimezone, body, generator_displayname, generator_link, klout_user_id, klout_score, topics_displayname, topics_id, topics_link, topics_score, topic_type, country, countrycode, profilelocations_locality, region, profilelocations_subregion, profilelocation_displayname, profilelocation_coordinates, load_data_timestamp, epoch, year, month, day, brand_name, filename from bd_db.stg_gnip_brand_tweets_feb18_new_sample_017"

    threshold_percent = 75.0

    klout_ids_total = spark.sql(gnip_data).select("klout_user_id", "brand_name").count()

    klout_ids_non_null = spark.sql(gnip_data) \
        .where(F.col("klout_user_id").isNotNull()) \
        .select("klout_user_id", "brand_name").count()

    percent_non_null = (klout_ids_non_null / klout_ids_total) * 100


    if percent_non_null >= threshold_percent:
        log.info("Count of missing ids is less than 25%")
    else:
        log.info("More than 25% of GNIP data has missing klout ids. {} of GNIP data has missing klout ids".format(
            (100 - percent_non_null)))


# 5
## Presence of all 7 Sub-Tribes
def check_all_subtribes_present_post_agg(log, gnip_data, subtribe_list, brand_details):

    df_twitter_data = spark.sql(gnip_data)\
        .where(F.col("klout_user_id").isNotNull())\
        .select("klout_user_id", "brand_name")

    df_brand_details = spark.read.option("header", "true").csv(brand_details)\
        .select("brand_name", "Handle Details", "SubTribe")\
        .withColumnRenamed("Handle Details", "handle_details")\
        .distinct()

    conditions = ((df_twitter_data.brand_name == df_brand_details.brand_name) |
                  (df_twitter_data.brand_name == df_brand_details.handle_details))

    df_subtribe_counts = df_twitter_data.join(df_brand_details, conditions)\
        .groupBy("SubTribe").agg({"SubTribe": "count"}).select("SubTribe")


    ## Check if all records have a sub-tribe assigned
    non_subtribe_list = df_subtribe_counts\
        .where(F.col("SubTribe").isin(subtribe_list) == False)\
        .collect()

    if non_subtribe_list != []:
        log.info("Some records do NOT have an appropriate subtribe assigned.")
    else:
        log.info("All records have appropriate subtribes assigned.")


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='GNIP_SanityCheck'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:

        gnip_data = processController.get("gnip_data")
        subtribe_list = processController.get("subtribe_list")[1:-1].split(",")
        threshold_percent = float(processController.get("threshold_percent"))
        brand_details = (processController.get("brand_details"))

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, gnip_data, subtribe_list, threshold_percent, brand_details)


def process(log, gnip_data, subtribe_list, threshold_percent, brand_details):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """
    log.info("Starting GNIP Sanity Check..")

    check_all_subtribes_present_pre_agg(log, gnip_data, subtribe_list, brand_details)
    check_null_klout_user_id_percentage(log, gnip_data, threshold_percent)
    check_all_subtribes_present_post_agg(log, gnip_data, subtribe_list, brand_details)


def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("GNIP_SanityCHeck")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    initProcess(spark, processController, log)
    stopSparkSession(log, spark)
