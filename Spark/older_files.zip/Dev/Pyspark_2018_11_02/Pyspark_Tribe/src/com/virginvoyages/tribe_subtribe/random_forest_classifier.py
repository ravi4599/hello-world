##  spark-submit --name Random_Forest --conf spark.executor.memoryOverhead=10240 --jars /home/ec2-user/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/ec2-user/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/random_forest/random_forest_classifier.py

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pyspark.sql.functions as F

from pyspark.mllib.evaluation import BinaryClassificationMetrics

from pyspark.ml import Pipeline
from pyspark.ml.feature import IndexToString, StringIndexer, VectorIndexer, VectorAssembler
from pyspark.ml.classification import RandomForestClassifier

import math, logging, traceback, time
import numpy as np


def to_long(df, by):
    # Filter dtypes and split into column names and type description
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in by))
    # Spark SQL supports only homogeneous columns
    assert len(set(dtypes)) == 1, "All columns have to be of the same type"

    # Create and explode an array of (column_name, column_value) structs
    kvs = F.explode(F.array([
        F.struct(F.lit(c).alias("key"), F.col(c).alias("val")) for c in cols
    ])).alias("kvs")

    return df.select(by + [kvs]).select(by + ["kvs.key", "kvs.val"])


def safe_div(x, y):
    if y == 0:
        return 0
    return x / y


def gnip_transpose(log, spark, gnip_data):
    """

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param gnip_data            : location of the gnip data
    :param brand_details        : location of the brand details document
    :param attribute_mapping    : location of the attribute mapping document
    :return:
    """

    try:
        log.info("Loading GNIP Data")
        log.info("Select only needed columns, explode synonyms list, and get those only with 1 tweet...")
        df_gnip_exp_syns = gnip_data.select(F.col("klout_user_id"), F.col("final_subtribe").alias("subtribe"),
                                               F.col("tweet_count"), F.col("synonyms_list"))\
            .withColumn("topicsdistinct", F.explode(F.col("synonyms_list")))\
            .withColumn("value", F.lit(1)).drop(F.col("synonyms_list"))\
            .filter(F.size(F.col('tweet_count')) == 1)


        log.info("Pivoting Dataframe...")
        df_gnip_pivoted = df_gnip_exp_syns.select("klout_user_id", "subtribe", "topicsdistinct", "value")\
            .groupBy("klout_user_id", "subtribe").pivot("topicsdistinct").avg("value")


        dict_none = {None: 0.0}
        broadcast_var = spark.sparkContext.broadcast(dict_none)

        def dict_lookup(x):
            if broadcast_var.value.get(x) is None:
                return x
            else:
                return broadcast_var.value.get(x)

        udf_dict_lookup = F.udf(dict_lookup)


        log.info("Removing blank columns...")
        df_gnip = df_gnip_pivoted.select(*(udf_dict_lookup(F.col(c)).alias(c) for c in df_gnip_pivoted.columns))


    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the hive table.")

    return df_gnip


def random_forest_func(log, df_input, input_dict_str, train_test_split, seed_split, numTrees, seed_train, prob_inc,
                       threshold_input, tribe_predictions, tribe_score, tribe_predicted_label, acxiom_query):

    def dict_lookup(x):
        if broadcast_var.value.get(x) is None:
            return x
        else:
            return broadcast_var.value.get(x)
    udf_dict_lookup = F.udf(dict_lookup)


    input_dict = dict([[b[0].strip(), float(b[1])] for b in map(lambda x: x.split(":"), input_dict_str.split(","))])
    broadcast_var = spark.sparkContext.broadcast(input_dict)


    log.info("Get Columns")
    df_subtribe = df_input.select(*(udf_dict_lookup(F.col(c)).alias(c) for c in df_input.columns))\
        .withColumnRenamed("subtribe", "label")
    df_subtribe_cols = df_subtribe.columns


    # Convert the columns into float -- Klout should not be Float
    cols_as_float = [F.col(c).cast("float").alias(c) for c in df_subtribe_cols if c not in ['klout_user_id']]
    cols_as_float.append("klout_user_id")

    ## Check this later...
    df_subtribe_cast_float = df_subtribe.select(*cols_as_float)


    # Columns to exclude from Vectorizing
    cols_excluded = ['klout_user_id', 'label']


    # Final list of columns to be vectorized
    cols_to_vectorized = [item for item in df_subtribe_cols if item not in cols_excluded]


    # Convert into Vector format
    vector_assembler = VectorAssembler(inputCols=cols_to_vectorized, outputCol="features")
    cols_selected = ["klout_user_id", "label", "features"]
    df_vector_assembler = vector_assembler.transform(df_subtribe_cast_float).select(cols_selected)


    train_split = float(train_test_split.split(",")[0])
    test_split = float(train_test_split.split(",")[1])


    log.info("Split Datasets")
    train_dataset, test_dataset = df_vector_assembler.randomSplit([train_split, test_split], seed=seed_split)


    # Index labels, adding metadata to the label column.
    # Fit on whole dataset to include all labels in index.
    log.info("Label Indexing")
    label_indexer = StringIndexer(inputCol="label", outputCol="indexedLabel").fit(train_dataset)


    # Automatically identify categorical features, and index them.
    # Set maxCategories so features with > 4 distinct values are treated as continuous.
    log.info("Train Feature Indexer")
    feature_indexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures", maxCategories=2).fit(train_dataset)


    # Build a RandomForest model.
    log.info("Train Random Forest Model")
    rf_classifier = RandomForestClassifier(labelCol="indexedLabel", featuresCol="indexedFeatures", numTrees=numTrees,
                                seed=seed_train)

    # Convert indexed labels back to original labels.
    log.info("Convert Indexes back")
    label_converter = IndexToString(inputCol="prediction", outputCol="predictedLabel", labels=label_indexer.labels)


    # Chain indexers and forest in a Pipeline
    log.info("Create Pipeline")
    pipeline = Pipeline(stages=[label_indexer, feature_indexer, rf_classifier, label_converter])


    # Train model.  This also runs the indexers.
    log.info("Train the model on the pipeline")
    rf_model = pipeline.fit(train_dataset)


    # Test on testing dataset
    log.info("Test the model")
    df_predictions_test = rf_model.transform(test_dataset)


    # For J Stats Model on the Training Dataset
    log.info("Training Dataset")
    df_predictions_train = rf_model.transform(train_dataset)


    log.info("Getting AUC")
    ###################
    ##    Get AUC    ##
    ###################
    firstelement = F.udf(lambda x: float(x[0]), FloatType())

    # df_train_results = df_predictions_train.select(['probability', 'label'])
    df_train_results = df_predictions_train.withColumn("label_minus_one", (1.0 - F.col("label")))\
        .select(firstelement('probability').alias("probability"), F.col("label_minus_one").alias("label"))

    # ## prepare score-label set
    # log.info("Collect Results")
    # results_collect = df_train_results.collect()
    # results_list = [(float(i[0][0]), 1.0 - float(i[1])) for i in results_collect]
    # # Change this...
    # df_score_and_labels = spark.sparkContext.parallelize(results_list)


    metrics = BinaryClassificationMetrics(df_train_results.rdd)
    log.info("The AUC is (@numTrees=100): {}".format(metrics.areaUnderROC))
    log.info("Split Probabilities")
    udf_split0 = F.udf(lambda value: value[0].item(), FloatType())
    udf_split1 = F.udf(lambda value: value[1].item(), FloatType())
    df_output_train = df_predictions_train \
        .withColumn("prediction_0", udf_split0(F.col("probability"))) \
        .withColumn("prediction_1", udf_split1(F.col("probability")))

    df_output_train.persist()
    df_output_train.show()


    log.info("Get the predictions")
    ## Get max(p(thing is 1)) and min(p(thing is 0))
    max_probability = df_output_train.select("prediction_1").agg({"prediction_1": "max"}).collect().pop()['max(prediction_1)']
    min_probability = df_output_train.select("prediction_1").agg({"prediction_1": "min"}).collect().pop()['min(prediction_1)']


    log.info("Get the model range")
    probability_increment = prob_inc
    log.info("ProbabilityIncrement: {}".format(probability_increment))
    probability_range = math.ceil((max_probability - min_probability) / probability_increment)


    # Get the initial CM values
    log.info("Get the CM values")
    TP = df_output_train.filter((F.col("predictedLabel") == F.col("label")) & (F.col("label") == 1.0)).count()
    TN = df_output_train.filter((F.col("predictedLabel") == F.col("label")) & (F.col("label") == 0.0)).count()

    ## These 2 flipped?
    FP = df_output_train.filter((F.col("predictedLabel") != F.col("label")) & (F.col("label") == 0.0)).count()
    FN = df_output_train.filter((F.col("predictedLabel") != F.col("label")) & (F.col("label") == 1.0)).count()


    log.info("TP: {}".format(TP))
    log.info("TN: {}".format(TN))
    log.info("FP: {}".format(FP))
    log.info("FN: {}".format(FN))


    # Initialize Sensitivity and Specificity
    sensitivity_list = []
    specificity_list = []
    prob_threshold_list = []

    ## Loop through the probability interval, from min to max
    log.info("Get the CM values at each increment...")
    log.info("Probability Range: {}".format(probability_range))
    for i in range(int(probability_range) + 1):
        threshold = min_probability + (i) * probability_increment
        prob_threshold_list.append(threshold)
        threshold_column = F.when(F.col("prediction_1") > threshold, 1.0).otherwise(0.0)
        df_output_train = df_output_train.withColumn("updatedpredictions", threshold_column)

        TPU = df_output_train.filter((F.col("updatedpredictions") == F.col("label")) & (F.col("label") == 1.0)).count()
        TNU = df_output_train.filter((F.col("updatedpredictions") == F.col("label")) & (F.col("label") == 0.0)).count()
        FPU = df_output_train.filter((F.col("updatedpredictions") != F.col("label")) & (F.col("label") == 0.0)).count()
        FNU = df_output_train.filter((F.col("updatedpredictions") != F.col("label")) & (F.col("label") == 1.0)).count()

        Sensitivity = TPU / (TPU + FNU)
        sensitivity_list.append(Sensitivity)

        Specificity = TNU / (TNU + FPU)
        specificity_list.append(Specificity)


    log.info("Get the Max CM Values")
    sensitivity_np = np.array(sensitivity_list)
    specificity_np = np.array(specificity_list)


    pre_JStat_list = []
    pre_JStat_list = sensitivity_np + specificity_np
    pre_JStat_list[:] = [x - 1 for x in pre_JStat_list]

    # Find the position of the maximum J Statitics in the array
    JStat_max_value_pos = np.argmax(pre_JStat_list)

    # Assign the Probability with Maximum JStatistic
    prob_threshold = prob_threshold_list[JStat_max_value_pos]

    log.info("ProbThreshold : {}".format(prob_threshold))
    log.info("MinProbability: {}".format(min_probability))
    log.info("MaxProbability: {}".format(max_probability))

    ##########################
    ##    End Train/Test    ##
    ##########################


    #########################
    ##    Start Scoring    ##
    #########################

    ## Reference Scoring Dataset
    # Treat the columns for NULL values
    log.info("Scoring data...")
    sql_query_score_set = list(map(lambda x: "cast(case when " + x + " is NULL then 0 else " + x + " end as float) as "
                                             + x, cols_to_vectorized))
    # spark.sql("select * from ds_db.Acxiom_Transformed_May29 limit 1").printSchema()

    ## Query input data
    log.info("Gettin Data to score...")
    df_scoring_w_cols = spark.sql(acxiom_query % (','.join(sql_query_score_set)))


    ##########################################
    ##    Can't we take this from above?    ##
    ##########################################
    # Choose the columns to be taken for converting into Vector Assembler
    col_scoring_table = df_scoring_w_cols.columns
    # print("col_datazapp", col_datazapp)

    # Remove the 16 that are not there in the DataZapp Dataset as well
    cols_excluded_scoring = ['Sequence', 'label']
    cols_selected_scoring = [item for item in col_scoring_table if item not in cols_excluded_scoring]
    # print("cols_selected_scoring", cols_selected_scoring)


    # Convert into Vector Assembler
    log.info("Convert into Vector Assembler")
    feature_assembler_score = VectorAssembler(inputCols=cols_selected_scoring, outputCol="features")
    df_feature_assembler_score = feature_assembler_score.transform(df_scoring_w_cols)


    cols_score = ["Sequence", "label", "features"]
    df_rf_model_input = df_feature_assembler_score.select(cols_score)
    df_rf_model_input.orderBy(F.col("Sequence").desc()).show(truncate=False)
    df_rf_model_input.orderBy(F.col("Sequence").asc()).show(truncate=False)


    # Make predictions.
    log.info("Making Predictions...")
    df_predictions_score = rf_model.transform(df_rf_model_input.where(F.col('Sequence').isNotNull()))


    # threshold = threshold_input
    threshold_column = F.when(F.col("prediction_1") > threshold_input, 1.0).otherwise(0.0)


    log.info("Score Alignment")
    df_output_score = df_predictions_score \
        .withColumn("prediction_0", udf_split0(F.col("probability"))) \
        .withColumn("prediction_1", udf_split1(F.col("probability"))) \
        .withColumn(tribe_predictions, threshold_column) \
        .withColumn(tribe_score, ((F.col("prediction_1") - min_probability) * 100) /
                    (max_probability - min_probability)) \
        .withColumnRenamed("predictedLabel", tribe_predicted_label)

    # output2_score = output2_score \
    #     .withColumn(tribe_predictions, threshold_column) \
    #     .withColumn(tribe_score,
    #                 ((F.col("prediction_1") - min_probability) * 100) / (max_probability - min_probability))

    # output2_score = output2_score.withColumnRenamed("predictedLabel", tribe_predicted_label)

    df_random_forest = df_output_score.select(["Sequence", tribe_predictions, tribe_score, tribe_predicted_label])

    ## For logging and inspection purposes
    df_random_forest.groupby(tribe_predictions).agg({tribe_predictions: "count"}).show()


    df_output_train.unpersist()


    log.info("Getting Confusion Matrix")
    ################################
    ##    Get Confusion Matrix    ##
    ################################

    df_output_test = df_predictions_test\
        .withColumn("prediction_0", udf_split0(F.col("probability")))\
        .withColumn("prediction_1", udf_split1(F.col("probability"))) \
        .withColumn(tribe_predictions, threshold_column)\
        .withColumn(tribe_score, ((F.col("prediction_1") - min_probability) * 100) / (max_probability - min_probability))

    df_output_test.persist()

    # output2_test.show()


    ## For logging and inspection purposes
    ## Check if the Aligned Scores are within 0-100
    df_output_test.orderBy(F.col(tribe_score).asc()).show(1)
    df_output_test.orderBy(F.col(tribe_score).desc()).show(1)


    ## Confusion Matrix
    log.info("Confusion Matrix...")
    TruePositive_input_threshold = df_output_test \
        .filter((F.col(tribe_predictions) == F.col("label")) & (F.col("label") == 1.0)).count()

    TrueNegative_input_threshold = df_output_test \
        .filter((F.col(tribe_predictions) == F.col("label")) & (F.col("label") == 0.0)).count()

    FalsePositive_input_threshold = df_output_test \
        .filter((F.col(tribe_predictions) != F.col("label")) & (F.col("label") == 0.0)).count()

    FalseNegative_input_threshold = df_output_test \
        .filter((F.col(tribe_predictions) != F.col("label")) & (F.col("label") == 1.0)).count()

    Accuracy_input_threshold = (df_output_test.filter(F.col("label") == F.col(tribe_predictions)).count()) / df_output_test.count()

    Recall_input_threshold = safe_div(TruePositive_input_threshold, (TruePositive_input_threshold + FalseNegative_input_threshold))
    Precision_input_threshold = safe_div(TruePositive_input_threshold, (TruePositive_input_threshold + FalsePositive_input_threshold))
    F1Score_input_threshold = 2 * safe_div((Precision_input_threshold * Recall_input_threshold), (Precision_input_threshold + Recall_input_threshold))


    ## Comes from input threshold (optimized)
    log.info("TruePositive: {}".format(str(TruePositive_input_threshold)))
    log.info("TrueNegative: {}".format(str(TrueNegative_input_threshold)))
    log.info("FalsePositive: {}".format(str(FalsePositive_input_threshold)))
    log.info("FalseNegative: {}".format(str(FalseNegative_input_threshold)))
    log.info("Accuracy: {}".format(str(Accuracy_input_threshold)))
    log.info("Recall: {}".format(str(Recall_input_threshold)))
    log.info("Precision: {}".format(str(Precision_input_threshold)))
    log.info("F1Score: {}".format(str(F1Score_input_threshold)))


    ### 3. Confusion Matrix Before
    log.info("Confusion Matrix Before...")
    TruePositive_predicted = df_output_test.filter(
        (F.col("predictedLabel") == F.col("label")) & (F.col("label") == 1.0)).count()
    TrueNegative_predicted = df_output_test.filter(
        (F.col("predictedLabel") == F.col("label")) & (F.col("label") == 0.0)).count()
    FalsePositive_predicted = df_output_test.filter(
        (F.col("predictedLabel") != F.col("label")) & (F.col("label") == 0.0)).count()
    FalseNegative_predicted = df_output_test.filter(
        (F.col("predictedLabel") != F.col("label")) & (F.col("label") == 1.0)).count()
    Accuracy_predicted = (df_output_test.filter(
        F.col("label") == F.col("predictedLabel")).count()) / df_output_test.count()
    Recall_predicted = safe_div(TruePositive_predicted, (TruePositive_predicted + FalseNegative_predicted))
    Precision_predicted = safe_div(TruePositive_predicted, (TruePositive_predicted + FalsePositive_predicted))
    F1Score_predicted = 2 * safe_div((Precision_predicted * Recall_predicted), (Precision_predicted + Recall_predicted))


    ## Comes from predicted/learned threshold
    log.info("TruePositive_predicted: {}".format(str(TruePositive_predicted)))
    log.info("TrueNegative_predicted: {}".format(str(TrueNegative_predicted)))
    log.info("FalsePositive_predicted: {}".format(str(FalsePositive_predicted)))
    log.info("FalseNegative_predicted: {}".format(str(FalseNegative_predicted)))
    log.info("Accuracy_predicted: {}".format(str(Accuracy_predicted)))
    log.info("Recall_predicted: {}".format(str(Recall_predicted)))
    log.info("Precision_predicted: {}".format(str(Precision_predicted)))
    log.info("F1Score_predicted: {}".format(str(F1Score_predicted)))


    ## Create Metrics Dataframe
    log.info("Creating Metrics Dataframe")
    min_score = df_output_test.select(F.col(tribe_score)).orderBy(F.col(tribe_score).asc()).take(1)[0][0]
    max_score = df_output_test.select(F.col(tribe_score)).orderBy(F.col(tribe_score).desc()).take(1)[0][0]
    sub_tribe = tribe_predictions.split("_")[0]


    test_dataset_count = test_dataset.count()
    train_dataset_count = train_dataset.count()

    ## Calculate Representation
    train_representation = (train_dataset.where(F.col("label") == '1.0').count() / train_dataset_count) * 100
    test_representation = (test_dataset.where(F.col("label") == '1.0').count() / test_dataset_count) * 100
    threshold_is_ok = ((threshold_input > min_probability) & (threshold_input < max_probability))

    values_list = [(TruePositive_input_threshold, TrueNegative_input_threshold, FalsePositive_input_threshold,
                    FalseNegative_input_threshold, Accuracy_input_threshold, Recall_input_threshold,
                    Precision_input_threshold, F1Score_input_threshold, min_score, max_score, min_probability,
                    max_probability, prob_threshold, threshold_input, train_representation, test_representation,
                    threshold_is_ok, metrics.areaUnderROC, test_dataset_count, 1)]

    columns_list = ["{}_TP_long".format(sub_tribe), "{}_TN_long".format(sub_tribe), "{}_FP_long".format(sub_tribe),
                    "{}_FN_long".format(sub_tribe), "{}_Accuracy".format(sub_tribe), "{}_Recall".format(sub_tribe),
                    "{}_Precision".format(sub_tribe), "{}_F1Score".format(sub_tribe), "{}_minScore".format(sub_tribe),
                    "{}_maxScore".format(sub_tribe), "{}_minProbability".format(sub_tribe),
                    "{}_maxProbability".format(sub_tribe), "{}_automatedTreshold".format(sub_tribe),
                    "{}_manualThreshold".format(sub_tribe), "{}_trainRepresentation".format(sub_tribe),
                    "{}_testRepresentation".format(sub_tribe), "{}_threshold_is_ok".format(sub_tribe),
                    "{}_AuC".format(sub_tribe), "{}_test_split_count_long".format(sub_tribe), "row_number_long"]

    df_metrics = spark.createDataFrame(values_list, columns_list)\
        .withColumn("{}_TP".format(sub_tribe), F.col("{}_TP_long".format(sub_tribe)).cast(IntegerType()))\
        .withColumn("{}_TN".format(sub_tribe), F.col("{}_TN_long".format(sub_tribe)).cast(IntegerType()))\
        .withColumn("{}_FP".format(sub_tribe), F.col("{}_FP_long".format(sub_tribe)).cast(IntegerType()))\
        .withColumn("{}_FN".format(sub_tribe), F.col("{}_FN_long".format(sub_tribe)).cast(IntegerType()))\
        .withColumn("{}_test_split_count".format(sub_tribe),
                    F.col("{}_test_split_count_long".format(sub_tribe)).cast(IntegerType()))\
        .withColumn("row_number".format(sub_tribe), F.col("row_number_long".format(sub_tribe)).cast(IntegerType()))\
        .drop("{}_TP_long".format(sub_tribe)).drop("{}_TN_long".format(sub_tribe)).drop("{}_FP_long".format(sub_tribe))\
        .drop("{}_FN_long".format(sub_tribe)).drop("{}_test_split_count_long".format(sub_tribe)).drop("row_number_long")

    df_metrics.show()

    df_output_test.unpersist()
    log.info("Returning Dataframe")
    return df_random_forest, rf_model, df_metrics


def assemble_tribes(log, spark, processController, sql_query, train_test_split, seed_split, numTrees, seed_train,
                    prob_inc, acxiom_query):

    try:

        def dict_lookup(x):
            if broadcastVar.value.get(x) is None:
                return x
            else:
                return broadcastVar.value.get(x)

        udf_dict_lookup = F.udf(dict_lookup)


        # log.info("Querying Table...")
        # df_input = spark.sql(sql_query).sample(False, 0.3)
        df_input = sql_query

        #####################
        ##    Adventure    ##
        #####################
        input_dict_adv = processController.get("input_dict_Adventure")
        adventure_predictions = processController.get("tribe_predictions_Adventure")
        adventure_score = processController.get("tribe_score_Adventure")
        adventure_predicted_label = processController.get("tribe_predicted_label_Adventure")
        adventure_threshold = float(processController.get("adventure_threshold"))

        df_adventure, model_adventure, metrics_adventure = random_forest_func(log, df_input, input_dict_adv, train_test_split, seed_split, numTrees, seed_train, prob_inc, adventure_threshold, adventure_predictions, adventure_score, adventure_predicted_label, acxiom_query)


        ###################
        ##    Mystery    ##
        ###################
        input_dict_mystery = processController.get("input_dict_Mystery")
        mystery_predictions = processController.get("tribe_predictions_Mystery")
        mystery_score = processController.get("tribe_score_Mystery")
        mystery_predicted_label = processController.get("tribe_predicted_label_Mystery")
        mystery_threshold = float(processController.get("mystery_threshold"))

        df_mystery, model_mystery, metrics_mystery = random_forest_func(log, df_input, input_dict_mystery, train_test_split, seed_split, numTrees, seed_train, prob_inc, mystery_threshold, mystery_predictions, mystery_score, mystery_predicted_label, acxiom_query)


        #################
        ##    Quirk    ##
        #################
        input_dict_quirk = processController.get("input_dict_Quirk")
        quirk_predictions = processController.get("tribe_predictions_Quirk")
        quirk_score = processController.get("tribe_score_Quirk")
        quirk_predicted_label = processController.get("tribe_predicted_label_Quirk")
        quirk_threshold = float(processController.get("quirk_threshold"))

        df_quirk, model_quirk, metrics_quirk = random_forest_func(log, df_input, input_dict_quirk, train_test_split, seed_split, numTrees, seed_train,  prob_inc, quirk_threshold, quirk_predictions, quirk_score, quirk_predicted_label, acxiom_query)


        #####################
        ##    Glamorous    ##
        #####################
        input_dict_glamorous = processController.get("input_dict_Glamorous")
        glamorous_predictions = processController.get("tribe_predictions_Glamorous")
        glamorous_score = processController.get("tribe_score_Glamorous")
        glamorous_predicted_label = processController.get("tribe_predicted_label_Glamorous")
        glamorous_threshold = float(processController.get("glamorous_threshold"))

        df_glamorous, model_glamorous, metrics_glamorous = random_forest_func(log, df_input, input_dict_glamorous, train_test_split, seed_split, numTrees, seed_train, prob_inc, glamorous_threshold, glamorous_predictions, glamorous_score, glamorous_predicted_label, acxiom_query)


        #################
        ##    Party    ##
        #################
        input_dict_party = processController.get("input_dict_Party")
        party_predictions = processController.get("tribe_predictions_Party")
        party_score = processController.get("tribe_score_Party")
        party_predicted_label = processController.get("tribe_predicted_label_Party")
        party_threshold = float(processController.get("party_threshold"))

        df_party, model_party, metrics_party = random_forest_func(log, df_input, input_dict_party, train_test_split, seed_split, numTrees, seed_train, prob_inc, party_threshold, party_predictions, party_score, party_predicted_label, acxiom_query)


        #################
        ##    Chill    ##
        #################
        input_dict_chill = processController.get("input_dict_Chill")
        chill_predictions = processController.get("tribe_predictions_Chill")
        chill_score = processController.get("tribe_score_Chill")
        chill_predicted_label = processController.get("tribe_predicted_label_Chill")
        chill_threshold = float(processController.get("chill_threshold"))

        df_chill, model_chill, metrics_chill = random_forest_func(log, df_input, input_dict_chill, train_test_split, seed_split, numTrees, seed_train, prob_inc, chill_threshold, chill_predictions, chill_score, chill_predicted_label, acxiom_query)


        ################
        ##    Cool    ##
        ################
        input_dict_cool = processController.get("input_dict_Cool")
        cool_predictions = processController.get("tribe_predictions_Cool")
        cool_score = processController.get("tribe_score_Cool")
        cool_predicted_label = processController.get("tribe_predicted_label_Cool")
        cool_threshold = float(processController.get("cool_threshold"))

        df_cool, model_cool, metrics_cool = random_forest_func(log, df_input, input_dict_cool, train_test_split, seed_split, numTrees, seed_train, prob_inc, cool_threshold, cool_predictions, cool_score, cool_predicted_label, acxiom_query)


        log.info("Joining Models")
        ## Join all the tribes together
        df_all_tribes_joined = df_adventure \
            .join(df_mystery, 'Sequence', 'outer') \
            .join(df_quirk, 'Sequence', 'outer') \
            .join(df_glamorous, 'Sequence', 'outer') \
            .join(df_party, 'Sequence', 'outer') \
            .join(df_cool, 'Sequence', 'outer') \
            .join(df_chill, 'Sequence', 'outer')


        log.info("Joining Metrics")
        ## Join all the metrics together
        df_all_metrics_joined = metrics_adventure\
            .join(metrics_mystery, "row_number", "outer")\
            .join(metrics_quirk, "row_number", "outer")\
            .join(metrics_glamorous, "row_number", "outer")\
            .join(metrics_party, "row_number", "outer")\
            .join(metrics_chill, "row_number", "outer")\
            .join(metrics_cool, "row_number", "outer")\
            .drop("row_number")


        # timestamp = str(int(time.time()))
        # path_model = "s3a://vv-dev-emr-cluster/data/core/random_forest/random_forest_2018_07_28_test/models"
        # model_list = [model_adventure, model_mystery, model_quirk, model_glamorous, model_party, model_chill, model_cool]
        # model_list_order = ["Adventure", "Mystery", "Quirk", "Glamorous", "Party", "Chill", "Cool"]
        # for model, order in zip(model_list, model_list_order):
        #     file_path = path_model + order + timestamp
        #     model.write().overwrite().save(file_path)
        #

        # df_all_metrics_joined.show()


        #####################
        ##    Transpose    ##
        #####################
        log.info("Adding Predictions...")
        # Add the predictions together
        df_all_tribes_total_predictions = df_all_tribes_joined \
            .withColumn("Total_Predictions", F.col('Adventure_Predictions') + F.col('Mystery_Predictions') + F.col(
            'Quirk_Predictions') + F.col('Glamorous_Predictions') + F.col('Chill_Predictions') + F.col('Cool_Predictions') + F.col(
            'Party_Predictions'))


        log.info("Get those with only single tribe predicted...")
        # Get the list of sequences where there are no multiple predictions
        df_all_single_tribe = df_all_tribes_total_predictions.filter(F.col('Total_Predictions') == 1.0).select(
            ["Sequence", "Adventure_Predictions", "Mystery_Predictions", "Quirk_Predictions", "Glamorous_Predictions",
             "Chill_Predictions", "Cool_Predictions", "Party_Predictions"])


        log.info("Get those with multiple tribes predicted...")
        # Get the list of sequences where there are multiple predictions
        df_all_multi_tribe = df_all_tribes_total_predictions.filter(F.col('Total_Predictions') != 1.0).select(
            ["Sequence", "Adventure_Score", "Mystery_Score", "Quirk_Score", "Glamorous_Score", "Chill_Score", "Cool_Score",
             "Party_Score"])


        log.info("Transpose Single Tribe...")
        # Transpose the Dataset with Only One Predictions
        df_single_tribe_transposed = to_long(df_all_single_tribe, ["Sequence"])


        log.info("Transpose Multiple Tribes")
        # Transpose the Dataset with Multiple Predictions
        df_multi_tribe_transposed = to_long(df_all_multi_tribe, ["Sequence"])


        #############################################
        ##    Max for Multiple Predicted Tribes    ##
        #############################################
        def dict_lookup(x):
            if broadcastVar.value.get(x) is None:
                return x
            else:
                return broadcastVar.value.get(x)
        udf_dict_lookup = F.udf(dict_lookup)

        window = Window.partitionBy(df_multi_tribe_transposed['Sequence']).orderBy(df_multi_tribe_transposed['val'].desc())
        df_multi_tribe_transposed_max = df_multi_tribe_transposed.select(F.col('*'), F.row_number().over(window).alias(
            'row_number')).where(F.col('row_number') <= 1).select(["Sequence", "key", "val"])

        ## Can this be removed by changing value in process driver table? Remove "_Score"?
        myDict = {"Quirk_Score": "Quirk", "Adventure_Score": "Adventure", "Mystery_Score": "Mystery",
                  "Glamorous_Score": "Glamorous", "Party_Score": "Party", "Cool_Score": "Cool",
                  "Chill_Score": "Chill"}
        broadcastVar = spark.sparkContext.broadcast(myDict)


        log.info("Rename Multi Tribe columns")
        df_multi_tribe_transposed_max_renamed = df_multi_tribe_transposed_max \
            .select(*(udf_dict_lookup(F.col(c)).alias(c) for c in df_multi_tribe_transposed_max.columns))


        ##################################
        ##    Single Predicted Tribe    ##
        ##################################
        def dict_lookup(x):
            if broadcastVar.value.get(x) is None:
                return x
            else:
                return broadcastVar.value.get(x)
        udf_dict_lookup = F.udf(dict_lookup)

        ## Can this be removed by changing value in process driver table? Remove "_Score"?
        myDict = {"Quirk_Predictions": "Quirk", "Adventure_Predictions": "Adventure", "Mystery_Predictions": "Mystery", "Glamorous_Predictions": "Glamorous", "Party_Predictions": "Party", "Cool_Predictions": "Cool", "Chill_Predictions": "Chill"}
        broadcastVar = spark.sparkContext.broadcast(myDict)


        log.info("Rename Single Tribe columns")
        df_single_tribe_transposed_max = df_single_tribe_transposed \
            .select(*(udf_dict_lookup(F.col(c)).alias(c) for c in df_single_tribe_transposed.columns))
        df_single_tribe_transposed_max_renamed = df_single_tribe_transposed_max.where(df_single_tribe_transposed_max.val == 1.0)



        log.info("Union Single and Multi Tribe Dataframes")
        #######################################
        ##    Union Both Single and Multi    ##
        #######################################
        df_all_transposed_max = df_single_tribe_transposed_max_renamed \
            .select(["Sequence", "key"]) \
            .union(df_multi_tribe_transposed_max_renamed.select(["Sequence", "key"])) \
            .withColumnRenamed("Sequence", "id")\
            .withColumnRenamed("key", "subtribe")

        ## For logging and inspection purposes
        df_all_transposed_max.show()
        df_all_transposed_max.groupby(["subtribe"]).agg({"id": "count"}).show()

        model_list = [model_adventure, model_mystery, model_quirk, model_glamorous, model_party, model_chill, model_cool]

        log.info("Exiting assemble_tribes function")
        return df_all_transposed_max, model_list, df_all_metrics_joined

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the hive table.")


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName, Value from {} where processName='RandomForest'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        gnip_data = processController.get("gnip_data")
        train_test_split = processController.get("train_test_split")
        seed_split = int(processController.get("seed_split"))
        numTrees = int(processController.get("numTrees"))
        seed_train = int(processController.get("seed_train"))
        prob_inc = float(processController.get("prob_inc"))
        acxiom_query = processController.get("acxiom_query")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, spark, processController, gnip_data, train_test_split, seed_split, numTrees, seed_train,
                   prob_inc, acxiom_query)


def process(log, spark, processController, gnip_data, train_test_split, seed_split, numTrees, seed_train, prob_inc, acxiom_query):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    df_gnip_data = spark.sql(gnip_data)
    log.info("Starting GNIP Transpose...")
    df_gnip_transposed = gnip_transpose(log, spark, df_gnip_data)
    df_gnip_transposed.printSchema()
    df_gnip_transposed.show()
    log.info("Finished GNIP Transpose")

    # df_gnip_transposed.printSchema()

    sql_query = df_gnip_transposed

    log.info("Starting Random Forest Processing...")
    return assemble_tribes(log, spark, processController, sql_query, train_test_split, seed_split, numTrees, seed_train,
                           prob_inc, acxiom_query)


def store(processController, log, data, model_list, df_all_metrics_joined):
    """
    Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param data                 : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    try:
        path_core = processController.get("path_random_forest")
        path_model = processController.get("path_random_forest_models")
        path_metrics_log = processController.get("path_random_forest_metrics_log")
        path_metrics = processController.get("path_random_forest_metrics")

        hbase_ip = processController.get("hbase_ip")
        random_forest_hbase_table = processController.get("random_forest_hbase_table")

        check_tbl_exists_rf = processController.get("check_tbl_exists_rf")
        drop_table_query_rf = processController.get("drop_table_query_rf")
        create_table_query_rf = processController.get("create_table_query_rf")

        check_tbl_exists_metrics_log = processController.get("check_tbl_exists_metrics_log")
        drop_table_query_metrics_log = processController.get("drop_table_query_metrics_log")
        create_table_query_metrics_log = processController.get("create_table_query_metrics_log")

        check_tbl_exists_metrics = processController.get("check_tbl_exists_metrics")
        drop_table_query_metrics = processController.get("drop_table_query_metrics")
        create_table_query_metrics = processController.get("create_table_query_metrics")

        timestamp = str(int(time.time()))

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 1: Please verify process driver query execution")


    # ## Write to HBase
    # try:
    #     log.info("Save the results in HBase as %s" % random_forest_hbase_table)
    #     data\
    #         .withColumn("sailor_id", F.col("id").cast(IntegerType())).drop("id") \
    #         .withColumnRenamed("sailor_id", "id") \
    #         .withColumn("timestamp", F.lit(timestamp).cast(IntegerType())) \
    #         .write \
    #         .format("org.apache.phoenix.spark") \
    #         .option("table", random_forest_hbase_table) \
    #         .option("zkUrl", hbase_ip) \
    #         .mode("overwrite")\
    #         .save()
    #     log.info("Finished saving the results to HBase")
    #
    # except Exception as e:
    #     traceback.print_exc()
    #     raise TypeError(
    #         "Error Writing Table to HBase")
    #
    #
    # ## Write to S3
    # try:
    #     log.info("Save the results in hive as %s" % path_core)
    #     data.write.mode("overwrite").format("parquet").save(path_core)
    #     log.info("Finished saving the results in hive")
    #
    #
    # except Exception as e:
    #     traceback.print_exc()
    #     raise TypeError(
    #         "Error Code 4: Please verify correct storage location(s) ({}) ".format(path_core))


    ## Write Models to S3
    try:
        log.info("Saving Model to {}...".format(path_model))
        model_list_order = ["Adventure", "Mystery", "Quirk", "Glamorous", "Party", "Chill", "Cool"]
        for model, order in zip(model_list, model_list_order):
            file_path = path_model + timestamp + "/" + order
            model.write().overwrite().save(file_path)
        log.info("Finished saving models")

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 4: Please verify correct storage location(s) ({}) ".format(path_model))


    ## Save Latest Run as Metrics table - This table will contain only the latest run's metrics
    try:
        log.info("Saving Latest Run's Metrics to {}".format(path_metrics))
        df_all_metrics_joined.withColumn("timestamp", F.lit(timestamp).cast(IntegerType()))\
            .write.mode("overwrite").format("parquet").save(path_metrics)
        log.info("Finished saving Latest Run's Metrics")

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Failed to write the latest run's metrics to path {}".format(path_metrics))


    ## Check to see if Metrics Log exists,
    ##    If it does, append to it and save to - This table will contain the metrics for all the runs
    try:
        spark.read.parquet(path_metrics_log)

        log.info("Metrics Log Exists. Appending Latest Run's Metrics {}".format(path_metrics_log))
        df_all_metrics_joined \
            .withColumn("timestamp", F.lit(timestamp).cast(IntegerType()))\
            .write.mode("append").format("parquet").save(path_metrics_log)
        log.info("Finished  Appending Appending Latest Run's Metrics")

    ##    If it does not, create it.
    except:
        log.info("Metrics Log Does Not Exist, Creating Metrics Log...")
        # df_all_metrics_joined.show()
        df_all_metrics_joined \
            .withColumn("timestamp", F.lit(timestamp).cast(IntegerType())) \
            .write.mode("overwrite").format("parquet").save(path_metrics_log)
            # .withColumn("timestamp", F.lit(0).cast(IntegerType())) \
        log.info("Finished Creating Metrics Log")


    #########################
    ##    Create Tables    ##
    #########################

    ## Check and see if the Sailor Subtribe Table Exists
    try:
        spark.sql(check_tbl_exists_rf)
        log.info("Sailor Subtribe Table Already Exist, No Need to Create One.")

    except:
        log.info("Sailor Subtribe Table Does Not Exist!")
        log.info("Creating Sailor Subtribe Table from file...")
        spark.sql(drop_table_query_rf)
        spark.sql(create_table_query_rf.format(path_core))


    ## Check and see if the Metrics Log Table Exists
    try:
        spark.sql(check_tbl_exists_metrics_log)
        log.info("Metrics Log Already Exist, No Need to Create One.")

    except:
        log.info("Metrics Log Does Not Exist!")
        log.info("Creating Metrics Log from file...")
        spark.sql(drop_table_query_metrics_log)
        spark.sql(create_table_query_metrics_log.format(path_metrics_log))


    ## Check and see if the Metrics Table Exists
    try:
        spark.sql(check_tbl_exists_metrics)
        log.info("Metrics Table Already Exist, No Need to Create One.")

    except:
        log.info("Metrics Table Does Not Exist!")
        log.info("Creating Metrics Table from file...")
        spark.sql(drop_table_query_metrics)
        spark.sql(create_table_query_metrics.format(path_metrics))


def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Random_Forest")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.hvtb_nbx_core_processdriver")
    data, model_list, df_all_metrics_joined = initProcess(spark, processController, log)
    data.show()
    store(processController, log, data, model_list, df_all_metrics_joined)
    stopSparkSession(log, spark)
