##  spark-submit --name Random_Forest_Single_User --packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.1 --conf spark.executor.memoryOverhead=10240 --jars /home/ec2-user/phoenix_jars/phoenix-spark-4.11.0-HBase-1.3.jar,/home/ec2-user/phoenix_jars/phoenix-4.11.0-HBase-1.3-client.jar --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/random_forest_single_user/random_forest_single_user.py 99999,1234

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.window import Window
import pyspark.sql.functions as F
import uuid

from pyspark.ml.feature import VectorAssembler
from pyspark.ml import PipelineModel

import logging, traceback, sys, time

from confluent_kafka import avro as kafka_avro
from confluent_kafka.avro import AvroProducer as kafka_AvroProducer


def to_long(df, by):
    # Filter dtypes and split into column names and type description
    cols, dtypes = zip(*((c, t) for (c, t) in df.dtypes if c not in by))
    # Spark SQL supports only homogeneous columns
    assert len(set(dtypes)) == 1, "All columns have to be of the same type"

    # Create and explode an array of (column_name, column_value) structs
    kvs = F.explode(F.array([
        F.struct(F.lit(c).alias("key"), F.col(c).alias("val")) for c in cols
    ])).alias("kvs")

    return df.select(by + [kvs]).select(by + ["kvs.key", "kvs.val"])


def random_forest_func(log, df_rf_model_input, tribe_model_path, threshold_input, tribe_predictions, tribe_score,
                       tribe_predicted_label, min_prob, max_prob):
    # try:
    rf_model = PipelineModel.load(tribe_model_path)

    ## Make predictions.
    df_predictions_score = rf_model.transform(df_rf_model_input.where(F.col('Sequence').isNotNull()))

    threshold_column = F.when(F.col("prediction_1") > threshold_input, 1.0).otherwise(0.0)

    udf_split0 = F.udf(lambda value: value[0].item(), FloatType())
    udf_split1 = F.udf(lambda value: value[1].item(), FloatType())

    df_output_score = df_predictions_score \
        .withColumn("prediction_0", udf_split0(F.col("probability"))) \
        .withColumn("prediction_1", udf_split1(F.col("probability"))) \
        .withColumn(tribe_predictions, threshold_column) \
        .withColumn(tribe_score, ((F.col("prediction_1") - min_prob) * 100) /
                    (max_prob - min_prob)) \
        .withColumnRenamed("predictedLabel", tribe_predicted_label)

    df_random_forest = df_output_score.select(["Sequence", tribe_predictions, tribe_score, tribe_predicted_label])

    return df_random_forest

    # except Exception as e:
    #     traceback.print_exc()
    #     raise TypeError("Error Code 2: Please review the hive table.")


def assemble_tribes(log, spark, processController, sailor_to_classify, model_cols, acxiom_query, min_max_prob_query):
    try:
        sql_query_score_set = list(
            map(lambda x: "cast(case when " + x + " is NULL then 0 else " + x + " end as float) as "
                          + x, model_cols))

        log.info("sailor_to_classify in assemble tribes: ")
        log.info(sailor_to_classify)

        df_scoring_w_cols = spark.sql(acxiom_query % (','.join(sql_query_score_set))) \
            .where(F.col("Sequence").isin(sailor_to_classify))
        df_scoring_w_cols.cache()

        if df_scoring_w_cols.count() == 0:
            log.info("No Users to classify!")
            stopSparkSession(log, spark)
            exit()

        ##########################################
        ##    Can't we take this from above?    ##
        ##########################################
        # Choose the columns to be taken for converting into Vector Assembler
        col_scoring_table = df_scoring_w_cols.columns

        # Remove the 16 that are not there in the DataZapp Dataset as well
        cols_excluded_scoring = ['Sequence', 'label']
        cols_selected_scoring = [item for item in col_scoring_table if item not in cols_excluded_scoring]

        # Convert into Vector Assembler
        feature_assembler_score = VectorAssembler(inputCols=cols_selected_scoring, outputCol="features")
        df_feature_assembler_score = feature_assembler_score.transform(df_scoring_w_cols)

        cols_score = ["Sequence", "label", "features"]
        df_rf_model_input = df_feature_assembler_score.select(cols_score)
        df_rf_model_input.cache()

        # timestamp = str(spark.sql("SELECT MAX(`timestamp`) FROM vv_db.hvtb_nbx_core_subtribe_metrics").collect()[0][0])
        # min_max_prob_list = spark.sql(min_max_prob_query + str(timestamp)).collect()[0]

        #####################
        ##    Adventure    ##
        #####################
        adventure_predictions = processController.get("tribe_predictions_Adventure")
        adventure_score = processController.get("tribe_score_Adventure")
        adventure_predicted_label = processController.get("tribe_predicted_label_Adventure")
        adventure_threshold = float(processController.get("adventure_threshold"))
        adv_min_prob = float(processController.get("adv_min_prob"))
        adv_max_prob = float(processController.get("adv_max_prob"))
        adventure_model_path = processController.get("adventure_model_path")

        # adv_min_prob = min_max_prob_list.Adventure_minProbability
        # adv_max_prob = min_max_prob_list.Adventure_maxProbability
        # adventure_model_path = "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/" + timestamp + "/Adventure"

        log.info("Adventure Start: ")
        start_time = time.time()
        df_adventure = random_forest_func(log, df_rf_model_input, adventure_model_path, adventure_threshold,
                                          adventure_predictions, adventure_score, adventure_predicted_label,
                                          adv_min_prob, adv_max_prob)
        log.info("Adventure End: {}".format(time.time() - start_time))

        ###################
        ##    Mystery    ##
        ###################
        mystery_predictions = processController.get("tribe_predictions_Mystery")
        mystery_score = processController.get("tribe_score_Mystery")
        mystery_predicted_label = processController.get("tribe_predicted_label_Mystery")
        mystery_threshold = float(processController.get("mystery_threshold"))
        mystery_min_prob = float(processController.get("mystery_min_prob"))
        mystery_max_prob = float(processController.get("mystery_max_prob"))
        mystery_model_path = processController.get("mystery_model_path")

        # mystery_min_prob = min_max_prob_list.Mystery_minProbability
        # mystery_max_prob = min_max_prob_list.Mystery_maxProbability
        # mystery_model_path = "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/" + timestamp + "/Mystery"

        log.info("Mystery Start: ")
        start_time = time.time()
        df_mystery = random_forest_func(log, df_rf_model_input, mystery_model_path, mystery_threshold,
                                        mystery_predictions, mystery_score, mystery_predicted_label, mystery_min_prob,
                                        mystery_max_prob)
        log.info("Mystery End: {}".format(time.time() - start_time))

        #################
        ##    Quirk    ##
        #################
        quirk_predictions = processController.get("tribe_predictions_Quirk")
        quirk_score = processController.get("tribe_score_Quirk")
        quirk_predicted_label = processController.get("tribe_predicted_label_Quirk")
        quirk_threshold = float(processController.get("quirk_threshold"))
        quirk_min_prob = float(processController.get("quirk_min_prob"))
        quirk_max_prob = float(processController.get("quirk_max_prob"))
        quirk_model_path = processController.get("quirk_model_path")

        # quirk_min_prob = min_max_prob_list.Quirk_minProbability
        # quirk_max_prob = min_max_prob_list.Quirk_maxProbability
        # quirk_model_path = "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/" + timestamp + "/Quirk"

        log.info("Quirk Start: ")
        start_time = time.time()
        df_quirk = random_forest_func(log, df_rf_model_input, quirk_model_path, quirk_threshold, quirk_predictions,
                                      quirk_score, quirk_predicted_label, quirk_min_prob, quirk_max_prob)
        log.info("Quirk End: {}".format(time.time() - start_time))

        #####################
        ##    Glamorous    ##
        #####################
        glamorous_predictions = processController.get("tribe_predictions_Glamorous")
        glamorous_score = processController.get("tribe_score_Glamorous")
        glamorous_predicted_label = processController.get("tribe_predicted_label_Glamorous")
        glamorous_threshold = float(processController.get("glamorous_threshold"))
        glamorous_min_prob = float(processController.get("glamorous_min_prob"))
        glamorous_max_prob = float(processController.get("glamorous_max_prob"))
        glamorous_model_path = processController.get("glamorous_model_path")

        # glamorous_min_prob = min_max_prob_list.Glamorous_minProbability
        # glamorous_max_prob = min_max_prob_list.Glamorous_maxProbability
        # glamorous_model_path = "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/" + timestamp + "/Glamorous"

        log.info("Glamorous Start: ")
        start_time = time.time()
        df_glamorous = random_forest_func(log, df_rf_model_input, glamorous_model_path, glamorous_threshold,
                                          glamorous_predictions, glamorous_score, glamorous_predicted_label,
                                          glamorous_min_prob, glamorous_max_prob)
        log.info("Glamorous End: {}".format(time.time() - start_time))

        #################
        ##    Party    ##
        #################
        party_predictions = processController.get("tribe_predictions_Party")
        party_score = processController.get("tribe_score_Party")
        party_predicted_label = processController.get("tribe_predicted_label_Party")
        party_threshold = float(processController.get("party_threshold"))
        party_min_prob = float(processController.get("party_min_prob"))
        party_max_prob = float(processController.get("party_max_prob"))
        party_model_path = processController.get("party_model_path")

        # party_min_prob = min_max_prob_list.Party_minProbability
        # party_max_prob = min_max_prob_list.Party_maxProbability
        # party_model_path = "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/" + timestamp + "/Party"

        log.info("Party Start: ")
        start_time = time.time()
        df_party = random_forest_func(log, df_rf_model_input, party_model_path, party_threshold, party_predictions,
                                      party_score, party_predicted_label, party_min_prob, party_max_prob)
        log.info("Party End: {}".format(time.time() - start_time))

        #################
        ##    Chill    ##
        #################
        chill_predictions = processController.get("tribe_predictions_Chill")
        chill_score = processController.get("tribe_score_Chill")
        chill_predicted_label = processController.get("tribe_predicted_label_Chill")
        chill_threshold = float(processController.get("chill_threshold"))
        chill_min_prob = float(processController.get("chill_min_prob"))
        chill_max_prob = float(processController.get("chill_max_prob"))
        chill_model_path = processController.get("chill_model_path")

        # chill_min_prob = min_max_prob_list.Chill_minProbability
        # chill_max_prob = min_max_prob_list.Chill_maxProbability
        # chill_model_path = "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/" + timestamp + "/Chill"

        log.info("Chill Start: ")
        start_time = time.time()
        df_chill = random_forest_func(log, df_rf_model_input, chill_model_path, chill_threshold, chill_predictions,
                                      chill_score, chill_predicted_label, chill_min_prob, chill_max_prob)
        log.info("Chill End: {}".format(time.time() - start_time))

        ################
        ##    Cool    ##
        ################

        cool_predictions = processController.get("tribe_predictions_Cool")
        cool_score = processController.get("tribe_score_Cool")
        cool_predicted_label = processController.get("tribe_predicted_label_Cool")
        cool_threshold = float(processController.get("cool_threshold"))
        cool_min_prob = float(processController.get("cool_min_prob"))
        cool_max_prob = float(processController.get("cool_max_prob"))
        cool_model_path = processController.get("cool_model_path")

        # cool_min_prob = min_max_prob_list.Cool_minProbability
        # cool_max_prob = min_max_prob_list.Cool_maxProbability
        # cool_model_path = "s3a://vv-dev-emr-cluster/data/core/tribe_subtribe/RF_Models/" + timestamp + "/Cool"

        log.info("Cool Start: ")
        start_time = time.time()
        df_cool = random_forest_func(log, df_rf_model_input, cool_model_path, cool_threshold, cool_predictions,
                                     cool_score, cool_predicted_label, cool_min_prob, cool_max_prob)
        log.info("Cool End: {}".format(time.time() - start_time))

        ## Join all the tribes together
        df_all_tribes_joined = df_adventure \
            .join(df_mystery, 'Sequence', 'outer') \
            .join(df_quirk, 'Sequence', 'outer') \
            .join(df_glamorous, 'Sequence', 'outer') \
            .join(df_party, 'Sequence', 'outer') \
            .join(df_cool, 'Sequence', 'outer') \
            .join(df_chill, 'Sequence', 'outer')
        log.info("All Models Joined")
        df_all_tribes_joined.cache()
        log.info("=============================================")
        log.info("========    Start Classifications    ========")
        log.info("=============================================")

        #####################
        ##    Transpose    ##
        #####################
        log.info("Adding Predictions...")
        # Add the predictions together
        df_all_tribes_total_predictions = df_all_tribes_joined \
            .withColumn("Total_Predictions", F.col('Adventure_Predictions') + F.col('Mystery_Predictions') + F.col(
            'Quirk_Predictions') + F.col('Glamorous_Predictions') + F.col('Chill_Predictions') + F.col(
            'Cool_Predictions') + F.col(
            'Party_Predictions'))

        log.info("Get those with only single tribe predicted...")
        # Get the list of sequences where there are no multiple predictions
        df_all_single_tribe = df_all_tribes_total_predictions.filter(F.col('Total_Predictions') == 1.0).select(
            ["Sequence", "Adventure_Predictions", "Mystery_Predictions", "Quirk_Predictions", "Glamorous_Predictions",
             "Chill_Predictions", "Cool_Predictions", "Party_Predictions"])

        log.info("Get those with multiple tribes predicted...")
        # Get the list of sequences where there are multiple predictions
        df_all_multi_tribe = df_all_tribes_total_predictions.filter(F.col('Total_Predictions') != 1.0).select(
            ["Sequence", "Adventure_Score", "Mystery_Score", "Quirk_Score", "Glamorous_Score", "Chill_Score",
             "Cool_Score",
             "Party_Score"])

        log.info("Transpose Single Tribe...")
        # Transpose the Dataset with Only One Predictions
        df_single_tribe_transposed = to_long(df_all_single_tribe, ["Sequence"])

        log.info("Transpose Multiple Tribes")
        # Transpose the Dataset with Multiple Predictions
        df_multi_tribe_transposed = to_long(df_all_multi_tribe, ["Sequence"])

        #############################################
        ##    Max for Multiple Predicted Tribes    ##
        #############################################
        def dict_lookup(x):
            if broadcastVar.value.get(x) is None:
                return x
            else:
                return broadcastVar.value.get(x)

        udf_dict_lookup = F.udf(dict_lookup)

        window = Window.partitionBy(df_multi_tribe_transposed['Sequence']).orderBy(
            df_multi_tribe_transposed['val'].desc())
        df_multi_tribe_transposed_max = df_multi_tribe_transposed.select(F.col('*'), F.row_number().over(window).alias(
            'row_number')).where(F.col('row_number') <= 1).select(["Sequence", "key", "val"])

        ## Can this be removed by changing value in process driver table? Remove "_Score"?
        myDict = {"Quirk_Score": "Quirk", "Adventure_Score": "Adventure", "Mystery_Score": "Mystery",
                  "Glamorous_Score": "Glamorous", "Party_Score": "Party", "Cool_Score": "Cool",
                  "Chill_Score": "Chill"}
        broadcastVar = spark.sparkContext.broadcast(myDict)

        log.info("Rename Multi Tribe columns")
        df_multi_tribe_transposed_max_renamed = df_multi_tribe_transposed_max \
            .select(*(udf_dict_lookup(F.col(c)).alias(c) for c in df_multi_tribe_transposed_max.columns))

        ##################################
        ##    Single Predicted Tribe    ##
        ##################################
        def dict_lookup(x):
            if broadcastVar.value.get(x) is None:
                return x
            else:
                return broadcastVar.value.get(x)

        udf_dict_lookup = F.udf(dict_lookup)

        ## Can this be removed by changing value in process driver table? Remove "_Score"?
        myDict = {"Quirk_Predictions": "Quirk", "Adventure_Predictions": "Adventure", "Mystery_Predictions": "Mystery",
                  "Glamorous_Predictions": "Glamorous", "Party_Predictions": "Party", "Cool_Predictions": "Cool",
                  "Chill_Predictions": "Chill"}
        broadcastVar = spark.sparkContext.broadcast(myDict)

        log.info("Rename Single Tribe columns")
        df_single_tribe_transposed_max = df_single_tribe_transposed \
            .select(*(udf_dict_lookup(F.col(c)).alias(c) for c in df_single_tribe_transposed.columns))
        df_single_tribe_transposed_max_renamed = df_single_tribe_transposed_max.where(
            df_single_tribe_transposed_max.val == 1.0)

        log.info("Union Single and Multi Tribe Dataframes")
        #######################################
        ##    Union Both Single and Multi    ##
        #######################################
        df_all_transposed_max = df_single_tribe_transposed_max_renamed \
            .select(["Sequence", "key"]) \
            .union(df_multi_tribe_transposed_max_renamed.select(["Sequence", "key"])) \
            .withColumnRenamed("Sequence", "id") \
            .withColumnRenamed("key", "subtribe")

        log.info("Exiting assemble_tribes function")
        return df_all_transposed_max

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the hive table.")


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='RandomForest'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log, sailor_to_classify):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        acxiom_query = processController.get("acxiom_query")
        model_cols = processController.get("model_cols").split(",")
        min_max_prob_query = processController.get("min_max_prob_query")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, spark, processController, sailor_to_classify, model_cols, acxiom_query, min_max_prob_query)


def process(log, spark, processController, sailor_to_classify, model_cols, acxiom_query, min_max_prob_query):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :return                     : Spark Dataframe with columns : [].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting Random Forest Processing...")
    return assemble_tribes(log, spark, processController, sailor_to_classify, model_cols, acxiom_query,
                           min_max_prob_query)


def store(processController, log, data):
    """
    Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param data                 : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    try:
        hbase_ip = processController.get("hbase_ip")
        acxiom_reservation_hbase_table = processController.get("acxiom_reservation_hbase_table")
        random_forest_hbase_table = processController.get("random_forest_hbase_table")
        timestamp = str(int(time.time()))

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 1: Please verify process driver query execution")

    try:
        log.info("Save the results in HBase as %s" % random_forest_hbase_table)

        list_of_updated_users = data.select("id").rdd.flatMap(lambda x: x).collect()

        # list_of_updated_users_int = list(map(lambda x: int(x), list_of_updated_users))
        # log.info(list_of_updated_users_int)
        # log.info(type(list_of_updated_users_int))

        df_records_to_write = spark.read.format("org.apache.phoenix.spark") \
            .option("table", random_forest_hbase_table) \
            .option("zkUrl", hbase_ip) \
            .load() \
            .select("C360ID", "SEAWARE_ID", "CRM_ID", "MASTER_ID", "VXP_ID") \
            .where(F.col("SEAWARE_ID").isin(list_of_updated_users))
        df_records_to_write.show()

        if df_records_to_write.count() > 0:

            joined_data = data.join(df_records_to_write, data.id == df_records_to_write.SEAWARE_ID, how="right_outer")
            joined_data.show()

            joined_final_data = joined_data.withColumn("SAILOR_SUBTRIBE", F.concat(F.lit("The "), F.col("SUBTRIBE"))) \
                .withColumn("SAILOR_TRIBE",
                            F.when(F.col("SAILOR_SUBTRIBE").isin("The Mystery", "The Adventure", "The Quirk"),
                                   "Explorer")
                            .when(F.col("SAILOR_SUBTRIBE").isin("The Cool", "The Party", "The Glamorous"), "Revel")
                            .otherwise("Bask")) \
                .drop("ID", "SUBTRIBE", "timestamp")
            joined_final_data.show()

            joined_final_data \
                .withColumn("timestamp", F.lit(timestamp)) \
                .write \
                .format("org.apache.phoenix.spark") \
                .option("table", random_forest_hbase_table) \
                .option("zkUrl", hbase_ip) \
                .mode("overwrite") \
                .save()
            log.info("Finished saving results into HBase")
        else:
            log.info("No records to write")

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Writing Table to HBase")


def push_to_kafka(log, processController, data):
    try:

        # kafka_schema_text = processController.get("kafka_schema_text")
        bootstrap_servers = processController.get("bootstrap_servers")
        schema_registry_url = processController.get("schema_registry_url")
        topic = processController.get("topic")

        log.info("Format Data to be ready for Kafka")
        kafka_schema_text = """{
          "type": "record",
          "name": "TribeRefreshedEvent",
          "namespace": "com.virginvoyages.data.event",
          "doc": "Informational event with fresh Tribe/Subtribe data for Sailor.",
          "fields": [
            {
              "name": "n",
              "type": {
                "type": "string",
                "avro.java.string": "String"
              },
              "doc": "Name of this event."
            },
            {
              "name": "ts",
              "type": {
                "type": "long",
                "logicalType": "timestamp-millis"
              },
              "doc": "Time stamp in micro second of when the event was created."
            },
            {
              "name": "ci",
              "type": [
                "null",
                {
                  "type": "string",
                  "avro.java.string": "String"
                }
              ],
              "doc": "Correlation ID of the transaction that created this event."
            },
            {
              "name": "cn",
              "type": [
                "null",
                {
                  "type": "string",
                  "avro.java.string": "String"
                }
              ],
              "doc": "Name of the component generating this event."
            },
            {
              "name": "tg",
              "type": [
                "null",
                {
                  "type": "string",
                  "avro.java.string": "String"
                }
              ],
              "doc": "Tags associated with the event as meta data."
            },
            {
              "name": "pl",
              "type": {
                "type": "record",
                "name": "TribeRefreshedPayload",
                "doc": "Payload with updated Tribe and Sub-Tribe of Sailor",
                "fields": [
                  {
                    "name": "C360ID",
                    "type": {
                      "type": "string",
                      "avro.java.string": "String"
                    },
                    "doc": "Customer 360 ID of sailor."
                  },
                  {
                    "name": "seawareClientID",
                    "type": {
                      "type": "string",
                      "avro.java.string": "String"
                    },
                    "doc": "seawareClientID."
                  },
                  {
                    "name": "tribe",
                    "type": {
                      "type": "string",
                      "avro.java.string": "String"
                    },
                    "doc": "Tribe of the sailor."
                  },
                  {
                    "name": "subTribe",
                    "type": {
                      "type": "string",
                      "avro.java.string": "String"
                    },
                    "doc": "Subtribe of the sailor."
                  }
                ]
              },
              "doc": "Specific payload for this event."
            }
          ]
        }"""

        log.info("Create Schema")
        # kafka_schema = avro.schema.Parse(kafka_schema_text)

        id_list = data.select("id").collect()
        subtribe_list = data.select("subtribe").collect()

        data_range = data.count()

        tribe_subtribe_mapping_dict = {"Mystery": "Explorer", "Adventure": "Explorer", "Quirk": "Explorer",
                                       "Cool": "Revel", "Party": "Revel", "Glamorous": "Revel",
                                       "Chill": "Bask"}

        value_schema = kafka_avro.loads(kafka_schema_text)
        avroProducer = kafka_AvroProducer({'bootstrap.servers': bootstrap_servers,
                                           'schema.registry.url': schema_registry_url},
                                          default_value_schema=value_schema)

        for i in range(data_range):
            value = {"n": "tribe.created", "ts": int(time.time()), "ci": str(uuid.uuid4()), "cn": "nbx", "tg": "test",
                     "pl": {"C360ID": "", "seawareClientID": str(id_list[i][0]),
                            "tribe": tribe_subtribe_mapping_dict.get(subtribe_list[i][0]),
                            "subTribe": "The " + subtribe_list[i][0]}}
            log.info("Value: ".format(value))
            log.info(value)
            log.info("Topic: ")
            log.info(topic)
            avroProducer.produce(topic=topic, value=value)

        avroProducer.flush()

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Pushing Data to Kafka Queue")


def update_processed_flag(log, processController, data):
    hbase_ip = processController.get("hbase_ip")
    seaware_reservation_hbase_table = processController.get("seaware_reservation_hbase_table")
    random_forest_hbase_table = processController.get("random_forest_hbase_table")

    log.info("Get List of updated users")
    list_of_updated_users = data.select("id").rdd.flatMap(lambda x: x).collect()
    log.info("list_of_updated_users: ".format(list_of_updated_users))
    log.info(list_of_updated_users)

    # list_of_updated_users_int = list(map(lambda x: int(x), list_of_updated_users))

    df_records_to_write = spark.read.format("org.apache.phoenix.spark") \
        .option("table", random_forest_hbase_table) \
        .option("zkUrl", hbase_ip) \
        .load() \
        .select("SEAWARE_ID") \
        .where(F.col("SEAWARE_ID").isin(list_of_updated_users))
    df_records_to_write.show()

    list_of_updated_sailors = df_records_to_write.select("SEAWARE_ID").rdd.flatMap(lambda x: x).collect()

    list_of_updated_users_int = list(map(lambda x: int(x), list_of_updated_sailors))
    # log(list_of_updated_users_int)

    if len(list_of_updated_users_int) != 0:

        log.info("Reading HBase Table")
        df_records_to_update = spark.read \
            .format("org.apache.phoenix.spark") \
            .option("table", seaware_reservation_hbase_table) \
            .option("zkUrl", hbase_ip) \
            .load().where(F.col("LOYALTYMEMBERSHIPID").isin(list_of_updated_users_int))
        df_records_to_update.show()

        if df_records_to_update.count() > 0:

            log.info("Changing Value")
            df_updated_records = df_records_to_update.drop("TRIBEPROCESSED").withColumn("TRIBEPROCESSED", F.lit("Y"))

            log.info("Updating Table Values")
            df_updated_records.write \
                .format("org.apache.phoenix.spark") \
                .option("table", seaware_reservation_hbase_table) \
                .option("zkUrl", hbase_ip) \
                .mode("overwrite") \
                .save()

            log.info("Done")

        else:
            log.info("No records to update")

    else:
        log.info("No records to update")


def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Random_Forest")
    log = get_logger()

    ## Make sure correct number of arguments
    if not len(sys.argv) > 1:
        log.info("Not enough arguments! Shutting down!")
        log.info("Arguments: ")
        log.info(sys.argv)
        stopSparkSession(log, spark)
        exit()

    log.info("sys.argv[1]: ")
    log.info(sys.argv[1])
    sailors = sys.argv[1].split(",")
    sailor_to_classify = [i.split('-', 1)[-1] for i in sailors]
    log.info("Sailors: ")
    log.info(sailor_to_classify)
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    data = initProcess(spark, processController, log, sailor_to_classify)
    data.show()

    if data.count() > 0:
        store(processController, log, data)
        push_to_kafka(log, processController, data)
        update_processed_flag(log, processController, data)

    else:
        log.info("No Users to Classify")

    stopSparkSession(log, spark)


