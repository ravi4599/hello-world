########################################################
#                                                      #
# Inputs:                                              #
#   3rd Party Datazapp Data                            #
#      Format:                                         #
#         id_seaware  :STRING                          #
#         attr1       :STRING                          #
#         attr2       :STRING                          #
#          ..         :...                             #
#         attr160     :STRING                          #
#                                                      #
#                                                      #
# Spark Submit Script:                                 #
#   spark-submit                                       #
#   --py-files affinity_synonym_generator.py           #
#   --jars /home/ec2-user/phoenix_jars/                #
#      phoenix-spark-4.11.0-HBase-1.3.jar,             #
#      /home/ec2-user/phoenix_jars/phoenix-            #
#      4.11.0-HBase-1.3-client.jar,/home/              #
#      ec2-user/phoenix_jars/mysql-connector           #
#      -java-5.1.45-bin.jar                            #
#   --conf spark.yarn.executor.memoryOverhead=10240    #
#   --num-executors 20                                 #
#   --executor-memory 8G                               #
#   --executor-cores 4                                 #
#   --name Calendar_Feedback_Loop                      #
#   --deploy-mode cluster                              #
#   --master yarn /path/to/feedback_loop.py            #
#                                                      #
########################################################

from pyspark.sql.types import *
from pyspark.sql.functions import col, explode, lit, split, round, row_number, sum, collect_set, size, when, array_contains, concat, regexp_replace, udf, lower
from pyspark.sql import SparkSession
import affinity_synonym_generator

import traceback, logging, time



##########################
#                        #
#    Define Functions    #
#                        #
##########################

def write_timestamp(time_stamp, hue_tbl_details):
    df_time_stamp = spark.createDataFrame([(1, "sailor_feedback", time_stamp)]).toDF("id", "process_name","time_stamp")
    df_time_stamp.write \
        .format("jdbc") \
        .options(
            url=hue_tbl_details[0],
            driver="com.mysql.jdbc.Driver",
            dbtable=hue_tbl_details[1],
            user=hue_tbl_details[2],
            password=hue_tbl_details[3],)\
        .mode("overwrite").save()


def concat_column_elements(col_1, col_2):
    lst = []
    for i, j in zip(col_1, col_2):
        lst.append(i + "-" + j)
    return lst
udf_concat_column_elements = udf(concat_column_elements, ArrayType(StringType()))


def add_element(lst, item_to_add):
    """
    Appends an item to a list

    :param lst            : list to append to
    :param item_to_add    : item to append to the list
    :return               : list with item added to it
    """
    return lst + item_to_add
udf_add_element = udf(add_element, ArrayType(StringType()))


def feedback_loop(log, spark, hbase_ip, sailor_syns_query, last_update_timestamp, feedback_location, seaware_activity_data, SAILOR_CALENDAR_NEW):
    """ Read the sailor ids and nbxKeys from the Sailor Feedback Table. This will tell us which activities a sailor
    has booked. We must also take the Sailor Recommendation History Table into account. We get which activities these
    sailor's have booked and their descriptions (which we will use as affinities). We then join the Feedback Table to
    the Recommendation History Table (based on nbxKeys) to find which which activities were booked by which sailors.
    We finally join that data to the Datazapp Data.

    :param log              : logger, used for logging execution details
    :param spark            : current SparkSession
    :param hbase_ip         : current ip of the hbase tables
    :param input_location   : name of datazapp data table
    :param days             : number of days worth of data to get
    :return: df_union_tbl   : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                              affinity is an attribute describing the sailor.
    """

    #######################################
    ##    Capture Timestamp for later    ##
    #######################################
    time_stamp = int(time.time()*1000)

    try:

        ######################################
        ##    Query HBase Activity Table    ##
        ######################################

        log.info("Getting Data from Activity Table.")
        df_activity_table = spark.read \
            .format("org.apache.phoenix.spark") \
            .option("table", seaware_activity_data) \
            .option("zkUrl", hbase_ip) \
            .load()

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the hbase table or the hbase connection to the Sailor Recommendations Table.")

    df_activity_table2 = df_activity_table \
        .select("ACTIVITY_ID", "ACTIVITY_TITLE", "START_DATETIME", "END_DATETIME", "ACTIVITY_TYPE",
                "PACKAGE_TYPE", "SURPRISE_EVENT", "SIGNATURE_EVENT") \
        .where((lower(col('activity_title')).like("%cirque soleil%")) |
               (lower(col('activity_title')).like("%lobster%")) |
               (lower(col('activity_title')).like("%i heart bikes%")) |
               (lower(col('activity_title')).like("%wine tasting%")) |
               (lower(col('activity_title')).like("%fancy-main lunch%")) |
               (lower(col('activity_title')).like("%fancy-dinner%")) |
               (lower(col('activity_title')).like("%fancy-dinner%"))
               )

    #####################################################################################################################################
    ##    Query SAILOR_CALENDAR_NEW Hbase table for the selected package and selected dining options and parse to get their details    ##
    #####################################################################################################################################
    try:
        log.info("Getting Data from Sailor Feedback Table")
        df_feedback_table = spark.read \
            .format("org.apache.phoenix.spark") \
            .option("table", SAILOR_CALENDAR_NEW) \
            .option("zkUrl", hbase_ip) \
            .load()\
            .where((col("LAST_UPDATE_TIMESTAMP") > (last_update_timestamp)))

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 2: Please review the hbase table or the hbase connection to the Sailor Feedback Table.")

    if df_feedback_table.count() > 0:
        try:

            ################################################################
            ##    Parse out nbxKey(s) () and SailorID    {SailID:nbxKey}  ##
            ################################################################

            log.info("Parse out nbxKeys and SailorIDs.")

            df_feedback_table_2 = df_feedback_table\
                .withColumn("json",
                            concat(lit("{\"SailorID\": "),
                                   split(col("SAILOR_ID"), "_").getItem(0),
                                   lit(", "),
                                   regexp_replace(col("CALENDAR_DETAILS"), '^\{', '')))\
                .select("json")

            df_feedback_table_3 = spark.read.json(df_feedback_table_2.rdd.map(lambda x: x["json"]))

            # df_all_package = df_feedback_table_3\
            #     .where(col("vx:SelectedPackages").isNotNull())\
            #     .where(col("vx:SelectedDining").isNotNull())\
            #     .select(col("SailorID"), col("vx:SelectedPackages.vx:SelectedPackage._CruisePackageCode").alias("cruise"),
            #             col("vx:SelectedDining._DiningRoom").alias("dining"),
            #             col("vx:SelectedDining._Sitting").alias("sitting"))\
            #     .withColumn("Dining_Sitting", udf_concat_column_elements(col("dining"), col("sitting")))\
            #     .drop(col("dining")).drop(col("sitting"))

            df_all_package = df_feedback_table_3\
                .where(col("vx:SelectedPackages").isNotNull())\
                .where(col("vx:SelectedDining").isNotNull())\
                .select(col("SailorID"), col("vx:SelectedPackages.vx:SelectedPackage._CruisePackageCode").alias("cruise"),
                        col("vx:SelectedDining._DiningRoom").alias("dining"),
                        col("vx:SelectedDining._Sitting").alias("sitting"))\
                .withColumn("Dining_Sitting", udf_concat_column_elements(col("dining"), col("sitting")))\
                .drop(col("dining")).drop(col("sitting"))\
                .withColumn("selected_activities", explode(udf_add_element(col("cruise"), col("Dining_Sitting"))))\
                .drop("Dining_Sitting").drop("cruise")\
                .dropDuplicates(["SailorID", "selected_activities"])\
                .withColumnRenamed("SailorID", "id_seaware")\
                .withColumnRenamed("selected_activities", "keywords")

            ####################################################################
            ##    Generate Synonyms/Affinities for the feedback Affinities    ##
            ####################################################################

            df_sails_acts_syns = affinity_synonym_generator.get_synonyms(log, spark, df_all_package, "id_seaware") \
                .select("id_seaware", "synonyms", "keywords") \
                .withColumn("weight", lit(float(1)))\
                .distinct()
            df_sails_acts_syns.show()


            ###################################################
            ##    Check and see if it has been run before    ##
            ###################################################
            try:
                feedback_file = spark.read.parquet(feedback_location)

            except:
                feedback_file = None

            if feedback_file is not None:
                ########################################################
                ##    If it has been run before, use feedback data    ##
                ########################################################
                df_sailor_syns = feedback_file.select("id_seaware", "synonyms", "keywords_list", "UpdatedWeight")\
                    .withColumnRenamed("UpdatedWeight", "weight")\
                    .withColumn("keywords", explode(col("keywords_list")))\
                    .drop("keywords_list") \
                    .select("id_seaware", "synonyms", "keywords", "weight")
                print("Not None")

            else:
                ########################################################################
                ##    If it has not been run before, read processed 3rd Party Data    ##
                ########################################################################
                df_sailor_syns = spark.sql(sailor_syns_query) \
                    .select("id_seaware", "synonyms")\
                    .withColumn("keywords", lit("None"))\
                    .withColumn("weight", lit(float(1)))
                print("Is None")


            #######################################################
            ##    Union Difference of above and Datazapp Data    ##
            #######################################################
            log.info("Unioning Joined Table with Datazapp Data.")
            df_union_tbl = df_sailor_syns.union(df_sails_acts_syns)


            #############################
            ##    Calculate Weights    ##
            #############################

            log.info("Groupby, agg, sum weights")
            df_union_tbl_group_agg = df_union_tbl\
                .groupby(["id_seaware", "synonyms"])\
                .agg(collect_set(col("keywords")).alias("keywords_list"))\
                .withColumn("UpdatedWeight", lit(size(col("keywords_list"))).cast(DoubleType())) \
                .withColumn("Source"
                            , when((size(col("keywords_list")) > 1) & (array_contains(col("keywords_list"), "None")),
                                   "Reinforced")
                            .when(~ (array_contains(col("keywords_list"), "None")), "Stated")
                            .otherwise("Derived")
                            )


            log.info("Get total weight")
            df_total_weights = df_union_tbl_group_agg\
                .groupby(["id_seaware"])\
                .agg({"UpdatedWeight": "sum"})\
                .withColumnRenamed("sum(UpdatedWeight)", "TotalUpdatedWeight")


            log.info("Get % of total weight")
            df_percent_of_whole = df_union_tbl_group_agg\
                .join(df_total_weights, 'id_seaware', 'inner')\
                .withColumn("UpdatedWeightPercentages", round((col("UpdatedWeight") * 100) / col("TotalUpdatedWeight"), 4))\
                .withColumn("time_stamp", lit(time_stamp).cast(LongType()))\
                .select("id_seaware", "synonyms", "keywords_list", "UpdatedWeight", "TotalUpdatedWeight", "UpdatedWeightPercentages", "Source", "time_stamp")


        except Exception as e:
            traceback.print_exc()
            raise TypeError("Error Code 2: Please review the input data to ensure it is proper.")

    else:
        log.info("No Feedback to Consider...")
        df_percent_of_whole = None

    return df_percent_of_whole, time_stamp


def initSparkSession(appName):
    """ Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """ Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='FeedbackLoop'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """ Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        hbase_ip = processController.get("hbase_ip")
        sailor_syns_query = processController.get("sailor_syns_query")
        feedback_location = processController.get("feedback_location")
        seaware_activity_data = processController.get("seaware_activity_data")
        SAILOR_CALENDAR_NEW = processController.get("SAILOR_CALENDAR_NEW")
        hue_tbl_details = processController.get("hue_tbl_details")[1:-1].split(",")
        last_update_timestamp = spark.read\
            .format("jdbc").options(
                url=hue_tbl_details[0],
                driver="com.mysql.jdbc.Driver",
                dbtable=hue_tbl_details[1],
                user=hue_tbl_details[2],
                password=hue_tbl_details[3])\
            .load()\
            .select("time_stamp")\
            .collect()[0][0]

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (hbase_ip|sailor_syns_query|last_update_timestamp)")

    return process(log, spark, hbase_ip, sailor_syns_query, last_update_timestamp, feedback_location, seaware_activity_data, SAILOR_CALENDAR_NEW)


def process(log, spark, hbase_ip, sailor_syns_query, last_update_timestamp, feedback_location, seaware_activity_data, SAILOR_CALENDAR_NEW):
    """ Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting Feedback Loop...")
    return feedback_loop(log, spark, hbase_ip, sailor_syns_query, last_update_timestamp, feedback_location, seaware_activity_data, SAILOR_CALENDAR_NEW)


def store(processController, log, feedback, time_stamp):
    """ Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param feedback             : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    if feedback is not None:
        try:
            path_core = processController.get("path_feedback_loop")
            hue_tbl_details = processController.get("hue_tbl_details")[1:-1].split(",")

        except Exception as e:
            traceback.print_exc()
            raise TypeError(
                "Error Code 1: Please verify process driver query execution")

        try:

            log.info("Save the results in hive as %s" % path_core)
            feedback.write.mode('overwrite').format("parquet").save(path_core)

            log.info("Save the timestamp in hue")
            write_timestamp(time_stamp, hue_tbl_details)

        except Exception as e:
            traceback.print_exc()
            raise TypeError(
                "Error Code 4: Please verify correct storage location {} ".format(path_core))

    else:
        log.info("No Feedback to Consider...")


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calendar_Feedback_Loop")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    feedback, time_stamp = initProcess(spark, processController, log)
    store(processController, log, feedback, time_stamp)
    stopSparkSession(log, spark)


###############################################
#                                             #
# Outputs:                                    #
#    Intermediate Table:                      #
#                                             #
#       vv_db.vv_synonyms_sailor_affinities   #
#          Format:                            #
#             id_seaware        :STRING       #
#             sailor_synonyms   :STRING       #
#             time_stamp        :STRING       #
#             date_stamp        :TIMESTAMP    #
#                                             #
###############################################

