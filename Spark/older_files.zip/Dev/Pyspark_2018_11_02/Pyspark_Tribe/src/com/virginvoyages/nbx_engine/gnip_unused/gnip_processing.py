##  spark-submit --name GNIP_Processing --conf spark.executor.memoryOverhead=10240 --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/gnip_processing/gnip_processing.py

import pyspark.sql.functions as F

from pyspark.sql.types import *
from pyspark.sql import SparkSession

from itertools import chain
from collections import Counter

import numpy
import nltk
import re, traceback, logging


##########################
#                        #
#    Define Functions    #
#                        #
##########################

def string_to_list_of_strings(in_string):
    """
    Converts a list-of-strings which has been converted to a string, back to a list-of-strings

    :param in_string    : input string which used be a list-of-strings but has been converted into a string
    :return             : a list of strings
    """
    list_of_strings = []
    for y in in_string:
        list_of_strings.append(re.sub('[\[,\"\]]+','',y))
    return list_of_strings
udf_string_to_list_of_strings = F.udf(string_to_list_of_strings, ArrayType(StringType()))


def remove_from_wrapped_array(wrapped_array):
    """
    Converts a wrapped array to an array

    :param wrapped_array    : input wrapped array of items
    :return                 : a list of items
    """
    out_array = []
    for lst in wrapped_array:
        for item in lst:
            if item != '':
                out_array.append(item.replace(" ", ""))
    return out_array
udf_remove_from_wrapped_array = F.udf(remove_from_wrapped_array, ArrayType(StringType()))



def add_pos_tag(word):
    """
    Finds and returns the Part of Speech of in the input word.

    :param word    : input word for which we want to find the Part of Speech Tag
    :return        : the part of speech of the input word
    """
    try:
        return nltk.pos_tag(nltk.word_tokenize(word))[0][1]
    except Exception as e:
        return "null"
udf_add_pos_tag = F.udf(add_pos_tag, StringType())


def to_list(word):
    """
    Converts a string to a list of strings

    :param word    : Converts a single string to a list of strings
    :return        : a list of strings
    """
    return [word]
udf_to_list = F.udf(to_list, ArrayType(StringType()))


def synonyms_fnc(word_list):
    """
    Collects all synonyms for the input word into a list.
    If no synonyms exist, the input word is returned in a list.

    :param word : Tokenized word
    :return     : A list of all the synonyms available for the given word.
                  If no synonyms exist, the input word is returned in a list.
    """
    a = []
    for word in word_list:
        synset = nltk.corpus.wordnet.synsets(word)
        # If there are synonyms...
        if len(synset) > 0:
            a.append(list(chain.from_iterable((syn.lemma_names() for syn in synset))))
    # If no synonyms, keep the original word
        else:
            a.append([word])
        flat_list = [item for sublist in a for item in sublist]
    return list(set(flat_list))
udf_synonyms_fnc = F.udf(synonyms_fnc, ArrayType(StringType()))


def filter_syns_func(topic, topic_pos_tag):
    """
    Filters out certain pos tags before finding synonyms for the words

    :param topic_list        : the topic to find synonyms for
    :param topic_pos_tag     : the pos tag for the input topic
    :return                  :
    """
    if(topic_pos_tag not in ["VBN", "CD", "DT", "FW", "PRP$", "PRP", "MD"]):
        return synonyms_fnc(topic)
    else:
        return topic
udf_filter_syns_func = F.udf(filter_syns_func, ArrayType(StringType()))


def max_tribe(sub_tribe_list, tweets_count):
    """
    Finds the max tribe for a given user based on the tweet count for each sub-tribe. If there is a tie for the max,
    'Mixed' is returned.

    :param sub_tribe_list       : list of sub-tribes
    :param tweets_count         : the tweet count for the user
    :return                     : the assigned sub-tribe for the user. If there is a tie for the max,
                                  'Mixed' is returned
    """
    if len(tweets_count) == 1:
        return sub_tribe_list[0]
    else:
        c = Counter()
        for q,w in zip(sub_tribe_list,tweets_count):
            c[q] += w
        tribe_distinct = list(c.keys())
        count = list(c.values())
        max_count = numpy.amax(count)
        if count.count(max_count) == 1:
            ind = count.index(max_count)
            return tribe_distinct[ind]
        else:
            return "Mixed"
udf_max_tribe = F.udf(max_tribe, StringType())


def add_element(lst, item_to_add):
    """
    Appends an item to a list

    :param lst            : list to append to
    :param item_to_add    : item to append to the list
    :return               : list with item added to it
    """
    return [lst] + item_to_add
udf_add_element = F.udf(add_element, ArrayType(StringType()))


def gnip_processing(log, spark, gnip_data, brand_details, attribute_mapping):
    """

    :param log                  : logger, used for logging execution details
    :param spark                : current SparkSession
    :param gnip_data            : location of the gnip data
    :param brand_details        : location of the brand details document
    :param attribute_mapping    : location of the attribute mapping document
    :return:
    """

    try:
        ## Read GNIP Table
        log.info("Read GNIP table")
        df_twitter_data = spark.sql(gnip_data)\
            .withColumn("klout_user_id", F.col("klout_user_id").cast(StringType())) \
            .where(F.col("klout_user_id").isNotNull())\
            .withColumnRenamed("topics_displayName", "topic_display_name")\
            .withColumnRenamed("topics_score", "topic_score")\
            .withColumn("prepared_topic_display_name", udf_string_to_list_of_strings(F.split(F.col("topic_display_name"), ",")))

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the Hive table or the connection to Hive.")

    try:
        ## Import Brand-Tribe Mapping
        log.info("Read brand details table")
        df_brand_details = spark\
            .read\
            .option("header", "true")\
            .csv(brand_details)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the Hive table or the connection to Hive.")


    try:
        log.info("Select only brand_name, handle_details, and subtribe")
        df_brand_details_distinct = df_brand_details.select("brand_name", "Handle Details", "SubTribe")\
            .withColumnRenamed("Handle Details", "handle_details")\
            .distinct()


        conditions = ((df_twitter_data.brand_name == df_brand_details_distinct.brand_name) |
                      (df_twitter_data.brand_name == df_brand_details_distinct.handle_details))


        log.info("Group By klout_user_id and collect details for each user")
        df_twitter_data_joined = df_twitter_data\
            .groupBy("klout_user_id", "brand_name")\
            .agg(F.count(F.lit(int(1))).cast(IntegerType()).alias("tweet_count"),
                 F.collect_list('prepared_topic_display_name').alias('prepared_topic_display_name'),
                 F.collect_list('topic_score').alias('topic_score'),
                 F.collect_list('topic_type').alias('topic_type')) \
            .join(F.broadcast(df_brand_details_distinct), conditions)\
            .drop(df_brand_details_distinct.brand_name).drop(df_brand_details_distinct.handle_details) \
            .groupBy("klout_user_id")\
            .agg(F.collect_list("brand_name").alias("brand_name"),
                 F.collect_list("SubTribe").alias("SubTribe"),
                 F.collect_list("tweet_count").alias("tweet_count"),
                 F.collect_list('prepared_topic_display_name')[0].alias('prepared_topic_display_name'),
                 F.collect_list('topic_score')[0].alias('topic_score'),
                 F.collect_list('topic_type')[0].alias('topic_type')
                 )


        log.info("Select only klout_user_id and topics")
        df_topics = df_twitter_data_joined.select("klout_user_id", F.col("prepared_topic_display_name").alias("topics"))


        log.info("Prepare topic data")
        df_exp_topics_not_null = df_topics.withColumn("topic", F.explode(udf_remove_from_wrapped_array(F.col("topics"))))\
            .drop('topics')\
            .where(F.col("topic") != '')\
            .where(F.col("topic").isNotNull())


        log.info("Add Part of Speech Tag")
        df_pos_tag = df_exp_topics_not_null.withColumn("topic_pos_tag", udf_add_pos_tag("topic"))


        log.info("Prepare Topic data and generate synonyms")
        df_topic_synonyms = df_pos_tag.withColumn("topic_list", udf_to_list(F.col("topic")))\
            .withColumn("synonyms", udf_filter_syns_func(F.col("topic_list"), F.col("topic_pos_tag")))\
            .withColumn("synonyms2", udf_filter_syns_func(F.col("synonyms"), F.col("topic_pos_tag")))


        log.info("Read Attribute Mappling list")
        # New Attribute List w/ Alternatives
        df_attrs_list = spark\
            .read\
            .option("header", "True")\
            .csv(attribute_mapping)\
            .select(F.col("Attribute").alias("attribute_value"), F.col("Alternate").alias("alternate"))


        log.info("Explode list of synonyms")
        df_exp_syns = df_topic_synonyms.withColumn("exploded_syns", F.explode(F.col("synonyms2")))


        log.info("Find matches between attributes and synonyms")
        df_common_syn_topics = df_exp_syns.join(df_attrs_list, df_exp_syns.exploded_syns == df_attrs_list.alternate)


        log.info("Group by klout_user_id and collect attributes")
        df_collect_common_syns = df_common_syn_topics\
            .groupBy(F.col("klout_user_id"))\
            .agg(F.collect_set(F.col("attribute_value")).alias("synonyms_list"))


        log.info("Group By klout_user_id and collect details for each user")
        df_joined_syns = df_twitter_data_joined.join(df_collect_common_syns, "klout_user_id", "inner")


        log.info("Find which sub-tribe a user belongs to")
        df_max_tribe = df_joined_syns\
            .withColumn('Max_Tribe', udf_max_tribe(df_joined_syns.SubTribe, df_joined_syns.tweet_count))


        log.info("Append the topic matches to the user's sub-tribe")
        df_topic_match_list = df_max_tribe\
            .withColumn("topic_match_list", udf_add_element(F.col("Max_Tribe"), F.col("synonyms_list")))


        log.info("Exiting GNIP Processing Script...")
        return df_topic_match_list


    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 2: Please review the hive table or the hbase connection to the Sailor Recommendations Table.")


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='GNIP_Processing'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        gnip_data = processController.get("gnip_data")
        brand_details = processController.get("brand_details")
        attribute_mapping = processController.get("attribute_mapping")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, spark, gnip_data, brand_details, attribute_mapping)


def process(log, spark, gnip_data, brand_details, attribute_mapping):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Starting GNIP Processing...")
    return gnip_processing(log, spark, gnip_data, brand_details, attribute_mapping)


def store(processController, log, data):
    """
    Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param data                 : Spark Dataframe with columns: [id_seaware, affinity]. id_seaware is the sailor's id,
                                  affinity is an attribute describing the sailor.
    :return                     : N/A
    """
    try:
        path_core = processController.get("gnip_processing_core")
        check_tbl_exists = processController.get("check_tbl_exists")
        drop_table_query = processController.get("drop_table_query")
        create_table_query = processController.get("create_table_query")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")


    try:
        log.info("Save the results in hive as %s" % path_core)
        data.write.mode('overwrite').format("parquet").save(path_core)


    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}) ".format(path_core))

    try:
        spark.sql(check_tbl_exists)
        log.info("Table Already Exist, No Need to Create One.")

    except:
        log.info("Table Does Not Exist!")
        log.info("Creating Table from file...")
        spark.sql(drop_table_query)
        spark.sql(create_table_query.format(path_core))



def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("GNIP_Processing")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    data = initProcess(spark, processController, log)
    # store(processController, log, data)
    stopSparkSession(log, spark)
