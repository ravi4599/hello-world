#############################################################
#                                                           #
# Inputs:                                                   #
#   tag Data from Seaware (JSON or XML)                     #
#   This will most likely be acquired                       #
#    through an OTA call.                                   #
#      Format:                                              #
#          Title                    :STRING                 #
#          Short description        :STRING                 #
#          Long description         :STRING                 #
#          Start date/time          :STRING                 #
#          End date/time            :STRING                 #
#          Capacity                 :STRING                 #
#          Tag Type                 :STRING                 #
#          Price                    :STRING                 #
#          VoyageID                 :STRING                 #
#          Package Type             :STRING                 #
#          Package Code             :STRING                 #
#          Destination/Port         :STRING                 #
#          Status                   :STRING                 #
#          Internal Comments        :STRING                 #
#          Tribe(s) Categorization  :STRING                 #
#          Invitation Only          :STRING                 #
#          Signature Event          :STRING                 #
#                                                           #
#                                                           #
# Spark Submit Script:                                      #
#   spark-submit --name Calculate_tag_synonyms              #
#   --py-files affinity_synonym_generator.py                #
#   --num-executors 4                                       #
#   --executor-memory 4G                                    #
#   --driver-memory 4G                                      #
#   --executor-cores 8                                      #
#   --master yarn                                           #
#   --deploy-mode cluster                                   #
#   /tmp/py_scripts/calculate_synonyms_content_tag.py       #
#                                                           #
#############################################################


import traceback, logging, sys

aff_syn_gen_loc = "/data/apps/talend/shared/scripts"
sys.path.append(aff_syn_gen_loc)

from pyspark.sql import SparkSession
import affinity_synonym_generator




##########################
#                        #
#    Define Functions    #
#                        #
##########################


def prepare_data(log, spark, sql_query):
    """ Prepares the input into a form that can be consumed by the get_synonyms function. The intention is to keep
    all get_synonym functions identical.

    NOTE - We do not as of yet know what the input tag data will look like, so this function will most
           likely change

    :param log              : current logger
    :param spark            : current SparkSession
    :param input_location   : name of tag data table
    :param attributes       : relevant columns to select from tag data table
    :return                 : Spark Dataframe with columns : [id, keywords]
    """
    try:
        log.info("Importing data from {}".format(sql_query))
        ## This will need to change to point to the CMS table, once that is finished.
		## -- Check with Upendra for table details
        prepared_data = spark.sql(sql_query)
        prepared_data = prepared_data.withColumnRenamed("title", "keywords")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code : Error reading data from {}. Please review input_location for errors. ".format(sql_query))

    return prepared_data


# Initialize Spark Session
def initSparkSession(appName):
    """ Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """ Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='TagSynonyms_Content'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


# Get variables to run main function
def initProcess(spark, processController, log):
    """ Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_tag, synonyms, time_stamp, date_stamp].
                                  id_tag is the tag's id, synonyms is a synonym corresponding to the tag,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        sql_query = processController.get("sql_query")
        id = processController.get("id")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (input_location|attributes)")

    return process(log, spark, sql_query, id)


def process(log, spark, sql_query, id):
    """ Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param input_location       : name of tag data table
    :param attributes           : Relevant columns to select from tag data table
    :return                     : Spark Dataframe with columns : [id_tag, synonyms, time_stamp, date_stamp].
                                  id_tag is the tag's id, synonyms is a synonym corresponding to the tag,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Preparing Data")
    df_prepared_data = prepare_data(log, spark, sql_query)
    log.info("Calculating Tag Synonyms")
    return affinity_synonym_generator.get_synonyms(log, spark, df_prepared_data, id).drop("keywords")


def store(processController, log, tag_synonyms):
    """ Saves the match_scores Dataframe to the location(s) defined in processController

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param tag_synonyms         : Spark Dataframe with columns : [id_tag, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the tag,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    :return                     : N/A
    """

    try:
        path_core = processController.get("path_tag_synonyms")
        path_staging = processController.get("path_tag_synonyms_staging")
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution")

    try:

        log.info("Save the results in hive as %s" % path_core)
        tag_synonyms.write.mode('overwrite').format("parquet").save(path_core)

        log.info("Save the results in hive as %s" % path_staging)
        spark.read.parquet(path_core).write.mode('overwrite').format("parquet").save(path_staging)

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 4: Please verify correct storage location(s) ({}|{}) ".format(path_core, path_staging))


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("Calculate_Content_tag_synonyms")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    tag_synonyms = initProcess(spark, processController, log)
    store(processController, log, tag_synonyms)
    stopSparkSession(log, spark)


################################################
#                                              #
# Outputs:                                     #
#    Intermediate Table:                       #
#       vv_db.vv_synonyms_tag_affinities       #
#          Format:                             #
#             id_tag              :STRING      #
#             tag_synonyms        :STRING      #
#             time_stamp          :STRING      #
#             date_stamp          :TIMESTAMP   #
#                                              #
################################################

