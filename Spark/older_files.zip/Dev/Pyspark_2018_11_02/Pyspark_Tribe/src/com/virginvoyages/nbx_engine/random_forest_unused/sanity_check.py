##  spark-submit --name Random_Forest_Sanity_Check --conf spark.yarn.executor.memoryOverhead=10240 --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/random_forest/sanity_check.py

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

import logging, traceback


# 1 - DONE - TESTED
## Input GNIP data - make sure all subtribes are represented
def gnip_processed_data_all_subtribes(log, subtribe_list, gnip_file):
    # subtribe_list = ["Adventure", "Mystery", "Quirk", "Glamorous", "Party", "Chill", "Cool"]
    # gnip_file = "s3a://vv-dev-emr-cluster/data/twitter/gnip_processing_output_spark_submit_001_sample_core"

    ## Read processed gnip data, group by user id, make sure all subtribes are present
    subtribes_present = spark.read.parquet(gnip_file)\
            .withColumn("subtribe_string", F.col("Subtribe").getItem(0))\
            .groupBy("klout_user_id")\
            .agg(F.collect_list(F.col("subtribe_string")).alias("b"))\
            .where(F.size(F.col("b")) == 1)\
            .select((F.col("b").getItem(0)).alias("subtribe")).distinct().collect()

    for item in subtribes_present:
        if item[0] not in subtribe_list:
            log.info(item[0] + " is not an appropriate subtribe!")
    if len(subtribes_present) == 7:
        log.info("All is Good! :)")
    else:
        log.info("All is NOT Good! :(")


# 2 - DONE - TESTED
## After Train/Test Split, make sure each subtribe makes up at least 2% of the overall
def target_subtribe_distributiion_rate(log, representation_threshold, metrics_file, test_cols, train_cols):
    # representation_threshold = 2.0
    # metrics_file = "s3://vv-dev-emr-cluster/tmp/RF_Metrics_Base/"

    # test_cols = ["Adventure_testRepresentation", "Mystery_testRepresentation", "Quirk_testRepresentation",
    #         "Glamorous_testRepresentation", "Party_testRepresentation", "Cool_testRepresentation",
    #         "Chill_testRepresentation"]

    # train_cols = ["Adventure_trainRepresentation", "Mystery_trainRepresentation", "Quirk_trainRepresentation",
    #         "Glamorous_trainRepresentation", "Party_trainRepresentation", "Cool_trainRepresentation",
    #         "Chill_trainRepresentation"]


    ## Read Metrics File
    data = spark.read.parquet(metrics_file)

    ## Approach 1 -- Is this guarenteed to produce exact results?
    test_data = data.select(test_cols).collect()[0]
    train_data = data.select(train_cols).collect()[0]

    adv_trainRep = float(test_data[0]) > representation_threshold
    myst_trainRep = float(test_data[1]) > representation_threshold
    quirk_trainRep = float(test_data[2]) > representation_threshold
    glam_trainRep = float(test_data[3]) > representation_threshold
    party_trainRep = float(test_data[4]) > representation_threshold
    cool_trainRep = float(test_data[5]) > representation_threshold
    chill_trainRep = float(test_data[6]) > representation_threshold

    adv_testRep = float(train_data[0]) > representation_threshold
    myst_testRep = float(train_data[1]) > representation_threshold
    quirk_testRep = float(train_data[2]) > representation_threshold
    glam_testRep = float(train_data[3]) > representation_threshold
    party_testRep = float(train_data[4]) > representation_threshold
    cool_testRep = float(train_data[5]) > representation_threshold
    chill_testRep = float(train_data[6]) > representation_threshold


    ## Check Train Representations...
    if adv_trainRep:
        log.info("Adventure Train Representation is ok!")
    else:
        log.info("Adventure Train Representation is NOT ok!")

    if myst_trainRep:
        log.info("Mystery Train Representation is ok!")
    else:
        log.info("Mystery Train Representation is NOT ok!")

    if quirk_trainRep:
        log.info("Quirk Train Representation is ok!")
    else:
        log.info("Quirk Train Representation is NOT ok!")

    if glam_trainRep:
        log.info("Glam Train Representation is ok!")
    else:
        log.info("Glam Train Representation is NOT ok!")

    if party_trainRep:
        log.info("Party Train Representation is ok!")
    else:
        log.info("Party Train Representation is NOT ok!")

    if cool_trainRep:
        log.info("Cool Train Representation is ok!")
    else:
        log.info("Cool Train Representation is NOT ok!")

    if chill_trainRep:
        log.info("Chill Train Representation is ok!")
    else:
        log.info("Chill Train Representation is NOT ok!")


    ## Check Test Representation
    if adv_testRep:
        log.info("Adventure Test Representation is ok!")
    else:
        log.info("Adventure Test Representation is NOT ok!")

    if myst_testRep:
        log.info("Mystery Test Representation is ok!")
    else:
        log.info("Mystery Test Representation is NOT ok!")

    if quirk_testRep:
        log.info("Quirk Test Representation is ok!")
    else:
        log.info("Quirk Test Representation is NOT ok!")

    if glam_testRep:
        log.info("Glam Test Representation is ok!")
    else:
        log.info("Glam Test Representation is NOT ok!")

    if party_testRep:
        log.info("Party Test Representation is ok!")
    else:
        log.info("Party Test Representation is NOT ok!")

    if cool_testRep:
        log.info("Cool Test Representation is ok!")
    else:
        log.info("Cool Test Representation is NOT ok!")

    if chill_testRep:
        log.info("Chill Test Representation is ok!")
    else:
        log.info("Chill Test Representation is NOT ok!")


# 3 - DONE - NEEDS TESTING
## Read metrics table, make sure threshold is between maxProb and minProb
def check_adjusted_probability_threshold(log, metrics_file, thresh_cols):
    # metrics_file = "s3://vv-dev-emr-cluster/tmp/RF_Metrics_Base/"
    # thresh_cols = [Adventure_threshold_is_ok,Mystery_threshold_is_ok,Quirk_threshold_is_ok,Glamorous_threshold_is_ok,Party_threshold_is_ok,Cool_threshold_is_ok,Chill_threshold_is_ok,timestamp]


    ## Read Metrics Table
    data = spark.read.parquet(metrics_file).select(thresh_cols).collect()[0]


    ## Check if threshold is between maxProb and minProb
    adv_thresh = data[0]
    myst_thresh = data[1]
    quirk_thresh = data[2]
    glam_thresh = data[3]
    party_thresh = data[4]
    cool_thresh = data[5]
    chill_thresh = data[6]


    if adv_thresh:
        log.info("Adventure Threshold is ok!")
    else:
        log.info("Adventure Threshold is NOT ok!")

    if myst_thresh:
        log.info("Mystery Threshold is ok!")
    else:
        log.info("Mystery Threshold is NOT ok!")

    if quirk_thresh:
        log.info("Quirk Threshold is ok!")
    else:
        log.info("Quirk Threshold is NOT ok!")

    if glam_thresh:
        log.info("Glam Threshold is ok!")
    else:
        log.info("Glam Threshold is NOT ok!")

    if party_thresh:
        log.info("Party Threshold is ok!")
    else:
        log.info("Party Threshold is NOT ok!")

    if cool_thresh:
        log.info("Cool Threshold is ok!")
    else:
        log.info("Cool Threshold is NOT ok!")

    if chill_thresh:
        log.info("Chill Threshold is ok!")
    else:
        log.info("Chill Threshold is NOT ok!")


# 5 - DONE - NEEDS TESTING
## Sub-tribe Assignment
def all_records_have_subtribe_assigned(log, random_forest_file, subtribe_list):
    # random_forest_file = "s3a://vv-dev-emr-cluster/data/core/random_forest/random_forest"
    # subtribe_list = ["Adventure", "Mystery", "Quirk", "Glamorous", "Party", "Chill", "Cool"]
    ## Read "Data_All"
    df_random_forest_output = spark.read.parquet(random_forest_file)

    ## Check if all records have a sub-tribe assigned
    non_subtribe_list = df_random_forest_output\
        .where(F.col("key").isin(subtribe_list) == False)\
        .collect()

    if non_subtribe_list != []:
        log.info("Some records do NOT have an appropriate subtribe assigned.")
    else:
        log.info("All records have appropriate subtribes assigned.")
        log.info(non_subtribe_list)


# 6 - DONE - TESTED
## Score Alignment between 0 - 1
def score_alignment_between_0_and_1(log, metrics_file, min_cols, max_cols):
    # metrics_file = "s3://vv-dev-emr-cluster/tmp/RF_Metrics_Base/"

    # ## Min Probability Columns
    # min_cols = [Adventure_minProbability,Mystery_minProbability,Quirk_minProbability,Glamorous_minProbability,                Party_minProbability,Cool_minProbability,Chill_minProbability,timestamp]
    #
    # ## Max Probability Columns
    # max_cols = [Adventure_maxProbability,Mystery_maxProbability,Quirk_maxProbability,Glamorous_maxProbability,Party_maxProbability,Cool_maxProbability,Chill_maxProbability,timestamp]



    min_prob = spark.read.parquet(metrics_file)\
        .select(min_cols)

    max_prob = spark.read.parquet(metrics_file)\
        .select(max_cols)


    ## Approach 1 -- Is this guarenteed to produce exact results?
    min_prob_values = min_prob.collect()[0]
    max_prob_values = max_prob.collect()[0]

    ## Check if each subtribe's max_prob <= 100 & min_prob >= 0
    adv_prob = (1 >= float(max_prob_values[0])) & (float(min_prob_values[0]) >= 0)
    myst_prob = (1 >= float(max_prob_values[1])) & (float(min_prob_values[1]) >= 0)
    quirk_prob = (1 >= float(max_prob_values[2])) & (float(min_prob_values[2]) >= 0)
    glam_prob = (1 >= float(max_prob_values[3])) & (float(min_prob_values[3]) >= 0)
    party_prob = (1 >= float(max_prob_values[4])) & (float(min_prob_values[4]) >= 0)
    cool_prob = (1 >= float(max_prob_values[5])) & (float(min_prob_values[5]) >= 0)
    chill_prob = (1 >= float(max_prob_values[6])) & (float(min_prob_values[6]) >= 0)


    if adv_prob:
        log.info("Adventure Probability Score is ok!")
        log.info("Max Probability: {}".format(max_prob_values[0]))
        log.info("Min Probability: {}".format(min_prob_values[0]))
        log.info("(1 >= {} AND {} >= 0  is {}".format(float(max_prob_values[0]), float(min_prob_values[0]), adv_prob))
    else:
        log.info("Adventure Probability Score is NOT ok!")
        log.info("Max Probability: {}".format(max_prob_values[0]))
        log.info("Min Probability: {}".format(min_prob_values[0]))
        log.info("(1 >= {} AND {} >= 0  is {}".format(float(max_prob_values[0]), float(min_prob_values[0]), adv_prob))

    if myst_prob:
        log.info("Mystery Probability Score is ok!")
    else:
        log.info("Mystery Probability Score is NOT ok!")

    if quirk_prob:
        log.info("Quirk Probability Score is ok!")
    else:
        log.info("Quirk Probability Score is NOT ok!")

    if glam_prob:
        log.info("Glam Probability Score is ok!")
    else:
        log.info("Glam Probability Score is NOT ok!")

    if party_prob:
        log.info("Party Probability Score is ok!")
    else:
        log.info("Party Probability Score is NOT ok!")

    if cool_prob:
        log.info("Cool Probability Score is ok!")
    else:
        log.info("Cool Probability Score is NOT ok!")

    if chill_prob:
        log.info("Chill Probability Score is ok!")
    else:
        log.info("Chill Probability Score is NOT ok!")


# 7 - DONE - TESTED
## Check Model AUC
def check_model_auc(log, auc_threshold, metrics_file, auc_cols):
    # auc_threshold = 0.05
    # metrics_file = "s3://vv-dev-emr-cluster/tmp/RF_Metrics_Base/"

    ## Read Metrics Table
    # auc_cols = [F.col("Adventure_AuC"), F.col("Mystery_AuC"),
    #             F.col("Quirk_AuC"), F.col("Glamorous_AuC"),
    #             F.col("Party_AuC"), F.col("Cool_AuC"),
    #             F.col("Chill_AuC"), F.col("timestamp")]

    ## Read Metrics Table
    base_auc = spark.read.parquet(metrics_file)\
        .select(auc_cols)\
        .where(F.col("timestamp") == 0)


    data = spark.read.parquet(metrics_file)\
        .select(auc_cols)

    ## Approach 1 -- Is this guarenteed to produce exact results?
    base_values = base_auc.collect()[0]
    new_values = data.collect()[0]

    adv_auc = (float(base_values[0]) - float(new_values[0])) > auc_threshold
    myst_auc = (float(base_values[1]) - float(new_values[1])) > auc_threshold
    quirk_auc = (float(base_values[2]) - float(new_values[2])) > auc_threshold
    glam_auc = (float(base_values[3]) - float(new_values[3])) > auc_threshold
    party_auc = (float(base_values[4]) - float(new_values[4])) > auc_threshold
    cool_auc = (float(base_values[5]) - float(new_values[5])) > auc_threshold
    chill_auc = (float(base_values[6]) - float(new_values[6])) > auc_threshold


    if adv_auc:
        log.info("Adventure AuC is ok!")
        log.info("Base Value: {}".format(base_values[0]))
        log.info("New Value : {}".format(new_values[0]))
        log.info("Threshold : {}".format(auc_threshold))
        log.info("({} - {}) = {} > {} is {}".format(float(base_values[0]), float(new_values[0]),
                                                    float(base_values[0]) - float(new_values[0]),
                                                    float(auc_threshold), adv_auc))

    else:
        log.info("Adventure AuC is NOT ok!")
        log.info("Adventure AuC is ok!")
        log.info("Base Value: {}".format(base_values[0]))
        log.info("New Value : {}".format(new_values[0]))
        log.info("Threshold : {}".format(auc_threshold))
        log.info("({} - {}) = {} > {} is {}".format(float(base_values[0]), float(new_values[0]),
                                                    float(base_values[0]) - float(new_values[0]),
                                                    float(auc_threshold), adv_auc))


    if myst_auc:
        log.info("Mystery AuC is ok!")
    else:
        log.info("Mystery AuC is NOT ok!")

    if quirk_auc:
        log.info("Quirk AuC is ok!")
    else:
        log.info("Quirk AuC is NOT ok!")

    if glam_auc:
        log.info("Glam AuC is ok!")
    else:
        log.info("Glam AuC is NOT ok!")

    if party_auc:
        log.info("Party AuC is ok!")
    else:
        log.info("Party AuC is NOT ok!")

    if cool_auc:
        log.info("Cool AuC is ok!")
    else:
        log.info("Cool AuC is NOT ok!")

    if chill_auc:
        log.info("Chill AuC is ok!")
    else:
        log.info("Chill AuC is NOT ok!")


    ## Approach 2
    ## Compare latest AuC to the 'base' AuC
    adv_auc = ( float(data.select(F.col("Adventure_AuC")).collect()[0][0]) - float(base_auc.select(F.col("Adventure_AuC")).collect()[0][0]) ) > 0.05

    if adv_auc:
        log.info("Adventure AuC is ok!")
    else:
        log.info("Adventure AuC is NOT ok!")

    myst_auc = ( float(data.select(F.col("Mystery_AuC")).collect()[0][0]) - float(base_auc.select(F.col("Mystery_AuC")).collect()[0][0]) ) > 0.05


    if myst_auc:
        log.info("Mystery AuC is ok!")
    else:
        log.info("Mystery AuC is NOT ok!")


    quirk_auc = ( float(data.select(F.col("Quirk_AuC")).collect()[0][0]) - float(base_auc.select(F.col("Quirk_AuC")).collect()[0][0]) ) > 0.05

    if quirk_auc:
        log.info("Quirk AuC is ok!")
    else:
        log.info("Quirk AuC is NOT ok!")


    glam_auc = ( float(data.select(F.col("Glamorous_AuC")).collect()[0][0]) - float(base_auc.select(F.col("Glamorous_AuC")).collect()[0][0]) ) > 0.05

    if glam_auc:
        log.info("Glam AuC is ok!")
    else:
        log.info("Glam AuC is NOT ok!")


    party_auc = ( float(data.select(F.col("Party_AuC")).collect()[0][0]) - float(base_auc.select(F.col("Party_AuC")).collect()[0][0]) ) > 0.05

    if party_auc:
        log.info("Party AuC is ok!")
    else:
        log.info("Party AuC is NOT ok!")


    cool_auc = ( float(data.select(F.col("Cool_AuC")).collect()[0][0]) - float(base_auc.select(F.col("Cool_AuC")).collect()[0][0]) ) > 0.05

    if cool_auc:
        log.info("Cool AuC is ok!")
    else:
        log.info("Cool AuC is NOT ok!")


    chill_auc = ( float(data.select(F.col("Chill_AuC")).collect()[0][0]) - float(base_auc.select(F.col("Chill_AuC")).collect()[0][0]) ) > 0.05

    if chill_auc:
        log.info("Chill AuC is ok!")
    else:
        log.info("Chill AuC is NOT ok!")


# 8 - DONE - TESTED
## Check Model Accuracy
def check_model_accuracy(log, acc_threshold, metrics_file, acc_cols):
    # acc_threshold = 0.05
    # metrics_file = "s3://vv-dev-emr-cluster/tmp/RF_Metrics_Base/"

    # acc_cols = [F.col("Adventure_Accuracy"), F.col("Mystery_Accuracy"),
    #             F.col("Quirk_Accuracy"), F.col("Glamorous_Accuracy"),
    #             F.col("Party_Accuracy"), F.col("Cool_Accuracy"),
    #             F.col("Chill_Accuracy"), F.col("timestamp")]


    ## Read Metrics Table
    base_acc = spark.read.parquet(metrics_file)\
        .select(acc_cols)\
        .where(F.col("timestamp") == 0)


    data = spark.read.parquet(metrics_file).select(acc_cols)


    ## Approach 1 -- Is this guarenteed to produce exact results?
    base_values = base_acc.collect()[0]
    new_values = data.collect()[0]

    adv_acc = (float(base_values[0]) - float(new_values[0])) >= acc_threshold
    myst_acc = (float(base_values[1]) - float(new_values[1])) >= acc_threshold
    quirk_acc = (float(base_values[2]) - float(new_values[2])) >= acc_threshold
    glam_acc = (float(base_values[3]) - float(new_values[3])) > acc_threshold
    party_acc = (float(base_values[4]) - float(new_values[4])) > acc_threshold
    cool_acc = (float(base_values[5]) - float(new_values[5])) > acc_threshold
    chill_acc = (float(base_values[6]) - float(new_values[6])) > acc_threshold


    if adv_acc:
        log.info("Adventure Accuracy is ok!")
        log.info("Base Value: {}".format(base_values[0]))
        log.info("New Value : {}".format(new_values[0]))
        log.info("Threshold : {}".format(acc_threshold))
        log.info("({} - {}) = {} > {} is {}".format(float(base_values[0]), float(new_values[0]),
                                                    float(base_values[0]) - float(new_values[0]),
                                                    float(acc_threshold), adv_acc))
    else:
        log.info("Adventure Accuracy is NOT ok!")
        log.info("Base Value: {}".format(base_values[0]))
        log.info("New Value : {}".format(new_values[0]))
        log.info("Threshold : {}".format(acc_threshold))
        log.info("({} - {}) = {} > {} is {}".format(float(base_values[0]), float(new_values[0]),
                                                    float(base_values[0]) - float(new_values[0]),
                                                    float(acc_threshold), adv_acc))

    if myst_acc:
        log.info("Mystery Accuracy is ok!")
    else:
        log.info("Mystery Accuracy is NOT ok!")

    if quirk_acc:
        log.info("Quirk Accuracy is ok!")
    else:
        log.info("Quirk Accuracy is NOT ok!")

    if glam_acc:
        log.info("Glam Accuracy is ok!")
    else:
        log.info("Glam Accuracy is NOT ok!")

    if party_acc:
        log.info("Party Accuracy is ok!")
    else:
        log.info("Party Accuracy is NOT ok!")

    if cool_acc:
        log.info("Cool Accuracy is ok!")
    else:
        log.info("Cool Accuracy is NOT ok!")

    if chill_acc:
        log.info("Chill Accuracy is ok!")
    else:
        log.info("Chill Accuracy is NOT ok!")


    ## Approach 2
    ## Compare latest Accuracy to the 'base' Accuracy
    adv_acc = ( float(data.select(F.col("Adventure_Accuracy")).collect()[0][0]) - float(base_acc.select(F.col("Adventure_Accuracy")).collect()[0][0]) ) > 0.05

    if adv_acc:
        log.info("Adventure Accuracy is ok!")
    else:
        log.info("Adventure Accuracy is NOT ok!")

    myst_acc = ( float(data.select(F.col("Mystery_Accuracy")).collect()[0][0]) - float(base_acc.select(F.col("Mystery_Accuracy")).collect()[0][0]) ) > 0.05


    if myst_acc:
        log.info("Mystery Accuracy is ok!")
    else:
        log.info("Mystery Accuracy is NOT ok!")


    quirk_acc = ( float(data.select(F.col("Quirk_Accuracy")).collect()[0][0]) - float(base_acc.select(F.col("Quirk_Accuracy")).collect()[0][0]) ) > 0.05

    if quirk_acc:
        log.info("Quirk Accuracy is ok!")
    else:
        log.info("Quirk Accuracy is NOT ok!")


    glam_acc = ( float(data.select(F.col("Glamorous_Accuracy")).collect()[0][0]) - float(base_acc.select(F.col("Glamorous_Accuracy")).collect()[0][0]) ) > 0.05

    if glam_acc:
        log.info("Glam Accuracy is ok!")
    else:
        log.info("Glam Accuracy is NOT ok!")


    party_acc = ( float(data.select(F.col("Party_Accuracy")).collect()[0][0]) - float(base_acc.select(F.col("Party_Accuracy")).collect()[0][0]) ) > 0.05

    if party_acc:
        log.info("Party Accuracy is ok!")
    else:
        log.info("Party Accuracy is NOT ok!")


    cool_acc = ( float(data.select(F.col("Cool_Accuracy")).collect()[0][0]) - float(base_acc.select(F.col("Cool_Accuracy")).collect()[0][0]) ) > 0.05

    if cool_acc:
        log.info("Cool Accuracy is ok!")
    else:
        log.info("Cool Accuracy is NOT ok!")


    chill_acc = ( float(data.select(F.col("Chill_Accuracy")).collect()[0][0]) - float(base_acc.select(F.col("Chill_Accuracy")).collect()[0][0]) ) > 0.05

    if chill_acc:
        log.info("Chill Accuracy is ok!")
    else:
        log.info("Chill Accuracy is NOT ok!")


# 9 - DONE - NEEDS TESTING
## Check Model F1 Score
def check_model_f1_score(log, metrics_file, f1_threshold, f1_cols):

    # metrics_file = "s3://vv-dev-emr-cluster/tmp/RF_Metrics_Base/"
    # f1_threshold = 0.05
    # f1_cols = [F.col("Adventure_F1Score"), F.col("Mystery_F1Score"),
    #             F.col("Quirk_F1Score"), F.col("Glamorous_F1Score"),
    #             F.col("Party_F1Score"), F.col("Cool_F1Score"),
    #             F.col("Chill_F1Score"), F.col("timestamp")]

    ## Read Metrics Table
    base_f1 = spark.read.parquet(metrics_file)\
        .select(f1_cols)\
        .where(F.col("timestamp") == 0)

    data = spark.read.parquet(metrics_file)\
        .select(f1_cols)

    ## Approach 1 -- Is this guarenteed to produce exact results?
    base_values = base_f1.collect()[0]
    new_values = data.collect()[0]

    adv_f1 = (float(base_values[0]) - float(new_values[0])) > float(f1_threshold)
    myst_f1 = (float(base_values[1]) - float(new_values[1])) > float(f1_threshold)
    quirk_f1 = (float(base_values[2]) - float(new_values[2])) > float(f1_threshold)
    glam_f1 = (float(base_values[3]) - float(new_values[3])) > float(f1_threshold)
    party_f1 = (float(base_values[4]) - float(new_values[4])) > float(f1_threshold)
    cool_f1 = (float(base_values[5]) - float(new_values[5])) > float(f1_threshold)
    chill_f1 = (float(base_values[6]) - float(new_values[6])) > float(f1_threshold)


    if adv_f1:
        log.info("Adventure F1 Score is ok!")
        log.info("Base Value: {}".format(base_values[0]))
        log.info("New Value : {}".format(new_values[0]))
        log.info("Threshold : {}".format(f1_threshold))
        log.info("({} - {}) = {} > {} is {}".format(float(base_values[0]), float(new_values[0]),
                                                    float(base_values[0]) - float(new_values[0]), float(f1_threshold),
                                                    adv_f1))
    else:
        log.info("Adventure F1 Score is NOT ok!")
        log.info("Base Value: {}".format(base_values[0]))
        log.info("New Value : {}".format(new_values[0]))
        log.info("Threshold : {}".format(f1_threshold))
        log.info("({} - {}) = {} > {} is {}".format(float(base_values[0]), float(new_values[0]),
                                                    float(base_values[0]) - float(new_values[0]), float(f1_threshold),
                                                    adv_f1))

    if myst_f1:
        log.info("Mystery F1 Score is ok!")
    else:
        log.info("Mystery F1 Score is NOT ok!")

    if quirk_f1:
        log.info("Quirk F1 Score is ok!")
    else:
        log.info("Quirk F1 Score is NOT ok!")

    if glam_f1:
        log.info("Glam F1 Score is ok!")
    else:
        log.info("Glam F1 Score is NOT ok!")

    if party_f1:
        log.info("Party F1 Score is ok!")
    else:
        log.info("Party F1 Score is NOT ok!")

    if cool_f1:
        log.info("Cool F1 Score is ok!")
    else:
        log.info("Cool F1 Score is NOT ok!")

    if chill_f1:
        log.info("Chill F1 Score is ok!")
    else:
        log.info("Chill F1 Score is NOT ok!")



    ## Approach 2
    ## Compare latest F1 Score to the 'base' F1 Score
    adv_f1 = ( float(data.select(F.col("Adventure_F1Score")).collect()[0][0]) - float(base_f1.select(F.col("Adventure_F1Score")).collect()[0][0]) ) > 0.05

    if adv_f1:
        log.info("Adventure F1 Score is ok!")
    else:
        log.info("Adventure F1 Score is NOT ok!")

    myst_f1 = ( float(data.select(F.col("Mystery_F1Score")).collect()[0][0]) - float(base_f1.select(F.col("Mystery_F1Score")).collect()[0][0]) ) > 0.05


    if myst_f1:
        log.info("Mystery F1 Score is ok!")
    else:
        log.info("Mystery F1 Score is NOT ok!")


    quirk_f1 = ( float(data.select(F.col("Quirk_F1Score")).collect()[0][0]) - float(base_f1.select(F.col("Quirk_F1Score")).collect()[0][0]) ) > 0.05

    if quirk_f1:
        log.info("Quirk F1 Score is ok!")
    else:
        log.info("Quirk F1 Score is NOT ok!")


    glam_f1 = ( float(data.select(F.col("Glamorous_F1Score")).collect()[0][0]) - float(base_f1.select(F.col("Glamorous_F1Score")).collect()[0][0]) ) > 0.05

    if glam_f1:
        log.info("Glam F1 Score is ok!")
    else:
        log.info("Glam F1 Score is NOT ok!")


    party_f1 = ( float(data.select(F.col("Party_F1Score")).collect()[0][0]) - float(base_f1.select(F.col("Party_F1Score")).collect()[0][0]) ) > 0.05

    if party_f1:
        log.info("Party F1 Score is ok!")
    else:
        log.info("Party F1 Score is NOT ok!")


    cool_f1 = ( float(data.select(F.col("Cool_F1Score")).collect()[0][0]) - float(base_f1.select(F.col("Cool_F1Score")).collect()[0][0]) ) > 0.05

    if cool_f1:
        log.info("Cool F1 Score is ok!")
    else:
        log.info("Cool F1 Score is NOT ok!")


    chill_f1 = ( float(data.select(F.col("Chill_F1Score")).collect()[0][0]) - float(base_f1.select(F.col("Chill_F1Score")).collect()[0][0]) ) > 0.05

    if chill_f1:
        log.info("Chill F1 Score is ok!")
    else:
        log.info("Chill F1 Score is NOT ok!")


## 10 & 11
##  Check all records have a sub-tribe assigned to them
def check_subtribe_assigned_output(log, random_forest_file):
    ##  Read output data
    random_forest_file = "s3a://vv-dev-emr-cluster/data/core/random_forest/random_forest_15MM"
    df_random_forest = spark.read.parquet(random_forest_file)

    ##  Group by id, agg sub-tribe, check len = 1 (or where size() > 1)
    check_sequences_asssigned = df_random_forest.groupBy(F.col("Sequence"))\
        .agg({"Sequence": "count"})\
        .where(F.col("count(Sequence)") != 1).collect()

    if check_sequences_asssigned == []:
        log.info("All Sequences only have 1 Subtribe assigned.")
        df_random_forest.groupBy(F.col("Sequence")).agg({"Sequence": "count"}).show()
    else:
        for item in check_sequences_asssigned:
            log.info("Sequence {} has more than 1 subtribe assigned!".format(item[0]))


    # ##  Group by id, count sub-tribe, this count should be equal to the total test split size.
    # metrics_file = "s3://vv-dev-emr-cluster/tmp/RF_Metrics_Base_test/"
    #
    # test_split_count_cols = [F.col("Adventure_test_split_count"), F.col("Mystery_test_split_count"),
    #             F.col("Quirk_test_split_count"), F.col("Glamorous_test_split_count"),
    #             F.col("Party_test_split_count"), F.col("Cool_test_split_count"),
    #             F.col("Chill_test_split_count")]
    #
    # test_split_count = spark.read.parquet(metrics_file).select(test_split_count_cols).collect()

    # ## Make sure all the value are the same
    # flag = True
    # for item in test_split_count[0]:
    #     if item != test_split_count[0][0]:
    #         flag = False
    #
    # if flag:
    #     log.info("All test split counts are the same!")
    # else:
    #     log.info("Not all test split counts are the same!")


    ## Check total Subtribe count
    df_rf_count = df_random_forest.count()
    total_subtribe_count = df_random_forest\
        .groupBy(F.col("key")).agg({"key": "count"})\
        .groupBy().sum("count(key)").collect()

    if df_rf_count != total_subtribe_count[0][0]:
        log.info("Total count ({}) does not equal Total Subtribe Count({})!".format(df_rf_count, total_subtribe_count[0][0]))
    else:
        log.info("Total count ({}) does equal Total Subtribe Count ({})!".format(df_rf_count, total_subtribe_count[0][0]))


def initSparkSession(appName):
    """
    Initializes the SparkSession

    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 6: Error initializing SparkSession. Please review SparkSession configurations. ")

    return spark


def get_logger():
    """
    Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='RF_SanityCheck'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """

    log.info("Fetch Parameters from Processor Driver")
    try:

        random_forest_file = processController.get("random_forest_file")
        metrics_file = processController.get("metrics_file")
        subtribe_list = processController.get("subtribe_list")[1:-1].split(",")


    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 3: Please verify driver variable initialization (gnip_data|brand_details|attribute_mapping)")

    return process(log, processController, random_forest_file, metrics_file, subtribe_list)


def process(log, processController, random_forest_file, metrics_file, subtribe_list):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param hbase_ip             : current ip of the hbase tables
    :param attributes           : Relevant columns to select from sailor data table
    :return                     : Spark Dataframe with columns : [id_seaware, synonyms, time_stamp, date_stamp].
                                  id_seaware is the sailor's id, synonyms is a synonym corresponding to the sailor,
                                  time_stamp and date_stamp are time/date stamps, respectively.
    """
    log.info("Starting Sanity Check...")

    gnip_file = processController.get("gnip_file")
    representation_threshold = float(processController.get("representation_threshold"))
    test_cols = processController.get("test_cols")[1:-1].split(",")
    train_cols = processController.get("train_cols")[1:-1].split(",")
    thresh_cols = processController.get("thresh_cols")[1:-1].split(",")
    min_cols = processController.get("min_cols")[1:-1].split(",")
    max_cols = processController.get("max_cols")[1:-1].split(",")
    auc_threshold = float(processController.get("auc_threshold"))
    auc_cols = processController.get("auc_cols")[1:-1].split(",")
    acc_threshold = float(processController.get("acc_threshold"))
    acc_cols = processController.get("acc_cols")[1:-1].split(",")
    f1_threshold = float(processController.get("f1_threshold"))
    f1_cols = processController.get("f1_cols")[1:-1].split(",")

    gnip_processed_data_all_subtribes(log, subtribe_list, gnip_file)
    target_subtribe_distributiion_rate(log, representation_threshold, metrics_file, test_cols, train_cols)
    check_adjusted_probability_threshold(log, metrics_file, thresh_cols)
    all_records_have_subtribe_assigned(log, random_forest_file, subtribe_list)
    score_alignment_between_0_and_1(log, metrics_file, min_cols, max_cols)
    check_model_auc(log, auc_threshold, metrics_file, auc_cols)
    check_model_accuracy(log, acc_threshold, metrics_file, acc_cols)
    check_model_f1_score(log, metrics_file, f1_threshold, f1_cols)
    check_subtribe_assigned_output(log, random_forest_file)


def stopSparkSession(log, spark):
    """
    Shuts down the current SparkSession

    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("RF_SanityCheck")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    initProcess(spark, processController, log)
    stopSparkSession(log, spark)

