from subprocess import call

from pyspark.ml.clustering import KMeans
from pyspark.ml.feature import VectorAssembler
from pyspark.sql import Row
from pyspark.sql import SparkSession
from pyspark.sql.types import *
import logging
import sys, traceback


def goodDensityVarSelection(data, attributes, varSelMethod, densityLow, densityHigh):
    log.info("Calculating Good Density")
    describe = data.describe()
    filter = 'summary ="' + varSelMethod + '"'
    result = describe.where(filter).select(*attributes).rdd.collect()
    resultset = [float(x) for x in list(result[0])]
    goodDensityVar = [i for i, j in zip(attributes, resultset) if j > densityLow and j < densityHigh]
    return goodDensityVar


def stepwiseKmeansVarSelection(log, data, numVarToSelect, goodDensityVar, seedVar, numOfClusters, kmeansMaxIter,
                               kmeansSeed):
    # Start KMEANS with seed variables to get a list of variables which forms best-separated clusters
    log.info("Step wise Kmeans Selection")
    attr_best = "none"
    for i in range(numVarToSelect):
        try_ls = [item for item in goodDensityVar if item not in seedVar]
        wssse_best = float('inf')
        for attribute in try_ls:
            test_var = list(seedVar)
            test_var.append(attribute)
            vectorAssembler = VectorAssembler(inputCols=test_var, outputCol="features")
            vdf_exp = vectorAssembler.transform(data)
            kmeans = KMeans(k=numOfClusters, maxIter=kmeansMaxIter, seed=kmeansSeed)
            model = kmeans.fit(vdf_exp)
            wssse = model.computeCost(vdf_exp)
            if wssse < wssse_best:
                wssse_best = wssse
                attr_best = attribute
        seedVar.append(attr_best)


def loadProcessDriver(spark, log, db_name):
    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='TribeSegmentation'".format(db_name)
    log.info(query_string)
    dic = {}
    try:
        out = spark.sql(query_string).collect()
        m = map(lambda x: (x[0], x[1]), out)
        dic = dict(m)
    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 1: Please verify process driver query execution ")
    return dic


def initProcess(log, processController):
    log.info("Retrieving Attributes")
    distillTable = processController.get("distillTable")
    densityLow = float(processController.get("densityLow"))
    densityHigh = float(processController.get("densityHigh"))
    seedVar = processController.get("seedVar").split("~")
    numVarToSelect = int(processController.get("numVarToSelect"))
    numOfClusters = int(processController.get("numOfClusters"))
    kmeansMaxIter = int(processController.get("kmeansMaxIter"))
    kmeansSeed = int(processController.get("numVarToSelect"))
    ## Reading the cleansed data for Tribe calculation from HIVE table
    # customerData = spark.sql("select * from vv_db.TribeSegData")
    customerData = spark.sql("select * from %s " % (distillTable))
    ## Finding the list of variable which meets the density threshold
    attributes = customerData.columns
    try:
        attributes.remove("sequence")
    except:
        pass
    goodDensityVar = goodDensityVarSelection( customerData, attributes, "mean", densityLow, densityHigh)
    ## Check quality of density variables and stop the job if necessary
    if len(goodDensityVar) >= 20:
        log.info("You got a list of " + str(len(goodDensityVar)) + " variables : " + ",".join(goodDensityVar))
    elif len(goodDensityVar) < 20:
        log.info("You have only got a list of " + str(
            len(goodDensityVar)) + " variables, something might be wrong, exiting process: " + ",".join(goodDensityVar))
        appId = spark.sparkContext.applicationId
        call(["yarn", "application", "-kill", appId])
    stepwiseKmeansVarSelection(log, customerData, numVarToSelect, goodDensityVar, seedVar, numOfClusters, kmeansMaxIter,
                               kmeansSeed)

    ## Saving the final KMEANS clustering variable list to HIVE
    return spark.createDataFrame(Row([seedVar]), StructType([StructField("columns", ArrayType(StringType()))]))


def get_logger():
    log = logging.getLogger('Spark')
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
    log.addHandler(_h)
    log.setLevel(logging.DEBUG)
    log.info("module imported and logger initialized")
    return log


def initSparkSession(appName):
    spark = SparkSession \
        .builder \
        .appName(appName) \
        .enableHiveSupport() \
        .getOrCreate()
    spark.conf.set("spark.sql.shuffle.partitions", "50")
    return spark


def store(processController, clusterVar, log):
    path = processController.get("path_vv_kmeans_variables")
    log.info("Saving to path %s" % path)
    clusterVar.write.mode('overwrite').format("parquet").save(path)


def stopSparkSession(spark, log):
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    ''' Design Flow of Tribe segmentation/clustering'''
    spark = initSparkSession("Cluster_var_generation")
    log = get_logger()
    ## Reading all the process variables for TribeSegmentation from HIVE table processController
    log.info("Spark Session Started")
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    clusterVar = initProcess(log, processController)
    ## Finding the list of final set of seed variables which forms best clusters
    store(processController, clusterVar, log)
    stopSparkSession(spark, log)
