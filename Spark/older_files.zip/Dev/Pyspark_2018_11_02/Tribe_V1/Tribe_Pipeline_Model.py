from __future__ import print_function

import sys
from random import random
from operator import add

from pyspark.sql import SparkSession

from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import regexp_replace, col
from pyspark.sql import functions as F
from pyspark.sql import HiveContext, SQLContext
# Import Vector Assembler to convert dataframe into
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.linalg import Vectors
from pyspark.ml.clustering import KMeans
from pyspark.sql.window import Window
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.types import DoubleType




if __name__ == "__main__":
    """
        Model build | Clustering of tribe data
    """

    conf = SparkConf().setAppName("Demo").setMaster("yarn").set("spark.sql.shuffle.partitions", "50")
    sc = SparkContext(conf=conf)

    hc = HiveContext(sc)
    #sqlContext = SQLContext(sc)

    ##################          cluster46m  / Zep Tab 1   #########################
    # Convert the PySpark Dataframe into a Vector for input into the Kmeans

    tribe = hc.sql("select aerobics , age_txt , anglers , anglers_4 , art_craft , auto_motorcycle_racing , auto_parts_repair_accesories_work , auto_work , avid_readers , bank_card , baseball , basketball , boating_or_sailing , bookbuyer , camping_or_hiking , career_minded , cars , casino_gambling , cc_premium_american_express , cc_premium_discover , cc_premium_store_or_retail , cc_premium_visa_or_mastercard , cc_regular_american_express , cc_regular_discover , cc_regular_store_or_retail , child0_3 , child10_12 , child13_18 , child4_6 , child7_9 , children , children_interests , collect_specialfoodsbuyer , collector_antiques , collector_coins , collector_dolls , collector_figurines , collector_fine_arts , collector_plates , collector_sports_memorabilia , collector_stamps , collectors , consumer_electronics , contribute_animal , contribute_childrens , contribute_environm , contribute_health , contribute_political , contribute_political_conservative , contribute_political_liberal , contribute_religious , contribute_veterans , contributor_index , contributors , crafts_hobbmerchbuyer , credit_card , credit_cards_regular_visa_or_mastercard , creditcard_newissue , credit_ranges , cultural_artistic , current_affairs_politics , diet_weight_loss , dnc_flag , doit_yourselfer , donor_arts_or_cultural , dpv_status , education_code , email_flag , entertainment_enth , family , femalemerchbuyer , fishing , fitness , food , football , gdiscindex , gincome , hobby_video_games , hobby_board_games , hobby_computer_games , gardening , gen_in_household , gender , general_info_grandchildren_le_12_yrs , genre_musictype_christian_or_gospel , genre_musictype_classical , genre_musictype_country , genre_musictype_jazz , genre_musictype_rhythm_and_blues , genre_musictype_rock_n_roll , genre_musictype_soft_rock_or_easy_listen , golf , great_outdoors , health_beauty , health_living , hightechleader , hobby_bird_watching , hobby_cigar_smoking , hobby_cooking , hobby_cooking_gourmet , hobby_crafts , hobby_home_study_courses , hobby_knitting_or_needlework , hobby_photography , hobby_quilting , hobby_self_improvement_courses , hobby_sewing , hobby_wine_appreciation , hobby_woodworking , hobbyists , hockey , home_decor , home_improvement , home_owner , hunting , internet_buyer , investment_type , investments , investments_own_mutual_funds_cds , investments_own_stocks_or_bonds , len_of_residence , loan_to_value , luxury_life , magazine , mail_buyer , mail_donor , mail_responder , malemerchbuyer , marital_status , membership_warehouse , mo_books , mo_books_or_mag , mo_children_s_products , mo_clothing , mo_cosmetics , mo_dvd , mo_gifts , mo_home_furnishing , mo_jewelry , mo_plus_size_clothing , mortgageamountinthousands , motor_cycle , movie , music , collector_music , musical_instruments , music_player , nascar , num_in_household , num_of_adults , num_of_children , online_education , opportunity_seeker , own_swimming_pool , owns_satellite_tv , pets , pets_own_at_least_one_cat , pets_own_at_least_one_dog , presence_of_elderly_parent , presenceofgoldorplatinumcreditcard , presence_premium_card , reading_news_finance , reading_astrology , reading_best_selling_fiction , reading_bible_or_devotional , reading_books_on_tape , reading_children_s , reading_computer , reading_cooking_or_culinary , reading_country_lifestyle , reading_fashion , reading_history , reading_interior_decorating , reading_medical_or_health , reading_military , reading_mystery , reading_natural_health_remedies , reading_people_or_entertainment , reading_romance , reading_science_fiction , reading_science_or_technology , reading_sports , reading_world_news_or_politics , religion , religious_inspirational , resident_delivery_indic , respondedtocatalog , retail_card , running , rv_own , science_space , scuba_diving , self_improvement , sequence , snow_skiing , soho_business , sporting_life , sports , sports_betting , sweepstakes_contest , tennis , toys , travel , travel_business , travel_card , travel_cruises , travel_international , travel_personal , travel_vacation , truck_owner , tv_sports , valuehunter , veteran_in_household , voter_indicator , walking , wealthrating , weight_lifting , working_woman , young_adult_in_household , soccer from ds_db.tribe_prep")
    table2 = tribe.na.fill(0,
                            ['baseball', 'basketball', 'camping_or_hiking', 'casino_gambling', 'consumer_electronics',
                             'diet_weight_loss', 'fitness', 'football', 'music_player', 'pets', 'travel_personal'])

    vectorAssembler = VectorAssembler(
        inputCols=['baseball', 'basketball', 'camping_or_hiking', 'casino_gambling', 'consumer_electronics',
                   'diet_weight_loss', 'fitness', 'football', 'music_player', 'pets', 'travel_personal'],
        outputCol="features")
    vdf = vectorAssembler.transform(table2)

    kmeans = KMeans(k=4, maxIter=10, seed=3)
    model = kmeans.fit(vdf)

    # The results contains "sequence" and "prediction" are saved into table "vv_db.cluster46m"
    cluster46m = model.transform(vdf).select("sequence", "prediction")
    cluster46m.persist()
    # df.write.partitionBy("favorite_color").format("parquet").save("namesPartByColor.parquet")
    s3_cluster46m_path = "s3://vv-dev-emr-cluster/data/hivetables/ds_db/cluster46m"
    cluster46m.write.mode('overwrite').format("parquet").save(s3_cluster46m_path)
    # 0-Revel
    # 1-Explorer
    # 2-Bask
    # 3-Luxuriate

    print(" $$$$$$$$$$$$$$    Success Of cluster46m $$$$$$$$$$$$$$$$$$")

    ##################          ExplorerClustering / Zep Tab 2   #########################
    cluster46mtrans = cluster46m.withColumnRenamed('prediction', 'prediction_tribe').withColumnRenamed('sequence', 'sequence_tribe')
    joinexp = cluster46mtrans.join(tribe, cluster46mtrans.sequence_tribe == tribe.sequence , "inner").filter(cluster46mtrans.prediction_tribe == 1)
    # Convert the PySpark Dataframe into a Vector for input into the Kmeans
    vectorAssembler = VectorAssembler(
        inputCols=['auto_motorcycle_racing', 'fishing', 'hunting', 'nascar', 'casino_gambling', 'hobby_photography'],
        outputCol="features")
    vdf1 = vectorAssembler.transform(joinexp)

    kmeans1 = KMeans(k=3, maxIter=10, seed=4)
    model1 = kmeans1.fit(vdf1)

    # Results that contains sequence and prediction are stored in table vv_db.subexplorer_46m
    subexplorer_46m = model1.transform(vdf1).select("sequence", "prediction")
    print(" $$$$$$$$$$$$$$    Success Of subexplorer_46m $$$$$$$$$$$$$$$$$$")
    s3_subexplorer_46m = "s3://vv-dev-emr-cluster/data/hivetables/ds_db/subexplorer46m"
    subexplorer_46m.write.mode('overwrite').format("parquet").save(s3_subexplorer_46m)

    # 0-Mystery
    # 1-Quirk
    # 2-Adventure

    ####################  RevelClustering / Tab 3   ##################################################
    reveltab = hc.sql("select sequence as sequence_rev, hunting,sports,fishing,boating_or_sailing,entertainment_enth,health_living,camping_or_hiking,movie,music,hobbyists,food,hobby_cooking,luxury_life,health_beauty,children from ds_db.tribe_prep where gincome not in ('1','2','A','B') AND age_txt BETWEEN 20 And 45 ")

    revtable = reveltab.na.fill(0, ['hunting', 'sports', 'fishing', 'boating_or_sailing', 'entertainment_enth',
                                'health_living', 'camping_or_hiking', 'movie', 'music', 'hobbyists', 'food',
                                'hobby_cooking', 'luxury_life', 'health_beauty', 'children'])
    # table2 = table1.na.fill(0,['reading_computer', 'great_outdoors', 'Casino_gambling', 'reading_romance', 'reading_fashion'])

    joinrevel = cluster46mtrans.join(revtable, cluster46mtrans.sequence_tribe == revtable.sequence_rev , "inner").filter(cluster46mtrans.prediction_tribe == 0)
    # Convert the PySpark Dataframe into a Vector for input into the Kmeans
    vectorAssembler = VectorAssembler(
        inputCols=['hunting', 'sports', 'fishing', 'boating_or_sailing', 'entertainment_enth', 'health_living',
                   'camping_or_hiking', 'movie', 'music', 'hobbyists', 'food', 'hobby_cooking', 'luxury_life',
                   'health_beauty', 'children'], outputCol="features")  # -1
    vdf2 = vectorAssembler.transform(joinrevel)
    kmeans2 = KMeans(k=3, maxIter=10, seed=4)
    model2 = kmeans2.fit(vdf2)

    # Results that contains sequence and prediction are stored in table vv_db.subrevel_1
    subrevel_1 = model2.transform(vdf2).select("sequence_rev", "prediction")
    print(" $$$$$$$$$$$$$$    Success Of subrevel_1 $$$$$$$$$$$$$$$$$$")
    s3_subrevel_46m = "s3://vv-dev-emr-cluster/data/hivetables/ds_db/subrevel"
    subrevel_1.write.mode('overwrite').format("parquet").save(s3_subrevel_46m)

    # 0-Glamorous
    # 1-Party
    # 2-Cool

    sc.stop()
