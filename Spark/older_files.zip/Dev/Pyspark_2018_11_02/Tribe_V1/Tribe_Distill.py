from __future__ import print_function

import sys
from random import random
from operator import add

from pyspark.sql import SparkSession

from pyspark import SparkContext, SparkConf
from pyspark.sql.functions import regexp_replace, col
from pyspark.sql import functions as F
from pyspark.sql import HiveContext
#sc = SparkContext.getOrCreate()
#hc = HiveContext(sc)



if __name__ == "__main__":
    """
        Distillation of tribe data
    """

    conf = SparkConf().setAppName("Demo").setMaster("yarn")
    sc = SparkContext(conf=conf)

    hc = HiveContext(sc)
    rawdf = hc.sql( "select *  from vv_db.customer_data_text where gincome not in ('1', '2', 'A', 'B', '', 'null') AND age_txt >= 20 And age_txt <= 45")
    # customerFile = "customer_data_fille_path"  # Should be some file on your system
    # customerFile = sc.textFile(customerFile).cache()

    # cust_data = c.textFile("s3://vv-dev-emr-cluster/data/hivetables/vv_db/customer_data_text")

    # filter applied on entire data set

    # performed distillation of replacing null with 0
    df_replace_null = rawdf.na.fill(0, ['aerobics', 'art_craft', 'auto_motorcycle_racing',
                                        'auto_parts_repair_accesories_work', 'auto_work', 'avid_readers',
                                        'bank_card',
                                        'baseball', 'basketball', 'boating_or_sailing', 'bookbuyer',
                                        'camping_or_hiking', 'career_minded', 'cars', 'casino_gambling',
                                        'cc_premium_american_express', 'cc_premium_discover',
                                        'cc_premium_store_or_retail', 'cc_premium_visa_or_mastercard',
                                        'cc_regular_american_express', 'cc_regular_discover',
                                        'cc_regular_store_or_retail', 'child0_3', 'child10_12', 'child13_18',
                                        'child4_6', 'child7_9', 'children', 'children_interests',
                                        'collect_specialfoodsbuyer', 'collector_antiques', 'collector_coins',
                                        'collector_dolls', 'collector_figurines', 'collector_fine_arts',
                                        'collector_plates', 'collector_sports_memorabilia', 'collector_stamps',
                                        'collectors', 'consumer_electronics', 'contribute_animal',
                                        'contribute_childrens', 'contribute_environm', 'contribute_health',
                                        'contribute_political', 'contribute_political_conservative',
                                        'contribute_political_liberal', 'contribute_religious',
                                        'contribute_veterans',
                                        'contributors', 'crafts_hobbmerchbuyer', 'credit_card',
                                        'credit_cards_regular_visa_or_mastercard', 'creditcard_newissue',
                                        'cultural_artistic', 'current_affairs_politics', 'diet_weight_loss',
                                        'dnc_flag',
                                        'doit_yourselfer', 'donor_arts_or_cultural', 'dpv_status', 'email_flag',
                                        'entertainment_enth', 'family', 'femalemerchbuyer', 'fishing', 'fitness',
                                        'food', 'football', 'general_info_grandchildren_le_12_yrs',
                                        'genre_musictype_christian_or_gospel', 'genre_musictype_classical',
                                        'genre_musictype_country', 'genre_musictype_jazz',
                                        'genre_musictype_rhythm_and_blues', 'genre_musictype_rock_n_roll',
                                        'genre_musictype_soft_rock_or_easy_listen', 'golf', 'great_outdoors',
                                        'health_beauty', 'health_living', 'hightechleader', 'hobby_bird_watching',
                                        'hobby_cigar_smoking', 'hobby_cooking', 'hobby_cooking_gourmet',
                                        'hobby_crafts',
                                        'hobby_home_study_courses', 'hobby_knitting_or_needlework',
                                        'hobby_photography',
                                        'hobby_quilting', 'hobby_self_improvement_courses', 'hobby_sewing',
                                        'hobby_wine_appreciation', 'hobby_woodworking', 'hobbyists', 'hockey',
                                        'home_decor', 'home_improvement', 'hunting', 'internet_buyer',
                                        'investments',
                                        'investments_own_mutual_funds_cds', 'investments_own_stocks_or_bonds',
                                        'luxury_life', 'magazine', 'mail_buyer', 'mail_donor', 'mail_responder',
                                        'malemerchbuyer', 'membership_warehouse', 'mo_books', 'mo_books_or_mag',
                                        'mo_children_s_products', 'mo_clothing', 'mo_cosmetics', 'mo_dvd',
                                        'mo_gifts',
                                        'mo_home_furnishing', 'mo_jewelry', 'mo_plus_size_clothing', 'motor_cycle',
                                        'movie', 'music', 'collector_music', 'musical_instruments', 'music_player',
                                        'nascar', 'online_education', 'opportunity_seeker', 'own_swimming_pool',
                                        'owns_satellite_tv', 'pets', 'pets_own_at_least_one_cat',
                                        'pets_own_at_least_one_dog', 'presence_of_elderly_parent',
                                        'presenceofgoldorplatinumcreditcard', 'presence_premium_card',
                                        'reading_news_finance', 'reading_astrology', 'reading_best_selling_fiction',
                                        'reading_bible_or_devotional', 'reading_books_on_tape',
                                        'reading_children_s',
                                        'reading_computer', 'reading_cooking_or_culinary',
                                        'reading_country_lifestyle',
                                        'reading_fashion', 'reading_history', 'reading_interior_decorating',
                                        'reading_medical_or_health', 'reading_military', 'reading_mystery',
                                        'reading_natural_health_remedies', 'reading_people_or_entertainment',
                                        'reading_romance', 'reading_science_fiction',
                                        'reading_science_or_technology',
                                        'reading_sports', 'reading_world_news_or_politics',
                                        'religious_inspirational',
                                        'resident_delivery_indic', 'respondedtocatalog', 'retail_card', 'running',
                                        'rv_own', 'science_space', 'scuba_diving', 'self_improvement',
                                        'snow_skiing',
                                        'soho_business', 'sporting_life', 'sports', 'sports_betting',
                                        'sweepstakes_contest', 'tennis', 'toys', 'travel', 'travel_business',
                                        'travel_card', 'travel_cruises', 'travel_international', 'travel_personal',
                                        'travel_vacation', 'truck_owner', 'tv_sports', 'valuehunter',
                                        'veteran_in_household', 'voter_indicator', 'walking', 'weight_lifting',
                                        'working_woman', 'young_adult_in_household', 'soccer'])

    df_replace_y = df_replace_null.withColumn("hightechleader",
                                              regexp_replace(col("hightechleader"), "Y", "1")).withColumn(
        "hightechleader", regexp_replace(col("hightechleader"), " ", "0")).withColumn("bookbuyer",
                                                                                      regexp_replace(col("bookbuyer"),
                                                                                                     "Y",
                                                                                                     "1")).withColumn(
        "bookbuyer", regexp_replace(col("bookbuyer"), " ", "0")).withColumn("collect_specialfoodsbuyer", regexp_replace(
        col("collect_specialfoodsbuyer"), "Y", "1")).withColumn("crafts_hobbmerchbuyer",
                                                                        regexp_replace(col("crafts_hobbmerchbuyer"),
                                                                                       "Y", "1")).withColumn(
        "dpv_status", regexp_replace(col("dpv_status"), "Y", "1")).withColumn("femalemerchbuyer",
                                                                              regexp_replace(col("femalemerchbuyer"),
                                                                                             "Y",
                                                                                             "1")).withColumn(
        "malemerchbuyer", regexp_replace(col("malemerchbuyer"), "Y", "1")).withColumn(
        "presenceofgoldorplatinumcreditcard",
        regexp_replace(col("presenceofgoldorplatinumcreditcard"), "Y", "1")).withColumn("respondedtocatalog",
                                                                                                regexp_replace(col(
                                                                                                    "respondedtocatalog"),
                                                                                                               "Y",
                                                                                                               "1")).withColumn(
        "valuehunter", regexp_replace(col("valuehunter"), "Y", "1"))



    s3_store_path = "s3://vv-dev-emr-cluster/data/hivetables/ds_db/tribe_prep"
    print(" $$$$$$$$$$$$$$    Sucesss Of Job $$$$$$$$$$$$$$$$$$")
    #print(df_replace_y.count())
    # df.write.partitionBy("favorite_color").format("parquet").save("namesPartByColor.parquet")
    df_replace_y.write.mode('overwrite').format("parquet").save(s3_store_path)
    sc.stop()
