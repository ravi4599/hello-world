

# This is a python module designed to read the Startup_Recommender_Engine.txt file.  The file is assumed to be in the 
# same directory as the module.

# Author:  John Abe
# Date:  September 5, 2017

###########################################################
# Step 1:  Open of channel to read                        #
# Step 2:  Read Startup_Recommender_Engine.txt file       #
# Step 3:  Parse text from file and assign to variables   # 
# Step 4:  Store in list and return			  #
###########################################################

def read():

	# Step 1:  Open of channel to read
	with open("Startup_Recommender_Engine_Python.txt","r") as f:
	
		# Step 2:  Read Startup_Recommender_Engine_Python.txt file 
		content = f.readlines()
	
	#Step 3:  Parse text from file and assign to variables
	str = content[0].split("= ",1)
	Database_Name = str[1]					# extract database name
	Database_Name = Database_Name.strip('\n')		# get rid of newline character
	
	
	str = content[1].split("= ",1)
	Main_Filepath = str[1]					# extract Main_Filepath
	Main_Filepath = Main_Filepath.strip('\n')		# get rid of newline character
	

	str = content[2].split("= ",1)
	Recommender_Engine_Configuration_Filepath = str[1]	# extract Recommender_Engine_Configuration_Filepath
	Recommender_Engine_Configuration_Filepath = Recommender_Engine_Configuration_Filepath.strip('\n') # get rid of newline character
	
	# Step 4:  Store in list and return	
	Data_List = [Database_Name, Main_Filepath, Recommender_Engine_Configuration_Filepath]
	
	f.close()

	return Data_List