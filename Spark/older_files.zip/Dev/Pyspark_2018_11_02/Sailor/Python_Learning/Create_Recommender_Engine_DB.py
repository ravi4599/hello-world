

# This module creates the database and tables for the recommender engine.  The class enables the creation of tables basedon
# on a configuration file.  As new needs emerge, the database can be rebuilt with added or modified tables.


# Author:  John Abe
# Date:  September 6, 2017



###########################################################################################
#											  #
# Step 1:  Import Libraries  								  #
# Step 2:  Read the recommender engine startup file - get directory etc.  		  #
# Step 3:  Read the configuration file - get the specific configuration of the engine     # 
# Step 4:  Get the database credentials 						  #  
# Step 5:  Establish database access    						  #
# Step 6:  Drop old database    							  #
# Step 7:  Create new database								  #
# Step 8:  Use database									  #
# Step 9:  get database table configuration 						  #
#											  #
###########################################################################################






#############################
#                           #
# Step 1:  Import Libraries #
#                           #
#############################
import mysql.connector
import Access_DB_Python
import Read_Startup_Recommender_Engine
import Read_Recommender_Engine_Configuration






#####################
#		    #
# Declare Variables #
#		    #
#####################
User = ""					# user to database
Pass = ""					# password of user to database
Host = ""					# location of the MySQL database as an ip address
Loop = True					# when true, looping is enabled
Database_Name = ""				# name of the recommender engine database
Main_Filepath = ""				# filepath to recommender engine directory
Recommender_Engine_Configuration_Filepath = ""	# filepath to the recommender engine configuration file
Create_Database_Specification = ""		# filepath to file containing sql commands to create database





###########################################################################
#                           						  #
# Step 2:   Read the recommender engine startup file - get directory etc. #
#                           						  #
###########################################################################

Content = Read_Startup_Recommender_Engine.read()
Database_Name = Content[0]			# extract database name from list
Main_Filepath = Content[1]			# extract the main filepath from list
Recommender_Engine_Configuration_Filepath = Content[2] # extract the main filepath from list 

# verify code - eventually toss
print(Database_Name)
print(Main_Filepath)
print(Recommender_Engine_Configuration_Filepath)





#######################################################################################
#                           						              #
# Step 3:  Read the configuration file - get the specific configuration of the engine #
#                           						              #
#######################################################################################

Content = Read_Recommender_Engine_Configuration.read(Recommender_Engine_Configuration_Filepath)
Create_Database_Specifications = Content[0]	# extract create database specification from list
Import_Data_Files = Content[1]			# extract import data files from list
Batch_File = Content[2]				# extract input batch file name

# verify code - eventually toss
print('\n Create database specifications:  ', Create_Database_Specifications)
print('\n Import data files;  ', Import_Data_Files)
print('\n Batch_File:  ', Batch_File)



#########################################
#                           		#
# Step 4:  Get the database credentials #
#                           		#
#########################################

Content = Access_DB_Python.read(Main_Filepath)
Host = Content[0]
User = Content[1]
Pass = Content[2]

# verify code - eventually toss
# print(Host)
# print(User)
# print(Pass)





try:		

	#########################################
	#                           		#
	# Step 5:  Establish database access    #
	#                           		#
	#########################################

	conn = mysql.connector.connect(

		user=User,

		password=Pass,

		host=Host,

		#database=Database_Name

		)

	cursor = conn.cursor()
	
	
	
	

	#################################
	#                               #
	# Step 6:  Drop old database    #
	#                               #
	#################################
	sql = "drop database if exists " + Database_Name
	print('\n here is the sql:  ',sql)
	cursor.execute(sql)
	
	
	
	#################################
	#                               #
	# Step 7:  Create new database  #
	#                               #
	#################################
	sql = "create database " + Database_Name
	print('\n here is the sql: ',sql)
	cursor.execute(sql)
	
	
	
	#################################
	#                               #
	# Step 8:  Use database         #
	#                               #
	#################################
	sql = "use " + Database_Name
	print('\n here is the sql: ',sql)
	cursor.execute(sql)	
	
	print('\n okay to here ')
	
	####################################################
	#                               		   #
	# Step 9:  get database table configuration        #
	#                               		   #
	####################################################
	print('\n this is the db spec filepath:  ', Create_Database_Specifications)		# debug - toss later
	
	Create_Database_Specifications = Create_Database_Specifications.strip('\n')		# strip newline characters (\n)	
	
	file = open(Create_Database_Specifications, "rt")

	
	for sql in file:
		print('\n here is the sql: ',sql)						# debug - toss later
		cursor.execute(sql)
		

	print('\n done')




except Error as e:				# capture error and print for analysis
	print (e)
	
finally:					# close out connector and cursor
	cursor.close()
	conn.close()
	