# This is a module computes the revenue, profit, and capacity score for an activity.  
# The module is called by the Recommender_Engine_V1

# Author:  John Abe
# Date:  September 21st, 2017


def run(cursor):

	#####################
	# declare variables #
	#####################
	sql = ""					# sequel query
	
	print('\n\n\n inside mode two')

	#################################################################################################
	# Step 1:  Get rid of of nulls etc., in tbl_sailor_tmp for revenue, profit, and capacity scores #
	#################################################################################################
	sql = "update tbl_sailor_tmp set revenue_score = 0.0, profit_score = 0, capacity_score = 0 where empty_reservation_count = 0"
	
	# print('\n',sql)
	
	cursor.execute(sql)
	
	
	###############################################################################################################################
	# Step 2:  Apply multipliers to revenue, profit, and capacity scores when current activity sign ups < sailor inflection point #
	###############################################################################################################################	
	sql = "update tbl_sailor_tmp as t1, tbl_economic_optimization as t2 set t1.revenue_score = t2.revenue_increment_per_sailor, t1.profit_score = t2.profit_increment_per_sailor, t1.capacity_score = 1.0 where t1.empty_reservation_count != 0 and t1.sailor_reservation_count >= t2.sailor_inflection_point and t1.id_activity = t2.id_activity"
	
	# print('\n',sql)
	
	cursor.execute(sql)	


	###############################################################################################################################
	# Step 3:  Apply multipliers to revenue, profit, and capacity scores when current activity sign ups < sailor inflection point #
	###############################################################################################################################
	sql = "update tbl_sailor_tmp as t1, tbl_economic_optimization as t2 set t1.revenue_score = t2.revenue_increment_per_sailor * t2.multiplier, t1.profit_score = t2.profit_increment_per_sailor * t2.multiplier, t1.capacity_score = 1.0 * t2.multiplier where t1.empty_reservation_count != 0 and t1.sailor_reservation_count < t2.sailor_inflection_point and t1.id_activity = t2.id_activity"
	
	# print('\n',sql)
	
	cursor.execute(sql)
	

	
	#######################################################################
	# Step 4:  Normalize revenue score, profit score, and capacity score  #
	#######################################################################
	sql = "select max(revenue_score) from tbl_sailor_tmp";
	
	# print('\n',sql)
	
	cursor.execute(sql)
	
	Max_Revenue_Score = cursor.fetchone()
	
	
	sql = "update tbl_sailor_tmp set revenue_score = revenue_score / " + str(Max_Revenue_Score[0])
	cursor.execute(sql)
	
	
	
	sql = "select max(profit_score) from tbl_sailor_tmp"
	
	# print('\n',sql)
	
	cursor.execute(sql)
		
	Max_Profit_Score = cursor.fetchone()
	
	
	sql = "update tbl_sailor_tmp set profit_score = profit_score / " + str(Max_Profit_Score[0])
	
	cursor.execute(sql)
	
	
	
	sql = "select max(capacity_score) from tbl_sailor_tmp"
	
	# print('\n',sql)
	
	cursor.execute(sql)
	
	Max_Capacity_Score = Max_Profit_Score = cursor.fetchone()
	
	
	sql = "update tbl_sailor_tmp set capacity_score = capacity_score / " + str(Max_Capacity_Score[0])
	
	# print('\n',sql)
	
	cursor.execute(sql)
	
	
	
	
	
	
	# print('\n\n\n leaving mode two')
	
	
	
	
	return
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	