

# Recommender Engine Version 0.1
# This is a program (insert previous patent like sow)

# Author:  John Abe
# Date:  September 6, 2017

##########################################################################################
#
# Step 1:  Import the libraries used in the recommender engine 
# Step 2:  Read the recommender engine startup file - get directory etc.
# Step 3:  Read the configuration file - get the specific configuration of the engine 
# Step 4:  Get the database credentials
# Step 5:  Start main process loop
# Step 6:  Get the console input, determine the command
# Step 6a: Read console input
# Step 6b: Parse console input
# Step 6c: Act on channel codes
# Step 6d: 
#


#############################
#                           #
# Step 1:  Import Libraries #
#                           #
#############################

import Access_DB_Python				# module that retrieves database credentials
import Read_Recommender_Engine_Configuration	# module that reads configuration file for recommender engine
import Read_Startup_Recommender_Engine		# module that reads the system startup file
import Read_Console				# module that reads the console for an input
import Read_Batch_File				# module that reads the sailor batch file input
import mysql.connector				# mysql to Python connector
import Sailor_Profile				# retrieves the profile of a sailor
import datetime					# retrieve library to handle date and time
import csv					# import library to handle .csv files
import time					# import library to handle time
import Mode_Two					# import module that scores revenue, profit, and capacity
import Mode_Three				# import module that scores geolocation


#####################
#		    #
# Declare Variables #
#		    #
#####################
User = ""					# user to database
Pass = ""					# password of user to database
Host = ""					# location of the MySQL database as an ip address
Loop = True					# when true, looping is enabled
Database_Name = ""				# name of the recommender engine database
Main_Filepath = ""				# filepath to recommender engine directory
Recommender_Engine_Configuration_Filepath = ""	# filepath to the recommender engine configuration file
Create_Database_Specification = ""		# filepath to file containing sql commands to create database
Import_Data_Files = ""				# list of files to import to database tables
Batch_Filepath = ""				# filepath to batch input files
Input_Channel_Code = 0				# if 1, then input from console, if 2,then input from batch file
Sailor_Id = ""					# sailor id as a string
Ship_Name = ""					# name of the ship
Start_Date = ""					# start date of the request
Start_Time = ""					# start time of the request
End_Date = ""					# end date of the request
End_Time = ""					# end time of the request
Processing_Mode = 0				# processing mode 1:  calendar match
						# processing mode 2:  profile and activity scoring
Special_Character = ""				# if special character is "z", then pay attention to input, otherwise ignore
Channel_Code = "" 				# if 1, then input from console, if 2, then input from batch file
Start_Date = ""					# day for query
Local_Start_Time = ""				# start time for query
Local_End_Time = ""				# end time for query
Batch_Input_Filepath = ""			# filepath to batch file containing sailor information for recommendation
Kiosk_Station = ""				# a number depicting the kiosk station location


#################
#		#
# Declare Lists #
#		#
#################
Raw_Profile_Score_List = list()
Index_Sailor_Tmp_List = list()



###########################################################################
#                           						  #
# Step 2:   Read the recommender engine startup file - get directory etc. #
#                           						  #
###########################################################################

Content = Read_Startup_Recommender_Engine.read()
Database_Name = Content[0]			# extract database name from list
Main_Filepath = Content[1]			# extract the main filepath from list
Recommender_Engine_Configuration_Filepath = Content[2] # extract the main filepath from list 

# verify code - eventually toss
# print(Database_Name)
# print(Main_Filepath)
# print(Recommender_Engine_Configuration_Filepath)



#######################################################################################
#                           						              #
# Step 3:  Read the configuration file - get the specific configuration of the engine #
#                           						              #
#######################################################################################

Content = Read_Recommender_Engine_Configuration.read(Recommender_Engine_Configuration_Filepath)
Create_Database_Specifications = Content[0]	# extract create database specification from list
Import_Data_Files = Content[1]			# extract import data files from list
Batch_File = Content[2]				# extract input batch file name

# verify code - eventually toss
# print(Create_Database_Specifications)
# print(Import_Data_Files)
# print(Batch_File)



#########################################
#                           		#
# Step 4:  Get the database credentials #
#                           		#
#########################################

Content = Access_DB_Python.read(Main_Filepath)
Host = Content[0]
User = Content[1]
Pass = Content[2]

# verify code - eventually toss
# print(Host)
# print(User)
# print(Pass)





try:						# enclose main loop in try statement since there will be many times a database is accessed in loop


	#########################################
	#                           		#
	# Step 4:  Establish database access    #
	#                           		#
	#########################################

	conn = mysql.connector.connect(

		user=User,

		password=Pass,

		host=Host,

		database=Database_Name

		)

	cursor = conn.cursor()
	
	


	#######################################
	#                                     #
	# Step 5:  Start main processing loop #
	#                                     #
	#######################################
	
	Loop = True				# enable main processing loop
	Read_Console_Flag = True		# enable reading of the console so that commands can be retrieved
	Read_Batch_Flag = True			# enable reading of batch file
	count = 1				# used for debugging - delete later
	Loop_Count = 0				# increments for each time through loop
	
	while Loop:
	
		#########################################################
		#                                                       #
		# Step 6:  Get the console input, determine the command #
		#                                                       #
		#########################################################
 
		if Read_Console_Flag:
		
			###############################
			# Step 6a: Read console input #
			###############################
			Content = Read_Console.read()			# get console input
			strLine = list(Content)
			

			#########################################
			# Step 6b: Parse the console input line #
			#########################################
			Input_Channel_Code = Content[1]			# get the first field which is input channel
			
			
			
			###########################################
			# Step 7: Act on console input for sailor #
			###########################################
			if Input_Channel_Code == '1':
				
				Read_Batch_Flag = False
				
				
				################################################################################
				# Step 8:  Extract processing mode, sailor parameters, and datetime parameters #
				################################################################################
				Special_Character = strLine[0]			# if special character, "z" is present, then process line of text.  
				Channel_Code = strLine[1]			# if code is 1, read from console, else, read 
				Processing_Mode = strLine[2]			# processing mode should be 3rd field
				Sailor_Id = strLine[3]				# get id of the sailor
				Ship_Name = strLine[4]				# get the ship's name
				Start_Date = strLine[5]				# get the start date
				Start_Time = strLine[6]				# get the start time
				End_Date = strLine[7]				# get the end date
				End_Time = strLine[8]				# get the end time
				
				if Processing_Mode == '3':
					Kiosk_Station = strLine[9]		# get the kiosk station number
			
				# verify code - toss later
				# print('\n\n')
				# print("Special Character = ",Special_Character)
				# print("Channel_Code = ",Channel_Code)
				# print("Processing_Mode = ",Processing_Mode)
				# print("Sailor_Id = ",Sailor_Id)
				# print("Ship_Name = ",Ship_Name)
				# print("Start_Date = ",Start_Date)
				# print("Start_Time = ",Start_Time)
				# print("End_Date = ",End_Date)
				# print("End_Time = ",End_Time)				
				
				
				#######################################################################################
				# Step 9:  Process_Mode 1 - match sailor calendar with available activities and score #
				#######################################################################################				
				if Processing_Mode == '1' or Processing_Mode == '2' or Processing_Mode == '3':
					
					##################################################2
					# Step 9a: Clear tbl_sailor_tmp for new analysis #
					##################################################
					sql = "truncate table tbl_sailor_tmp"
			
					cursor.execute(sql)
					
					##################################################################
					# Step 9b: Insert into tbl_sailor_tmp from tbl_activity_schedule #
					##################################################################									
					sql = "insert into tbl_sailor_tmp (id_activity_schedule, id_activity, local_date, local_start_time, local_end_time, sailor_reservation_count, capacity_in_sailors) select id_activity_schedule, id_activity, local_date, local_start_time, local_end_time, sailor_reservation_count, capacity_in_sailors from tbl_activity_schedule where local_date = '" + Start_Date + "' and local_start_time >= '" + Start_Time + "' and local_end_time <= '" + End_Time + "'"
			
					cursor.execute(sql)
				
					######################################################################
					# Step 9c: Update tbl_sailor with attribute values from tbl_activity #
					######################################################################
					#insert data into tbl_sailor_tmp from tbl_activity
					sql = "update tbl_sailor_tmp as t1, tbl_activity as t2 set t1.title = t2.title, t1.description = t2.description, t1.location = t2.location, t1.ship_name = t2.ship_name, t1.geolocation_x = t2.geolocation_x, t1.geolocation_y = t2.geolocation_y, t1.geolocation_z = t2.geolocation_z, t1.category_1 = t2.category_1, t1.category_2 = t2.category_2, t1.category_3 = t2.category_3, t1.general_start_date = t2.general_start_date, t1.general_end_date = t2.general_end_date, t1.id_activity_level = t2.id_activity_level, t1.age_low = t2.age_low, t1.age_high = t2.age_high, t1.attribute_1 = t2.attribute_1, t1.attribute_2 = t2.attribute_2, t1.attribute_3 = t2.attribute_3, t1.attribute_4 = t2.attribute_4, t1.attribute_5 = t2.attribute_5, t1.attribute_6 = t2.attribute_6, t1.attribute_7 = t2.attribute_7, t1.attribute_8 = t2.attribute_8, t1.attribute_9 = t2.attribute_9, t1.attribute_10 = t2.attribute_10, t1.attribute_11 = t2.attribute_11, t1.attribute_12 = t2.attribute_12, t1.attribute_13 = t2.attribute_13, t1.attribute_14 = t2.attribute_14, t1.attribute_15 = t2.attribute_15, t1.attribute_16 = t2.attribute_16, t1.attribute_17 = t2.attribute_17, t1.attribute_18 = t2.attribute_18, t1.attribute_19 = t2.attribute_19, t1.attribute_20 = t2.attribute_20,t1.attribute_21 = t2.attribute_21, t1.attribute_22 = t2.attribute_22, t1.attribute_23 = t2.attribute_23, t1.attribute_24 = t2.attribute_24, t1.attribute_25 = t2.attribute_25, t1.attribute_26 = t2.attribute_26, t1.attribute_27 = t2.attribute_27, t1.attribute_28 = t2.attribute_28, t1.attribute_29 = t2.attribute_29, t1.attribute_30 = t2.attribute_30, t1.attribute_31 = t2.attribute_31, t1.attribute_32 = t2.attribute_32, t1.attribute_33 = t2.attribute_33, t1.attribute_34 = t2.attribute_34, t1.attribute_35 = t2.attribute_35, t1.attribute_36 = t2.attribute_36, t1.attribute_37 = t2.attribute_37, t1.attribute_38 = t2.attribute_38, t1.attribute_39 = t2.attribute_39, t1.attribute_40 = t2.attribute_40,t1.attribute_41 = t2.attribute_41, t1.attribute_42 = t2.attribute_42, t1.attribute_43 = t2.attribute_43, t1.attribute_44 = t2.attribute_44, t1.attribute_45 = t2.attribute_45, t1.attribute_46 = t2.attribute_46, t1.attribute_47 = t2.attribute_47, t1.attribute_48 = t2.attribute_48, t1.attribute_49 = t2.attribute_49, t1.attribute_50 = t2.attribute_50, t1.attribute_51 = t2.attribute_51, t1.attribute_52 = t2.attribute_52, t1.attribute_53 = t2.attribute_53, t1.attribute_54 = t2.attribute_54, t1.attribute_55 = t2.attribute_55, t1.attribute_56 = t2.attribute_56, t1.attribute_57 = t2.attribute_57, t1.attribute_58 = t2.attribute_58, t1.attribute_59 = t2.attribute_59, t1.attribute_60 = t2.attribute_60, t1.attribute_61 = t2.attribute_61, t1.attribute_62 = t2.attribute_62, t1.attribute_63 = t2.attribute_63, t1.attribute_64 = t2.attribute_64, t1.attribute_65 = t2.attribute_65, t1.attribute_66 = t2.attribute_66, t1.attribute_67 = t2.attribute_67, t1.attribute_68 = t2.attribute_68, t1.attribute_69 = t2.attribute_69, t1.attribute_70 = t2.attribute_70, t1.attribute_71 = t2.attribute_71, t1.attribute_72 = t2.attribute_72, t1.attribute_73 = t2.attribute_73, t1.attribute_74 = t2.attribute_74, t1.attribute_75 = t2.attribute_75, t1.attribute_76 = t2.attribute_76, t1.attribute_77 = t2.attribute_77, t1.attribute_78 = t2.attribute_78, t1.attribute_79 = t2.attribute_79, t1.attribute_80 = t2.attribute_80, t1.attribute_81 = t2.attribute_81, t1.attribute_82 = t2.attribute_82, t1.attribute_83 = t2.attribute_83, t1.attribute_84 = t2.attribute_84, t1.attribute_85 = t2.attribute_85, t1.attribute_86 = t2.attribute_86, t1.attribute_87 = t2.attribute_87, t1.attribute_88 = t2.attribute_88, t1.attribute_89 = t2.attribute_89, t1.attribute_90 = t2.attribute_90, t1.attribute_91 = t2.attribute_91, t1.attribute_92 = t2.attribute_92, t1.attribute_93 = t2.attribute_93, t1.attribute_94 = t2.attribute_94, t1.attribute_95 = t2.attribute_95, t1.attribute_96 = t2.attribute_96, t1.attribute_97 = t2.attribute_97, t1.attribute_98 = t2.attribute_98, t1.attribute_99 = t2.attribute_99, t1.attribute_100 = t2.attribute_100, t1.attribute_101 = t2.attribute_101, t1.attribute_102 = t2.attribute_102, t1.attribute_103 = t2.attribute_103, t1.attribute_104 = t2.attribute_104, t1.attribute_105 = t2.attribute_105, t1.attribute_106 = t2.attribute_106, t1.attribute_107 = t2.attribute_107, t1.attribute_108 = t2.attribute_108, t1.attribute_109 = t2.attribute_109, t1.attribute_110 = t2.attribute_110, t1.attribute_111 = t2.attribute_111, t1.attribute_112 = t2.attribute_112, t1.attribute_113 = t2.attribute_113, t1.attribute_114 = t2.attribute_114, t1.attribute_115 = t2.attribute_115, t1.attribute_116 = t2.attribute_116, t1.attribute_117 = t2.attribute_117, t1.attribute_118 = t2.attribute_118, t1.attribute_119 = t2.attribute_119, t1.attribute_120 = t2.attribute_120, t1.attribute_121 = t2.attribute_121, t1.attribute_122 = t2.attribute_122, t1.attribute_123 = t2.attribute_123, t1.attribute_124 = t2.attribute_124, t1.attribute_125 = t2.attribute_125, t1.attribute_126 = t2.attribute_126, t1.attribute_127 = t2.attribute_127, t1.attribute_128 = t2.attribute_128, t1.attribute_129 = t2.attribute_129, t1.attribute_130 = t2.attribute_130, t1.attribute_131 = t2.attribute_131, t1.attribute_132 = t2.attribute_132, t1.attribute_133 = t2.attribute_133, t1.attribute_134 = t2.attribute_134, t1.attribute_135 = t2.attribute_135, t1.attribute_136 = t2.attribute_136, t1.attribute_137 = t2.attribute_137, t1.attribute_138 = t2.attribute_138, t1.attribute_139 = t2.attribute_139, t1.attribute_140 = t2.attribute_140, t1.attribute_141 = t2.attribute_141, t1.attribute_142 = t2.attribute_142, t1.attribute_143 = t2.attribute_143, t1.attribute_144 = t2.attribute_144, t1.attribute_145 = t2.attribute_145, t1.attribute_146 = t2.attribute_146, t1.attribute_147 = t2.attribute_147, t1.attribute_148 = t2.attribute_148, t1.attribute_149 = t2.attribute_149, t1.attribute_150 = t2.attribute_150, t1.attribute_151 = t2.attribute_151, t1.attribute_152 = t2.attribute_152, t1.attribute_153 = t2.attribute_153, t1.attribute_154 = t2.attribute_154, t1.attribute_155 = t2.attribute_155, t1.attribute_156 = t2.attribute_156, t1.attribute_157 = t2.attribute_157, t1.attribute_158 = t2.attribute_158, t1.attribute_159 = t2.attribute_159, t1.attribute_160 = t2.attribute_160, t1.attribute_161 = t2.attribute_161, t1.attribute_162 = t2.attribute_162, t1.attribute_163 = t2.attribute_163, t1.attribute_164 = t2.attribute_164, t1.attribute_165 = t2.attribute_165, t1.attribute_166 = t2.attribute_166, t1.attribute_167 = t2.attribute_167, t1.attribute_168 = t2.attribute_168, t1.attribute_169 = t2.attribute_169, t1.attribute_170 = t2.attribute_170, t1.attribute_171 = t2.attribute_171, t1.attribute_172 = t2.attribute_172, t1.attribute_173 = t2.attribute_173, t1.attribute_174 = t2.attribute_174, t1.attribute_175 = t2.attribute_175, t1.attribute_176 = t2.attribute_176, t1.attribute_177 = t2.attribute_177, t1.attribute_178 = t2.attribute_178, t1.attribute_179 = t2.attribute_179, t1.attribute_180 = t2.attribute_180, t1.attribute_181 = t2.attribute_181, t1.attribute_182 = t2.attribute_182, t1.attribute_183 = t2.attribute_183, t1.attribute_184 = t2.attribute_184, t1.attribute_185 = t2.attribute_185, t1.attribute_186 = t2.attribute_186, t1.attribute_187 = t2.attribute_187, t1.attribute_188 = t2.attribute_188, t1.attribute_189 = t2.attribute_189, t1.attribute_190 = t2.attribute_190, t1.attribute_191 = t2.attribute_191, t1.attribute_192 = t2.attribute_192, t1.attribute_193 = t2.attribute_193, t1.attribute_194 = t2.attribute_194, t1.attribute_195 = t2.attribute_195, t1.attribute_196 = t2.attribute_196, t1.attribute_197 = t2.attribute_197, t1.attribute_198 = t2.attribute_198, t1.attribute_199 = t2.attribute_199, t1.attribute_200 = t2.attribute_200, t1.attribute_201 = t2.attribute_201, t1.attribute_202 = t2.attribute_202, t1.attribute_203 = t2.attribute_203, t1.attribute_204 = t2.attribute_204, t1.attribute_205 = t2.attribute_205, t1.attribute_206 = t2.attribute_206, t1.attribute_207 = t2.attribute_207, t1.attribute_208 = t2.attribute_208, t1.attribute_209 = t2.attribute_209, t1.attribute_210 = t2.attribute_210, t1.attribute_211 = t2.attribute_211, t1.attribute_212 = t2.attribute_212, t1.attribute_213 = t2.attribute_213, t1.attribute_214 = t2.attribute_214, t1.attribute_215 = t2.attribute_215, t1.attribute_216 = t2.attribute_216, t1.attribute_217 = t2.attribute_217, t1.attribute_218 = t2.attribute_218, t1.attribute_219 = t2.attribute_219, t1.attribute_220 = t2.attribute_220, t1.attribute_221 = t2.attribute_221, t1.attribute_222 = t2.attribute_222, t1.attribute_223 = t2.attribute_223, t1.attribute_224 = t2.attribute_224, t1.attribute_225 = t2.attribute_225, t1.attribute_226 = t2.attribute_226, t1.attribute_227 = t2.attribute_227, t1.attribute_228 = t2.attribute_228, t1.attribute_229 = t2.attribute_229, t1.attribute_230 = t2.attribute_230, t1.attribute_231 = t2.attribute_231, t1.attribute_232 = t2.attribute_232, t1.attribute_233 = t2.attribute_233, t1.attribute_234 = t2.attribute_234, t1.attribute_235 = t2.attribute_235, t1.attribute_236 = t2.attribute_236, t1.attribute_237 = t2.attribute_237, t1.attribute_238 = t2.attribute_238, t1.attribute_239 = t2.attribute_239, t1.attribute_240 = t2.attribute_240, t1.attribute_241 = t2.attribute_241, t1.attribute_242 = t2.attribute_242, t1.attribute_243 = t2.attribute_243, t1.attribute_244 = t2.attribute_244, t1.attribute_245 = t2.attribute_245, t1.attribute_246 = t2.attribute_246, t1.attribute_247 = t2.attribute_247, t1.attribute_248 = t2.attribute_248, t1.attribute_249 = t2.attribute_249, t1.attribute_250 = t2.attribute_250, t1.attribute_251 = t2.attribute_251, t1.attribute_252 = t2.attribute_252, t1.attribute_253 = t2.attribute_253, t1.attribute_254 = t2.attribute_254, t1.attribute_255 = t2.attribute_255, t1.gmt_date_created = t2.gmt_date_created, t1.id_employee = t2.id_employee where t1.id_activity = t2.id_activity"
				
					cursor.execute(sql)
				
					######################################################
					# Step 9d: Update tbl_sailor empty reservation count #
					######################################################
					sql = "update tbl_sailor_tmp set empty_reservation_count = capacity_in_sailors - sailor_reservation_count"

					cursor.execute(sql)
									
					############################################################################################
					# Step 9e:  Populate lists with date and times used to eliminate sailor calendar conflicts #
					############################################################################################
					
					# get from tbl_sailor_calendar where dates and times are commited
					sql  = "select id_activity_schedule, local_start_date, local_start_time, local_end_time from tbl_sailor_calendar where id_sailor = " + Sailor_Id
					
					cursor.execute(sql)
					
					row = cursor.fetchone()
					
					while row is not None:					# loop while there remains rows to process
						
						print('\n')
						#print(row)
						
						Start_Date = row[1]
						Start_Date = Start_Date.strftime('%Y-%m-%d')
						
						Local_Start_Time = row[2]
						Local_Start_Time = (datetime.datetime.min + Local_Start_Time).time()
						Local_Start_Time = Local_Start_Time.strftime('%H:%M:%S')
						
						Local_End_Time = row[3]
						Local_End_Time = (datetime.datetime.min + Local_End_Time).time()
						Local_End_Time = Local_End_Time.strftime('%H:%M:%S')
						
						
						
					
						# delete from tbl_sailor_tmp where conflict exists
						sql = "delete from tbl_sailor_tmp where local_date = '" + Start_Date + "' and ((local_start_time >= '" + Local_Start_Time + "' and local_start_time <= '" + Local_End_Time + "') or (local_end_time >= '" + Local_Start_Time + "' and local_end_time <= '" + Local_End_Time + "'))" 
						
						cursor.execute(sql)
								
						row = cursor.fetchone()				# get next row
					
					
									
					#############################################################################################################################
					# Step 9f:  Eliminate from tbl_sailor_tmp where the activity has no remaining capacity or sailor isn't in correct age range #
					#############################################################################################################################
					
					# get sailor's age
					sql = "select age from tbl_sailor where id_sailor = " + Sailor_Id
					cursor.execute(sql)
					row = cursor.fetchone()
					Age = row[0]
				
					
					sql = "delete from tbl_sailor_tmp where (capacity_in_sailors > 0 and empty_reservation_count = 0) or (age_low > " + str(Age) + " or age_high < " + str(Age) + ")"
					
					
					cursor.execute(sql)
				
							
									
					#######################################################################################################
					# Step 9g:  Add offer history data to tbl_sailor_tmp by joining on id_sailor and id_activity_schedule #
					#######################################################################################################
					
					sql = "update tbl_sailor_tmp as t1, tbl_offer_history as t2 set t1.activity_yes_count = t2.activity_yes_count, t1.activity_maybe_count = t2.activity_maybe_count, t1.activity_no_count = t2.activity_no_count, t1.activity_schedule_yes_count = t2.activity_schedule_yes_count, t1.activity_schedule_maybe_count = t2.activity_schedule_maybe_count, t1.activity_schedule_no_count = t2.activity_schedule_no_count where t1.id_activity_schedule = t2.id_activity_schedule and t2.id_sailor = " + Sailor_Id
					
			
					cursor.execute(sql)
				
				
					###############################################################
					# Step 9h:  Get sailor's profile attributes and store in list #
					###############################################################
					
					sql = "select id_sailor, Attribute_1,Attribute_2,Attribute_3,Attribute_4,Attribute_5,Attribute_6,Attribute_7,Attribute_8,Attribute_9,Attribute_10,Attribute_11,Attribute_12,Attribute_13,Attribute_14,Attribute_15,Attribute_16,Attribute_17,Attribute_18,Attribute_19,Attribute_20,Attribute_21,Attribute_22,Attribute_23,Attribute_24,Attribute_25,Attribute_26,Attribute_27,Attribute_28,Attribute_29,Attribute_30,Attribute_31,Attribute_32,Attribute_33,Attribute_34,Attribute_35,Attribute_36,Attribute_37,Attribute_38,Attribute_39,Attribute_40,Attribute_41,Attribute_42,Attribute_43,Attribute_44,Attribute_45,Attribute_46,Attribute_47,Attribute_48,Attribute_49,Attribute_50,Attribute_51,Attribute_52,Attribute_53,Attribute_54,Attribute_55,Attribute_56,Attribute_57,Attribute_58,Attribute_59,Attribute_60,Attribute_61,Attribute_62,Attribute_63,Attribute_64,Attribute_65,Attribute_66,Attribute_67,Attribute_68,Attribute_69,Attribute_70,Attribute_71,Attribute_72,Attribute_73,Attribute_74,Attribute_75,Attribute_76,Attribute_77,Attribute_78,Attribute_79,Attribute_80,Attribute_81,Attribute_82,Attribute_83,Attribute_84,Attribute_85,Attribute_86,Attribute_87,Attribute_88,Attribute_89,Attribute_90,Attribute_91,Attribute_92,Attribute_93,Attribute_94,Attribute_95,Attribute_96,Attribute_97,Attribute_98,Attribute_99,Attribute_100,Attribute_101,Attribute_102,Attribute_103,Attribute_104,Attribute_105,Attribute_106,Attribute_107,Attribute_108,Attribute_109,Attribute_110,Attribute_111,Attribute_112,Attribute_113,Attribute_114,Attribute_115,Attribute_116,Attribute_117,Attribute_118,Attribute_119,Attribute_120,Attribute_121,Attribute_122,Attribute_123,Attribute_124,Attribute_125,Attribute_126,Attribute_127,Attribute_128,Attribute_129,Attribute_130,Attribute_131,Attribute_132,Attribute_133,Attribute_134,Attribute_135,Attribute_136,Attribute_137,Attribute_138,Attribute_139,Attribute_140,Attribute_141,Attribute_142,Attribute_143,Attribute_144,Attribute_145,Attribute_146,Attribute_147,Attribute_148,Attribute_149,Attribute_150,Attribute_151,Attribute_152,Attribute_153,Attribute_154,Attribute_155,Attribute_156,Attribute_157,Attribute_158,Attribute_159,Attribute_160,Attribute_161,Attribute_162,Attribute_163,Attribute_164,Attribute_165,Attribute_166,Attribute_167,Attribute_168,Attribute_169,Attribute_170,Attribute_171,Attribute_172,Attribute_173,Attribute_174,Attribute_175,Attribute_176,Attribute_177,Attribute_178,Attribute_179,Attribute_180,Attribute_181,Attribute_182,Attribute_183,Attribute_184,Attribute_185,Attribute_186,Attribute_187,Attribute_188,Attribute_189,Attribute_190,Attribute_191,Attribute_192,Attribute_193,Attribute_194,Attribute_195,Attribute_196,Attribute_197,Attribute_198,Attribute_199,Attribute_200,Attribute_201,Attribute_202,Attribute_203,Attribute_204,Attribute_205,Attribute_206,Attribute_207,Attribute_208,Attribute_209,Attribute_210,Attribute_211,Attribute_212,Attribute_213,Attribute_214,Attribute_215,Attribute_216,Attribute_217,Attribute_218,Attribute_219,Attribute_220,Attribute_221,Attribute_222,Attribute_223,Attribute_224,Attribute_225,Attribute_226,Attribute_227,Attribute_228,Attribute_229,Attribute_230,Attribute_231,Attribute_232,Attribute_233,Attribute_234,Attribute_235,Attribute_236,Attribute_237,Attribute_238,Attribute_239,Attribute_240,Attribute_241,Attribute_242,Attribute_243,Attribute_244,Attribute_245,Attribute_246,Attribute_247,Attribute_248,Attribute_249,Attribute_250,Attribute_251,Attribute_252,Attribute_253,Attribute_254,Attribute_255 from tbl_sailor where id_sailor = " + str(Sailor_Id)
					
					
					cursor.execute(sql)
				
					Sailor_Attributes = cursor.fetchone()
					
					
					
					#######################################################
					# Step 9i:  Get activity attributes and store in list #
					#######################################################
					
					# verification code - toss later
					sql = "select count(*) from tbl_sailor_tmp"
					cursor.execute(sql)
					Record_Count = cursor.fetchone()
					
					
					
					
				
					sql = "select id_sailor_tmp, Attribute_1,Attribute_2,Attribute_3,Attribute_4,Attribute_5,Attribute_6,Attribute_7,Attribute_8,Attribute_9,Attribute_10,Attribute_11,Attribute_12,Attribute_13,Attribute_14,Attribute_15,Attribute_16,Attribute_17,Attribute_18,Attribute_19,Attribute_20,Attribute_21,Attribute_22,Attribute_23,Attribute_24,Attribute_25,Attribute_26,Attribute_27,Attribute_28,Attribute_29,Attribute_30,Attribute_31,Attribute_32,Attribute_33,Attribute_34,Attribute_35,Attribute_36,Attribute_37,Attribute_38,Attribute_39,Attribute_40,Attribute_41,Attribute_42,Attribute_43,Attribute_44,Attribute_45,Attribute_46,Attribute_47,Attribute_48,Attribute_49,Attribute_50,Attribute_51,Attribute_52,Attribute_53,Attribute_54,Attribute_55,Attribute_56,Attribute_57,Attribute_58,Attribute_59,Attribute_60,Attribute_61,Attribute_62,Attribute_63,Attribute_64,Attribute_65,Attribute_66,Attribute_67,Attribute_68,Attribute_69,Attribute_70,Attribute_71,Attribute_72,Attribute_73,Attribute_74,Attribute_75,Attribute_76,Attribute_77,Attribute_78,Attribute_79,Attribute_80,Attribute_81,Attribute_82,Attribute_83,Attribute_84,Attribute_85,Attribute_86,Attribute_87,Attribute_88,Attribute_89,Attribute_90,Attribute_91,Attribute_92,Attribute_93,Attribute_94,Attribute_95,Attribute_96,Attribute_97,Attribute_98,Attribute_99,Attribute_100,Attribute_101,Attribute_102,Attribute_103,Attribute_104,Attribute_105,Attribute_106,Attribute_107,Attribute_108,Attribute_109,Attribute_110,Attribute_111,Attribute_112,Attribute_113,Attribute_114,Attribute_115,Attribute_116,Attribute_117,Attribute_118,Attribute_119,Attribute_120,Attribute_121,Attribute_122,Attribute_123,Attribute_124,Attribute_125,Attribute_126,Attribute_127,Attribute_128,Attribute_129,Attribute_130,Attribute_131,Attribute_132,Attribute_133,Attribute_134,Attribute_135,Attribute_136,Attribute_137,Attribute_138,Attribute_139,Attribute_140,Attribute_141,Attribute_142,Attribute_143,Attribute_144,Attribute_145,Attribute_146,Attribute_147,Attribute_148,Attribute_149,Attribute_150,Attribute_151,Attribute_152,Attribute_153,Attribute_154,Attribute_155,Attribute_156,Attribute_157,Attribute_158,Attribute_159,Attribute_160,Attribute_161,Attribute_162,Attribute_163,Attribute_164,Attribute_165,Attribute_166,Attribute_167,Attribute_168,Attribute_169,Attribute_170,Attribute_171,Attribute_172,Attribute_173,Attribute_174,Attribute_175,Attribute_176,Attribute_177,Attribute_178,Attribute_179,Attribute_180,Attribute_181,Attribute_182,Attribute_183,Attribute_184,Attribute_185,Attribute_186,Attribute_187,Attribute_188,Attribute_189,Attribute_190,Attribute_191,Attribute_192,Attribute_193,Attribute_194,Attribute_195,Attribute_196,Attribute_197,Attribute_198,Attribute_199,Attribute_200,Attribute_201,Attribute_202,Attribute_203,Attribute_204,Attribute_205,Attribute_206,Attribute_207,Attribute_208,Attribute_209,Attribute_210,Attribute_211,Attribute_212,Attribute_213,Attribute_214,Attribute_215,Attribute_216,Attribute_217,Attribute_218,Attribute_219,Attribute_220,Attribute_221,Attribute_222,Attribute_223,Attribute_224,Attribute_225,Attribute_226,Attribute_227,Attribute_228,Attribute_229,Attribute_230,Attribute_231,Attribute_232,Attribute_233,Attribute_234,Attribute_235,Attribute_236,Attribute_237,Attribute_238,Attribute_239,Attribute_240,Attribute_241,Attribute_242,Attribute_243,Attribute_244,Attribute_245,Attribute_246,Attribute_247,Attribute_248,Attribute_249,Attribute_250,Attribute_251,Attribute_252,Attribute_253,Attribute_254,Attribute_255 from tbl_sailor_tmp"					
				
					cursor.execute(sql)
									
					Activity_Attributes = cursor.fetchone()
					
					
					
					Record_Count = 0;					# initialize and count records
					while Activity_Attributes is not None:			# loop while there remains rows to process
					
						
					
						Raw_Profile_Score = 0				# initialize the raw profile score
						
						for i in range(1, 255):
							
							if Sailor_Attributes[i] == 1 and Activity_Attributes[i] == 1:
								Raw_Profile_Score = Raw_Profile_Score + 1
								
						Raw_Profile_Score_List.insert(Record_Count,Raw_Profile_Score)
						
						# print('\n Here is the Raw Profile_Score:  ', Raw_Profile_Score_List[iCount])
				
						
						Index_Sailor_Tmp_List.insert(Record_Count,Activity_Attributes[0])
						
						Record_Count = Record_Count + 1			# count record						
						
				
						Activity_Attributes = cursor.fetchone()		# get next row

					
					
					
					
					#######################################################
					# Step 9j:  Store raw_profile score in tbl_sailor_tmp #
					#######################################################

					
					for i in range(0,Record_Count):
					
						sql = "update tbl_sailor_tmp set profile_score = " + str(Raw_Profile_Score_List[i]) + " where id_sailor_tmp = " + str(Index_Sailor_Tmp_List[i])

						cursor.execute(sql)
						
						
					sql = "select max(profile_score) from tbl_sailor_tmp"
					cursor.execute(sql)
					
					
					#######################################################
					# Step 9k:  Store raw_profile score in tbl_sailor_tmp #
					#######################################################
					
					Max_Raw_Profile_Score = cursor.fetchone()
					
					
					
					sql = "update tbl_sailor_tmp set profile_score = profile_score / " + str(Max_Raw_Profile_Score[0])
					
					cursor.execute(sql)
					
					
					##################################################
					# Step 9l:  Order tbl_sailor_tmp and readin table#
					##################################################
					
					sql = "select count(*) from tbl_sailor_tmp"
					
					cursor.execute(sql)
					
					Record_Count = cursor.fetchone()
					
					
					sql = "select * from tbl_sailor_tmp order by profile_score desc"
					
					cursor.execute(sql)
					
					rows = cursor.fetchall()
				
					
					##################################################
					# Step 9m:  Make an output file and then output  #
					##################################################					
					
					if Processing_Mode == '1':
					
						print('\nPrinting Mode 1')
					
						Current_Date = datetime.datetime.now().date()

						strDate = str(Current_Date)



						Output_Filepath = "e:/projects/sailors/output/recommender_engine/" + str(Sailor_Id) + "_" + strDate + "_" + Start_Date + "_" + End_Date + ".csv"



						with open(Output_Filepath,"w") as out:
							csv_out = csv.writer(out)
							for row in rows:
								csv_out.writerow(row)



						#out.close()


						#del Raw_Profile_Score_List[:]				# clear list
						#del Index_Sailor_Tmp_List[:]				# clear list


						#print('\nDone!')


					################################################
					# Step 10:  Process_Mode 2 - economic scoring  #
					################################################
					if Processing_Mode == '2':
						print('\n\n\n Mode 2')

						Mode_Two.run(cursor)


						###################################################
						# Step 10a:  Order tbl_sailor_tmp and readin table #
						###################################################

						sql = "select * from tbl_sailor_tmp order by profile_score desc"

						cursor.execute(sql)

						rows = cursor.fetchall()



						print('\nPrinting Mode 2')


						Current_Date = datetime.datetime.now().date()

						strDate = str(Current_Date)



						Output_Filepath = "e:/projects/sailors/output/recommender_engine/" + str(Sailor_Id) + "_" + strDate + "_" + Start_Date + "_" + End_Date + ".csv"



						with open(Output_Filepath,"w") as out:
							csv_out = csv.writer(out)
							for row in rows:
								csv_out.writerow(row)
							
				
				

					################################################
					# Step 11:  Process_Mode 3 - geo scoring  #
					################################################
					if Processing_Mode == '3':
						print('\n\n\n Mode 3')

						Mode_Three.run(cursor, Kiosk_Station)	
						
					
						###################################################
						# Step 11a:  Order tbl_sailor_tmp and readin table #
						###################################################

						sql = "select * from tbl_sailor_tmp order by profile_score desc"

						cursor.execute(sql)

						rows = cursor.fetchall()					
						print('\nPrinting Mode 3')


						Current_Date = datetime.datetime.now().date()

						strDate = str(Current_Date)



						Output_Filepath = "e:/projects/sailors/output/recommender_engine/" + str(Sailor_Id) + "_" + strDate + "_" + Start_Date + "_" + End_Date + ".csv"



						with open(Output_Filepath,"w") as out:
							csv_out = csv.writer(out)
							for row in rows:
								csv_out.writerow(row)					
					
					
					



				out.close()


				del Raw_Profile_Score_List[:]				# clear list
				del Index_Sailor_Tmp_List[:]				# clear list


				print('\nDone!')










					
				
					
			###########################################
			# Step 100: Act on batch input for sailor #
			###########################################				
			if Input_Channel_Code == '2':
			
				print("input channel code 2 found")	# debug code - toss later
				
				
				Read_Batch_Flag = True
				
				Batch_Input_Filepath = Main_Filepath + "Input/Recommender_Engine_Input/Batch_Sailor_Python.csv"
				
				print('\n\n\n', Batch_Input_Filepath)
				
				with open(Batch_Input_Filepath) as csvDataFile:
					csvReader = csv.reader(csvDataFile)
					for strLine in csvReader:
						
						
						
				
				
						###################################################################################
						# Step 100a:  Extract processing mode, sailor parameters, and datetime parameters #
						###################################################################################
						Special_Character = strLine[0]			# if special character, "z" is present, then process line of text.  
						Channel_Code = strLine[1]			# if code is 1, read from console, else, read 
						Processing_Mode = strLine[2]			# processing mode should be 3rd field
						Sailor_Id = strLine[3]				# get id of the sailor
						Ship_Name = strLine[4]				# get the ship's name
						Start_Date = strLine[5]				# get the start date
						Start_Time = strLine[6]				# get the start time
						End_Date = strLine[7]				# get the end date
						End_Time = strLine[8]				# get the end time

						# verify code - toss later
						print('\n\n')
						print("Special Character = ",Special_Character)
						print("Channel_Code = ",Channel_Code)
						print("Processing_Mode = ",Processing_Mode)
						print("Sailor_Id = ",Sailor_Id)
						print("Ship_Name = ",Ship_Name)
						print("Start_Date = ",Start_Date)
						print("Start_Time = ",Start_Time)
						print("End_Date = ",End_Date)
						print("End_Time = ",End_Time)						
			
			
			



						##########################################################################################
						# Step 100b:  Process_Mode 1 - match sailor calendar with available activities and score #
						##########################################################################################				
						if Processing_Mode == '1' or Processing_Mode == '2':

							####################################################
							# Step 100c: Clear tbl_sailor_tmp for new analysis #
							####################################################
							sql = "truncate table tbl_sailor_tmp"

							cursor.execute(sql)

							####################################################################
							# Step 100d: Insert into tbl_sailor_tmp from tbl_activity_schedule #
							####################################################################									
							sql = "insert into tbl_sailor_tmp (id_activity_schedule, id_activity, local_date, local_start_time, local_end_time, sailor_reservation_count, capacity_in_sailors) select id_activity_schedule, id_activity, local_date, local_start_time, local_end_time, sailor_reservation_count, capacity_in_sailors from tbl_activity_schedule where local_date = '" + Start_Date + "' and local_start_time >= '" + Start_Time + "' and local_end_time <= '" + End_Time + "'"

							cursor.execute(sql)

							########################################################################
							# Step 100e: Update tbl_sailor with attribute values from tbl_activity #
							########################################################################
							#insert data into tbl_sailor_tmp from tbl_activity
							sql = "update tbl_sailor_tmp as t1, tbl_activity as t2 set t1.title = t2.title, t1.description = t2.description, t1.location = t2.location, t1.ship_name = t2.ship_name, t1.geolocation_x = t2.geolocation_x, t1.geolocation_y = t2.geolocation_y, t1.geolocation_z = t2.geolocation_z, t1.category_1 = t2.category_1, t1.category_2 = t2.category_2, t1.category_3 = t2.category_3, t1.general_start_date = t2.general_start_date, t1.general_end_date = t2.general_end_date, t1.id_activity_level = t2.id_activity_level, t1.age_low = t2.age_low, t1.age_high = t2.age_high, t1.attribute_1 = t2.attribute_1, t1.attribute_2 = t2.attribute_2, t1.attribute_3 = t2.attribute_3, t1.attribute_4 = t2.attribute_4, t1.attribute_5 = t2.attribute_5, t1.attribute_6 = t2.attribute_6, t1.attribute_7 = t2.attribute_7, t1.attribute_8 = t2.attribute_8, t1.attribute_9 = t2.attribute_9, t1.attribute_10 = t2.attribute_10, t1.attribute_11 = t2.attribute_11, t1.attribute_12 = t2.attribute_12, t1.attribute_13 = t2.attribute_13, t1.attribute_14 = t2.attribute_14, t1.attribute_15 = t2.attribute_15, t1.attribute_16 = t2.attribute_16, t1.attribute_17 = t2.attribute_17, t1.attribute_18 = t2.attribute_18, t1.attribute_19 = t2.attribute_19, t1.attribute_20 = t2.attribute_20,t1.attribute_21 = t2.attribute_21, t1.attribute_22 = t2.attribute_22, t1.attribute_23 = t2.attribute_23, t1.attribute_24 = t2.attribute_24, t1.attribute_25 = t2.attribute_25, t1.attribute_26 = t2.attribute_26, t1.attribute_27 = t2.attribute_27, t1.attribute_28 = t2.attribute_28, t1.attribute_29 = t2.attribute_29, t1.attribute_30 = t2.attribute_30, t1.attribute_31 = t2.attribute_31, t1.attribute_32 = t2.attribute_32, t1.attribute_33 = t2.attribute_33, t1.attribute_34 = t2.attribute_34, t1.attribute_35 = t2.attribute_35, t1.attribute_36 = t2.attribute_36, t1.attribute_37 = t2.attribute_37, t1.attribute_38 = t2.attribute_38, t1.attribute_39 = t2.attribute_39, t1.attribute_40 = t2.attribute_40,t1.attribute_41 = t2.attribute_41, t1.attribute_42 = t2.attribute_42, t1.attribute_43 = t2.attribute_43, t1.attribute_44 = t2.attribute_44, t1.attribute_45 = t2.attribute_45, t1.attribute_46 = t2.attribute_46, t1.attribute_47 = t2.attribute_47, t1.attribute_48 = t2.attribute_48, t1.attribute_49 = t2.attribute_49, t1.attribute_50 = t2.attribute_50, t1.attribute_51 = t2.attribute_51, t1.attribute_52 = t2.attribute_52, t1.attribute_53 = t2.attribute_53, t1.attribute_54 = t2.attribute_54, t1.attribute_55 = t2.attribute_55, t1.attribute_56 = t2.attribute_56, t1.attribute_57 = t2.attribute_57, t1.attribute_58 = t2.attribute_58, t1.attribute_59 = t2.attribute_59, t1.attribute_60 = t2.attribute_60, t1.attribute_61 = t2.attribute_61, t1.attribute_62 = t2.attribute_62, t1.attribute_63 = t2.attribute_63, t1.attribute_64 = t2.attribute_64, t1.attribute_65 = t2.attribute_65, t1.attribute_66 = t2.attribute_66, t1.attribute_67 = t2.attribute_67, t1.attribute_68 = t2.attribute_68, t1.attribute_69 = t2.attribute_69, t1.attribute_70 = t2.attribute_70, t1.attribute_71 = t2.attribute_71, t1.attribute_72 = t2.attribute_72, t1.attribute_73 = t2.attribute_73, t1.attribute_74 = t2.attribute_74, t1.attribute_75 = t2.attribute_75, t1.attribute_76 = t2.attribute_76, t1.attribute_77 = t2.attribute_77, t1.attribute_78 = t2.attribute_78, t1.attribute_79 = t2.attribute_79, t1.attribute_80 = t2.attribute_80, t1.attribute_81 = t2.attribute_81, t1.attribute_82 = t2.attribute_82, t1.attribute_83 = t2.attribute_83, t1.attribute_84 = t2.attribute_84, t1.attribute_85 = t2.attribute_85, t1.attribute_86 = t2.attribute_86, t1.attribute_87 = t2.attribute_87, t1.attribute_88 = t2.attribute_88, t1.attribute_89 = t2.attribute_89, t1.attribute_90 = t2.attribute_90, t1.attribute_91 = t2.attribute_91, t1.attribute_92 = t2.attribute_92, t1.attribute_93 = t2.attribute_93, t1.attribute_94 = t2.attribute_94, t1.attribute_95 = t2.attribute_95, t1.attribute_96 = t2.attribute_96, t1.attribute_97 = t2.attribute_97, t1.attribute_98 = t2.attribute_98, t1.attribute_99 = t2.attribute_99, t1.attribute_100 = t2.attribute_100, t1.attribute_101 = t2.attribute_101, t1.attribute_102 = t2.attribute_102, t1.attribute_103 = t2.attribute_103, t1.attribute_104 = t2.attribute_104, t1.attribute_105 = t2.attribute_105, t1.attribute_106 = t2.attribute_106, t1.attribute_107 = t2.attribute_107, t1.attribute_108 = t2.attribute_108, t1.attribute_109 = t2.attribute_109, t1.attribute_110 = t2.attribute_110, t1.attribute_111 = t2.attribute_111, t1.attribute_112 = t2.attribute_112, t1.attribute_113 = t2.attribute_113, t1.attribute_114 = t2.attribute_114, t1.attribute_115 = t2.attribute_115, t1.attribute_116 = t2.attribute_116, t1.attribute_117 = t2.attribute_117, t1.attribute_118 = t2.attribute_118, t1.attribute_119 = t2.attribute_119, t1.attribute_120 = t2.attribute_120, t1.attribute_121 = t2.attribute_121, t1.attribute_122 = t2.attribute_122, t1.attribute_123 = t2.attribute_123, t1.attribute_124 = t2.attribute_124, t1.attribute_125 = t2.attribute_125, t1.attribute_126 = t2.attribute_126, t1.attribute_127 = t2.attribute_127, t1.attribute_128 = t2.attribute_128, t1.attribute_129 = t2.attribute_129, t1.attribute_130 = t2.attribute_130, t1.attribute_131 = t2.attribute_131, t1.attribute_132 = t2.attribute_132, t1.attribute_133 = t2.attribute_133, t1.attribute_134 = t2.attribute_134, t1.attribute_135 = t2.attribute_135, t1.attribute_136 = t2.attribute_136, t1.attribute_137 = t2.attribute_137, t1.attribute_138 = t2.attribute_138, t1.attribute_139 = t2.attribute_139, t1.attribute_140 = t2.attribute_140, t1.attribute_141 = t2.attribute_141, t1.attribute_142 = t2.attribute_142, t1.attribute_143 = t2.attribute_143, t1.attribute_144 = t2.attribute_144, t1.attribute_145 = t2.attribute_145, t1.attribute_146 = t2.attribute_146, t1.attribute_147 = t2.attribute_147, t1.attribute_148 = t2.attribute_148, t1.attribute_149 = t2.attribute_149, t1.attribute_150 = t2.attribute_150, t1.attribute_151 = t2.attribute_151, t1.attribute_152 = t2.attribute_152, t1.attribute_153 = t2.attribute_153, t1.attribute_154 = t2.attribute_154, t1.attribute_155 = t2.attribute_155, t1.attribute_156 = t2.attribute_156, t1.attribute_157 = t2.attribute_157, t1.attribute_158 = t2.attribute_158, t1.attribute_159 = t2.attribute_159, t1.attribute_160 = t2.attribute_160, t1.attribute_161 = t2.attribute_161, t1.attribute_162 = t2.attribute_162, t1.attribute_163 = t2.attribute_163, t1.attribute_164 = t2.attribute_164, t1.attribute_165 = t2.attribute_165, t1.attribute_166 = t2.attribute_166, t1.attribute_167 = t2.attribute_167, t1.attribute_168 = t2.attribute_168, t1.attribute_169 = t2.attribute_169, t1.attribute_170 = t2.attribute_170, t1.attribute_171 = t2.attribute_171, t1.attribute_172 = t2.attribute_172, t1.attribute_173 = t2.attribute_173, t1.attribute_174 = t2.attribute_174, t1.attribute_175 = t2.attribute_175, t1.attribute_176 = t2.attribute_176, t1.attribute_177 = t2.attribute_177, t1.attribute_178 = t2.attribute_178, t1.attribute_179 = t2.attribute_179, t1.attribute_180 = t2.attribute_180, t1.attribute_181 = t2.attribute_181, t1.attribute_182 = t2.attribute_182, t1.attribute_183 = t2.attribute_183, t1.attribute_184 = t2.attribute_184, t1.attribute_185 = t2.attribute_185, t1.attribute_186 = t2.attribute_186, t1.attribute_187 = t2.attribute_187, t1.attribute_188 = t2.attribute_188, t1.attribute_189 = t2.attribute_189, t1.attribute_190 = t2.attribute_190, t1.attribute_191 = t2.attribute_191, t1.attribute_192 = t2.attribute_192, t1.attribute_193 = t2.attribute_193, t1.attribute_194 = t2.attribute_194, t1.attribute_195 = t2.attribute_195, t1.attribute_196 = t2.attribute_196, t1.attribute_197 = t2.attribute_197, t1.attribute_198 = t2.attribute_198, t1.attribute_199 = t2.attribute_199, t1.attribute_200 = t2.attribute_200, t1.attribute_201 = t2.attribute_201, t1.attribute_202 = t2.attribute_202, t1.attribute_203 = t2.attribute_203, t1.attribute_204 = t2.attribute_204, t1.attribute_205 = t2.attribute_205, t1.attribute_206 = t2.attribute_206, t1.attribute_207 = t2.attribute_207, t1.attribute_208 = t2.attribute_208, t1.attribute_209 = t2.attribute_209, t1.attribute_210 = t2.attribute_210, t1.attribute_211 = t2.attribute_211, t1.attribute_212 = t2.attribute_212, t1.attribute_213 = t2.attribute_213, t1.attribute_214 = t2.attribute_214, t1.attribute_215 = t2.attribute_215, t1.attribute_216 = t2.attribute_216, t1.attribute_217 = t2.attribute_217, t1.attribute_218 = t2.attribute_218, t1.attribute_219 = t2.attribute_219, t1.attribute_220 = t2.attribute_220, t1.attribute_221 = t2.attribute_221, t1.attribute_222 = t2.attribute_222, t1.attribute_223 = t2.attribute_223, t1.attribute_224 = t2.attribute_224, t1.attribute_225 = t2.attribute_225, t1.attribute_226 = t2.attribute_226, t1.attribute_227 = t2.attribute_227, t1.attribute_228 = t2.attribute_228, t1.attribute_229 = t2.attribute_229, t1.attribute_230 = t2.attribute_230, t1.attribute_231 = t2.attribute_231, t1.attribute_232 = t2.attribute_232, t1.attribute_233 = t2.attribute_233, t1.attribute_234 = t2.attribute_234, t1.attribute_235 = t2.attribute_235, t1.attribute_236 = t2.attribute_236, t1.attribute_237 = t2.attribute_237, t1.attribute_238 = t2.attribute_238, t1.attribute_239 = t2.attribute_239, t1.attribute_240 = t2.attribute_240, t1.attribute_241 = t2.attribute_241, t1.attribute_242 = t2.attribute_242, t1.attribute_243 = t2.attribute_243, t1.attribute_244 = t2.attribute_244, t1.attribute_245 = t2.attribute_245, t1.attribute_246 = t2.attribute_246, t1.attribute_247 = t2.attribute_247, t1.attribute_248 = t2.attribute_248, t1.attribute_249 = t2.attribute_249, t1.attribute_250 = t2.attribute_250, t1.attribute_251 = t2.attribute_251, t1.attribute_252 = t2.attribute_252, t1.attribute_253 = t2.attribute_253, t1.attribute_254 = t2.attribute_254, t1.attribute_255 = t2.attribute_255, t1.gmt_date_created = t2.gmt_date_created, t1.id_employee = t2.id_employee where t1.id_activity = t2.id_activity"

							cursor.execute(sql)

							########################################################
							# Step 100f: Update tbl_sailor empty reservation count #
							########################################################
							sql = "update tbl_sailor_tmp set empty_reservation_count = capacity_in_sailors - sailor_reservation_count"

							cursor.execute(sql)

							##############################################################################################
							# Step 100g:  Populate lists with date and times used to eliminate sailor calendar conflicts #
							##############################################################################################

							# get from tbl_sailor_calendar where dates and times are commited
							sql  = "select id_activity_schedule, local_start_date, local_start_time, local_end_time from tbl_sailor_calendar where id_sailor = " + Sailor_Id

							cursor.execute(sql)

							row = cursor.fetchone()

							while row is not None:					# loop while there remains rows to process

								print('\n')
								print(row)

								Start_Date = row[1]
								Start_Date = Start_Date.strftime('%Y-%m-%d')

								Local_Start_Time = row[2]
								Local_Start_Time = (datetime.datetime.min + Local_Start_Time).time()
								Local_Start_Time = Local_Start_Time.strftime('%H:%M:%S')

								Local_End_Time = row[3]
								Local_End_Time = (datetime.datetime.min + Local_End_Time).time()
								Local_End_Time = Local_End_Time.strftime('%H:%M:%S')




								# delete from tbl_sailor_tmp where conflict exists
								sql = "delete from tbl_sailor_tmp where local_date = '" + Start_Date + "' and ((local_start_time >= '" + Local_Start_Time + "' and local_start_time <= '" + Local_End_Time + "') or (local_end_time >= '" + Local_Start_Time + "' and local_end_time <= '" + Local_End_Time + "'))" 

								cursor.execute(sql)

								row = cursor.fetchone()				# get next row



							###############################################################################################################################
							# Step 100h:  Eliminate from tbl_sailor_tmp where the activity has no remaining capacity or sailor isn't in correct age range #
							###############################################################################################################################

							# get sailor's age
							sql = "select age from tbl_sailor where id_sailor = " + Sailor_Id
							cursor.execute(sql)
							row = cursor.fetchone()
							Age = row[0]


							sql = "delete from tbl_sailor_tmp where (capacity_in_sailors > 0 and empty_reservation_count = 0) or (age_low > " + str(Age) + " or age_high < " + str(Age) + ")"


							cursor.execute(sql)



							#########################################################################################################
							# Step 100i:  Add offer history data to tbl_sailor_tmp by joining on id_sailor and id_activity_schedule #
							#########################################################################################################

							sql = "update tbl_sailor_tmp as t1, tbl_offer_history as t2 set t1.activity_yes_count = t2.activity_yes_count, t1.activity_maybe_count = t2.activity_maybe_count, t1.activity_no_count = t2.activity_no_count, t1.activity_schedule_yes_count = t2.activity_schedule_yes_count, t1.activity_schedule_maybe_count = t2.activity_schedule_maybe_count, t1.activity_schedule_no_count = t2.activity_schedule_no_count where t1.id_activity_schedule = t2.id_activity_schedule and t2.id_sailor = " + Sailor_Id


							cursor.execute(sql)


							#################################################################
							# Step 100j:  Get sailor's profile attributes and store in list #
							#################################################################

							sql = "select id_sailor, Attribute_1,Attribute_2,Attribute_3,Attribute_4,Attribute_5,Attribute_6,Attribute_7,Attribute_8,Attribute_9,Attribute_10,Attribute_11,Attribute_12,Attribute_13,Attribute_14,Attribute_15,Attribute_16,Attribute_17,Attribute_18,Attribute_19,Attribute_20,Attribute_21,Attribute_22,Attribute_23,Attribute_24,Attribute_25,Attribute_26,Attribute_27,Attribute_28,Attribute_29,Attribute_30,Attribute_31,Attribute_32,Attribute_33,Attribute_34,Attribute_35,Attribute_36,Attribute_37,Attribute_38,Attribute_39,Attribute_40,Attribute_41,Attribute_42,Attribute_43,Attribute_44,Attribute_45,Attribute_46,Attribute_47,Attribute_48,Attribute_49,Attribute_50,Attribute_51,Attribute_52,Attribute_53,Attribute_54,Attribute_55,Attribute_56,Attribute_57,Attribute_58,Attribute_59,Attribute_60,Attribute_61,Attribute_62,Attribute_63,Attribute_64,Attribute_65,Attribute_66,Attribute_67,Attribute_68,Attribute_69,Attribute_70,Attribute_71,Attribute_72,Attribute_73,Attribute_74,Attribute_75,Attribute_76,Attribute_77,Attribute_78,Attribute_79,Attribute_80,Attribute_81,Attribute_82,Attribute_83,Attribute_84,Attribute_85,Attribute_86,Attribute_87,Attribute_88,Attribute_89,Attribute_90,Attribute_91,Attribute_92,Attribute_93,Attribute_94,Attribute_95,Attribute_96,Attribute_97,Attribute_98,Attribute_99,Attribute_100,Attribute_101,Attribute_102,Attribute_103,Attribute_104,Attribute_105,Attribute_106,Attribute_107,Attribute_108,Attribute_109,Attribute_110,Attribute_111,Attribute_112,Attribute_113,Attribute_114,Attribute_115,Attribute_116,Attribute_117,Attribute_118,Attribute_119,Attribute_120,Attribute_121,Attribute_122,Attribute_123,Attribute_124,Attribute_125,Attribute_126,Attribute_127,Attribute_128,Attribute_129,Attribute_130,Attribute_131,Attribute_132,Attribute_133,Attribute_134,Attribute_135,Attribute_136,Attribute_137,Attribute_138,Attribute_139,Attribute_140,Attribute_141,Attribute_142,Attribute_143,Attribute_144,Attribute_145,Attribute_146,Attribute_147,Attribute_148,Attribute_149,Attribute_150,Attribute_151,Attribute_152,Attribute_153,Attribute_154,Attribute_155,Attribute_156,Attribute_157,Attribute_158,Attribute_159,Attribute_160,Attribute_161,Attribute_162,Attribute_163,Attribute_164,Attribute_165,Attribute_166,Attribute_167,Attribute_168,Attribute_169,Attribute_170,Attribute_171,Attribute_172,Attribute_173,Attribute_174,Attribute_175,Attribute_176,Attribute_177,Attribute_178,Attribute_179,Attribute_180,Attribute_181,Attribute_182,Attribute_183,Attribute_184,Attribute_185,Attribute_186,Attribute_187,Attribute_188,Attribute_189,Attribute_190,Attribute_191,Attribute_192,Attribute_193,Attribute_194,Attribute_195,Attribute_196,Attribute_197,Attribute_198,Attribute_199,Attribute_200,Attribute_201,Attribute_202,Attribute_203,Attribute_204,Attribute_205,Attribute_206,Attribute_207,Attribute_208,Attribute_209,Attribute_210,Attribute_211,Attribute_212,Attribute_213,Attribute_214,Attribute_215,Attribute_216,Attribute_217,Attribute_218,Attribute_219,Attribute_220,Attribute_221,Attribute_222,Attribute_223,Attribute_224,Attribute_225,Attribute_226,Attribute_227,Attribute_228,Attribute_229,Attribute_230,Attribute_231,Attribute_232,Attribute_233,Attribute_234,Attribute_235,Attribute_236,Attribute_237,Attribute_238,Attribute_239,Attribute_240,Attribute_241,Attribute_242,Attribute_243,Attribute_244,Attribute_245,Attribute_246,Attribute_247,Attribute_248,Attribute_249,Attribute_250,Attribute_251,Attribute_252,Attribute_253,Attribute_254,Attribute_255 from tbl_sailor where id_sailor = " + str(Sailor_Id)


							cursor.execute(sql)

							Sailor_Attributes = cursor.fetchone()



							#########################################################
							# Step 100k:  Get activity attributes and store in list #
							#########################################################

							# verification code - toss later
							sql = "select count(*) from tbl_sailor_tmp"
							cursor.execute(sql)
							Record_Count = cursor.fetchone()





							sql = "select id_sailor_tmp, Attribute_1,Attribute_2,Attribute_3,Attribute_4,Attribute_5,Attribute_6,Attribute_7,Attribute_8,Attribute_9,Attribute_10,Attribute_11,Attribute_12,Attribute_13,Attribute_14,Attribute_15,Attribute_16,Attribute_17,Attribute_18,Attribute_19,Attribute_20,Attribute_21,Attribute_22,Attribute_23,Attribute_24,Attribute_25,Attribute_26,Attribute_27,Attribute_28,Attribute_29,Attribute_30,Attribute_31,Attribute_32,Attribute_33,Attribute_34,Attribute_35,Attribute_36,Attribute_37,Attribute_38,Attribute_39,Attribute_40,Attribute_41,Attribute_42,Attribute_43,Attribute_44,Attribute_45,Attribute_46,Attribute_47,Attribute_48,Attribute_49,Attribute_50,Attribute_51,Attribute_52,Attribute_53,Attribute_54,Attribute_55,Attribute_56,Attribute_57,Attribute_58,Attribute_59,Attribute_60,Attribute_61,Attribute_62,Attribute_63,Attribute_64,Attribute_65,Attribute_66,Attribute_67,Attribute_68,Attribute_69,Attribute_70,Attribute_71,Attribute_72,Attribute_73,Attribute_74,Attribute_75,Attribute_76,Attribute_77,Attribute_78,Attribute_79,Attribute_80,Attribute_81,Attribute_82,Attribute_83,Attribute_84,Attribute_85,Attribute_86,Attribute_87,Attribute_88,Attribute_89,Attribute_90,Attribute_91,Attribute_92,Attribute_93,Attribute_94,Attribute_95,Attribute_96,Attribute_97,Attribute_98,Attribute_99,Attribute_100,Attribute_101,Attribute_102,Attribute_103,Attribute_104,Attribute_105,Attribute_106,Attribute_107,Attribute_108,Attribute_109,Attribute_110,Attribute_111,Attribute_112,Attribute_113,Attribute_114,Attribute_115,Attribute_116,Attribute_117,Attribute_118,Attribute_119,Attribute_120,Attribute_121,Attribute_122,Attribute_123,Attribute_124,Attribute_125,Attribute_126,Attribute_127,Attribute_128,Attribute_129,Attribute_130,Attribute_131,Attribute_132,Attribute_133,Attribute_134,Attribute_135,Attribute_136,Attribute_137,Attribute_138,Attribute_139,Attribute_140,Attribute_141,Attribute_142,Attribute_143,Attribute_144,Attribute_145,Attribute_146,Attribute_147,Attribute_148,Attribute_149,Attribute_150,Attribute_151,Attribute_152,Attribute_153,Attribute_154,Attribute_155,Attribute_156,Attribute_157,Attribute_158,Attribute_159,Attribute_160,Attribute_161,Attribute_162,Attribute_163,Attribute_164,Attribute_165,Attribute_166,Attribute_167,Attribute_168,Attribute_169,Attribute_170,Attribute_171,Attribute_172,Attribute_173,Attribute_174,Attribute_175,Attribute_176,Attribute_177,Attribute_178,Attribute_179,Attribute_180,Attribute_181,Attribute_182,Attribute_183,Attribute_184,Attribute_185,Attribute_186,Attribute_187,Attribute_188,Attribute_189,Attribute_190,Attribute_191,Attribute_192,Attribute_193,Attribute_194,Attribute_195,Attribute_196,Attribute_197,Attribute_198,Attribute_199,Attribute_200,Attribute_201,Attribute_202,Attribute_203,Attribute_204,Attribute_205,Attribute_206,Attribute_207,Attribute_208,Attribute_209,Attribute_210,Attribute_211,Attribute_212,Attribute_213,Attribute_214,Attribute_215,Attribute_216,Attribute_217,Attribute_218,Attribute_219,Attribute_220,Attribute_221,Attribute_222,Attribute_223,Attribute_224,Attribute_225,Attribute_226,Attribute_227,Attribute_228,Attribute_229,Attribute_230,Attribute_231,Attribute_232,Attribute_233,Attribute_234,Attribute_235,Attribute_236,Attribute_237,Attribute_238,Attribute_239,Attribute_240,Attribute_241,Attribute_242,Attribute_243,Attribute_244,Attribute_245,Attribute_246,Attribute_247,Attribute_248,Attribute_249,Attribute_250,Attribute_251,Attribute_252,Attribute_253,Attribute_254,Attribute_255 from tbl_sailor_tmp"					

							cursor.execute(sql)

							Activity_Attributes = cursor.fetchone()



							Record_Count = 0;					# initialize and count records
							while Activity_Attributes is not None:			# loop while there remains rows to process



								Raw_Profile_Score = 0				# initialize the raw profile score

								for i in range(1, 255):

									if Sailor_Attributes[i] == 1 and Activity_Attributes[i] == 1:
										Raw_Profile_Score = Raw_Profile_Score + 1

								Raw_Profile_Score_List.insert(Record_Count,Raw_Profile_Score)

								# print('\n Here is the Raw Profile_Score:  ', Raw_Profile_Score_List[iCount])


								Index_Sailor_Tmp_List.insert(Record_Count,Activity_Attributes[0])

								Record_Count = Record_Count + 1			# count record						


								Activity_Attributes = cursor.fetchone()		# get next row





							#########################################################
							# Step 100l:  Store raw_profile score in tbl_sailor_tmp #
							#########################################################


							for i in range(0,Record_Count):

								sql = "update tbl_sailor_tmp set profile_score = " + str(Raw_Profile_Score_List[i]) + " where id_sailor_tmp = " + str(Index_Sailor_Tmp_List[i])

								cursor.execute(sql)


							sql = "select max(profile_score) from tbl_sailor_tmp"
							cursor.execute(sql)


							#########################################################
							# Step 100m:  Store raw_profile score in tbl_sailor_tmp #
							#########################################################

							Max_Raw_Profile_Score = cursor.fetchone()



							sql = "update tbl_sailor_tmp set profile_score = profile_score / " + str(Max_Raw_Profile_Score[0])

							cursor.execute(sql)


							#####################################################
							# Step 100n:  Order tbl_sailor_tmp and readin table #
							#####################################################

							if Processing_Mode == '1':

								sql = "select * from tbl_sailor_tmp order by profile_score desc"

								cursor.execute(sql)

								rows = cursor.fetchall()


								###################################################
								# Step 100p:  Make an output file and then output #
								###################################################					



								Current_Date = datetime.datetime.now().date()

								strDate = str(Current_Date)



								Output_Filepath = "e:/projects/sailors/output/recommender_engine/" + str(Sailor_Id) + "_" + strDate + "_" + Start_Date + "_" + End_Date + ".csv"



								with open(Output_Filepath,"w") as out:
									csv_out = csv.writer(out)
									for row in rows:
										csv_out.writerow(row)



								# out.close()


								# del Raw_Profile_Score_List[:]				# clear list
								# del Index_Sailor_Tmp_List[:]				# clear list


								# print('\nDone!')






						################################################
						# Step 100q:  Process_Mode 2 - economic scoring #
						################################################
						if Processing_Mode == '2':
							print('\n\n\n Mode 2')

							Mode_Two.run(cursor)						


							sql = "select * from tbl_sailor_tmp order by profile_score desc"

							cursor.execute(sql)

							rows = cursor.fetchall()


							###################################################
							# Step 100p:  Make an output file and then output #
							###################################################					



							Current_Date = datetime.datetime.now().date()

							strDate = str(Current_Date)



							Output_Filepath = "e:/projects/sailors/output/recommender_engine/" + str(Sailor_Id) + "_" + strDate + "_" + Start_Date + "_" + End_Date + ".csv"



							with open(Output_Filepath,"w") as out:
								csv_out = csv.writer(out)
								for row in rows:
									csv_out.writerow(row)



						out.close()


						del Raw_Profile_Score_List[:]				# clear list
						del Index_Sailor_Tmp_List[:]				# clear list


						print('\nDone!')

					


							
							
							





































			
			
			
			
			
			
			
			


		

		count = count + 1
		if count > 2:
			break

except Error as e:				# capture error and print for analysis
	print (e)
	
finally:					# close out connector and cursor
	cursor.close()
	conn.close()







































