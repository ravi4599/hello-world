# This is a python module designed to read the Access.txt file for credentials.  

# Author:  John Abe
# Date:  September 5, 2017

###################################################################################
# Step 1:  Receive the Application directory filepath and make path to Access.txt #
# Step 2:  Open channel to read                                                   #
# Step 3:  Parse text from file and assign to variables  	                  #        
# Step 4:  Assign to list and return				                  #
###################################################################################

def read(Main_Filepath):

	# Step 1:  Open of channel to read
	Application_Filepath = Main_Filepath + "Application/Access_Python.txt"
	with open(Application_Filepath,"r") as f:
	
		# Step 2:  Access.txt file 
		content = f.readlines()

	
	#Step 3:  Parse text from file and assign to variables
	str = content[0].split("= ",1)
	Host = str[1]						# extract localhost
	Host = Host.strip('\n')					# get rid of newline character
	
	str = content[1].split("= ",1)
	User = str[1]						# extract user name
	User = User.strip('\n')					# get rid of newline character
	
	str = content[2].split("= ",1)
	Pass = str[1]						# extract pass
	
	
	
	
	# Step 4:  Assign to list and return  	
	Data_List = [Host, User, Pass]
	
	f.close()

	return Data_List