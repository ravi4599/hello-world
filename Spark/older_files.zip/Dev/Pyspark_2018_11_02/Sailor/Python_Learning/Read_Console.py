# This is a module to read the console input.  The module waits for a console input, then returns the value of the console

# Author:  John Abe
# Date:  September 6th, 2017

###########################################################################################################
# Step 1:  Receive an input from the console                              				  #
# Step 2:  Parse input, using comma as a field separator                  				  #
# Step 3:  Use 'z' to qualify the console input, if not z, ignore input and loop, otherwise, break loop   #        
# Step 4:  return parsed console input				          			          #
###########################################################################################################

def read():
	# print("waiting for an input\n")			# this is a prompt that should be removed when piping via another application
	
	while True:
	

		# Step 1:  Receive an input from the console 
		console_input = input()				# read from the console
	
		# Step 2:  Parse input, using comma as a field separator
		parsed_console_input = console_input.split(",")	# parse the input by commas
		
		# Step 3:  Use 'z' to qualify the console input, if not z, ignore input and loop, otherwise, break loop
		if parsed_console_input[0] == 'z':
			break
	# Step 4:  return parsed console input
	return parsed_console_input			# return the console input