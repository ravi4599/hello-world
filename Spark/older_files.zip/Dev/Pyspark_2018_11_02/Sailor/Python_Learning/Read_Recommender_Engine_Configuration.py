# This is a python module designed to read the Recommender_Engine_Configuration.txt file.  

# Author:  John Abe
# Date:  September 5, 2017

##################################################################
# Step 1:  Receive the Recommender_Engine_Configuration_Filepath #
# Step 2:  Open channel to read                                  #
# Step 3:  Parse text from file and assign to variables  	 #        
# Step 4:  Assign to list and return				 #
##################################################################

def read(Recommender_Engine_Configuration_Filepath):

	# Step 1:  Open of channel to read
	with open(Recommender_Engine_Configuration_Filepath,"r") as f:
	
		# Step 2:  Read Recommender_Engine_Configuration.txt file 
		content = f.readlines()

	
	#Step 3:  Parse text from file and assign to variables
	str = content[0].split("= ",1)
	Create_Database_Specifications = str[1]			# extract Create_Database_Specifications
	
	str = content[1].split("= ",1)
	Import_Data_Files = str[1]				# extract Import_Data_Files
	
	
	str = content[2].split("= ",1)
	Batch_Filepath = str[1]					# extract Batch_Filepath
	
	# Step 4:  Assign to list and return  	
	Data_List = [Create_Database_Specifications, Import_Data_Files, Batch_Filepath]
	
	f.close()

	return Data_List