# This module imports the Offer History data into the database.  



# Author:  John Abe
# Date:  September 11, 2017



##########################################################################
#									 #
# Step 1:  Import Libraries  						 #
# Step 2:  Read the recommender engine startup file - get directory etc. #
# Step 3:  Get the database credentials 			         #  
# Step 4:  Establish database access    				 #
# Step 5:  Read Offer_History_Data_Python file    			 #
# Step 6:  Truncate tbl_offer_history 					 #
# Step 7:  Load data file directly into database    			 #
#									 #
##########################################################################




#############################
#                           #
# Step 1:  Import Libraries #
#                           #
#############################
import mysql.connector
import Access_DB_Python
import Read_Startup_Recommender_Engine
import Read_Recommender_Engine_Configuration







#####################
#		    #
# Declare Variables #
#		    #
#####################
Data_Filepath = ""				# filepath to data for import
List_Length = 0					# length of the list containing activity data after reading
User = ""					# user to database
Pass = ""					# password of user to database
Host = ""					# location of the MySQL database as an ip address



###########################################################################
#                           						  #
# Step 2:   Read the recommender engine startup file - get directory etc. #
#                           						  #
###########################################################################

Content = Read_Startup_Recommender_Engine.read()
Database_Name = Content[0]			# extract database name from list
Main_Filepath = Content[1]			# extract the main filepath from list
Recommender_Engine_Configuration_Filepath = Content[2] # extract the main filepath from list 

# verify code - eventually toss
print(Database_Name)
print(Main_Filepath)
print(Recommender_Engine_Configuration_Filepath)




#########################################
#                           		#
# Step 3:  Get the database credentials #
#                           		#
#########################################

Content = Access_DB_Python.read(Main_Filepath)
Host = Content[0]
User = Content[1]
Pass = Content[2]

# verify code - eventually toss
# print(Host)
# print(User)
# print(Pass)



try:		

	#########################################
	#                           		#
	# Step 4:  Establish database access    #
	#                           		#
	#########################################

	conn = mysql.connector.connect(

		user=User,

		password=Pass,

		host=Host,

		database=Database_Name

		)

	cursor = conn.cursor()
	
	
	###################################################
	#                           	    	          #
	# Step 5:  Read Offer_History_Data_Python file    #
	#                           	                  #
	###################################################	
	
	Data_Filepath = Main_Filepath + "Input/Recommender_Engine_Database_Input/Offer_History_Data_Python.csv"
	with open(Data_Filepath,"r") as f:
			
		content = f.readlines()
	
	List_Length = len(content)			# get the length of list
	
	print("Data_Filepath:  ", Data_Filepath)	# show the filepath
	print("Record count of the file is ", List_Length)
	

	
	if List_Length > 0:				# if not true, then list is empty and no process should be done
	
		#########################################
		#                           	        #
		# Step 6:  Truncate tbl_offer_history   #
		#                           	        #
		#########################################	
	
		sql = "truncate table tbl_offer_history"
		print('\n here is the sql:  ',sql)
		cursor.execute(sql)
	
		
	
		####################################################
		#                           	    		   #
		# Step 7:  Load data file directly into database   #
		#                           	    		   #
		####################################################
		
		sql = "Load data local infile '" + Data_Filepath  + "' into table tbl_offer_history"  + " fields terminated by ',' " + "optionally enclosed by '\"' " + " lines terminated by '\\r\\n' " + " ignore 1 lines"
					
		print('\n here is the sql:  ',sql)
		cursor.execute(sql)
	
	
	else:
	
		print("The file ",Data_Filepath," appears to be missing")
	



except Error as e:				# capture error and print for analysis
	print (e)
	
finally:					# close out connector and cursor
	cursor.close()
	conn.close()
	