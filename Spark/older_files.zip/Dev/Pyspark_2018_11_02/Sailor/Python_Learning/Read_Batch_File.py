

# The following module reads a batch file, located at Batch_Filepath, into Batch_Content_List and returned.

# Author:  John Abe
# Date:  9/7/2017




################################################################################################
# Step 1:  Receive the Application directory filepath and make path to Batch_Sailor_Python.csv #
# Step 2:  Open channel to read                                                   	       #
# Step 3:  Parse text from file and assign to variables  	                               #        
# Step 4:  Assign to list and return				                               #
################################################################################################

def read(Main_Filepath):

	# Step 1:  Open of channel to read
	Batch_Filepath = Main_Filepath + "Input/Recommender_Engine_Input/Batch_Sailor_Python.csv"
	with open(Batch_Filepath,"r") as f:
	
		
		content = f.readlines()
		
		
		
		
	
	
	
	
	f.close()

	return content