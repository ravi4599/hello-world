# This module receives a sailor id and retrieves the sailor profile from a MySQL database.
# The use of MySQL simplifies the design, but will be replace by a query to the cloud

# Author:  John Abe
# Date:  9/8/2017



def get(cursor, Sailor_Id):

	cursor.execute("select * from tbl_sailor where id_sailor = " + Sailor_Id)
	data = cursor.fetchall()
	return data