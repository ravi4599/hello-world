# This is a module computes the geolocation score for an activity.  
# The module is called by the Recommender_Engine_V1

# Author:  John Abe
# Date:  September 25th, 2017


def run(cursor, Kiosk_Station):

	print('\n\n\nInside Mode 3')
	print('kiosk station = ', Kiosk_Station)
	#####################
	# declare variables #
	#####################
	sql = ""					# sequel query
	x_position = ""					# x position of the kiosk
	y_position = ""					# y position of the kiosk
	z_position = ""					# z position of the kiosk
	Max_Geo_Score = ""				# 
	
	
	
	
	##################################
	# retrieve position of the kiosk #
	##################################
	print('kiosk station = ', Kiosk_Station)
	sql = "select x_position, y_position, z_position from tbl_kiosk_position where id_station = " + Kiosk_Station;
	
	print('\nkiosk query')
	print(sql)
	
	cursor.execute(sql)
	
	rows = cursor.fetchone()
	
	x_position = str(rows[0]);			# convert query to a string
	
	y_position = str(rows[1]);			# convert query to a string
	
	z_position = str(rows[2]);			# convert query to a string
	
	
	###############################
	# compute Euclidean Distance  #
	###############################	
	sql = "update tbl_sailor_tmp set geolocation_score = (" + x_position + " - geolocation_x) * (" + x_position + " - geolocation_x) + (" + y_position + " - geolocation_y) * (" + y_position  + " - geolocation_y) + (" + z_position + " - geolocation_z) * (" + z_position  + " - geolocation_z)"
	
	print('\nhere is the Euclidean Square query')
	print(sql)
	
	cursor.execute(sql)
	
	
	sql = "update tbl_sailor_tmp set geolocation_score = sqrt(geolocation_score)"
	
	cursor.execute(sql)
	


	
	######################
	# find max distance  #
	######################
	sql = "select max(geolocation_score) from tbl_sailor_tmp"
	
	cursor.execute(sql)
	
	row = cursor.fetchone()
	
	Max_Geo_Score = str(row[0])
	
	#######################
	# normalize distance  #
	#######################	
	
	
	sql = "update tbl_sailor_tmp set geolocation_score = geolocation_score / " + Max_Geo_Score
	
	cursor.execute(sql)
	
	
	return