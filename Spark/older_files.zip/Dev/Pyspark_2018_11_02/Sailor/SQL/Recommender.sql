use sailor_recommender_db_1;			/* java */
use sailor_recommender_db_2;			/* python */
show tables;
show databases;

describe tbl_activity;
describe tbl_sailor;
describe tbl_activity_schedule;
describe tbl_activity_category;
describe tbl_activity_level;
describe tbl_sailor_tmp;
describe tbl_offer_history;
describe tbl_economic_optimization;
describe tbl_kiosk_position;
describe tbl_booking;
describe tbl_tmp_activity;
describe tbl_sailor;
describe tbl_sailor_calendar;



select * from tbl_activity;
select * from tbl_activity_category;
select * from tbl_activity_level;
select * from tbl_activity_pricing;
select * from tbl_activity_schedule limit 1100;
select * from tbl_sailor_calendar;
select * from tbl_sailor_tmp limit 10000;
select * from tbl_sailor;
select * from tbl_offer_history;
select * from tbl_economic_optimization limit 1000;
select * from tbl_kiosk_position;
select * from tbl_booking;
select * from tbl_tmp_activity;
select * from tbl_tmp_possible_affinity limit 1000;
select * from tbl_tmp_new_possible_affinity;
select * from tbl_tmp_affinity;




select * from tbl_sailor_tmp;
select count(*) from tbl_sailor_tmp;
truncate tbl_sailor_tmp;

select * from tbl_sailor_tmp order by profile_score asc;



select * from tbl_sailor_tmp;
select * from tbl_activity;
truncate tbl_activity;


drop table tbl_sailor_calendar;

create table tbl_sailor_calendar(id_sailor int, id_activity_schedule int, local_start_date date, local_start_time time, local_end_time time);


select * from tbl_sailor_calendar;


Load data local infile 'e:/Projects/Sailors/Input/Recommender_Engine_Database_Input/Sailor_Calendar_Data_Python.csv' 
into table tbl_sailor_calendar fields terminated by ',' optionally enclosed by '"'  lines terminated by '\r\n'  ignore 1 lines;


drop table tbl_test;

create table tbl_test(id_sailor varchar(10), id_activity_schedule varchar(10), local_start_date varchar(15), local_start_time varchar(15), local_end_time varchar(15));
create table tbl_test(id_sailor int);


insert into tbl_test (id_sailor) values ('cat');

select * from tbl_test;

describe tbl_test;

insert into tbl_test values('10');


show processlist;

kill 103;



update tbl_sailor_tmp set profile_score = 0 where id_sailor_tmp = 2;


show variables like "max_connections";
set global max_connections = 50;













