

use sailor_db_1;
use sailor_recommender_db_1;
show tables;

select * from tbl_attribute_definition limit 1000;
select * from tbl_master limit 1000;
select * from tbl_normalized_numerical limit 1000;
select * from tbl_staging limit 1000;
select * from tbl_cluster limit 1000;
select * from tbl_attribute_influence limit 100000;
select * from tbl_distinct_attribute_values;
select * from tbl_centroid_history;
describe tbl_normalized_numerical;




/* recommender engine */
select * from tbl_activity;
select * from tbl_activity_level;
select * from tbl_activity_pricing;
select * from tbl_activity_schedule;
select * from tbl_activity_economics;
select * from tbl_country_names;
select * from tbl_employee;
select * from tbl_exchange_rate;
select * from tbl_position;


describe tbl_activity;


drop table tmp_master;
select * from tmp_master;
create table tmp_master like tbl_master;
insert into tmp_master select * from tbl_master;
alter table tmp_master add column assigned_group int;
update tmp_master, tbl_cluster set tmp_master.assigned_group = tbl_cluster.cluster where tmp_master.id = tbl_cluster.id;

select 281_travel_cruises, assigned_group from tmp_master;
select count(*) from tmp_master where 281_travel_cruises = 1; /* 24802 */
select count(*) from tmp_master where 281_travel_cruises = 1 && assigned_group = 2; /* 20537 */
select count(*) from tmp_master where 281_travel_cruises is null && assigned_group = 2; /* 9035 */
select count(*) from tmp_master where assigned_group = 2; /* 29572 */

select * from tbl_distinct_attribute_values where attribute_name = '4_age';
























