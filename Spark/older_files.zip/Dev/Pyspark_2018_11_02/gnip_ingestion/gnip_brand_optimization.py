##  spark-submit --name GNIP_Optimization --conf spark.executor.memoryOverhead=10240 --num-executors 20 --driver-memory 4G --executor-memory 8G --executor-cores 4 --master yarn --deploy-mode cluster /home/ec2-user/py_scripts/gnip_optimization/gnip_optimization.py

from pyspark.sql import SparkSession,SQLContext
import pyspark.sql.functions as F

import traceback, logging


def initSparkSession(appName):
    """ Initializes the SparkSession
    :param appName  : name for the SparkSession
    :return         : initialized SparkSession
    """

    try:
        spark = SparkSession \
            .builder \
            .appName(appName) \
            .enableHiveSupport() \
            .getOrCreate()
        # spark.conf.set("spark.sql.shuffle.partitions", "50")

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 6: Error initializing SparkSession. Please review SparkSession configurations.")

    return spark


def get_logger():
    """ Create the logger which will be used for this script

    :return : configured logger
    """

    try:
        log = logging.getLogger('Spark')
        _h = logging.StreamHandler()
        _h.setFormatter(logging.Formatter("%(levelname)s  %(msg)s"))
        log.addHandler(_h)
        log.setLevel(logging.DEBUG)
        log.info("module imported and logger initialized")

    except Exception as e:
        traceback.print_exc()
        raise TypeError(
            "Error Code 7: Error initializing Logger. Please review Logger.")

    return log


def loadProcessDriver(spark, log, db_name):
    """
    Load data relevant to the current script from the Process Driver Table

    :param spark    : current SparkSession
    :param log      : current logger
    :param db_name  : name of the database which contains the data relevant to the current script
    :return         : dictionary of data relevant to the current script in form of {VariableName:Value}
    """

    log.info("Reading data from Processdriver")
    query_string = "select VariableName,Value from {} where processName='GNIP_Optimization'".format(db_name)
    log.info(query_string)
    data_dict = {}
    try:
        raw_data = spark.sql(query_string).collect()
        data = map(lambda x: (x[0], x[1]), raw_data)
        data_dict = dict(data)
    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 1: Please verify process driver query execution.")
    return data_dict


def initProcess(spark, processController, log):
    """
    Fetches the relevant parameters from the processController dictionary

    :param spark                : current SparkSession
    :param log                  : current logger
    :param processController    : dictionary of relevant parameters
    :return                     : Spark Dataframe
    """

    log.info("Fetch Parameters from Processor Driver")
    try:
        max_date_query = processController.get("max_date_query")
        gnip_data_query = processController.get("gnip_data_query")
        initial_cap = float(processController.get("initial_cap"))
        max_allowed_tweets = float(processController.get("max_allowed_tweets"))
        incr = float(processController.get("incr"))

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 3: Please verify driver table connection and entries.")

    return process(log, spark, max_date_query, gnip_data_query, initial_cap, max_allowed_tweets, incr)


def process(log, spark, max_date_query, gnip_data_query, initial_cap, max_allowed_tweets, incr):
    """
    Prepares data and gets synonyms

    :param log                  : current logger
    :param spark                : current SparkSession
    :param max_date_query       : query to get max date
    :param gnip_data_query      : query to get gnip data
    :param initial_cap          : initial cap
    :param max_allowed_tweets   : max allowed number of tweets
    :param incr                 : increment

    :return                     : spark dataframe
    """
    try:
        log.info("Query Max Date")
        maxdate = spark.sql(max_date_query)
        maxdate.registerTempTable("maxjobdate")


        log.info("Query GNIP Data")
        gnip_data = spark.sql(gnip_data_query)
        sample_sum = gnip_data.select("quotation").agg({"quotation": "sum"}).collect().pop()['sum(quotation)']

    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 3: Please verify connection to Hive tables.")

    try:
        ## Someone more familiar with this script, please fill in after 'Then..."
        log.info("If Sample Sum, {}, is greater than Max Allowed Tweets, {}, Then...".format(sample_sum, max_allowed_tweets))
        if sample_sum > max_allowed_tweets:
            while sample_sum > max_allowed_tweets:
                log.info("Sample Sum IS greater than Max Allowed Tweets")
                df2 = gnip_data\
                    .select(["uuid", "brandname", "quotation", "jobcreateddate"])\
                    .withColumn("sample_per",
                                F.when(F.col('quotation') > initial_cap,
                                       (F.round((initial_cap / F.col('quotation')) * 100, 0)))
                                .otherwise(100))
                df2.show()

                df3 = df2.select(["uuid", "brandname", "quotation", "sample_per", "jobcreateddate"])\
                    .withColumn("sample_size", F.col('sample_per') * F.col('quotation') / 100)
                df3.show()

                ## Why are these not used?
                sample_sum = df3.select("sample_size").agg({"sample_size": "sum"}).collect().pop()['sum(sample_size)']
                initial_cap = initial_cap - incr

                log.info("Sample Sum: {}".format(sample_sum))
                log.info("Initial Cap: {}".format(initial_cap))

        else:
            log.info("Sample Sum is NOT greater than Max Allowed Tweets")
            df3 = gnip_data\
                    .select(["uuid", "brandname", "quotation", "jobcreateddate"]).\
					withColumn("sample_per", F.lit(100))\
                .withColumn("sample_size", F.col('sample_per') * F.col('quotation') / 100)


    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 3: Please verify that the data is proper.")


    log.info("Returning Dataframe...")
    return df3


def store(log, spark, processController, data):
    """
    Saves the input Dataframe to the location(s) defined in the process driver table

    :param processController    : dictionary of relevant parameters
    :param log                  : current logger
    :param data                 : Spark Dataframe
    :return                     : N/A
    """

    try:
        path_gnip_optimization = processController.get("path_gnip_optimization")
        drop_table_query = processController.get("drop_table_query")
        create_table_query = processController.get("create_table_query2")
        check_tbl_exists_query = processController.get("check_table_query")
        path_gnip_optimization_bk = processController.get("path_gnip_optimization_bk")
        distinct_query = processController.get("distinct_query")
    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 3: Please verify driver table connection and entries.")


    try:
        log.info("Save the results in hive as %s" % path_gnip_optimization)
        log.info("Save the results in s3 bk_up as %s" % path_gnip_optimization_bk)
        data.write.mode("append").format("parquet").save(path_gnip_optimization_bk)
        dfappend = spark.read.parquet(path_gnip_optimization_bk)
        dfappend.registerTempTable("tempappend")
        dfdistinct = spark.sql(distinct_query)
        dfdistinct.write.mode("overwrite").format("parquet").save(path_gnip_optimization)
        spark.sql(drop_table_query)
        spark.sql(create_table_query.format(path_gnip_optimization))

#        dfappend.show() 
#        spark.sql(create_table_query.format(path_gnip_optimization))
#        data.registerTempTable("temp") 
#        data.show()
#        spark.sql("insert into bd_db.gnip_brand_optimized_quotation select t1.uuid,t1.brandname,t1.quotation,t1.jobcreateddate,t1.sample_per,t1.sample_size from temp t1 group by t1.uuid,t1.brandname,t1.quotation,t1.jobcreateddate,t1.sample_per,t1.sample_size ")
#        data.write.mode("append").format("parquet").save(path_gnip_optimization)
#        spark.sql("insert into bd_db.gnip_brand_optimized_quotation select t1.uuid,t1.brandname,t1.quotation,t1.jobcreateddate,t1.sample_per,t1.sample_size from temp t1 where not exists(select uuid from bd_db.gnip_brand_optimized_quotation t2  where t1.uuid = t2.uuid)")
#        log.info(spark.sql("select * from bd_db.gnip_brand_optimized_quotation").count())
#        if "gnip_brand_optimized_quotation" in SQLContext.tableNames(u"bd_db"): 
#       #spark.sql("insert into table bd_db.gnip_brand_optimized_quotation select * from temp")
#        else:
#        spark.sql(create_table_query.format(path_gnip_optimization))
#        data.write.mode("append").insertInto("bd_db.gnip_brand_optimized_quotation")
#        gnip_data = spark.sql(check_tbl_exists_query)
#        if gnip_data.count()>0:
#          gnip_data.show()
#           log.info("append in the table...")
#           data.write.mode("append").insertInto("bd_db.gnip_brand_optimized_quotation")
#          spark.sql("insert into table vv_db.gnip_brand_optimized_quotation select * from temp")
#        else:
#           log.info("create the table....")
#           spark.sql(create_table_query.format(path_gnip_optimization))
#	log.info("Creating Table from file...")
#        spark.sql(drop_table_query)
#        spark.sql(create_table_query.format(path_gnip_optimization))


    except Exception as e:
        traceback.print_exc()
        raise TypeError("Error Code 3: Please verify connection to Hive and S3")


def stopSparkSession(log, spark):
    """ Shuts down the current SparkSession
    :param log      : current logger
    :param spark    : current SparkSession
    :return         : N/A
    """
    log.info("Shutting Down")
    spark.stop()


if __name__ == "__main__":
    spark = initSparkSession("GNIP_Brand_Query_Optimization")
    log = get_logger()
    processController = loadProcessDriver(spark, log, "vv_db.processdriver")
    gnipdf = initProcess(spark, processController, log)
    store(log, spark, processController, gnipdf)
    stopSparkSession(log, spark)
