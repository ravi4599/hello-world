package routines;

import routines.system.*;

public class DataCleanser {

    public static Dynamic replaceAllDynamic(Dynamic data, String replaceChr, String replacement) {
    
    	if (replaceChr == null || replacement == null) {
    		return data;
    	}
    	
    	java.util.List<DynamicMetadata> metadatas = data.metadatas;
    
        for (int i = 0; i < metadatas.size(); i++) {
            DynamicMetadata metadata = metadatas.get(i);
            if("id_Date".equals(metadata.getType()) && !("id_MSSQL".equalsIgnoreCase(data.getDbmsId())
                        && !(metadata.getDbType().toLowerCase().indexOf("timestamp") < 0))) { 
                //do nothing;
            } else {
                data.setColumnValue(i, String.valueOf(data.getColumnValue(i)).replaceAll(replaceChr, replacement));
            }
        }
        
        return data;

    }
    
    public static Dynamic replaceNewLinesAndReturns(Dynamic data) {
    	
    	java.util.List<DynamicMetadata> metadatas = data.metadatas;
    
        for (int i = 0; i < metadatas.size(); i++) {
            DynamicMetadata metadata = metadatas.get(i);
            if("id_Date".equals(metadata.getType()) && !("id_MSSQL".equalsIgnoreCase(data.getDbmsId())
                        && !(metadata.getDbType().toLowerCase().indexOf("timestamp") < 0))) { 
                //do nothing;
            } else {
            	if ("null".equals(String.valueOf(data.getColumnValue(i)))) {
            		data.setColumnValue(i, "");
            	} else {
            		data.setColumnValue(i, String.valueOf(data.getColumnValue(i)).replaceAll("\r\n", "").replaceAll("\n", "").replaceAll("\r", "").replaceAll("\n\r", ""));
            	}
            }
        }
        
        return data;

    }

    public static Dynamic replaceHeader(Dynamic data, String delimitedString) {
    
    	if (delimitedString == null) {
    		return data;
    	}
    	
    	java.util.List<DynamicMetadata> metadatas = data.metadatas;
    	
    	String inputData [] = delimitedString.replaceAll("\"", "").trim().split("\\s*,[,\\s]*");
    	
    	for (int i = 0; i < inputData.length; i++) {
    		DynamicMetadata metadata = metadatas.get(i);
    		metadata.setName(inputData[i]);
    	}
    	
    	return data;

    }
}