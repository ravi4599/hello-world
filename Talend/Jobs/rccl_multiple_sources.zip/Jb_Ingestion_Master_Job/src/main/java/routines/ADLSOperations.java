package routines;

import com.microsoft.azure.datalake.store.*;
import com.microsoft.azure.datalake.store.oauth2.*;
import java.io.*;

public class ADLSOperations {

	private String clientId;
	private String authTokenEndpoint;
	private String clientKey;
	private String accountFQDN;
	private AccessTokenProvider provider;
	private ADLStoreClient client;
	
    public ADLSOperations(String clientId, String authTokenEndpoint, String clientKey, String accountFQDN) {
        this.clientId = clientId;
        this.authTokenEndpoint = authTokenEndpoint;
        this.clientKey = clientKey;
        this.accountFQDN = accountFQDN;
    }
    
    public void connectADLS() {
    	this.provider = new ClientCredsTokenProvider(authTokenEndpoint, clientId, clientKey);
    	this.client = ADLStoreClient.createClient(this.accountFQDN, this.provider);
    }
    
    public void upload(String filename, String localFilename, IfExists mode) throws IOException  {
        if (localFilename == null || localFilename.trim().equals(""))
            throw new IllegalArgumentException("localFilename cannot be null");

        try (FileInputStream in = new FileInputStream(localFilename)){
            upload(filename, in, mode);
        }
    }

    public void upload(String filename, InputStream in, IfExists mode) throws IOException {
        if (filename == null || filename.trim().equals(""))
            throw new IllegalArgumentException("filename cannot be null");
        if (in == null) throw new IllegalArgumentException("InputStream cannot be null");

        try (ADLFileOutputStream out = client.createFile(filename, mode)) {
            int bufSize = 4 * 1000 * 1000;
            out.setBufferSize(bufSize);
            byte[] buffer = new byte[bufSize];
            int n;

            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
            }
        }
    }
}
