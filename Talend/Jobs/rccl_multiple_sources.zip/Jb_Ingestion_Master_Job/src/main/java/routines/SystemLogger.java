package routines;
import java.io.IOException;
import java.io.PrintStream;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class SystemLogger extends PrintStream{

	PrintStream printStream ; 
	private Logger logger ;
	private Level level;
	public SystemLogger(PrintStream out) 
	{
		super(out);
		this.printStream = out;
		
	}

	public SystemLogger(PrintStream out,Logger logger, Level level) 
	{
		super(out);
		this.printStream = out;
		this.logger = logger;
		this.level = level;	
	}
	
	@Override
	public void write(byte[] b) throws IOException
	{
		printStream.write(b);
	    String string = new String(b);
	    
		if (!string.trim().isEmpty())
	        logger.log( this.level,string);
	}
	@Override
	public void write(byte[] b, int off, int len)
	{
		printStream.write(b, off, len);
	    String string = new String(b, off, len);
	    if (!string.trim().isEmpty())
	    	logger.log(this.level,string);
	}
	@Override
	public void write(int b)
	{
		printStream.write(b);
	    String string = String.valueOf((char) b);
	    if (!string.trim().isEmpty())
	    	logger.log( this.level,string);
	}
}
