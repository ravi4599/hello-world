package routines;

import java.net.UnknownHostException;
import java.util.Calendar;

import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class rccl_common_routine {

	public static String currentJobName;
	/**
     * Gets a RCCL JobRunInstance ID that is a unique identifier for job executions. Returns a string id (for example "40015791") that is less than 10 digits long.
     * 
     * {talendTypes} String
     * 
     * {Category} RCCL Routines
     * {example} getJobRunInstanceID()  returns a string id (for example "40015791"), less than 10 digits long.
     */
	
    public static String getJobRunInstanceID() 
    {
    	/** JobRunInstanceID is a unique ID for every job execution or run. It's composed of two parts: 
    	 * Part 1: 4 - 6 digits long, is the number of days, hours, minutes and seconds
    	 * since January 1, 2000.
    	 * Part 2: 4 digits long, is the sum of number of milliseconds at start of a 
    	 * job plus a random 4-digit number (to ensure uniqueness)
    	 */

    	Calendar dateTimeNow = Calendar.getInstance();
    	// part 1 - get number of days, then add hours, minutes & seconds
    	Long part1 = TalendDate.diffDate(dateTimeNow.getTime(),TalendDate.parseDate("yyyy-MM-dd","2000-01-01"),"dd");
    	part1 += Integer.valueOf(dateTimeNow.get(Calendar.HOUR_OF_DAY)) * 3600; // add # hours in seconds
    	part1 += Integer.valueOf(dateTimeNow.get(Calendar.MINUTE)) * 60; // add # minutes in seconds
    	part1 += Integer.valueOf(dateTimeNow.get(Calendar.SECOND)) * 1; // add # seconds

    	// part 2 - get milliseconds and add random number for uniqueness
    	Integer part2 = Integer.valueOf(dateTimeNow.get(Calendar.MILLISECOND));
    	part2 += Numeric.random(1000, 9999); 
 	
    	return part1.toString() + part2.toString();
    }
    
    
    /**
     * Creates a file log appender
     * 
     * {talendTypes} String
     * 
     * {Category} RCCL Routines
     * 
     * 
     * {example} Creates a file log appender.
     */
    public static void createLogFileAppender(
    										String loggerDir, 
    										String loggerFileName, 
    										String loggerPattern, 
    										String FileAppenderName
    										) 
    { 
    FileAppender logFileAppender = new FileAppender();
    logFileAppender.setName(FileAppenderName);
    logFileAppender.setFile(loggerDir + "/" + loggerFileName);
    logFileAppender.setLayout(new PatternLayout(loggerPattern));
    logFileAppender.setAppend(true);
    logFileAppender.activateOptions();

    // add appender to root logger 
    Logger.getRootLogger().addAppender(logFileAppender); 
    }
        
    
    public void setCurrentJobName(String curJobName) {
    	currentJobName = curJobName;
     }
    
    // create audit logger
    public static Logger auditLog = Logger.getLogger("auditLog");
    //public static Logger auditLog = Logger.getLogger(currentJobName);  
    //public static final Logger auditLog = Logger.getLogger(new Object() { }.getClass().getEnclosingClass());
    //public static final StackTraceElement stackTraceElement = new Throwable().getStackTrace()[3];
   		
    public static void createAuditFileAppender(
    											String loggerDir, 
    											String loggerFileName, 
    											String loggerPattern, 
    											String FileAppenderName
    											//,Logger loggerName
    											) 
    { 
    	    
    FileAppender auditFileAppender = new FileAppender();
    auditFileAppender.setName(FileAppenderName);
    auditFileAppender.setFile(loggerDir + "/" + loggerFileName);
    auditFileAppender.setLayout(new PatternLayout(loggerPattern));
    auditFileAppender.setAppend(true); 
    auditFileAppender.activateOptions();
    
    // do not send audit logs to root logger
    auditLog.setAdditivity(false);
       
    // add appender to audit logger
    auditLog.addAppender(auditFileAppender);
    }
    
    /**
     * Gets a job execution server name (Google Cloud Engine or other VM or physical server name)
     * 
     * {talendTypes} String
     * 
     * {Category} RCCL Routines
     * 
     * 
     * {example} getServerName("short")  returns the short server name.
     */
	public static String getServerName(String nameType)
	    {
		// get machine name
		java.net.InetAddress localMachine = null;
		try {
			localMachine = java.net.InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		String nameOS = "os.name";        
		String versionOS = "os.version";        
		String architectureOS = "os.arch";
		String machineName = "";

		// get short name
		String shortMachineName = localMachine.getHostName();
		
		// get information for long machine name
		String longMachineInfo = " (" + System.getProperty(nameOS);
		longMachineInfo += ", ver. " + System.getProperty(versionOS);
		longMachineInfo += " [" + System.getProperty(architectureOS) + "])";
		
		if (nameType.equals("short"))
		{
			machineName = shortMachineName;
		}
		else
		{
			machineName = shortMachineName + longMachineInfo;
		}			
	 return machineName;
	}    
	  
    
}

