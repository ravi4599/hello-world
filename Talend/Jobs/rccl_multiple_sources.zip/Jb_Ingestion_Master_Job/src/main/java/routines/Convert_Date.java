/* This routine is use to  convert any valid date from HUB to desire format for ADS
 
 * Project: LightSpeed -ADS reporting
 * Developer: Milan Dhore
 * Date: 12/15/2015
 * Version : 1.0
 * */

package routines;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.text.ParseException;
public class Convert_Date{

                public static String convertAnyDateFormat(String sourceDate,String sourceDateFormat,String targetDateFormat)
                {
                                String var_Date = "";
                                

                                if(sourceDateFormat != null && sourceDate.length() != 0  && sourceDate !=null && !sourceDate.isEmpty())
                                {
                  SimpleDateFormat sdf_source = new SimpleDateFormat(sourceDateFormat); 

                  SimpleDateFormat sdf_target = new SimpleDateFormat(targetDateFormat);
                
                  

                  try
                  {
                   var_Date = sdf_target.format(sdf_source.parse(sourceDate)); 
                  }
                  catch(ParseException e)
                  {
                   System.out.println("Source Format not correct");
                  }
                                }
                                else 
                                {
                                                var_Date = null;
                                }
                  
                                return var_Date;
                
                 }
    
                public static BigDecimal StringtoBigDecimal(String a, int id ){
                                
                
                                BigDecimal x=null;
                                
                                try{
                                                if(a.matches("[a-zA-Z]+") || a==null || a.length()==0)
                                                                x=null;
                                                else
                                                x= new BigDecimal(a.replaceAll(",", ""));
                                            
                                }
                                
                                catch(NumberFormatException nfe)
                                {
                                                System.out.println("BigDecimal column  has invalid data: [" + a + "] for ID:" + id + " with exception " +  nfe);
                                }
                                
                                return x;
                                
                }
                public static Float StringtoFloat(String f,int id){
                                Float x=null;
                                try {
                                                  if(f.matches("[a-zA-Z]+") || f==null || f.length()==0)
                                                                x=null;
                                                  else 
                                                                 x=Float.parseFloat(f);

                                }
                                catch(NumberFormatException nfe)
                                {
                                	System.out.println("Float Column has invalid data: [" + f + "] for ID :" + id + " with exception " +  nfe);
                                }
                                               
                                return x;
                }             
                public static Integer StringtoInt(String i,int id){
                    int  x = -9999999;
                    try {
                                      if(i.matches("[a-zA-Z]+") || i==null || i.length()==0)
                                                    x= -9999999;
                                      else 
                                                     x=Integer.parseInt(i);

                    }
                    catch(NumberFormatException nfe)
                    {
                    	System.out.println("Integer Column has invalid data: [" + i + "] for ID :" + id + " with exception " +  nfe);
                    }
                                   
                    return x;
    }            
}

