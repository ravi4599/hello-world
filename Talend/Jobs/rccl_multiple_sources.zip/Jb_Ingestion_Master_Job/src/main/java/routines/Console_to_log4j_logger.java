package routines;

import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.PatternLayout;
import java.io.File;
import org.apache.log4j.Logger;  
/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class Console_to_log4j_logger {

	public static final Logger logger = Logger.getRootLogger();
	 public static Logger initLogger(String dirName,String fileName) 
	    {
	
	    try {
	      final File logDir = new File(dirName);
	      logDir.mkdirs();

	      final File logFile = new File(logDir + fileName);

	      final PatternLayout pl = new PatternLayout("%d %-5p: %m%n");
	      final DailyRollingFileAppender dailyfp = new DailyRollingFileAppender( pl, logFile.getCanonicalPath(), ".yyyy-MM-dd" );

	      logger.addAppender( dailyfp );
	      logger.setLevel(Level.DEBUG);

	         
	      SystemLogger sysLogger = new SystemLogger(System.out,logger, Level.DEBUG);
	      System.setOut(sysLogger);
	      SystemLogger errLogger = new SystemLogger(System.err,logger, Level.ERROR);
	      System.setErr(errLogger);
	      	      
	    } catch ( Exception e ) {
	      e.printStackTrace( System.err );
	    }
	  
	    return logger;
	    }
	 
	 
	 public static void debug(String errorMessage)
	 {
		 logger.debug(errorMessage);
	}
	 
	 public static void debug(Exception exception)
	 {
		 logger.debug(exception.getMessage(),exception);
		 
	 }
	 
	 
	 public static void error(String errorMessage)
	 {
		 logger.error(errorMessage);
	}
	 
	 public static void error(Exception exception)
	 {
		 logger.error(exception.getMessage(),exception);
		 
	 }
	 
	 public static void info(String errorMessage)
	 {
		 logger.info(errorMessage);
	}
	 
	 public static void info(Exception exception)
	 {
		 logger.info(exception.getMessage(),exception);
		 
	 }
	 
	
}
