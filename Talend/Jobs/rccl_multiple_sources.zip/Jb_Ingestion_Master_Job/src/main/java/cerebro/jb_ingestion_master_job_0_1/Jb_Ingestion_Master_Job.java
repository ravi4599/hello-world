
package cerebro.jb_ingestion_master_job_0_1;

import routines.DataOperation;
import routines.TalendEncrypt;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.DQTechnical;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaRow_1
	//import java.util.List;

	//the import part of tJavaRow_3
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_10
	//import java.util.List;

	//the import part of tJava_4
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJava_6
	//import java.util.List;

	//the import part of tJava_7
	//import java.util.List;

	//the import part of tJava_9
	//import java.util.List;

	//the import part of tJava_11
	//import java.util.List;

	//the import part of tJava_13
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJavaFlex_1
	//import java.util.List;

	//the import part of tJava_8
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: Jb_Ingestion_Master_Job Purpose: Master job that ingests data into ADLS<br>
 * Description: Master job that ingests data into ADLS <br>
 * @author Ganguly, Soumya
 * @version 6.4.1.20170623_1246
 * @status 
 */
public class Jb_Ingestion_Master_Job implements TalendJob {
	static {System.setProperty("TalendJob.log", "Jb_Ingestion_Master_Job.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(Jb_Ingestion_Master_Job.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(keyfile_path != null){
				
					this.setProperty("keyfile_path", keyfile_path.toString());
				
			}
			
			if(prop_file_path != null){
				
					this.setProperty("prop_file_path", prop_file_path.toString());
				
			}
			
			if(group_id != null){
				
					this.setProperty("group_id", group_id.toString());
				
			}
			
			if(job_type != null){
				
					this.setProperty("job_type", job_type.toString());
				
			}
			
			if(override_parallel != null){
				
					this.setProperty("override_parallel", override_parallel.toString());
				
			}
			
			if(parallel_executions != null){
				
					this.setProperty("parallel_executions", parallel_executions.toString());
				
			}
			
			if(src_sys_id != null){
				
					this.setProperty("src_sys_id", src_sys_id.toString());
				
			}
			
			if(sub_sys_id != null){
				
					this.setProperty("sub_sys_id", sub_sys_id.toString());
				
			}
			
		}

public String keyfile_path;
public String getKeyfile_path(){
	return this.keyfile_path;
}
public String prop_file_path;
public String getProp_file_path(){
	return this.prop_file_path;
}
public String group_id;
public String getGroup_id(){
	return this.group_id;
}
public String job_type;
public String getJob_type(){
	return this.job_type;
}
public String override_parallel;
public String getOverride_parallel(){
	return this.override_parallel;
}
public Integer parallel_executions;
public Integer getParallel_executions(){
	return this.parallel_executions;
}
public String src_sys_id;
public String getSrc_sys_id(){
	return this.src_sys_id;
}
public String sub_sys_id;
public String getSub_sys_id(){
	return this.sub_sys_id;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Jb_Ingestion_Master_Job";
	private final String projectName = "CEREBRO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Jb_Ingestion_Master_Job.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Jb_Ingestion_Master_Job.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				tLogCatcher_1.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				tLogCatcher_1Process(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputProperties_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
						try {
							
								if(this.execStat){
									runStat.updateStatOnConnection("OnComponentError1", 0, "error");
								}
							
							
								errorCode = null;
								tWarn_2Process(globalMap);
								if (!"failure".equals(status)) {
									status = "end";
								}
								

						} catch (Exception e) {
							e.printStackTrace();
						}
						
					tMSSqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tRunJob_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterColumns_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSetGlobalVar_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDie_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDie_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tUnite_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaFlex_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileList_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileDelete_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileList_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSendMail_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDenormalize_1_DenormalizeOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tDenormalize_1_ArrayIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tDenormalize_1_ArrayIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSortRow_1_SortOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tSortRow_1_SortIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tSortRow_1_SortIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAggregateRow_1_AGGOUT_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tAggregateRow_1_AGGIN_error(exception, errorComponent, globalMap);
						
						}
					
			public void tAggregateRow_1_AGGIN_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSortRow_2_SortOut_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
							tSortRow_2_SortIn_error(exception, errorComponent, globalMap);
						
						}
					
			public void tSortRow_2_SortIn_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputProperties_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError1", 0, "error");
						}
					
					errorCode = null;
					tWarn_1Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError2", 0, "error");
						}
					
					errorCode = null;
					tWarn_3Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLogCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSetGlobalVar_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDie_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileList_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSendMail_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}







			


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		
    	class BytesLimit65535_tPrejob_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tPrejob_1().limitLog4jByte();

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tFileInputProperties_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputProperties_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputProperties_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();
row5Struct row5 = new row5Struct();





	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("row5.value")+", KEY="+("row5.key")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */



	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_1 = 0;
		
    	class BytesLimit65535_tJavaRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_1().limitLog4jByte();

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tFileInputProperties_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputProperties_1", false);
		start_Hash.put("tFileInputProperties_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputProperties_1";

	
		int tos_count_tFileInputProperties_1 = 0;
		
    	class BytesLimit65535_tFileInputProperties_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFileInputProperties_1().limitLog4jByte();

	java.io.File file_tFileInputProperties_1 = new java.io.File(context.prop_file_path);
	int nb_line_tFileInputProperties_1 = 0;				log.debug("tFileInputProperties_1 - Retrieving records from the datasource.");
			
	java.util.Properties properties_tFileInputProperties_1 = new java.util.Properties();
	java.io.FileInputStream fis_tFileInputProperties_1=new java.io.FileInputStream(file_tFileInputProperties_1);
   	try{
		properties_tFileInputProperties_1.load(fis_tFileInputProperties_1);
		java.util.Enumeration enumeration_tFileInputProperties_1 = properties_tFileInputProperties_1.propertyNames();
		while (enumeration_tFileInputProperties_1.hasMoreElements()) {
			nb_line_tFileInputProperties_1++;
				log.debug("tFileInputProperties_1 - Retrieving the record " + (nb_line_tFileInputProperties_1) + ".");
			
			row4.key = (String)enumeration_tFileInputProperties_1.nextElement();
			row4.value = (String)properties_tFileInputProperties_1.getProperty(row4.key);

 



/**
 * [tFileInputProperties_1 begin ] stop
 */
	
	/**
	 * [tFileInputProperties_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

 


	tos_count_tFileInputProperties_1++;

/**
 * [tFileInputProperties_1 main ] stop
 */

	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

			//row4
			//row4


			
				if(execStat){
					runStat.updateStatOnConnection("row4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

    row5.key = row4.key; 
if (row4.key.toLowerCase ().contains("password")) { 
	routines.TalendEncrypt enc = new routines.TalendEncrypt();
	row5.value = enc.decryptText(row4.value, enc.getPrivate(context.keyfile_path));
} else { 
  row5.value = row4.value; 
}
    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			//row5
			//row5


			
				if(execStat){
					runStat.updateStatOnConnection("row5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

globalMap.put(row5.key, row5.value);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */






	
	/**
	 * [tFileInputProperties_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

		}
	}finally{
		if(fis_tFileInputProperties_1!=null){
			fis_tFileInputProperties_1.close();
		}
	}
globalMap.put("tFileInputProperties_1_NB_LINE", nb_line_tFileInputProperties_1);
				log.debug("tFileInputProperties_1 - Retrieved records count: "+ nb_line_tFileInputProperties_1 + " .");
			
 

ok_Hash.put("tFileInputProperties_1", true);
end_Hash.put("tFileInputProperties_1", System.currentTimeMillis());




/**
 * [tFileInputProperties_1 end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row4"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());




/**
 * [tJavaRow_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row5"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputProperties_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tMSSqlConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputProperties_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

 



/**
 * [tFileInputProperties_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

 



/**
 * [tJavaRow_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputProperties_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tMSSqlConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlConnection_1", false);
		start_Hash.put("tMSSqlConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlConnection_1";

	
		int tos_count_tMSSqlConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlConnection_1 = new StringBuilder();
            log4jParamters_tMSSqlConnection_1.append("Parameters:");
                    log4jParamters_tMSSqlConnection_1.append("DRIVER" + " = " + "JTDS");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("HOST" + " = " + "((String)globalMap.get(\"AUDIT_HOSTNAME\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PORT" + " = " + "((String)globalMap.get(\"AUDIT_PORT\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SCHEMA_DB" + " = " + "((String)globalMap.get(\"AUDIT_SCHEMA\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("DBNAME" + " = " + "((String)globalMap.get(\"AUDIT_DATABASE\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("USER" + " = " + "((String)globalMap.get(\"AUDIT_USERNAME\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(((String)globalMap.get("AUDIT_PASSWORD")))).substring(0, 4) + "...");     
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PROPERTIES" + " = " + "((String)globalMap.get(\"AUDIT_ADDITIONAL_PARAMETERS\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + (log4jParamters_tMSSqlConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlConnection_1().limitLog4jByte();
	

	
			String url_tMSSqlConnection_1 = "jdbc:jtds:sqlserver://" + ((String)globalMap.get("AUDIT_HOSTNAME")) ;
		String port_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_PORT"));
		String dbname_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_DATABASE")) ;
    	if (!"".equals(port_tMSSqlConnection_1)) {
    		url_tMSSqlConnection_1 += ":" + ((String)globalMap.get("AUDIT_PORT"));
    	}
    	if (!"".equals(dbname_tMSSqlConnection_1)) {
    		
				url_tMSSqlConnection_1 += "//" + ((String)globalMap.get("AUDIT_DATABASE")); 
    	}
		url_tMSSqlConnection_1 += ";appName=" + projectName + ";" + ((String)globalMap.get("AUDIT_ADDITIONAL_PARAMETERS"));  

	String dbUser_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_USERNAME"));
	
	
		
	final String decryptedPassword_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_PASSWORD")); 
		String dbPwd_tMSSqlConnection_1 = decryptedPassword_tMSSqlConnection_1;
	

	java.sql.Connection conn_tMSSqlConnection_1 = null;
	
		
			String driverClass_tMSSqlConnection_1 = "net.sourceforge.jtds.jdbc.Driver";
			java.lang.Class.forName(driverClass_tMSSqlConnection_1);
		
	    		log.debug("tMSSqlConnection_1 - Driver ClassName: "+driverClass_tMSSqlConnection_1+".");
			
	    		log.debug("tMSSqlConnection_1 - Connection attempt to '" + url_tMSSqlConnection_1 + "' with the username '" + dbUser_tMSSqlConnection_1 + "'.");
			
		conn_tMSSqlConnection_1 = java.sql.DriverManager.getConnection(url_tMSSqlConnection_1,dbUser_tMSSqlConnection_1,dbPwd_tMSSqlConnection_1);
	    		log.debug("tMSSqlConnection_1 - Connection to '" + url_tMSSqlConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tMSSqlConnection_1", conn_tMSSqlConnection_1);
	if (null != conn_tMSSqlConnection_1) {
		
			log.debug("tMSSqlConnection_1 - Connection is set auto commit to 'true'.");
			conn_tMSSqlConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tMSSqlConnection_1", ((String)globalMap.get("AUDIT_SCHEMA")));

	globalMap.put("db_tMSSqlConnection_1",  ((String)globalMap.get("AUDIT_DATABASE")));

	globalMap.put("conn_tMSSqlConnection_1",conn_tMSSqlConnection_1);
	
	globalMap.put("shareIdentitySetting_tMSSqlConnection_1",  false);

 



/**
 * [tMSSqlConnection_1 begin ] stop
 */
	
	/**
	 * [tMSSqlConnection_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 


	tos_count_tMSSqlConnection_1++;

/**
 * [tMSSqlConnection_1 main ] stop
 */
	
	/**
	 * [tMSSqlConnection_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlConnection_1", true);
end_Hash.put("tMSSqlConnection_1", System.currentTimeMillis());




/**
 * [tMSSqlConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tMSSqlConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tMSSqlInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 



/**
 * [tMSSqlConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";

	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
            log4jParamters_tWarn_1.append("Parameters:");
                    log4jParamters_tWarn_1.append("MESSAGE" + " = " + "\"200|Audit connection failed\"");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("CODE" + " = " + "999");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_1().limitLog4jByte();

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "ERROR","","200|Audit connection failed","", "");
            log.error("tWarn_1 - "  + ("Message: ")  + ("200|Audit connection failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_1", 5, "200|Audit connection failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_1_WARN_MESSAGES", "200|Audit connection failed"); 
globalMap.put("tWarn_1_WARN_PRIORITY", 5);
globalMap.put("tWarn_1_WARN_CODE", 999);


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());




/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row14Struct row14 = new row14Struct();
row15Struct row15 = new row15Struct();





	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row15" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
            log4jParamters_tSetGlobalVar_3.append("Parameters:");
                    log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("row15.value")+", KEY="+("row15.key")+"}]");
                log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */



	
	/**
	 * [tJavaRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_3", false);
		start_Hash.put("tJavaRow_3", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row14" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_3 = 0;
		
    	class BytesLimit65535_tJavaRow_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_3().limitLog4jByte();

int nb_line_tJavaRow_3 = 0;

 



/**
 * [tJavaRow_3 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_3", false);
		start_Hash.put("tMSSqlInput_3", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_3";

	
		int tos_count_tMSSqlInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_3 = new StringBuilder();
            log4jParamters_tMSSqlInput_3.append("Parameters:");
                    log4jParamters_tMSSqlInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("QUERY" + " = " + "\"  SELECT DISTINCT UPPER(CONTEXT_KEY) AS CONTEXT_KEY  	, CONTEXT_VALUE  FROM DBO.T_TALEND_CONTEXT_LOAD CT  	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR  		ON CT.CONTEXT_ID = SR.CONTEXT_ID  WHERE SR.SRC_SYS_ID = '\" + context.src_sys_id + \"'\" +  (context.sub_sys_id.trim().length() > 0 ? \"   	AND SR.SUB_SYS_ID = '\" + context.sub_sys_id + \"'\"  :  \"\") + \"  \"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("key")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("value")+"}]");
                log4jParamters_tMSSqlInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + (log4jParamters_tMSSqlInput_3) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_3().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_3, talendToDBArray_tMSSqlInput_3); 
		    int nb_line_tMSSqlInput_3 = 0;
		    java.sql.Connection conn_tMSSqlInput_3 = null;
		        conn_tMSSqlInput_3 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_3 != null) {
					if(conn_tMSSqlInput_3.getMetaData() != null) {
						
						log.debug("tMSSqlInput_3 - Uses an existing connection with username '" + conn_tMSSqlInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_3 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_3 = conn_tMSSqlInput_3.createStatement();

		    String dbquery_tMSSqlInput_3 = "\nSELECT DISTINCT UPPER(CONTEXT_KEY) AS CONTEXT_KEY\n	, CONTEXT_VALUE\nFROM DBO.T_TALEND_CONTEXT_LOAD CT\n	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR\n		ON CT.CONTEXT_ID = SR.CONTEXT_ID\nWHERE SR.SRC_SYS_ID = '" + context.src_sys_id + "'" +
(context.sub_sys_id.trim().length() > 0 ? " \n	AND SR.SUB_SYS_ID = '" + context.sub_sys_id + "'"
:
"") + "\n";
			
                log.debug("tMSSqlInput_3 - Executing the query: '"+dbquery_tMSSqlInput_3+"'.");
			

                       globalMap.put("tMSSqlInput_3_QUERY",dbquery_tMSSqlInput_3);

		    java.sql.ResultSet rs_tMSSqlInput_3 = null;
		try{
		    rs_tMSSqlInput_3 = stmt_tMSSqlInput_3.executeQuery(dbquery_tMSSqlInput_3);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_3 = rs_tMSSqlInput_3.getMetaData();
		    int colQtyInRs_tMSSqlInput_3 = rsmd_tMSSqlInput_3.getColumnCount();

		    String tmpContent_tMSSqlInput_3 = null;
		    
		    
		    	log.debug("tMSSqlInput_3 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_3.next()) {
		        nb_line_tMSSqlInput_3++;
		        
							if(colQtyInRs_tMSSqlInput_3 < 1) {
								row14.key = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3.getString(1);
            if(tmpContent_tMSSqlInput_3 != null) {
            	if (talendToDBList_tMSSqlInput_3 .contains(rsmd_tMSSqlInput_3.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row14.key = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_3);
            	} else {
                	row14.key = tmpContent_tMSSqlInput_3;
                }
            } else {
                row14.key = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_3 < 2) {
								row14.value = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3.getString(2);
            if(tmpContent_tMSSqlInput_3 != null) {
            	if (talendToDBList_tMSSqlInput_3 .contains(rsmd_tMSSqlInput_3.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row14.value = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_3);
            	} else {
                	row14.value = tmpContent_tMSSqlInput_3;
                }
            } else {
                row14.value = null;
            }
		                    }
					
						log.debug("tMSSqlInput_3 - Retrieving the record " + nb_line_tMSSqlInput_3 + ".");
					





 



/**
 * [tMSSqlInput_3 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_3 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

 


	tos_count_tMSSqlInput_3++;

/**
 * [tMSSqlInput_3 main ] stop
 */

	
	/**
	 * [tJavaRow_3 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

			//row14
			//row14


			
				if(execStat){
					runStat.updateStatOnConnection("row14"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row14 - " + (row14==null? "": row14.toLogString()));
    			}
    		

    row15.key = row14.key; 
if (row14.key.toLowerCase ().contains("password")) { 
	routines.TalendEncrypt enc = new routines.TalendEncrypt();
	row15.value = enc.decryptText(row14.value, enc.getPrivate(context.keyfile_path));
} else { 
  row15.value = row14.value; 
}
    nb_line_tJavaRow_3++;   

 


	tos_count_tJavaRow_3++;

/**
 * [tJavaRow_3 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			//row15
			//row15


			
				if(execStat){
					runStat.updateStatOnConnection("row15"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row15 - " + (row15==null? "": row15.toLogString()));
    			}
    		

globalMap.put(row15.key, row15.value);

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */






	
	/**
	 * [tMSSqlInput_3 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

	}
}finally{
	stmt_tMSSqlInput_3.close();

}
globalMap.put("tMSSqlInput_3_NB_LINE",nb_line_tMSSqlInput_3);
	    		log.debug("tMSSqlInput_3 - Retrieved records count: "+nb_line_tMSSqlInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_3", true);
end_Hash.put("tMSSqlInput_3", System.currentTimeMillis());




/**
 * [tMSSqlInput_3 end ] stop
 */

	
	/**
	 * [tJavaRow_3 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

globalMap.put("tJavaRow_3_NB_LINE",nb_line_tJavaRow_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row14"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_3", true);
end_Hash.put("tJavaRow_3", System.currentTimeMillis());




/**
 * [tJavaRow_3 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row15"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_3 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

 



/**
 * [tMSSqlInput_3 finally ] stop
 */

	
	/**
	 * [tJavaRow_3 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_3";

	

 



/**
 * [tJavaRow_3 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_3", false);
		start_Hash.put("tWarn_3", System.currentTimeMillis());
		
	
	currentComponent="tWarn_3";

	
		int tos_count_tWarn_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_3 = new StringBuilder();
            log4jParamters_tWarn_3.append("Parameters:");
                    log4jParamters_tWarn_3.append("MESSAGE" + " = " + "\"101|Load context variables failed\"");
                log4jParamters_tWarn_3.append(" | ");
                    log4jParamters_tWarn_3.append("CODE" + " = " + "999");
                log4jParamters_tWarn_3.append(" | ");
                    log4jParamters_tWarn_3.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + (log4jParamters_tWarn_3) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_3().limitLog4jByte();

 



/**
 * [tWarn_3 begin ] stop
 */
	
	/**
	 * [tWarn_3 main ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_3", "", Thread.currentThread().getId() + "", "ERROR","","101|Load context variables failed","", "");
            log.error("tWarn_3 - "  + ("Message: ")  + ("101|Load context variables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_3", 5, "101|Load context variables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_3_WARN_MESSAGES", "101|Load context variables failed"); 
globalMap.put("tWarn_3_WARN_PRIORITY", 5);
globalMap.put("tWarn_3_WARN_CODE", 999);


 


	tos_count_tWarn_3++;

/**
 * [tWarn_3 main ] stop
 */
	
	/**
	 * [tWarn_3 end ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Done.") );

ok_Hash.put("tWarn_3", true);
end_Hash.put("tWarn_3", System.currentTimeMillis());




/**
 * [tWarn_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_3 finally ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

 



/**
 * [tWarn_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
    	class BytesLimit65535_tJava_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_1().limitLog4jByte();


globalMap.put("JOB_START_DTTM", TalendDate.getCurrentDate());

globalMap.put("BATCH_ID", java.util.UUID.randomUUID().toString());

if ("Y".equals((String)globalMap.get("RERUN_FAILED"))) {
	globalMap.put("INCLUDE_STATUS", ("M".equals(context.job_type) ? "'C', 'F', 'I'" : "'F'"));
} else {
	globalMap.put("INCLUDE_STATUS", ("M".equals(context.job_type) ? "'C', 'F', 'I'" : "'C', 'F'"));
}

if (!Relational.ISNULL(globalMap.get("RERUN_OBJECT_LIST")) && ((String)globalMap.get("RERUN_OBJECT_LIST")).trim().length() > 0) {
	globalMap.put("RERUN_OBJECT_LIST", " AND LC.OBJECT_ID IN ('" + String.join("','", ((String)globalMap.get("RERUN_OBJECT_LIST")).replaceAll("'", "").trim().split("\\s*,[,\\s]*")) + "') ");
} else {
	globalMap.put("RERUN_OBJECT_LIST", "");
}

if (!Relational.ISNULL(context.group_id) && context.group_id.trim().length() > 0) {
	context.group_id = " ('" + String.join("','", context.group_id.replaceAll("'", "").trim().split("\\s*,[,\\s]*")) + "') ";
} else {
	context.group_id = "";
}

if (!"Y".equals(context.override_parallel)) {
	context.parallel_executions = Relational.ISNULL(globalMap.get("PARALLEL_EXECUTIONS")) ? (Relational.ISNULL(context.parallel_executions) ? 1 : context.parallel_executions) : Integer.parseInt((String)globalMap.get("PARALLEL_EXECUTIONS"));
} else {
	context.parallel_executions = Relational.ISNULL(context.parallel_executions) ? 1 : context.parallel_executions;
}

if ("Y".equals((String)globalMap.get("TRIGGER_FILE_BASED"))) {
	context.parallel_executions = 1;
}

if (!Relational.ISNULL(context.job_type) && context.job_type.length() > 0) {
	globalMap.put("JOB_TYPE", context.job_type);
}
 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());

   			if (!("Y".equals((String)globalMap.get("IS_FAILED")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				
    			tFixedFlowInput_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	


public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.status = readString(dis);
					
					this.object_nm = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",status="+status);
		sb.append(",object_nm="+object_nm);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row18Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row18Struct row18 = new row18Struct();




	
	/**
	 * [tHashOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_4", false);
		start_Hash.put("tHashOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row18" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_4 = 0;
		
    	class BytesLimit65535_tHashOutput_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_4().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_4=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row18Struct> tHashFile_tHashOutput_4 = null;
		String hashKey_tHashOutput_4 = "tHashFile_Jb_Ingestion_Master_Job_" + pid + "_tHashOutput_4";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_4)){
			    if(mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4) == null){
	      		    mf_tHashOutput_4.getResourceMap().put(hashKey_tHashOutput_4, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row18Struct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_4 = mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4);
			    }else{
			    	tHashFile_tHashOutput_4 = mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4);
			    }
			}
        int nb_line_tHashOutput_4 = 0;
 



/**
 * [tHashOutput_4 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_3", false);
		start_Hash.put("tFixedFlowInput_3", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_3";

	
		int tos_count_tFixedFlowInput_3 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_3().limitLog4jByte();

	    for (int i_tFixedFlowInput_3 = 0 ; i_tFixedFlowInput_3 < 0 ; i_tFixedFlowInput_3++) {
	                	            	
    	            		row18.process_type = null;        	            	
    	            	        	            	
    	            		row18.src_sys_id = null;        	            	
    	            	        	            	
    	            		row18.sub_sys_id = null;        	            	
    	            	        	            	
    	            		row18.object_id = null;        	            	
    	            	        	            	
    	            		row18.status = null;        	            	
    	            	        	            	
    	            		row18.object_nm = null;        	            	
    	            	
 



/**
 * [tFixedFlowInput_3 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_3 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

 


	tos_count_tFixedFlowInput_3++;

/**
 * [tFixedFlowInput_3 main ] stop
 */

	
	/**
	 * [tHashOutput_4 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_4";

	

			//row18
			//row18


			
				if(execStat){
					runStat.updateStatOnConnection("row18"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row18 - " + (row18==null? "": row18.toLogString()));
    			}
    		



    
		row18Struct oneRow_tHashOutput_4 = new row18Struct();
				
					oneRow_tHashOutput_4.process_type = row18.process_type;
					oneRow_tHashOutput_4.src_sys_id = row18.src_sys_id;
					oneRow_tHashOutput_4.sub_sys_id = row18.sub_sys_id;
					oneRow_tHashOutput_4.object_id = row18.object_id;
					oneRow_tHashOutput_4.status = row18.status;
					oneRow_tHashOutput_4.object_nm = row18.object_nm;
		
        tHashFile_tHashOutput_4.put(oneRow_tHashOutput_4);
        nb_line_tHashOutput_4 ++;
 


	tos_count_tHashOutput_4++;

/**
 * [tHashOutput_4 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_3 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

        }
        globalMap.put("tFixedFlowInput_3_NB_LINE", 0);        

 

ok_Hash.put("tFixedFlowInput_3", true);
end_Hash.put("tFixedFlowInput_3", System.currentTimeMillis());




/**
 * [tFixedFlowInput_3 end ] stop
 */

	
	/**
	 * [tHashOutput_4 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_4";

	
globalMap.put("tHashOutput_4_NB_LINE", nb_line_tHashOutput_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row18"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_4", true);
end_Hash.put("tHashOutput_4", System.currentTimeMillis());




/**
 * [tHashOutput_4 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk8", 0, "ok");
								} 
							
							tMSSqlInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_3 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

 



/**
 * [tFixedFlowInput_3 finally ] stop
 */

	
	/**
	 * [tHashOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_4";

	

 



/**
 * [tHashOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_3_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public String src_sys_desc;

				public String getSrc_sys_desc () {
					return this.src_sys_desc;
				}
				
			    public String object_position;

				public String getObject_position () {
					return this.object_position;
				}
				
			    public String priority;

				public String getPriority () {
					return this.priority;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
					this.src_sys_desc = readString(dis);
					
					this.object_position = readString(dis);
					
					this.priority = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// String
				
						writeString(this.src_sys_desc,dos);
					
					// String
				
						writeString(this.object_position,dos);
					
					// String
				
						writeString(this.priority,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_sys_desc="+src_sys_desc);
		sb.append(",object_position="+object_position);
		sb.append(",priority="+priority);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_desc == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_desc);
            			}
            		
        			sb.append("|");
        		
        				if(object_position == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_position);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

	
				TalendThreadPool mtp_tJava_10 = new TalendThreadPool(context.parallel_executions);

				globalMap.put("lockWrite_tJava_10", new Object[0]);
				int threadIdCounter_tJava_10 =0;
						
			int NB_ITERATE_tJava_10 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
            log4jParamters_tFlowToIterate_1.append("Parameters:");
                    log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + (log4jParamters_tFlowToIterate_1) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_1().limitLog4jByte();

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_2", false);
		start_Hash.put("tMSSqlInput_2", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_2";

	
		int tos_count_tMSSqlInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_2 = new StringBuilder();
            log4jParamters_tMSSqlInput_2.append("Parameters:");
                    log4jParamters_tMSSqlInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("QUERY" + " = " + "Relational.ISNULL(globalMap.get(\"MERGE_SUBSYSTEM_FILES\")) ?   \"  SELECT DISTINCT LC.SRC_SYS_ID  	, LC.SUB_SYS_ID  	, LC.OBJECT_ID  	, LC.OBJECT_NM  	, SR.SRC_SYS_DESC\" +  (\"Y\".equals((String)globalMap.get(\"TRIGGER_FILE_BASED\")) && \"Y\".equals((String)globalMap.get(\"VERFIY_ALL_FILES_EXISTS\")) ? \"  	, CASE WHEN ROW_NUMBER() OVER(PARTITION BY LC.SRC_SYS_ID, LC.SUB_SYS_ID ORDER BY LC.OBJECT_ID DESC) = 1 THEN 'LAST'  		WHEN ROW_NUMBER() OVER(PARTITION BY LC.SRC_SYS_ID, LC.SUB_SYS_ID ORDER BY LC.OBJECT_ID ASC) = 1 THEN 'FIRST'      	ELSE 'OTHER' END AS OBJECT_POSITION\"  : \"  	, 'NA' AS OBJECT_POSITION\") + \"  	, LC.PRIORITY  FROM DBO.T_LOAD_CTL_DTL LC  	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR  		ON LC.SRC_SYS_ID = SR.SRC_SYS_ID  			AND LC.SUB_SYS_ID = SR.SUB_SYS_ID\" +  (context.group_id.trim().length() > 0 ? \"   	INNER JOIN DBO.T_TALEND_CONTEXT_LOAD TC  		ON LC.CONTEXT_ID = TC.CONTEXT_ID \" : \" \") + \"  WHERE LC.SRC_SYS_ID = '\" + context.src_sys_id + \"'  	AND LC.SUB_SYS_ID = '\" + context.sub_sys_id + \"'  	AND LC.IS_ACTIVE = 'Y'  	AND LC.STATUS IN (\" + ((String)globalMap.get(\"INCLUDE_STATUS\")) + \")  \" + ((String)globalMap.get(\"RERUN_OBJECT_LIST\")) +  (context.group_id.trim().length() > 0 ? \"   	AND UPPER(TC.CONTEXT_KEY) = 'GROUP_ID'  	AND TC.CONTEXT_VALUE IN \" + context.group_id.trim() : \"\") + \"  ORDER BY LC.PRIORITY\"  :  \"  SELECT DISTINCT LC.SRC_SYS_ID  	, \" + (\"I\".equals(context.job_type) ? \"LC.SUB_SYS_ID\" : \"'' AS SUB_SYS_ID\") + \"  	, LC.OBJECT_ID  	, LC.OBJECT_NM  	, SR.SRC_SYS_DESC      , \" + (\"I\".equals(context.job_type) ? \"CASE WHEN ROW_NUMBER() OVER(PARTITION BY LC.OBJECT_ID ORDER BY LC.SUB_SYS_ID DESC) = 1 THEN 'LAST'  		WHEN ROW_NUMBER() OVER(PARTITION BY LC.OBJECT_ID ORDER BY LC.SUB_SYS_ID ASC) = 1 THEN 'FIRST'      	ELSE 'OTHER' END AS OBJECT_POSITION\" : \"'OTHER' AS OBJECT_POSITION\") + \"  	, LC.PRIORITY  FROM DBO.T_LOAD_CTL_DTL LC  	INNER JOIN (SELECT DISTINCT SRC_SYS_ID, SRC_SYS_DESC FROM DBO.T_SRC_SYS_DCT_TBL) SR  		ON LC.SRC_SYS_ID = SR.SRC_SYS_ID  \" +  (context.group_id.trim().length() > 0 ? \"   	INNER JOIN DBO.T_TALEND_CONTEXT_LOAD TC  		ON LC.CONTEXT_ID = TC.CONTEXT_ID \" : \" \") +  \"WHERE LC.SRC_SYS_ID = '\" + context.src_sys_id + \"'  	AND LC.IS_ACTIVE = 'Y'  	AND LC.STATUS IN (\" + ((String)globalMap.get(\"INCLUDE_STATUS\")) + \")\" + ((String)globalMap.get(\"RERUN_OBJECT_LIST\")) +   (context.group_id.trim().length() > 0 ? \"   	AND UPPER(TC.CONTEXT_KEY) = 'GROUP_ID'  	AND TC.CONTEXT_VALUE IN \" + context.group_id.trim() + \" \" : \" \") +  \"  ORDER BY LC.OBJECT_ID  \"  ");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("src_sys_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sub_sys_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("object_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("object_nm")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("src_sys_desc")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("object_position")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("priority")+"}]");
                log4jParamters_tMSSqlInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_2 - "  + (log4jParamters_tMSSqlInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_2().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_2 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_2  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_2, talendToDBArray_tMSSqlInput_2); 
		    int nb_line_tMSSqlInput_2 = 0;
		    java.sql.Connection conn_tMSSqlInput_2 = null;
		        conn_tMSSqlInput_2 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_2 != null) {
					if(conn_tMSSqlInput_2.getMetaData() != null) {
						
						log.debug("tMSSqlInput_2 - Uses an existing connection with username '" + conn_tMSSqlInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_2 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_2 = conn_tMSSqlInput_2.createStatement();

		    String dbquery_tMSSqlInput_2 = Relational.ISNULL(globalMap.get("MERGE_SUBSYSTEM_FILES")) ? 
"\nSELECT DISTINCT LC.SRC_SYS_ID\n	, LC.SUB_SYS_ID\n	, LC.OBJECT_ID\n	, LC.OBJECT_NM\n	, SR.SRC_SYS_DESC" +
("Y".equals((String)globalMap.get("TRIGGER_FILE_BASED")) && "Y".equals((String)globalMap.get("VERFIY_ALL_FILES_EXISTS")) ? "\n	, CASE WHEN ROW_NUMBER() OVER(PARTITION BY LC.SRC_SYS_ID, LC.SUB_SYS_ID ORDER BY LC.OBJECT_ID DESC) = 1 THEN 'LAST'\n		WHEN ROW_NUMBER() OVER(PARTITION BY LC.SRC_SYS_ID, LC.SUB_SYS_ID ORDER BY LC.OBJECT_ID ASC) = 1 THEN 'FIRST'\n    	ELSE 'OTHER' END AS OBJECT_POSITION"
: "\n	, 'NA' AS OBJECT_POSITION") + "\n	, LC.PRIORITY\nFROM DBO.T_LOAD_CTL_DTL LC\n	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR\n		ON LC.SRC_SYS_ID = SR.SRC_SYS_ID\n			AND LC.SUB_SYS_ID = SR.SUB_SYS_ID" +
(context.group_id.trim().length() > 0 ? " \n	INNER JOIN DBO.T_TALEND_CONTEXT_LOAD TC\n		ON LC.CONTEXT_ID = TC.CONTEXT_ID " : " ") + "\nWHERE LC.SRC_SYS_ID = '" + context.src_sys_id + "'\n	AND LC.SUB_SYS_ID = '" + context.sub_sys_id + "'\n	AND LC.IS_ACTIVE = 'Y'\n	AND LC.STATUS IN (" + ((String)globalMap.get("INCLUDE_STATUS")) + ")\n" + ((String)globalMap.get("RERUN_OBJECT_LIST")) +
(context.group_id.trim().length() > 0 ? " \n	AND UPPER(TC.CONTEXT_KEY) = 'GROUP_ID'\n	AND TC.CONTEXT_VALUE IN " + context.group_id.trim() : "") + "\nORDER BY LC.PRIORITY"
:
"\nSELECT DISTINCT LC.SRC_SYS_ID\n	, " + ("I".equals(context.job_type) ? "LC.SUB_SYS_ID" : "'' AS SUB_SYS_ID") + "\n	, LC.OBJECT_ID\n	, LC.OBJECT_NM\n	, SR.SRC_SYS_DESC\n    , " + ("I".equals(context.job_type) ? "CASE WHEN ROW_NUMBER() OVER(PARTITION BY LC.OBJECT_ID ORDER BY LC.SUB_SYS_ID DESC) = 1 THEN 'LAST'\n		WHEN ROW_NUMBER() OVER(PARTITION BY LC.OBJECT_ID ORDER BY LC.SUB_SYS_ID ASC) = 1 THEN 'FIRST'\n    	ELSE 'OTHER' END AS OBJECT_POSITION" : "'OTHER' AS OBJECT_POSITION") + "\n	, LC.PRIORITY\nFROM DBO.T_LOAD_CTL_DTL LC\n	INNER JOIN (SELECT DISTINCT SRC_SYS_ID, SRC_SYS_DESC FROM DBO.T_SRC_SYS_DCT_TBL) SR\n		ON LC.SRC_SYS_ID = SR.SRC_SYS_ID\n" +
(context.group_id.trim().length() > 0 ? " \n	INNER JOIN DBO.T_TALEND_CONTEXT_LOAD TC\n		ON LC.CONTEXT_ID = TC.CONTEXT_ID " : " ") +
"WHERE LC.SRC_SYS_ID = '" + context.src_sys_id + "'\n	AND LC.IS_ACTIVE = 'Y'\n	AND LC.STATUS IN (" + ((String)globalMap.get("INCLUDE_STATUS")) + ")" + ((String)globalMap.get("RERUN_OBJECT_LIST")) + 
(context.group_id.trim().length() > 0 ? " \n	AND UPPER(TC.CONTEXT_KEY) = 'GROUP_ID'\n	AND TC.CONTEXT_VALUE IN " + context.group_id.trim() + " " : " ") +
"\nORDER BY LC.OBJECT_ID\n"
;
			
                log.debug("tMSSqlInput_2 - Executing the query: '"+dbquery_tMSSqlInput_2+"'.");
			

                       globalMap.put("tMSSqlInput_2_QUERY",dbquery_tMSSqlInput_2);

		    java.sql.ResultSet rs_tMSSqlInput_2 = null;
		try{
		    rs_tMSSqlInput_2 = stmt_tMSSqlInput_2.executeQuery(dbquery_tMSSqlInput_2);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_2 = rs_tMSSqlInput_2.getMetaData();
		    int colQtyInRs_tMSSqlInput_2 = rsmd_tMSSqlInput_2.getColumnCount();

		    String tmpContent_tMSSqlInput_2 = null;
		    
		    
		    	log.debug("tMSSqlInput_2 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_2.next()) {
		        nb_line_tMSSqlInput_2++;
		        
							if(colQtyInRs_tMSSqlInput_2 < 1) {
								row1.src_sys_id = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2.getString(1);
            if(tmpContent_tMSSqlInput_2 != null) {
            	if (talendToDBList_tMSSqlInput_2 .contains(rsmd_tMSSqlInput_2.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.src_sys_id = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_2);
            	} else {
                	row1.src_sys_id = tmpContent_tMSSqlInput_2;
                }
            } else {
                row1.src_sys_id = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_2 < 2) {
								row1.sub_sys_id = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2.getString(2);
            if(tmpContent_tMSSqlInput_2 != null) {
            	if (talendToDBList_tMSSqlInput_2 .contains(rsmd_tMSSqlInput_2.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.sub_sys_id = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_2);
            	} else {
                	row1.sub_sys_id = tmpContent_tMSSqlInput_2;
                }
            } else {
                row1.sub_sys_id = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_2 < 3) {
								row1.object_id = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2.getString(3);
            if(tmpContent_tMSSqlInput_2 != null) {
            	if (talendToDBList_tMSSqlInput_2 .contains(rsmd_tMSSqlInput_2.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.object_id = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_2);
            	} else {
                	row1.object_id = tmpContent_tMSSqlInput_2;
                }
            } else {
                row1.object_id = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_2 < 4) {
								row1.object_nm = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2.getString(4);
            if(tmpContent_tMSSqlInput_2 != null) {
            	if (talendToDBList_tMSSqlInput_2 .contains(rsmd_tMSSqlInput_2.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.object_nm = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_2);
            	} else {
                	row1.object_nm = tmpContent_tMSSqlInput_2;
                }
            } else {
                row1.object_nm = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_2 < 5) {
								row1.src_sys_desc = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2.getString(5);
            if(tmpContent_tMSSqlInput_2 != null) {
            	if (talendToDBList_tMSSqlInput_2 .contains(rsmd_tMSSqlInput_2.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.src_sys_desc = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_2);
            	} else {
                	row1.src_sys_desc = tmpContent_tMSSqlInput_2;
                }
            } else {
                row1.src_sys_desc = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_2 < 6) {
								row1.object_position = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2.getString(6);
            if(tmpContent_tMSSqlInput_2 != null) {
            	if (talendToDBList_tMSSqlInput_2 .contains(rsmd_tMSSqlInput_2.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.object_position = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_2);
            	} else {
                	row1.object_position = tmpContent_tMSSqlInput_2;
                }
            } else {
                row1.object_position = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_2 < 7) {
								row1.priority = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_2 = rs_tMSSqlInput_2.getString(7);
            if(tmpContent_tMSSqlInput_2 != null) {
            	if (talendToDBList_tMSSqlInput_2 .contains(rsmd_tMSSqlInput_2.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.priority = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_2);
            	} else {
                	row1.priority = tmpContent_tMSSqlInput_2;
                }
            } else {
                row1.priority = null;
            }
		                    }
					
						log.debug("tMSSqlInput_2 - Retrieving the record " + nb_line_tMSSqlInput_2 + ".");
					





 



/**
 * [tMSSqlInput_2 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_2 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_2";

	

 


	tos_count_tMSSqlInput_2++;

/**
 * [tMSSqlInput_2 main ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.src_sys_id, value=")  + (row1.src_sys_id)  + (".") );            
            globalMap.put("row1.src_sys_id", row1.src_sys_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.sub_sys_id, value=")  + (row1.sub_sys_id)  + (".") );            
            globalMap.put("row1.sub_sys_id", row1.sub_sys_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.object_id, value=")  + (row1.object_id)  + (".") );            
            globalMap.put("row1.object_id", row1.object_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.object_nm, value=")  + (row1.object_nm)  + (".") );            
            globalMap.put("row1.object_nm", row1.object_nm);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.src_sys_desc, value=")  + (row1.src_sys_desc)  + (".") );            
            globalMap.put("row1.src_sys_desc", row1.src_sys_desc);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.object_position, value=")  + (row1.object_position)  + (".") );            
            globalMap.put("row1.object_position", row1.object_position);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row1.priority, value=")  + (row1.priority)  + (".") );            
            globalMap.put("row1.priority", row1.priority);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_1)  + (".") );
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	NB_ITERATE_tJava_10++;
	
				
			class tJava_10Thread extends TalendThread {//implements routines.system.TalendThreadPool.PropertySettable
				class ThreadedMap extends java.util.HashMap<String, Object> {
			
					private static final long serialVersionUID = 0L;
		
					public ThreadedMap(java.util.Map<String, Object> globalMap) {
						super(globalMap);
					}
		
					@Override
					public Object put(String key, Object value) {
						
						synchronized (Jb_Ingestion_Master_Job.this.obj) {
						
							super.put(key, value);
							return Jb_Ingestion_Master_Job.this.globalMap.put(key, value);
						
						}
						
					}
				}	
				
				private java.util.Map<String, Object> globalMap = null;
				boolean isRunning = false;
				String iterateId = "";
				
				
						row1Struct row1 = new row1Struct();

					
	
				public tJava_10Thread(java.util.Map<String, Object> globalMap,row1Struct row1, int threadID) {
					super();
					
		        		if(row1 != null){
		            		
		    					this.row1.src_sys_id = row1.src_sys_id;
		    	            
		    					this.row1.sub_sys_id = row1.sub_sys_id;
		    	            
		    					this.row1.object_id = row1.object_id;
		    	            
		    					this.row1.object_nm = row1.object_nm;
		    	            
		    					this.row1.src_sys_desc = row1.src_sys_desc;
		    	            
		    					this.row1.object_position = row1.object_position;
		    	            
		    					this.row1.priority = row1.priority;
		    	            
		        		}
		        		
					
						synchronized (Jb_Ingestion_Master_Job.this.obj) {
							this.globalMap = new ThreadedMap(globalMap);
					
						}
					iterateId = "." + threadID;
					
					
				}


				public void run() {		
		
					java.util.Map threadRunResultMap = new java.util.HashMap();
					threadRunResultMap.put("errorCode", null);
					threadRunResultMap.put("status", "");
					threadLocal.set(threadRunResultMap);
					
					this.isRunning = true;
					String currentComponent = "";
					java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();
					
					try {			
						
							if(execStat){
								runStat.updateStatOnConnection("iterate1",0,"exec"+iterateId);
							}				
						

	
	/**
	 * [tJava_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_10", false);
		start_Hash.put("tJava_10", System.currentTimeMillis());
		
	
	currentComponent="tJava_10";

	
		int tos_count_tJava_10 = 0;
		
    	class BytesLimit65535_tJava_10{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_10().limitLog4jByte();



 



/**
 * [tJava_10 begin ] stop
 */
	
	/**
	 * [tJava_10 main ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 


	tos_count_tJava_10++;

/**
 * [tJava_10 main ] stop
 */
	
	/**
	 * [tJava_10 end ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 

ok_Hash.put("tJava_10", true);
end_Hash.put("tJava_10", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk18", 0, "ok");
				}
				tJava_4Process(globalMap);



/**
 * [tJava_10 end ] stop
 */
					if(execStat){
						runStat.updateStatOnConnection("iterate1",2,"exec"+iterateId);
					}				
				
						} catch (java.lang.Exception e) {
							this.status = "failure";
							Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
							if (localErrorCode != null) {
								if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
									this.errorCode = localErrorCode;
								}
							}					
				            		            
		                    TalendException te = new TalendException(e, currentComponent, globalMap);
							
							this.exception = te;
							talendThreadPool.setErrorThread(this);
				            talendThreadPool.stopAllWorkers();
	
						} catch (java.lang.Error error){
							this.status = "failure";
							Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
							if (localErrorCode != null) {
								if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
									this.errorCode = localErrorCode;
								}
							}					
							this.error = error;				            		            
							talendThreadPool.setErrorThread(this);
				            talendThreadPool.stopAllWorkers();
						} finally {
							try{
								
	
	/**
	 * [tJava_10 finally ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 



/**
 * [tJava_10 finally ] stop
 */
							}catch(java.lang.Exception e){	
								//ignore
							}catch(java.lang.Error error){
								//ignore
							}
							resourceMap = null;
						}
						this.isRunning = false;
				
						Integer localErrorCode = (Integer) (((java.util.Map) threadLocal.get()).get("errorCode"));
						String localStatus = (String) (((java.util.Map) threadLocal.get()).get("status"));
						if (localErrorCode != null) {
							if (this.errorCode == null || localErrorCode.compareTo(this.errorCode) > 0) {
								this.errorCode = localErrorCode;
							}
						} 
						if (!this.status.equals("failure")) {
							this.status = localStatus;
						}
						
						talendThreadPool.getTalendThreadResult().setErrorCode(this.errorCode);
						talendThreadPool.getTalendThreadResult().setStatus(this.status);						
					}
				}

				tJava_10Thread bt_tJava_10 = new tJava_10Thread(globalMap,row1,threadIdCounter_tJava_10++);
				mtp_tJava_10.execute(bt_tJava_10);

				







	
	/**
	 * [tMSSqlInput_2 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_2";

	

	}
}finally{
	stmt_tMSSqlInput_2.close();

}
globalMap.put("tMSSqlInput_2_NB_LINE",nb_line_tMSSqlInput_2);
	    		log.debug("tMSSqlInput_2 - Retrieved records count: "+nb_line_tMSSqlInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_2 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_2", true);
end_Hash.put("tMSSqlInput_2", System.currentTimeMillis());




/**
 * [tMSSqlInput_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());


			mtp_tJava_10.waitForEndOfQueue();
			
			TalendThread errorThread_tJava_10 = mtp_tJava_10.getErrorThread();

	if(errorThread_tJava_10 != null) {
		if (errorThread_tJava_10.errorCode != null) {
			if (errorCode == null
					|| errorThread_tJava_10.errorCode.compareTo(errorCode) > 0) {
				errorCode = errorThread_tJava_10.errorCode;
			}
		} 
		if (!status.equals("failure")) {
			status = errorThread_tJava_10.status;
		}
		if(errorThread_tJava_10.exception!=null){
			throw errorThread_tJava_10.exception;
		}
		if(errorThread_tJava_10.error!=null){
			throw errorThread_tJava_10.error;
		}
	}else{				
		Integer threadErrorCode = mtp_tJava_10.getTalendThreadResult().getErrorCode();
		String threadStatus = mtp_tJava_10.getTalendThreadResult().getStatus();
		
		if (threadErrorCode != null) {
			if (errorCode == null
					|| threadErrorCode.compareTo(errorCode) > 0) {
				errorCode = threadErrorCode;
			}
		} 
		if (!status.equals("failure")) {
			status = threadStatus;
		}
	 }			
			
			


/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_2 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_2";

	

 



/**
 * [tMSSqlInput_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_4", false);
		start_Hash.put("tJava_4", System.currentTimeMillis());
		
	
	currentComponent="tJava_4";

	
		int tos_count_tJava_4 = 0;
		
    	class BytesLimit65535_tJava_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_4().limitLog4jByte();



 



/**
 * [tJava_4 begin ] stop
 */
	
	/**
	 * [tJava_4 main ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 


	tos_count_tJava_4++;

/**
 * [tJava_4 main ] stop
 */
	
	/**
	 * [tJava_4 end ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 

ok_Hash.put("tJava_4", true);
end_Hash.put("tJava_4", System.currentTimeMillis());

   			if ("MSSQL".equals((String)globalMap.get("SOURCE_SYSTEM_TYPE")) && ("I".equals((String)globalMap.get("JOB_TYPE")) || "B".equals((String)globalMap.get("JOB_TYPE")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				
    			tRunJob_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}
   			if ("FILE".equals((String)globalMap.get("SOURCE_SYSTEM_TYPE")) && ("I".equals((String)globalMap.get("JOB_TYPE")) || "B".equals((String)globalMap.get("JOB_TYPE")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				
    			tRunJob_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}
   			if ("ORACLE".equals((String)globalMap.get("SOURCE_SYSTEM_TYPE")) && ("I".equals((String)globalMap.get("JOB_TYPE")) || "B".equals((String)globalMap.get("JOB_TYPE")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "true");
					}
				
    			tRunJob_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "false");
					}   	 
   				}
   			if ("DB2".equals((String)globalMap.get("SOURCE_SYSTEM_TYPE")) && ("I".equals((String)globalMap.get("JOB_TYPE")) || "B".equals((String)globalMap.get("JOB_TYPE")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "true");
					}
				
    			tRunJob_4Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "false");
					}   	 
   				}



/**
 * [tJava_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tJava_11Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_4 finally ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_4_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_1", false);
		start_Hash.put("tRunJob_1", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_1";

	
		int tos_count_tRunJob_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_1 = new StringBuilder();
            log4jParamters_tRunJob_1.append("Parameters:");
                    log4jParamters_tRunJob_1.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_1.append(" | ");
                    log4jParamters_tRunJob_1.append("PROCESS" + " = " + "Jb_Load_MSSQL_ADLS_Child");
                log4jParamters_tRunJob_1.append(" | ");
                    log4jParamters_tRunJob_1.append("USE_INDEPENDENT_PROCESS" + " = " + "true");
                log4jParamters_tRunJob_1.append(" | ");
                    log4jParamters_tRunJob_1.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_1.append(" | ");
                    log4jParamters_tRunJob_1.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                log4jParamters_tRunJob_1.append(" | ");
                    log4jParamters_tRunJob_1.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("src_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.src_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("sub_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.sub_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("object_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_id\"))")+"}, {PARAM_NAME_COLUMN="+("keyfile_path")+", PARAM_VALUE_COLUMN="+("context.keyfile_path")+"}, {PARAM_NAME_COLUMN="+("prop_file_path")+", PARAM_VALUE_COLUMN="+("context.prop_file_path")+"}, {PARAM_NAME_COLUMN="+("root_pid")+", PARAM_VALUE_COLUMN="+("pid")+"}, {PARAM_NAME_COLUMN="+("object_nm")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_nm\"))")+"}, {PARAM_NAME_COLUMN="+("object_position")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_position\"))")+"}, {PARAM_NAME_COLUMN="+("batch_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"BATCH_ID\"))")+"}]");
                log4jParamters_tRunJob_1.append(" | ");
                    log4jParamters_tRunJob_1.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_1 - "  + (log4jParamters_tRunJob_1) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_1().limitLog4jByte();
class DealChildJobLibrary_tRunJob_1 {

	public String replaceJarPathsFromCrcMap(String originalClassPathLine) throws java.lang.Exception {
		String classPathLine = "";
		String crcMapPath = new java.io.File("../crcMap").getCanonicalPath();
		if (isNeedAddLibsPath( crcMapPath)) {
			java.util.Map<String, String> crcMap = null;
			java.io.ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(crcMapPath));
			crcMap = (java.util.Map<String, String>) ois.readObject();
			ois.close();
			classPathLine = addLibsPath(originalClassPathLine, crcMap);
		} else {
			classPathLine = originalClassPathLine;
		}
		return classPathLine;
	}
	
	private boolean isNeedAddLibsPath(String crcMapPath) {
		if (!(new java.io.File(crcMapPath).exists())) {// when not use cache
			return false;
		}
		return true;
	}
	
	
	private String addLibsPath(String line, java.util.Map<String, String> crcMap) {
		for (java.util.Map.Entry<String, String> entry : crcMap.entrySet()) {
			line = adaptLibPaths(line, entry);
		}
		return line;
	}
	
	private String adaptLibPaths(String line, java.util.Map.Entry<String, String> entry) {
		String jarName = entry.getValue();
		String crc = entry.getKey();
		String libStringFinder = "../lib/" + jarName;
		if (line.contains(libStringFinder)) {
			line = line.replace(libStringFinder, "../../../cache/lib/" + crc + "/" + jarName);
		} else if (line.contains(":$ROOT_PATH/" + jarName + ":")) {
			line = line.replace(":$ROOT_PATH/" + jarName + ":", ":$ROOT_PATH/../../../cache/lib/" + crc + "/" + jarName + ":");
		} else if (line.contains(";" + jarName + ";")) {
			line = line.replace(";" + jarName + ";", ";../../../cache/lib/" + crc + "/" + jarName + ";");
		}
		return line;
	}
	
}
	DealChildJobLibrary_tRunJob_1 dealChildJobLibrary_tRunJob_1 = new DealChildJobLibrary_tRunJob_1();


 



/**
 * [tRunJob_1 begin ] stop
 */
	
	/**
	 * [tRunJob_1 main ] start
	 */

	

	
	
	currentComponent="tRunJob_1";

	
	java.util.List<String> paraList_tRunJob_1 = new java.util.ArrayList<String>();
	
			String osName_tRunJob_1 = System.getProperty("os.name");
			if (osName_tRunJob_1 != null && osName_tRunJob_1.toLowerCase().startsWith("win")){
	      		
		      			paraList_tRunJob_1.add("java");
		      		
		      					paraList_tRunJob_1.add("-Xms256M");
		      				
		      					paraList_tRunJob_1.add("-Xmx1024M");
		      				
		      					paraList_tRunJob_1.add("-cp");
		      				
		        				paraList_tRunJob_1.add(dealChildJobLibrary_tRunJob_1.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/antlr-runtime-3.5.2.jar;../lib/commons-codec-1.7.jar;../lib/dom4j-1.6.1.jar;../lib/ini4j-0.5.1.jar;../lib/jakarta-oro-2.0.8.jar;../lib/jtds-1.3.1-patch.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/talend_DB_mssqlUtil.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talendcsv.jar;../lib/thashfile-2.0-20170329.jar;jb_load_mssql_adls_child_0_1.jar;"));
		      				
		      					paraList_tRunJob_1.add("cerebro.jb_load_mssql_adls_child_0_1.Jb_Load_MSSQL_ADLS_Child");
		      				
		      					paraList_tRunJob_1.add("--father_pid="+pid);
		      				
		      					paraList_tRunJob_1.add("--root_pid="+rootPid);
		      				
		      					paraList_tRunJob_1.add("--father_node=tRunJob_1");
		      				
		      					paraList_tRunJob_1.add("--context=PROD");
		      				
		      					paraList_tRunJob_1.add("%*");
		      				
			} else {
	      		
						paraList_tRunJob_1.add("java");
		      		
								paraList_tRunJob_1.add("-Xms256M");
		      				
								paraList_tRunJob_1.add("-Xmx1024M");
		      				
								paraList_tRunJob_1.add("-cp");
		      				
								paraList_tRunJob_1.add(dealChildJobLibrary_tRunJob_1.replaceJarPathsFromCrcMap(".:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/antlr-runtime-3.5.2.jar:$ROOT_PATH/../lib/commons-codec-1.7.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/ini4j-0.5.1.jar:$ROOT_PATH/../lib/jakarta-oro-2.0.8.jar:$ROOT_PATH/../lib/jtds-1.3.1-patch.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/../lib/org.talend.dataquality.parser.jar:$ROOT_PATH/../lib/talend_DB_mssqlUtil.jar:$ROOT_PATH/../lib/talend_file_enhanced_20070724.jar:$ROOT_PATH/../lib/talendcsv.jar:$ROOT_PATH/../lib/thashfile-2.0-20170329.jar:$ROOT_PATH/jb_load_mssql_adls_child_0_1.jar:").replace("$ROOT_PATH",System.getProperty("user.dir")));
		      				
								paraList_tRunJob_1.add("cerebro.jb_load_mssql_adls_child_0_1.Jb_Load_MSSQL_ADLS_Child");
		      				
								paraList_tRunJob_1.add("--father_pid="+pid);
		      				
								paraList_tRunJob_1.add("--root_pid="+rootPid);
		      				
								paraList_tRunJob_1.add("--father_node=tRunJob_1");
		      				
								paraList_tRunJob_1.add("--context=PROD");
		      				
								paraList_tRunJob_1.add("$@");
		      				
			}    
	  	
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_1.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_1.add("--stat_port=" + null);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_1.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_1 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_1 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_1".equals(tRunJobName_tRunJob_1) && childResumePath_tRunJob_1 != null){
		paraList_tRunJob_1.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_1.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_1");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_1 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_1 = null;

	
		obj_tRunJob_1 = ((String)globalMap.get("row1.src_sys_id"));
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param src_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param src_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("src_sys_id", obj_tRunJob_1);
	
		obj_tRunJob_1 = ((String)globalMap.get("row1.sub_sys_id"));
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param sub_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param sub_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("sub_sys_id", obj_tRunJob_1);
	
		obj_tRunJob_1 = ((String)globalMap.get("row1.object_id"));
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param object_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param object_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("object_id", obj_tRunJob_1);
	
		obj_tRunJob_1 = context.keyfile_path;
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param keyfile_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param keyfile_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("keyfile_path", obj_tRunJob_1);
	
		obj_tRunJob_1 = context.prop_file_path;
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param prop_file_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param prop_file_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("prop_file_path", obj_tRunJob_1);
	
		obj_tRunJob_1 = pid;
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param root_pid=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param root_pid=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("root_pid", obj_tRunJob_1);
	
		obj_tRunJob_1 = ((String)globalMap.get("row1.object_nm"));
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param object_nm=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param object_nm=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("object_nm", obj_tRunJob_1);
	
		obj_tRunJob_1 = ((String)globalMap.get("row1.object_position"));
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param object_position=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param object_position=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("object_position", obj_tRunJob_1);
	
		obj_tRunJob_1 = ((String)globalMap.get("BATCH_ID"));
		if(obj_tRunJob_1!=null) {
			paraList_tRunJob_1.add("--context_param batch_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_1));
		} else {
			paraList_tRunJob_1.add("--context_param batch_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_1.put("batch_id", obj_tRunJob_1);
	
	
		Runtime runtime_tRunJob_1 = Runtime.getRuntime();
		final Process ps_tRunJob_1;
		ps_tRunJob_1 = runtime_tRunJob_1.exec((String[])paraList_tRunJob_1.toArray(new String[paraList_tRunJob_1.size()]));

		Thread normal_tRunJob_1 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_1.getInputStream()));
					String line = "";
					try {
						while((line = reader.readLine()) != null) {
						System.out.println(line);
						}
					} finally {
					reader.close();
					}
				} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_1 - " + ioe.getMessage());
					
					ioe.printStackTrace();
				}
	    	}
  		};
		
			log.info("tRunJob_1 - The child job 'Jb_Load_MSSQL_ADLS_Child' starts on the version '0.1' with the context 'PROD'.");
		
		normal_tRunJob_1.start();
		
			log.info("tRunJob_1 - The child job 'Jb_Load_MSSQL_ADLS_Child' is done.");
		

		final StringBuffer errorMsg_tRunJob_1 = new StringBuffer();
		Thread error_tRunJob_1 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_1.getErrorStream()));
					String line = "";
        			try {
          				while((line = reader.readLine()) != null) {
            				errorMsg_tRunJob_1.append(line).append("\n");
          				}
        			} finally {
          				reader.close();
        			}
      			} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_1 - " + ioe.getMessage());
					
			        ioe.printStackTrace();
      			}
    		}
		};
		error_tRunJob_1.start();

		//0 indicates normal termination	
		int result_tRunJob_1 = ps_tRunJob_1.waitFor();
		normal_tRunJob_1.join(10000);
		error_tRunJob_1.join(10000);
  
		globalMap.put("tRunJob_1_CHILD_RETURN_CODE",result_tRunJob_1);
		if(result_tRunJob_1 != 0){
   			globalMap.put("tRunJob_1_CHILD_EXCEPTION_STACKTRACE",errorMsg_tRunJob_1.toString());
			
				
					log.error("tRunJob_1 - Child job returns " + result_tRunJob_1 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_1.toString());
				
				System.err.println("Child job returns " + result_tRunJob_1 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_1.toString());
			
  		}

		
 


	tos_count_tRunJob_1++;

/**
 * [tRunJob_1 main ] stop
 */
	
	/**
	 * [tRunJob_1 end ] start
	 */

	

	
	
	currentComponent="tRunJob_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_1 - "  + ("Done.") );

ok_Hash.put("tRunJob_1", true);
end_Hash.put("tRunJob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk7", 0, "ok");
				}
				tJava_5Process(globalMap);



/**
 * [tRunJob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_1 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_1";

	

 



/**
 * [tRunJob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";

	
		int tos_count_tJava_5 = 0;
		
    	class BytesLimit65535_tJava_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_5().limitLog4jByte();


globalMap.put("SUB_JOB_STATUS", (((Integer)globalMap.get("tRunJob_1_CHILD_RETURN_CODE")) == 0 ? "C" : "F"));

globalMap.put("PROCESS_TYPE", "INGESTION");


 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk13", 0, "ok");
				}
				tFixedFlowInput_1Process(globalMap);



/**
 * [tJava_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_5_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.status = readString(dis);
					
					this.object_nm = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",status="+status);
		sb.append(",object_nm="+object_nm);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row6Struct row6 = new row6Struct();




	
	/**
	 * [tHashOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_1", false);
		start_Hash.put("tHashOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_1 = 0;
		
    	class BytesLimit65535_tHashOutput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_1().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row18Struct> tHashFile_tHashOutput_1 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_1.getKeyMap().put("tHashFile_Jb_Ingestion_Master_Job_" +pid + "_tHashOutput_1", "tHashFile_Jb_Ingestion_Master_Job_" + pid + "_tHashOutput_4");
        int nb_line_tHashOutput_1 = 0;
 



/**
 * [tHashOutput_1 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_1", false);
		start_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_1";

	
		int tos_count_tFixedFlowInput_1 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_1().limitLog4jByte();

	    for (int i_tFixedFlowInput_1 = 0 ; i_tFixedFlowInput_1 < 1 ; i_tFixedFlowInput_1++) {
	                	            	
    	            		row6.process_type = ((String)globalMap.get("PROCESS_TYPE"));
    	            	        	            	
    	            		row6.src_sys_id = ((String)globalMap.get("row1.src_sys_id"));
    	            	        	            	
    	            		row6.sub_sys_id = ((String)globalMap.get("row1.sub_sys_id"));
    	            	        	            	
    	            		row6.object_id = ((String)globalMap.get("row1.object_id"));
    	            	        	            	
    	            		row6.status = ((String)globalMap.get("SUB_JOB_STATUS"));
    	            	        	            	
    	            		row6.object_nm = ((String)globalMap.get("row1.object_nm"));
    	            	
 



/**
 * [tFixedFlowInput_1 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 


	tos_count_tFixedFlowInput_1++;

/**
 * [tFixedFlowInput_1 main ] stop
 */

	
	/**
	 * [tHashOutput_1 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_1 == null){
			tHashFile_tHashOutput_1 = mf_tHashOutput_1.getAdvancedMemoryHashFile("tHashFile_Jb_Ingestion_Master_Job_" + pid +"_tHashOutput_4");
			mf_tHashOutput_1.getResourceMap().put("tHashFile_Jb_Ingestion_Master_Job_" + pid +"_tHashOutput_1", tHashFile_tHashOutput_1);
		}
		row18Struct oneRow_tHashOutput_1 = new row18Struct();
			oneRow_tHashOutput_1.process_type = row6.process_type;
			oneRow_tHashOutput_1.src_sys_id = row6.src_sys_id;
			oneRow_tHashOutput_1.sub_sys_id = row6.sub_sys_id;
			oneRow_tHashOutput_1.object_id = row6.object_id;
			oneRow_tHashOutput_1.status = row6.status;
			oneRow_tHashOutput_1.object_nm = row6.object_nm;
        tHashFile_tHashOutput_1.put(oneRow_tHashOutput_1);
        nb_line_tHashOutput_1 ++;	
 


	tos_count_tHashOutput_1++;

/**
 * [tHashOutput_1 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

        }
        globalMap.put("tFixedFlowInput_1_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_1", true);
end_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());




/**
 * [tFixedFlowInput_1 end ] stop
 */

	
	/**
	 * [tHashOutput_1 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	
globalMap.put("tHashOutput_1_NB_LINE", nb_line_tHashOutput_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_1", true);
end_Hash.put("tHashOutput_1", System.currentTimeMillis());




/**
 * [tHashOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_1 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 



/**
 * [tFixedFlowInput_1 finally ] stop
 */

	
	/**
	 * [tHashOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	

 



/**
 * [tHashOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_2", false);
		start_Hash.put("tRunJob_2", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_2";

	
		int tos_count_tRunJob_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_2 = new StringBuilder();
            log4jParamters_tRunJob_2.append("Parameters:");
                    log4jParamters_tRunJob_2.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("PROCESS" + " = " + "Jb_Load_File_ADLS_Child");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("USE_INDEPENDENT_PROCESS" + " = " + "true");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("src_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.src_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("sub_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.sub_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("object_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_id\"))")+"}, {PARAM_NAME_COLUMN="+("keyfile_path")+", PARAM_VALUE_COLUMN="+("context.keyfile_path")+"}, {PARAM_NAME_COLUMN="+("prop_file_path")+", PARAM_VALUE_COLUMN="+("context.prop_file_path")+"}, {PARAM_NAME_COLUMN="+("root_pid")+", PARAM_VALUE_COLUMN="+("pid")+"}, {PARAM_NAME_COLUMN="+("object_nm")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_nm\"))")+"}, {PARAM_NAME_COLUMN="+("object_position")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_position\"))")+"}, {PARAM_NAME_COLUMN="+("batch_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"BATCH_ID\"))")+"}]");
                log4jParamters_tRunJob_2.append(" | ");
                    log4jParamters_tRunJob_2.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + (log4jParamters_tRunJob_2) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_2().limitLog4jByte();
class DealChildJobLibrary_tRunJob_2 {

	public String replaceJarPathsFromCrcMap(String originalClassPathLine) throws java.lang.Exception {
		String classPathLine = "";
		String crcMapPath = new java.io.File("../crcMap").getCanonicalPath();
		if (isNeedAddLibsPath( crcMapPath)) {
			java.util.Map<String, String> crcMap = null;
			java.io.ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(crcMapPath));
			crcMap = (java.util.Map<String, String>) ois.readObject();
			ois.close();
			classPathLine = addLibsPath(originalClassPathLine, crcMap);
		} else {
			classPathLine = originalClassPathLine;
		}
		return classPathLine;
	}
	
	private boolean isNeedAddLibsPath(String crcMapPath) {
		if (!(new java.io.File(crcMapPath).exists())) {// when not use cache
			return false;
		}
		return true;
	}
	
	
	private String addLibsPath(String line, java.util.Map<String, String> crcMap) {
		for (java.util.Map.Entry<String, String> entry : crcMap.entrySet()) {
			line = adaptLibPaths(line, entry);
		}
		return line;
	}
	
	private String adaptLibPaths(String line, java.util.Map.Entry<String, String> entry) {
		String jarName = entry.getValue();
		String crc = entry.getKey();
		String libStringFinder = "../lib/" + jarName;
		if (line.contains(libStringFinder)) {
			line = line.replace(libStringFinder, "../../../cache/lib/" + crc + "/" + jarName);
		} else if (line.contains(":$ROOT_PATH/" + jarName + ":")) {
			line = line.replace(":$ROOT_PATH/" + jarName + ":", ":$ROOT_PATH/../../../cache/lib/" + crc + "/" + jarName + ":");
		} else if (line.contains(";" + jarName + ";")) {
			line = line.replace(";" + jarName + ";", ";../../../cache/lib/" + crc + "/" + jarName + ";");
		}
		return line;
	}
	
}
	DealChildJobLibrary_tRunJob_2 dealChildJobLibrary_tRunJob_2 = new DealChildJobLibrary_tRunJob_2();


 



/**
 * [tRunJob_2 begin ] stop
 */
	
	/**
	 * [tRunJob_2 main ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	
	java.util.List<String> paraList_tRunJob_2 = new java.util.ArrayList<String>();
	
			String osName_tRunJob_2 = System.getProperty("os.name");
			if (osName_tRunJob_2 != null && osName_tRunJob_2.toLowerCase().startsWith("win")){
	      		
		      			paraList_tRunJob_2.add("java");
		      		
		      					paraList_tRunJob_2.add("-Xms256M");
		      				
		      					paraList_tRunJob_2.add("-Xmx4096M");
		      				
		      					paraList_tRunJob_2.add("-cp");
		      				
		        				paraList_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/ant.jar;../lib/antlr-runtime-3.5.2.jar;../lib/checkArchive.jar;../lib/commons-codec-1.7.jar;../lib/commons-compress-1.10.jar;../lib/dom4j-1.6.1.jar;../lib/filecopy.jar;../lib/ini4j-0.5.1.jar;../lib/jakarta-oro-2.0.8.jar;../lib/jtds-1.3.1-patch.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/talend_DB_mssqlUtil.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talendcsv.jar;../lib/talendzip.jar;../lib/thashfile-2.0-20170329.jar;../lib/zip4j_1.3.1.jar;jb_load_file_adls_child_0_1.jar;"));
		      				
		      					paraList_tRunJob_2.add("cerebro.jb_load_file_adls_child_0_1.Jb_Load_File_ADLS_Child");
		      				
		      					paraList_tRunJob_2.add("--father_pid="+pid);
		      				
		      					paraList_tRunJob_2.add("--root_pid="+rootPid);
		      				
		      					paraList_tRunJob_2.add("--father_node=tRunJob_2");
		      				
		      					paraList_tRunJob_2.add("--context=PROD");
		      				
		      					paraList_tRunJob_2.add("%*");
		      				
			} else {
	      		
						paraList_tRunJob_2.add("java");
		      		
								paraList_tRunJob_2.add("-Xms256M");
		      				
								paraList_tRunJob_2.add("-Xmx4096M");
		      				
								paraList_tRunJob_2.add("-cp");
		      				
								paraList_tRunJob_2.add(dealChildJobLibrary_tRunJob_2.replaceJarPathsFromCrcMap(".:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/ant.jar:$ROOT_PATH/../lib/antlr-runtime-3.5.2.jar:$ROOT_PATH/../lib/checkArchive.jar:$ROOT_PATH/../lib/commons-codec-1.7.jar:$ROOT_PATH/../lib/commons-compress-1.10.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/filecopy.jar:$ROOT_PATH/../lib/ini4j-0.5.1.jar:$ROOT_PATH/../lib/jakarta-oro-2.0.8.jar:$ROOT_PATH/../lib/jtds-1.3.1-patch.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/../lib/org.talend.dataquality.parser.jar:$ROOT_PATH/../lib/talend_DB_mssqlUtil.jar:$ROOT_PATH/../lib/talend_file_enhanced_20070724.jar:$ROOT_PATH/../lib/talendcsv.jar:$ROOT_PATH/../lib/talendzip.jar:$ROOT_PATH/../lib/thashfile-2.0-20170329.jar:$ROOT_PATH/../lib/zip4j_1.3.1.jar:$ROOT_PATH/jb_load_file_adls_child_0_1.jar:").replace("$ROOT_PATH",System.getProperty("user.dir")));
		      				
								paraList_tRunJob_2.add("cerebro.jb_load_file_adls_child_0_1.Jb_Load_File_ADLS_Child");
		      				
								paraList_tRunJob_2.add("--father_pid="+pid);
		      				
								paraList_tRunJob_2.add("--root_pid="+rootPid);
		      				
								paraList_tRunJob_2.add("--father_node=tRunJob_2");
		      				
								paraList_tRunJob_2.add("--context=PROD");
		      				
								paraList_tRunJob_2.add("$@");
		      				
			}    
	  	
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_2.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_2.add("--stat_port=" + null);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_2.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_2 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_2 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_2".equals(tRunJobName_tRunJob_2) && childResumePath_tRunJob_2 != null){
		paraList_tRunJob_2.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_2.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_2");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_2 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_2 = null;

	
		obj_tRunJob_2 = ((String)globalMap.get("row1.src_sys_id"));
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param src_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param src_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("src_sys_id", obj_tRunJob_2);
	
		obj_tRunJob_2 = ((String)globalMap.get("row1.sub_sys_id"));
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param sub_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param sub_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("sub_sys_id", obj_tRunJob_2);
	
		obj_tRunJob_2 = ((String)globalMap.get("row1.object_id"));
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param object_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param object_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("object_id", obj_tRunJob_2);
	
		obj_tRunJob_2 = context.keyfile_path;
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param keyfile_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param keyfile_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("keyfile_path", obj_tRunJob_2);
	
		obj_tRunJob_2 = context.prop_file_path;
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param prop_file_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param prop_file_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("prop_file_path", obj_tRunJob_2);
	
		obj_tRunJob_2 = pid;
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param root_pid=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param root_pid=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("root_pid", obj_tRunJob_2);
	
		obj_tRunJob_2 = ((String)globalMap.get("row1.object_nm"));
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param object_nm=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param object_nm=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("object_nm", obj_tRunJob_2);
	
		obj_tRunJob_2 = ((String)globalMap.get("row1.object_position"));
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param object_position=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param object_position=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("object_position", obj_tRunJob_2);
	
		obj_tRunJob_2 = ((String)globalMap.get("BATCH_ID"));
		if(obj_tRunJob_2!=null) {
			paraList_tRunJob_2.add("--context_param batch_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_2));
		} else {
			paraList_tRunJob_2.add("--context_param batch_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_2.put("batch_id", obj_tRunJob_2);
	
	
		Runtime runtime_tRunJob_2 = Runtime.getRuntime();
		final Process ps_tRunJob_2;
		ps_tRunJob_2 = runtime_tRunJob_2.exec((String[])paraList_tRunJob_2.toArray(new String[paraList_tRunJob_2.size()]));

		Thread normal_tRunJob_2 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_2.getInputStream()));
					String line = "";
					try {
						while((line = reader.readLine()) != null) {
						System.out.println(line);
						}
					} finally {
					reader.close();
					}
				} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_2 - " + ioe.getMessage());
					
					ioe.printStackTrace();
				}
	    	}
  		};
		
			log.info("tRunJob_2 - The child job 'Jb_Load_File_ADLS_Child' starts on the version '0.1' with the context 'PROD'.");
		
		normal_tRunJob_2.start();
		
			log.info("tRunJob_2 - The child job 'Jb_Load_File_ADLS_Child' is done.");
		

		final StringBuffer errorMsg_tRunJob_2 = new StringBuffer();
		Thread error_tRunJob_2 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_2.getErrorStream()));
					String line = "";
        			try {
          				while((line = reader.readLine()) != null) {
            				errorMsg_tRunJob_2.append(line).append("\n");
          				}
        			} finally {
          				reader.close();
        			}
      			} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_2 - " + ioe.getMessage());
					
			        ioe.printStackTrace();
      			}
    		}
		};
		error_tRunJob_2.start();

		//0 indicates normal termination	
		int result_tRunJob_2 = ps_tRunJob_2.waitFor();
		normal_tRunJob_2.join(10000);
		error_tRunJob_2.join(10000);
  
		globalMap.put("tRunJob_2_CHILD_RETURN_CODE",result_tRunJob_2);
		if(result_tRunJob_2 != 0){
   			globalMap.put("tRunJob_2_CHILD_EXCEPTION_STACKTRACE",errorMsg_tRunJob_2.toString());
			
				
					log.error("tRunJob_2 - Child job returns " + result_tRunJob_2 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_2.toString());
				
				System.err.println("Child job returns " + result_tRunJob_2 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_2.toString());
			
  		}

		
 


	tos_count_tRunJob_2++;

/**
 * [tRunJob_2 main ] stop
 */
	
	/**
	 * [tRunJob_2 end ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_2 - "  + ("Done.") );

ok_Hash.put("tRunJob_2", true);
end_Hash.put("tRunJob_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk11", 0, "ok");
				}
				tJava_6Process(globalMap);



/**
 * [tRunJob_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_2 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_2";

	

 



/**
 * [tRunJob_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_6", false);
		start_Hash.put("tJava_6", System.currentTimeMillis());
		
	
	currentComponent="tJava_6";

	
		int tos_count_tJava_6 = 0;
		
    	class BytesLimit65535_tJava_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_6().limitLog4jByte();


globalMap.put("SUB_JOB_STATUS", (((Integer)globalMap.get("tRunJob_2_CHILD_RETURN_CODE")) == 0 ? "C" : "F"));

globalMap.put("PROCESS_TYPE", "INGESTION");
 



/**
 * [tJava_6 begin ] stop
 */
	
	/**
	 * [tJava_6 main ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 


	tos_count_tJava_6++;

/**
 * [tJava_6 main ] stop
 */
	
	/**
	 * [tJava_6 end ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 

ok_Hash.put("tJava_6", true);
end_Hash.put("tJava_6", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk14", 0, "ok");
				}
				tFixedFlowInput_1Process(globalMap);



/**
 * [tJava_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_6 finally ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_6_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_3", false);
		start_Hash.put("tRunJob_3", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_3";

	
		int tos_count_tRunJob_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_3 = new StringBuilder();
            log4jParamters_tRunJob_3.append("Parameters:");
                    log4jParamters_tRunJob_3.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("PROCESS" + " = " + "Jb_Load_ORACLE_ADLS_Child");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("USE_INDEPENDENT_PROCESS" + " = " + "true");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("src_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.src_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("sub_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.sub_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("object_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_id\"))")+"}, {PARAM_NAME_COLUMN="+("keyfile_path")+", PARAM_VALUE_COLUMN="+("context.keyfile_path")+"}, {PARAM_NAME_COLUMN="+("prop_file_path")+", PARAM_VALUE_COLUMN="+("context.prop_file_path")+"}, {PARAM_NAME_COLUMN="+("root_pid")+", PARAM_VALUE_COLUMN="+("pid")+"}, {PARAM_NAME_COLUMN="+("object_nm")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_nm\"))")+"}, {PARAM_NAME_COLUMN="+("object_position")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_position\"))")+"}, {PARAM_NAME_COLUMN="+("batch_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"BATCH_ID\"))")+"}]");
                log4jParamters_tRunJob_3.append(" | ");
                    log4jParamters_tRunJob_3.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + (log4jParamters_tRunJob_3) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_3().limitLog4jByte();
class DealChildJobLibrary_tRunJob_3 {

	public String replaceJarPathsFromCrcMap(String originalClassPathLine) throws java.lang.Exception {
		String classPathLine = "";
		String crcMapPath = new java.io.File("../crcMap").getCanonicalPath();
		if (isNeedAddLibsPath( crcMapPath)) {
			java.util.Map<String, String> crcMap = null;
			java.io.ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(crcMapPath));
			crcMap = (java.util.Map<String, String>) ois.readObject();
			ois.close();
			classPathLine = addLibsPath(originalClassPathLine, crcMap);
		} else {
			classPathLine = originalClassPathLine;
		}
		return classPathLine;
	}
	
	private boolean isNeedAddLibsPath(String crcMapPath) {
		if (!(new java.io.File(crcMapPath).exists())) {// when not use cache
			return false;
		}
		return true;
	}
	
	
	private String addLibsPath(String line, java.util.Map<String, String> crcMap) {
		for (java.util.Map.Entry<String, String> entry : crcMap.entrySet()) {
			line = adaptLibPaths(line, entry);
		}
		return line;
	}
	
	private String adaptLibPaths(String line, java.util.Map.Entry<String, String> entry) {
		String jarName = entry.getValue();
		String crc = entry.getKey();
		String libStringFinder = "../lib/" + jarName;
		if (line.contains(libStringFinder)) {
			line = line.replace(libStringFinder, "../../../cache/lib/" + crc + "/" + jarName);
		} else if (line.contains(":$ROOT_PATH/" + jarName + ":")) {
			line = line.replace(":$ROOT_PATH/" + jarName + ":", ":$ROOT_PATH/../../../cache/lib/" + crc + "/" + jarName + ":");
		} else if (line.contains(";" + jarName + ";")) {
			line = line.replace(";" + jarName + ";", ";../../../cache/lib/" + crc + "/" + jarName + ";");
		}
		return line;
	}
	
}
	DealChildJobLibrary_tRunJob_3 dealChildJobLibrary_tRunJob_3 = new DealChildJobLibrary_tRunJob_3();


 



/**
 * [tRunJob_3 begin ] stop
 */
	
	/**
	 * [tRunJob_3 main ] start
	 */

	

	
	
	currentComponent="tRunJob_3";

	
	java.util.List<String> paraList_tRunJob_3 = new java.util.ArrayList<String>();
	
			String osName_tRunJob_3 = System.getProperty("os.name");
			if (osName_tRunJob_3 != null && osName_tRunJob_3.toLowerCase().startsWith("win")){
	      		
		      			paraList_tRunJob_3.add("java");
		      		
		      					paraList_tRunJob_3.add("-Xms256M");
		      				
		      					paraList_tRunJob_3.add("-Xmx1024M");
		      				
		      					paraList_tRunJob_3.add("-cp");
		      				
		        				paraList_tRunJob_3.add(dealChildJobLibrary_tRunJob_3.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/antlr-runtime-3.5.2.jar;../lib/commons-codec-1.7.jar;../lib/dom4j-1.6.1.jar;../lib/ini4j-0.5.1.jar;../lib/jtds-1.3.1-patch.jar;../lib/log4j-1.2.16.jar;../lib/ojdbc6.jar;../lib/ojdbc7.jar;../lib/org.talend.dataquality.parser.jar;../lib/talend-oracle-timestamptz.jar;../lib/talend_DB_mssqlUtil.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talendcsv.jar;../lib/thashfile-2.0-20170329.jar;../lib/tns.jar;jb_load_oracle_adls_child_0_1.jar;"));
		      				
		      					paraList_tRunJob_3.add("cerebro.jb_load_oracle_adls_child_0_1.Jb_Load_ORACLE_ADLS_Child");
		      				
		      					paraList_tRunJob_3.add("--father_pid="+pid);
		      				
		      					paraList_tRunJob_3.add("--root_pid="+rootPid);
		      				
		      					paraList_tRunJob_3.add("--father_node=tRunJob_3");
		      				
		      					paraList_tRunJob_3.add("--context=PROD");
		      				
		      					paraList_tRunJob_3.add("%*");
		      				
			} else {
	      		
						paraList_tRunJob_3.add("java");
		      		
								paraList_tRunJob_3.add("-Xms256M");
		      				
								paraList_tRunJob_3.add("-Xmx1024M");
		      				
								paraList_tRunJob_3.add("-cp");
		      				
								paraList_tRunJob_3.add(dealChildJobLibrary_tRunJob_3.replaceJarPathsFromCrcMap(".:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/antlr-runtime-3.5.2.jar:$ROOT_PATH/../lib/commons-codec-1.7.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/ini4j-0.5.1.jar:$ROOT_PATH/../lib/jtds-1.3.1-patch.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/../lib/ojdbc6.jar:$ROOT_PATH/../lib/ojdbc7.jar:$ROOT_PATH/../lib/org.talend.dataquality.parser.jar:$ROOT_PATH/../lib/talend-oracle-timestamptz.jar:$ROOT_PATH/../lib/talend_DB_mssqlUtil.jar:$ROOT_PATH/../lib/talend_file_enhanced_20070724.jar:$ROOT_PATH/../lib/talendcsv.jar:$ROOT_PATH/../lib/thashfile-2.0-20170329.jar:$ROOT_PATH/../lib/tns.jar:$ROOT_PATH/jb_load_oracle_adls_child_0_1.jar:").replace("$ROOT_PATH",System.getProperty("user.dir")));
		      				
								paraList_tRunJob_3.add("cerebro.jb_load_oracle_adls_child_0_1.Jb_Load_ORACLE_ADLS_Child");
		      				
								paraList_tRunJob_3.add("--father_pid="+pid);
		      				
								paraList_tRunJob_3.add("--root_pid="+rootPid);
		      				
								paraList_tRunJob_3.add("--father_node=tRunJob_3");
		      				
								paraList_tRunJob_3.add("--context=PROD");
		      				
								paraList_tRunJob_3.add("$@");
		      				
			}    
	  	
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_3.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_3.add("--stat_port=" + null);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_3.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_3 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_3 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_3".equals(tRunJobName_tRunJob_3) && childResumePath_tRunJob_3 != null){
		paraList_tRunJob_3.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_3.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_3");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_3 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_3 = null;

	
		obj_tRunJob_3 = ((String)globalMap.get("row1.src_sys_id"));
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param src_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param src_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("src_sys_id", obj_tRunJob_3);
	
		obj_tRunJob_3 = ((String)globalMap.get("row1.sub_sys_id"));
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param sub_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param sub_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("sub_sys_id", obj_tRunJob_3);
	
		obj_tRunJob_3 = ((String)globalMap.get("row1.object_id"));
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param object_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param object_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("object_id", obj_tRunJob_3);
	
		obj_tRunJob_3 = context.keyfile_path;
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param keyfile_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param keyfile_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("keyfile_path", obj_tRunJob_3);
	
		obj_tRunJob_3 = context.prop_file_path;
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param prop_file_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param prop_file_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("prop_file_path", obj_tRunJob_3);
	
		obj_tRunJob_3 = pid;
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param root_pid=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param root_pid=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("root_pid", obj_tRunJob_3);
	
		obj_tRunJob_3 = ((String)globalMap.get("row1.object_nm"));
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param object_nm=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param object_nm=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("object_nm", obj_tRunJob_3);
	
		obj_tRunJob_3 = ((String)globalMap.get("row1.object_position"));
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param object_position=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param object_position=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("object_position", obj_tRunJob_3);
	
		obj_tRunJob_3 = ((String)globalMap.get("BATCH_ID"));
		if(obj_tRunJob_3!=null) {
			paraList_tRunJob_3.add("--context_param batch_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_3));
		} else {
			paraList_tRunJob_3.add("--context_param batch_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_3.put("batch_id", obj_tRunJob_3);
	
	
		Runtime runtime_tRunJob_3 = Runtime.getRuntime();
		final Process ps_tRunJob_3;
		ps_tRunJob_3 = runtime_tRunJob_3.exec((String[])paraList_tRunJob_3.toArray(new String[paraList_tRunJob_3.size()]));

		Thread normal_tRunJob_3 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_3.getInputStream()));
					String line = "";
					try {
						while((line = reader.readLine()) != null) {
						System.out.println(line);
						}
					} finally {
					reader.close();
					}
				} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_3 - " + ioe.getMessage());
					
					ioe.printStackTrace();
				}
	    	}
  		};
		
			log.info("tRunJob_3 - The child job 'Jb_Load_ORACLE_ADLS_Child' starts on the version '0.1' with the context 'PROD'.");
		
		normal_tRunJob_3.start();
		
			log.info("tRunJob_3 - The child job 'Jb_Load_ORACLE_ADLS_Child' is done.");
		

		final StringBuffer errorMsg_tRunJob_3 = new StringBuffer();
		Thread error_tRunJob_3 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_3.getErrorStream()));
					String line = "";
        			try {
          				while((line = reader.readLine()) != null) {
            				errorMsg_tRunJob_3.append(line).append("\n");
          				}
        			} finally {
          				reader.close();
        			}
      			} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_3 - " + ioe.getMessage());
					
			        ioe.printStackTrace();
      			}
    		}
		};
		error_tRunJob_3.start();

		//0 indicates normal termination	
		int result_tRunJob_3 = ps_tRunJob_3.waitFor();
		normal_tRunJob_3.join(10000);
		error_tRunJob_3.join(10000);
  
		globalMap.put("tRunJob_3_CHILD_RETURN_CODE",result_tRunJob_3);
		if(result_tRunJob_3 != 0){
   			globalMap.put("tRunJob_3_CHILD_EXCEPTION_STACKTRACE",errorMsg_tRunJob_3.toString());
			
				
					log.error("tRunJob_3 - Child job returns " + result_tRunJob_3 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_3.toString());
				
				System.err.println("Child job returns " + result_tRunJob_3 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_3.toString());
			
  		}

		
 


	tos_count_tRunJob_3++;

/**
 * [tRunJob_3 main ] stop
 */
	
	/**
	 * [tRunJob_3 end ] start
	 */

	

	
	
	currentComponent="tRunJob_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_3 - "  + ("Done.") );

ok_Hash.put("tRunJob_3", true);
end_Hash.put("tRunJob_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk12", 0, "ok");
				}
				tJava_7Process(globalMap);



/**
 * [tRunJob_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_3 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_3";

	

 



/**
 * [tRunJob_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_7", false);
		start_Hash.put("tJava_7", System.currentTimeMillis());
		
	
	currentComponent="tJava_7";

	
		int tos_count_tJava_7 = 0;
		
    	class BytesLimit65535_tJava_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_7().limitLog4jByte();


globalMap.put("SUB_JOB_STATUS", (((Integer)globalMap.get("tRunJob_3_CHILD_RETURN_CODE")) == 0 ? "C" : "F"));

globalMap.put("PROCESS_TYPE", "INGESTION");
 



/**
 * [tJava_7 begin ] stop
 */
	
	/**
	 * [tJava_7 main ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 


	tos_count_tJava_7++;

/**
 * [tJava_7 main ] stop
 */
	
	/**
	 * [tJava_7 end ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 

ok_Hash.put("tJava_7", true);
end_Hash.put("tJava_7", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk15", 0, "ok");
				}
				tFixedFlowInput_1Process(globalMap);



/**
 * [tJava_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_7 finally ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 



/**
 * [tJava_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_7_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_4", false);
		start_Hash.put("tRunJob_4", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_4";

	
		int tos_count_tRunJob_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_4 = new StringBuilder();
            log4jParamters_tRunJob_4.append("Parameters:");
                    log4jParamters_tRunJob_4.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("PROCESS" + " = " + "Jb_Load_DB2_ADLS_Child");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("USE_INDEPENDENT_PROCESS" + " = " + "true");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("src_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.src_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("sub_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.sub_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("object_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_id\"))")+"}, {PARAM_NAME_COLUMN="+("keyfile_path")+", PARAM_VALUE_COLUMN="+("context.keyfile_path")+"}, {PARAM_NAME_COLUMN="+("prop_file_path")+", PARAM_VALUE_COLUMN="+("context.prop_file_path")+"}, {PARAM_NAME_COLUMN="+("root_pid")+", PARAM_VALUE_COLUMN="+("pid")+"}, {PARAM_NAME_COLUMN="+("object_nm")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_nm\"))")+"}, {PARAM_NAME_COLUMN="+("object_position")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_position\"))")+"}, {PARAM_NAME_COLUMN="+("batch_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"BATCH_ID\"))")+"}]");
                log4jParamters_tRunJob_4.append(" | ");
                    log4jParamters_tRunJob_4.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + (log4jParamters_tRunJob_4) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_4().limitLog4jByte();
class DealChildJobLibrary_tRunJob_4 {

	public String replaceJarPathsFromCrcMap(String originalClassPathLine) throws java.lang.Exception {
		String classPathLine = "";
		String crcMapPath = new java.io.File("../crcMap").getCanonicalPath();
		if (isNeedAddLibsPath( crcMapPath)) {
			java.util.Map<String, String> crcMap = null;
			java.io.ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(crcMapPath));
			crcMap = (java.util.Map<String, String>) ois.readObject();
			ois.close();
			classPathLine = addLibsPath(originalClassPathLine, crcMap);
		} else {
			classPathLine = originalClassPathLine;
		}
		return classPathLine;
	}
	
	private boolean isNeedAddLibsPath(String crcMapPath) {
		if (!(new java.io.File(crcMapPath).exists())) {// when not use cache
			return false;
		}
		return true;
	}
	
	
	private String addLibsPath(String line, java.util.Map<String, String> crcMap) {
		for (java.util.Map.Entry<String, String> entry : crcMap.entrySet()) {
			line = adaptLibPaths(line, entry);
		}
		return line;
	}
	
	private String adaptLibPaths(String line, java.util.Map.Entry<String, String> entry) {
		String jarName = entry.getValue();
		String crc = entry.getKey();
		String libStringFinder = "../lib/" + jarName;
		if (line.contains(libStringFinder)) {
			line = line.replace(libStringFinder, "../../../cache/lib/" + crc + "/" + jarName);
		} else if (line.contains(":$ROOT_PATH/" + jarName + ":")) {
			line = line.replace(":$ROOT_PATH/" + jarName + ":", ":$ROOT_PATH/../../../cache/lib/" + crc + "/" + jarName + ":");
		} else if (line.contains(";" + jarName + ";")) {
			line = line.replace(";" + jarName + ";", ";../../../cache/lib/" + crc + "/" + jarName + ";");
		}
		return line;
	}
	
}
	DealChildJobLibrary_tRunJob_4 dealChildJobLibrary_tRunJob_4 = new DealChildJobLibrary_tRunJob_4();


 



/**
 * [tRunJob_4 begin ] stop
 */
	
	/**
	 * [tRunJob_4 main ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	
	java.util.List<String> paraList_tRunJob_4 = new java.util.ArrayList<String>();
	
			String osName_tRunJob_4 = System.getProperty("os.name");
			if (osName_tRunJob_4 != null && osName_tRunJob_4.toLowerCase().startsWith("win")){
	      		
		      			paraList_tRunJob_4.add("java");
		      		
		      					paraList_tRunJob_4.add("-Xms256M");
		      				
		      					paraList_tRunJob_4.add("-Xmx1024M");
		      				
		      					paraList_tRunJob_4.add("-cp");
		      				
		        				paraList_tRunJob_4.add(dealChildJobLibrary_tRunJob_4.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/antlr-runtime-3.5.2.jar;../lib/commons-codec-1.7.jar;../lib/dom4j-1.6.1.jar;../lib/ini4j-0.5.1.jar;../lib/jt400_V6R1.jar;../lib/jtds-1.3.1-patch.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/talend_DB_mssqlUtil.jar;../lib/talend_file_enhanced_20070724.jar;../lib/talendcsv.jar;jb_load_db2_adls_child_0_1.jar;"));
		      				
		      					paraList_tRunJob_4.add("cerebro.jb_load_db2_adls_child_0_1.Jb_Load_DB2_ADLS_Child");
		      				
		      					paraList_tRunJob_4.add("--father_pid="+pid);
		      				
		      					paraList_tRunJob_4.add("--root_pid="+rootPid);
		      				
		      					paraList_tRunJob_4.add("--father_node=tRunJob_4");
		      				
		      					paraList_tRunJob_4.add("--context=PROD");
		      				
		      					paraList_tRunJob_4.add("%*");
		      				
			} else {
	      		
						paraList_tRunJob_4.add("java");
		      		
								paraList_tRunJob_4.add("-Xms256M");
		      				
								paraList_tRunJob_4.add("-Xmx1024M");
		      				
								paraList_tRunJob_4.add("-cp");
		      				
								paraList_tRunJob_4.add(dealChildJobLibrary_tRunJob_4.replaceJarPathsFromCrcMap(".:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/antlr-runtime-3.5.2.jar:$ROOT_PATH/../lib/commons-codec-1.7.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/ini4j-0.5.1.jar:$ROOT_PATH/../lib/jt400_V6R1.jar:$ROOT_PATH/../lib/jtds-1.3.1-patch.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/../lib/org.talend.dataquality.parser.jar:$ROOT_PATH/../lib/talend_DB_mssqlUtil.jar:$ROOT_PATH/../lib/talend_file_enhanced_20070724.jar:$ROOT_PATH/../lib/talendcsv.jar:$ROOT_PATH/jb_load_db2_adls_child_0_1.jar:").replace("$ROOT_PATH",System.getProperty("user.dir")));
		      				
								paraList_tRunJob_4.add("cerebro.jb_load_db2_adls_child_0_1.Jb_Load_DB2_ADLS_Child");
		      				
								paraList_tRunJob_4.add("--father_pid="+pid);
		      				
								paraList_tRunJob_4.add("--root_pid="+rootPid);
		      				
								paraList_tRunJob_4.add("--father_node=tRunJob_4");
		      				
								paraList_tRunJob_4.add("--context=PROD");
		      				
								paraList_tRunJob_4.add("$@");
		      				
			}    
	  	
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_4.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_4.add("--stat_port=" + null);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_4.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_4 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_4 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_4".equals(tRunJobName_tRunJob_4) && childResumePath_tRunJob_4 != null){
		paraList_tRunJob_4.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_4.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_4");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_4 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_4 = null;

	
		obj_tRunJob_4 = ((String)globalMap.get("row1.src_sys_id"));
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param src_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param src_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("src_sys_id", obj_tRunJob_4);
	
		obj_tRunJob_4 = ((String)globalMap.get("row1.sub_sys_id"));
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param sub_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param sub_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("sub_sys_id", obj_tRunJob_4);
	
		obj_tRunJob_4 = ((String)globalMap.get("row1.object_id"));
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param object_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param object_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("object_id", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.keyfile_path;
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param keyfile_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param keyfile_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("keyfile_path", obj_tRunJob_4);
	
		obj_tRunJob_4 = context.prop_file_path;
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param prop_file_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param prop_file_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("prop_file_path", obj_tRunJob_4);
	
		obj_tRunJob_4 = pid;
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param root_pid=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param root_pid=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("root_pid", obj_tRunJob_4);
	
		obj_tRunJob_4 = ((String)globalMap.get("row1.object_nm"));
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param object_nm=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param object_nm=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("object_nm", obj_tRunJob_4);
	
		obj_tRunJob_4 = ((String)globalMap.get("row1.object_position"));
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param object_position=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param object_position=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("object_position", obj_tRunJob_4);
	
		obj_tRunJob_4 = ((String)globalMap.get("BATCH_ID"));
		if(obj_tRunJob_4!=null) {
			paraList_tRunJob_4.add("--context_param batch_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_4));
		} else {
			paraList_tRunJob_4.add("--context_param batch_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_4.put("batch_id", obj_tRunJob_4);
	
	
		Runtime runtime_tRunJob_4 = Runtime.getRuntime();
		final Process ps_tRunJob_4;
		ps_tRunJob_4 = runtime_tRunJob_4.exec((String[])paraList_tRunJob_4.toArray(new String[paraList_tRunJob_4.size()]));

		Thread normal_tRunJob_4 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_4.getInputStream()));
					String line = "";
					try {
						while((line = reader.readLine()) != null) {
						System.out.println(line);
						}
					} finally {
					reader.close();
					}
				} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_4 - " + ioe.getMessage());
					
					ioe.printStackTrace();
				}
	    	}
  		};
		
			log.info("tRunJob_4 - The child job 'Jb_Load_DB2_ADLS_Child' starts on the version '0.1' with the context 'PROD'.");
		
		normal_tRunJob_4.start();
		
			log.info("tRunJob_4 - The child job 'Jb_Load_DB2_ADLS_Child' is done.");
		

		final StringBuffer errorMsg_tRunJob_4 = new StringBuffer();
		Thread error_tRunJob_4 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_4.getErrorStream()));
					String line = "";
        			try {
          				while((line = reader.readLine()) != null) {
            				errorMsg_tRunJob_4.append(line).append("\n");
          				}
        			} finally {
          				reader.close();
        			}
      			} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_4 - " + ioe.getMessage());
					
			        ioe.printStackTrace();
      			}
    		}
		};
		error_tRunJob_4.start();

		//0 indicates normal termination	
		int result_tRunJob_4 = ps_tRunJob_4.waitFor();
		normal_tRunJob_4.join(10000);
		error_tRunJob_4.join(10000);
  
		globalMap.put("tRunJob_4_CHILD_RETURN_CODE",result_tRunJob_4);
		if(result_tRunJob_4 != 0){
   			globalMap.put("tRunJob_4_CHILD_EXCEPTION_STACKTRACE",errorMsg_tRunJob_4.toString());
			
				
					log.error("tRunJob_4 - Child job returns " + result_tRunJob_4 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_4.toString());
				
				System.err.println("Child job returns " + result_tRunJob_4 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_4.toString());
			
  		}

		
 


	tos_count_tRunJob_4++;

/**
 * [tRunJob_4 main ] stop
 */
	
	/**
	 * [tRunJob_4 end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Done.") );

ok_Hash.put("tRunJob_4", true);
end_Hash.put("tRunJob_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk16", 0, "ok");
				}
				tJava_9Process(globalMap);



/**
 * [tRunJob_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_4 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 



/**
 * [tRunJob_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_9", false);
		start_Hash.put("tJava_9", System.currentTimeMillis());
		
	
	currentComponent="tJava_9";

	
		int tos_count_tJava_9 = 0;
		
    	class BytesLimit65535_tJava_9{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_9().limitLog4jByte();


globalMap.put("SUB_JOB_STATUS", (((Integer)globalMap.get("tRunJob_4_CHILD_RETURN_CODE")) == 0 ? "C" : "F"));

globalMap.put("PROCESS_TYPE", "INGESTION");
 



/**
 * [tJava_9 begin ] stop
 */
	
	/**
	 * [tJava_9 main ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 


	tos_count_tJava_9++;

/**
 * [tJava_9 main ] stop
 */
	
	/**
	 * [tJava_9 end ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 

ok_Hash.put("tJava_9", true);
end_Hash.put("tJava_9", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk17", 0, "ok");
				}
				tFixedFlowInput_1Process(globalMap);



/**
 * [tJava_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_9 finally ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 



/**
 * [tJava_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_9_SUBPROCESS_STATE", 1);
	}
	

public void tJava_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_11", false);
		start_Hash.put("tJava_11", System.currentTimeMillis());
		
	
	currentComponent="tJava_11";

	
		int tos_count_tJava_11 = 0;
		
    	class BytesLimit65535_tJava_11{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_11().limitLog4jByte();



 



/**
 * [tJava_11 begin ] stop
 */
	
	/**
	 * [tJava_11 main ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 


	tos_count_tJava_11++;

/**
 * [tJava_11 main ] stop
 */
	
	/**
	 * [tJava_11 end ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 

ok_Hash.put("tJava_11", true);
end_Hash.put("tJava_11", System.currentTimeMillis());

   			if (("M".equals((String)globalMap.get("JOB_TYPE")) || "B".equals((String)globalMap.get("JOB_TYPE")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If13", 0, "true");
					}
				
    			tRunJob_5Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If13", 0, "false");
					}   	 
   				}



/**
 * [tJava_11 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_11 finally ] start
	 */

	

	
	
	currentComponent="tJava_11";

	

 



/**
 * [tJava_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_11_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_5", false);
		start_Hash.put("tRunJob_5", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_5";

	
		int tos_count_tRunJob_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tRunJob_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tRunJob_5 = new StringBuilder();
            log4jParamters_tRunJob_5.append("Parameters:");
                    log4jParamters_tRunJob_5.append("USE_DYNAMIC_JOB" + " = " + "false");
                log4jParamters_tRunJob_5.append(" | ");
                    log4jParamters_tRunJob_5.append("PROCESS" + " = " + "Jb_Merge_ADLS_Staging_Child");
                log4jParamters_tRunJob_5.append(" | ");
                    log4jParamters_tRunJob_5.append("USE_INDEPENDENT_PROCESS" + " = " + "true");
                log4jParamters_tRunJob_5.append(" | ");
                    log4jParamters_tRunJob_5.append("DIE_ON_CHILD_ERROR" + " = " + "false");
                log4jParamters_tRunJob_5.append(" | ");
                    log4jParamters_tRunJob_5.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                log4jParamters_tRunJob_5.append(" | ");
                    log4jParamters_tRunJob_5.append("CONTEXTPARAMS" + " = " + "[{PARAM_NAME_COLUMN="+("src_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.src_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("sub_sys_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.sub_sys_id\"))")+"}, {PARAM_NAME_COLUMN="+("object_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_id\"))")+"}, {PARAM_NAME_COLUMN="+("keyfile_path")+", PARAM_VALUE_COLUMN="+("context.keyfile_path")+"}, {PARAM_NAME_COLUMN="+("prop_file_path")+", PARAM_VALUE_COLUMN="+("context.prop_file_path")+"}, {PARAM_NAME_COLUMN="+("root_pid")+", PARAM_VALUE_COLUMN="+("pid")+"}, {PARAM_NAME_COLUMN="+("object_nm")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_nm\"))")+"}, {PARAM_NAME_COLUMN="+("object_position")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"row1.object_position\"))")+"}, {PARAM_NAME_COLUMN="+("batch_id")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"BATCH_ID\"))")+"}, {PARAM_NAME_COLUMN="+("rerun_failed")+", PARAM_VALUE_COLUMN="+("((String)globalMap.get(\"RERUN_FAILED\"))")+"}]");
                log4jParamters_tRunJob_5.append(" | ");
                    log4jParamters_tRunJob_5.append("PRINT_PARAMETER" + " = " + "false");
                log4jParamters_tRunJob_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + (log4jParamters_tRunJob_5) );
    		}
    	}
    	
        new BytesLimit65535_tRunJob_5().limitLog4jByte();
class DealChildJobLibrary_tRunJob_5 {

	public String replaceJarPathsFromCrcMap(String originalClassPathLine) throws java.lang.Exception {
		String classPathLine = "";
		String crcMapPath = new java.io.File("../crcMap").getCanonicalPath();
		if (isNeedAddLibsPath( crcMapPath)) {
			java.util.Map<String, String> crcMap = null;
			java.io.ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(crcMapPath));
			crcMap = (java.util.Map<String, String>) ois.readObject();
			ois.close();
			classPathLine = addLibsPath(originalClassPathLine, crcMap);
		} else {
			classPathLine = originalClassPathLine;
		}
		return classPathLine;
	}
	
	private boolean isNeedAddLibsPath(String crcMapPath) {
		if (!(new java.io.File(crcMapPath).exists())) {// when not use cache
			return false;
		}
		return true;
	}
	
	
	private String addLibsPath(String line, java.util.Map<String, String> crcMap) {
		for (java.util.Map.Entry<String, String> entry : crcMap.entrySet()) {
			line = adaptLibPaths(line, entry);
		}
		return line;
	}
	
	private String adaptLibPaths(String line, java.util.Map.Entry<String, String> entry) {
		String jarName = entry.getValue();
		String crc = entry.getKey();
		String libStringFinder = "../lib/" + jarName;
		if (line.contains(libStringFinder)) {
			line = line.replace(libStringFinder, "../../../cache/lib/" + crc + "/" + jarName);
		} else if (line.contains(":$ROOT_PATH/" + jarName + ":")) {
			line = line.replace(":$ROOT_PATH/" + jarName + ":", ":$ROOT_PATH/../../../cache/lib/" + crc + "/" + jarName + ":");
		} else if (line.contains(";" + jarName + ";")) {
			line = line.replace(";" + jarName + ";", ";../../../cache/lib/" + crc + "/" + jarName + ";");
		}
		return line;
	}
	
}
	DealChildJobLibrary_tRunJob_5 dealChildJobLibrary_tRunJob_5 = new DealChildJobLibrary_tRunJob_5();


 



/**
 * [tRunJob_5 begin ] stop
 */
	
	/**
	 * [tRunJob_5 main ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	
	java.util.List<String> paraList_tRunJob_5 = new java.util.ArrayList<String>();
	
			String osName_tRunJob_5 = System.getProperty("os.name");
			if (osName_tRunJob_5 != null && osName_tRunJob_5.toLowerCase().startsWith("win")){
	      		
		      			paraList_tRunJob_5.add("java");
		      		
		      					paraList_tRunJob_5.add("-Xms256M");
		      				
		      					paraList_tRunJob_5.add("-Xmx1024M");
		      				
		      					paraList_tRunJob_5.add("-cp");
		      				
		        				paraList_tRunJob_5.add(dealChildJobLibrary_tRunJob_5.replaceJarPathsFromCrcMap(".;../lib/routines.jar;../lib/antlr-runtime-3.5.2.jar;../lib/commons-codec-1.7.jar;../lib/dom4j-1.6.1.jar;../lib/ini4j-0.5.1.jar;../lib/jtds-1.3.1-patch.jar;../lib/log4j-1.2.16.jar;../lib/org.talend.dataquality.parser.jar;../lib/talend_DB_mssqlUtil.jar;../lib/talend_file_enhanced_20070724.jar;../lib/thashfile-2.0-20170329.jar;jb_merge_adls_staging_child_0_1.jar;"));
		      				
		      					paraList_tRunJob_5.add("cerebro.jb_merge_adls_staging_child_0_1.Jb_Merge_ADLS_Staging_Child");
		      				
		      					paraList_tRunJob_5.add("--father_pid="+pid);
		      				
		      					paraList_tRunJob_5.add("--root_pid="+rootPid);
		      				
		      					paraList_tRunJob_5.add("--father_node=tRunJob_5");
		      				
		      					paraList_tRunJob_5.add("--context=PROD");
		      				
		      					paraList_tRunJob_5.add("%*");
		      				
			} else {
	      		
						paraList_tRunJob_5.add("java");
		      		
								paraList_tRunJob_5.add("-Xms256M");
		      				
								paraList_tRunJob_5.add("-Xmx1024M");
		      				
								paraList_tRunJob_5.add("-cp");
		      				
								paraList_tRunJob_5.add(dealChildJobLibrary_tRunJob_5.replaceJarPathsFromCrcMap(".:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/antlr-runtime-3.5.2.jar:$ROOT_PATH/../lib/commons-codec-1.7.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/ini4j-0.5.1.jar:$ROOT_PATH/../lib/jtds-1.3.1-patch.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/../lib/org.talend.dataquality.parser.jar:$ROOT_PATH/../lib/talend_DB_mssqlUtil.jar:$ROOT_PATH/../lib/talend_file_enhanced_20070724.jar:$ROOT_PATH/../lib/thashfile-2.0-20170329.jar:$ROOT_PATH/jb_merge_adls_staging_child_0_1.jar:").replace("$ROOT_PATH",System.getProperty("user.dir")));
		      				
								paraList_tRunJob_5.add("cerebro.jb_merge_adls_staging_child_0_1.Jb_Merge_ADLS_Staging_Child");
		      				
								paraList_tRunJob_5.add("--father_pid="+pid);
		      				
								paraList_tRunJob_5.add("--root_pid="+rootPid);
		      				
								paraList_tRunJob_5.add("--father_node=tRunJob_5");
		      				
								paraList_tRunJob_5.add("--context=PROD");
		      				
								paraList_tRunJob_5.add("$@");
		      				
			}    
	  	
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_5.add("--log4jLevel="+log4jLevel);
			}
		
	//for feature:10589
	
		paraList_tRunJob_5.add("--stat_port=" + null);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_5.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_5 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_5 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_5".equals(tRunJobName_tRunJob_5) && childResumePath_tRunJob_5 != null){
		paraList_tRunJob_5.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_5.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_5");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_5 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_5 = null;

	
		obj_tRunJob_5 = ((String)globalMap.get("row1.src_sys_id"));
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param src_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param src_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("src_sys_id", obj_tRunJob_5);
	
		obj_tRunJob_5 = ((String)globalMap.get("row1.sub_sys_id"));
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param sub_sys_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param sub_sys_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("sub_sys_id", obj_tRunJob_5);
	
		obj_tRunJob_5 = ((String)globalMap.get("row1.object_id"));
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param object_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param object_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("object_id", obj_tRunJob_5);
	
		obj_tRunJob_5 = context.keyfile_path;
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param keyfile_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param keyfile_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("keyfile_path", obj_tRunJob_5);
	
		obj_tRunJob_5 = context.prop_file_path;
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param prop_file_path=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param prop_file_path=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("prop_file_path", obj_tRunJob_5);
	
		obj_tRunJob_5 = pid;
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param root_pid=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param root_pid=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("root_pid", obj_tRunJob_5);
	
		obj_tRunJob_5 = ((String)globalMap.get("row1.object_nm"));
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param object_nm=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param object_nm=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("object_nm", obj_tRunJob_5);
	
		obj_tRunJob_5 = ((String)globalMap.get("row1.object_position"));
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param object_position=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param object_position=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("object_position", obj_tRunJob_5);
	
		obj_tRunJob_5 = ((String)globalMap.get("BATCH_ID"));
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param batch_id=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param batch_id=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("batch_id", obj_tRunJob_5);
	
		obj_tRunJob_5 = ((String)globalMap.get("RERUN_FAILED"));
		if(obj_tRunJob_5!=null) {
			paraList_tRunJob_5.add("--context_param rerun_failed=" + RuntimeUtils.tRunJobConvertContext(obj_tRunJob_5));
		} else {
			paraList_tRunJob_5.add("--context_param rerun_failed=" + NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY);
		}
		
		parentContextMap_tRunJob_5.put("rerun_failed", obj_tRunJob_5);
	
	
		Runtime runtime_tRunJob_5 = Runtime.getRuntime();
		final Process ps_tRunJob_5;
		ps_tRunJob_5 = runtime_tRunJob_5.exec((String[])paraList_tRunJob_5.toArray(new String[paraList_tRunJob_5.size()]));

		Thread normal_tRunJob_5 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_5.getInputStream()));
					String line = "";
					try {
						while((line = reader.readLine()) != null) {
						System.out.println(line);
						}
					} finally {
					reader.close();
					}
				} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_5 - " + ioe.getMessage());
					
					ioe.printStackTrace();
				}
	    	}
  		};
		
			log.info("tRunJob_5 - The child job 'Jb_Merge_ADLS_Staging_Child' starts on the version '0.1' with the context 'PROD'.");
		
		normal_tRunJob_5.start();
		
			log.info("tRunJob_5 - The child job 'Jb_Merge_ADLS_Staging_Child' is done.");
		

		final StringBuffer errorMsg_tRunJob_5 = new StringBuffer();
		Thread error_tRunJob_5 = new Thread() {
			public void run() {
				try {
					java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tRunJob_5.getErrorStream()));
					String line = "";
        			try {
          				while((line = reader.readLine()) != null) {
            				errorMsg_tRunJob_5.append(line).append("\n");
          				}
        			} finally {
          				reader.close();
        			}
      			} catch(java.io.IOException ioe) {
					
						log.error("tRunJob_5 - " + ioe.getMessage());
					
			        ioe.printStackTrace();
      			}
    		}
		};
		error_tRunJob_5.start();

		//0 indicates normal termination	
		int result_tRunJob_5 = ps_tRunJob_5.waitFor();
		normal_tRunJob_5.join(10000);
		error_tRunJob_5.join(10000);
  
		globalMap.put("tRunJob_5_CHILD_RETURN_CODE",result_tRunJob_5);
		if(result_tRunJob_5 != 0){
   			globalMap.put("tRunJob_5_CHILD_EXCEPTION_STACKTRACE",errorMsg_tRunJob_5.toString());
			
				
					log.error("tRunJob_5 - Child job returns " + result_tRunJob_5 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_5.toString());
				
				System.err.println("Child job returns " + result_tRunJob_5 + ". It doesn't terminate normally.\n" + errorMsg_tRunJob_5.toString());
			
  		}

		
 


	tos_count_tRunJob_5++;

/**
 * [tRunJob_5 main ] stop
 */
	
	/**
	 * [tRunJob_5 end ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Done.") );

ok_Hash.put("tRunJob_5", true);
end_Hash.put("tRunJob_5", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk19", 0, "ok");
				}
				tJava_13Process(globalMap);



/**
 * [tRunJob_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_5 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	

 



/**
 * [tRunJob_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_5_SUBPROCESS_STATE", 1);
	}
	

public void tJava_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_13", false);
		start_Hash.put("tJava_13", System.currentTimeMillis());
		
	
	currentComponent="tJava_13";

	
		int tos_count_tJava_13 = 0;
		
    	class BytesLimit65535_tJava_13{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_13().limitLog4jByte();


globalMap.put("SUB_JOB_STATUS", (((Integer)globalMap.get("tRunJob_5_CHILD_RETURN_CODE")) == 0 ? "C" : "F"));

globalMap.put("PROCESS_TYPE", "MERGE");
 



/**
 * [tJava_13 begin ] stop
 */
	
	/**
	 * [tJava_13 main ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 


	tos_count_tJava_13++;

/**
 * [tJava_13 main ] stop
 */
	
	/**
	 * [tJava_13 end ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 

ok_Hash.put("tJava_13", true);
end_Hash.put("tJava_13", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk21", 0, "ok");
				}
				tFixedFlowInput_1Process(globalMap);



/**
 * [tJava_13 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_13 finally ] start
	 */

	

	
	
	currentComponent="tJava_13";

	

 



/**
 * [tJava_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_13_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";

	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
            log4jParamters_tWarn_2.append("Parameters:");
                    log4jParamters_tWarn_2.append("MESSAGE" + " = " + "\"201|Failed to retrieve the list of objects to be processed\"");
                log4jParamters_tWarn_2.append(" | ");
                    log4jParamters_tWarn_2.append("CODE" + " = " + "999");
                log4jParamters_tWarn_2.append(" | ");
                    log4jParamters_tWarn_2.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_2().limitLog4jByte();

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "ERROR","","201|Failed to retrieve the list of objects to be processed","", "");
            log.error("tWarn_2 - "  + ("Message: ")  + ("201|Failed to retrieve the list of objects to be processed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_2", 5, "201|Failed to retrieve the list of objects to be processed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_2_WARN_MESSAGES", "201|Failed to retrieve the list of objects to be processed"); 
globalMap.put("tWarn_2_WARN_PRIORITY", 5);
globalMap.put("tWarn_2_WARN_CODE", 999);


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String message;

				public String getMessage () {
					return this.message;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.message = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.message,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("message="+message);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tLogCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();
row3Struct row3 = new row3Struct();





	
	/**
	 * [tHashOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_2", false);
		start_Hash.put("tHashOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_2 = 0;
		
    	class BytesLimit65535_tHashOutput_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_2().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row3Struct> tHashFile_tHashOutput_2 = null;
		String hashKey_tHashOutput_2 = "tHashFile_Jb_Ingestion_Master_Job_" + pid + "_tHashOutput_2";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_2)){
			    if(mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2) == null){
	      		    mf_tHashOutput_2.getResourceMap().put(hashKey_tHashOutput_2, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row3Struct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
			    }else{
			    	tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
			    }
			}
        int nb_line_tHashOutput_2 = 0;
 



/**
 * [tHashOutput_2 begin ] stop
 */



	
	/**
	 * [tFilterColumns_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterColumns_1", false);
		start_Hash.put("tFilterColumns_1", System.currentTimeMillis());
		
	
	currentComponent="tFilterColumns_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFilterColumns_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterColumns_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFilterColumns_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFilterColumns_1 = new StringBuilder();
            log4jParamters_tFilterColumns_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tFilterColumns_1 - "  + (log4jParamters_tFilterColumns_1) );
    		}
    	}
    	
        new BytesLimit65535_tFilterColumns_1().limitLog4jByte();

                if(log.isDebugEnabled())
            log.debug("tFilterColumns_1 - "  + ("The input columns are: ")  + ("[moment, pid, root_pid, father_pid, project, job, context, priority, type, origin, message, code]")  + (".") );
                if(log.isDebugEnabled())
            log.debug("tFilterColumns_1 - "  + ("The output columns are: ")  + ("[message]")  + (".") );

 int nb_line_tFilterColumns_1 = 0;
 



/**
 * [tFilterColumns_1 begin ] stop
 */



	
	/**
	 * [tLogCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogCatcher_1", false);
		start_Hash.put("tLogCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tLogCatcher_1";

	
		int tos_count_tLogCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogCatcher_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogCatcher_1 = new StringBuilder();
            log4jParamters_tLogCatcher_1.append("Parameters:");
                    log4jParamters_tLogCatcher_1.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TDIE" + " = " + "false");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TACTIONFAILURE" + " = " + "false");
                log4jParamters_tLogCatcher_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + (log4jParamters_tLogCatcher_1) );
    		}
    	}
    	
        new BytesLimit65535_tLogCatcher_1().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1.getMessages()) {
		row2.type = lcm.getType();
		row2.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row2.priority = lcm.getPriority();
		row2.message = lcm.getMessage();
		row2.code = lcm.getCode();
		
		row2.moment = java.util.Calendar.getInstance().getTime();
	
    	row2.pid = pid;
		row2.root_pid = rootPid;
		row2.father_pid = fatherPid;
	
    	row2.project = projectName;
    	row2.job = jobName;
    	row2.context = contextStr;
    		
 



/**
 * [tLogCatcher_1 begin ] stop
 */
	
	/**
	 * [tLogCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 


	tos_count_tLogCatcher_1++;

/**
 * [tLogCatcher_1 main ] stop
 */

	
	/**
	 * [tFilterColumns_1 main ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		
	

	row3.message = row2.message;

	
    nb_line_tFilterColumns_1++;

 


	tos_count_tFilterColumns_1++;

/**
 * [tFilterColumns_1 main ] stop
 */

	
	/**
	 * [tHashOutput_2 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	

			//row3
			//row3


			
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



    
		row3Struct oneRow_tHashOutput_2 = new row3Struct();
				
					oneRow_tHashOutput_2.message = row3.message;
		
        tHashFile_tHashOutput_2.put(oneRow_tHashOutput_2);
        nb_line_tHashOutput_2 ++;
 


	tos_count_tHashOutput_2++;

/**
 * [tHashOutput_2 main ] stop
 */






	
	/**
	 * [tLogCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Done.") );

ok_Hash.put("tLogCatcher_1", true);
end_Hash.put("tLogCatcher_1", System.currentTimeMillis());




/**
 * [tLogCatcher_1 end ] stop
 */

	
	/**
	 * [tFilterColumns_1 end ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	

globalMap.put("tFilterColumns_1_NB_LINE",nb_line_tFilterColumns_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFilterColumns_1 - "  + ("Done.") );

ok_Hash.put("tFilterColumns_1", true);
end_Hash.put("tFilterColumns_1", System.currentTimeMillis());




/**
 * [tFilterColumns_1 end ] stop
 */

	
	/**
	 * [tHashOutput_2 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	
globalMap.put("tHashOutput_2_NB_LINE", nb_line_tHashOutput_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row3"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_2", true);
end_Hash.put("tHashOutput_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk3", 0, "ok");
				}
				tSetGlobalVar_2Process(globalMap);



/**
 * [tHashOutput_2 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLogCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 finally ] stop
 */

	
	/**
	 * [tFilterColumns_1 finally ] start
	 */

	

	
	
	currentComponent="tFilterColumns_1";

	

 



/**
 * [tFilterColumns_1 finally ] stop
 */

	
	/**
	 * [tHashOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	

 



/**
 * [tHashOutput_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void tSetGlobalVar_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";

	
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
            log4jParamters_tSetGlobalVar_2.append("Parameters:");
                    log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("\"Y\"")+", KEY="+("\"IS_FAILED\"")+"}]");
                log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

globalMap.put("IS_FAILED", "Y");

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk6", 0, "ok");
				}
				tDie_1Process(globalMap);



/**
 * [tSetGlobalVar_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSetGlobalVar_2_SUBPROCESS_STATE", 1);
	}
	

public void tDie_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDie_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDie_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDie_1", false);
		start_Hash.put("tDie_1", System.currentTimeMillis());
		
	
	currentComponent="tDie_1";

	
		int tos_count_tDie_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tDie_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tDie_1 = new StringBuilder();
            log4jParamters_tDie_1.append("Parameters:");
                    log4jParamters_tDie_1.append("MESSAGE" + " = " + "\"The main job has issues\"");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("CODE" + " = " + "909");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("PRIORITY" + " = " + "5");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("EXIT_JVM" + " = " + "false");
                log4jParamters_tDie_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + (log4jParamters_tDie_1) );
    		}
    	}
    	
        new BytesLimit65535_tDie_1().limitLog4jByte();

 



/**
 * [tDie_1 begin ] stop
 */
	
	/**
	 * [tDie_1 main ] start
	 */

	

	
	
	currentComponent="tDie_1";

	


	globalMap.put("tDie_1_DIE_PRIORITY", 5);
	System.err.println("The main job has issues");
	
		log.error("tDie_1 - The die message: "+"The main job has issues");
	
	globalMap.put("tDie_1_DIE_MESSAGE", "The main job has issues");
	globalMap.put("tDie_1_DIE_MESSAGES", "The main job has issues");
	currentComponent = "tDie_1";
	status = "failure";
        errorCode = new Integer(909);
        globalMap.put("tDie_1_DIE_CODE", errorCode);        
    
	if(true){	
	    throw new TDieException();
	}

 


	tos_count_tDie_1++;

/**
 * [tDie_1 main ] stop
 */
	
	/**
	 * [tDie_1 end ] start
	 */

	

	
	
	currentComponent="tDie_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + ("Done.") );

ok_Hash.put("tDie_1", true);
end_Hash.put("tDie_1", System.currentTimeMillis());




/**
 * [tDie_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDie_1 finally ] start
	 */

	

	
	
	currentComponent="tDie_1";

	

 



/**
 * [tDie_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDie_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";

	
		int tos_count_tPostjob_1 = 0;
		
    	class BytesLimit65535_tPostjob_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tPostjob_1().limitLog4jByte();

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tJava_2Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
    	class BytesLimit65535_tJava_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_2().limitLog4jByte();


if(globalMap.containsKey("conn_tMSSqlConnection_1"))
{
		tMSSqlConnection_1Process(globalMap);
}

globalMap.put("EMAIL_MESSAGE", "<html><body><h1>" + (Relational.ISNULL(globalMap.get("JOB_NAME_QUALIFIER")) ? (Relational.ISNULL(globalMap.get("row1.src_sys_desc")) ? "" : ((String)globalMap.get("row1.src_sys_desc"))) :("Y".equals((String)globalMap.get("MERGE_SUBSYSTEM_FILES")) ? ((String)globalMap.get("JOB_NAME_QUALIFIER")).split("_")[0] : ((String)globalMap.get("JOB_NAME_QUALIFIER")))) + (context.group_id.trim().length() > 0 ? " - Group(s) in " + context.group_id : "") + " - Status</h1>");
 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

   			if ("Y".equals((String)globalMap.get("IS_FAILED"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "true");
					}
				
    			tHashInput_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "false");
					}   	 
   				}
   			if (!("Y".equals((String)globalMap.get("IS_FAILED"))) && (Relational.ISNULL(globalMap.get("tHashOutput_1_NB_LINE")) ? 0 : ((Integer)globalMap.get("tHashOutput_1_NB_LINE"))) > 0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "true");
					}
				
    			tMSSqlInput_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "false");
					}   	 
   				}



/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tJava_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String message;

				public String getMessage () {
					return this.message;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.message = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.message,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("message="+message);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtDenormalize_1 implements routines.system.IPersistableRow<OnRowsEndStructtDenormalize_1> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String message;

				public String getMessage () {
					return this.message;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.message = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.message,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("message="+message);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtDenormalize_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String message;

				public String getMessage () {
					return this.message;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.message = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.message,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("message="+message);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tHashInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();
row8Struct row8 = new row8Struct();




	
	/**
	 * [tDenormalize_1_DenormalizeOut begin ] start
	 */

	

	
		
		ok_Hash.put("tDenormalize_1_DenormalizeOut", false);
		start_Hash.put("tDenormalize_1_DenormalizeOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_DenormalizeOut";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tDenormalize_1_DenormalizeOut = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDenormalize_1_DenormalizeOut - "  + ("Start to work.") );
    	class BytesLimit65535_tDenormalize_1_DenormalizeOut{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tDenormalize_1_DenormalizeOut = new StringBuilder();
            log4jParamters_tDenormalize_1_DenormalizeOut.append("Parameters:");
                    log4jParamters_tDenormalize_1_DenormalizeOut.append("DESTINATION" + " = " + "tDenormalize_1");
                log4jParamters_tDenormalize_1_DenormalizeOut.append(" | ");
                    log4jParamters_tDenormalize_1_DenormalizeOut.append("DENORMALIZE_COLUMNS" + " = " + "[{MERGE="+("false")+", INPUT_COLUMN="+("message")+", DELIMITER="+("\"|\"")+"}]");
                log4jParamters_tDenormalize_1_DenormalizeOut.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDenormalize_1_DenormalizeOut - "  + (log4jParamters_tDenormalize_1_DenormalizeOut) );
    		}
    	}
    	
        new BytesLimit65535_tDenormalize_1_DenormalizeOut().limitLog4jByte();

class DenormalizeStructtDenormalize_1_DenormalizeOut {
StringBuilder message = new StringBuilder();
}
DenormalizeStructtDenormalize_1_DenormalizeOut denormalize_result_tDenormalize_1_DenormalizeOut = null;

 



/**
 * [tDenormalize_1_DenormalizeOut begin ] stop
 */



	
	/**
	 * [tHashInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_1", false);
		start_Hash.put("tHashInput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_1";

	
		int tos_count_tHashInput_1 = 0;
		
    	class BytesLimit65535_tHashInput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashInput_1().limitLog4jByte();


int nb_line_tHashInput_1 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row3Struct> tHashFile_tHashInput_1 = mf_tHashInput_1.getAdvancedMemoryHashFile("tHashFile_Jb_Ingestion_Master_Job_" + pid +"_tHashOutput_2");
if(tHashFile_tHashInput_1==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row3Struct> iterator_tHashInput_1 = tHashFile_tHashInput_1.iterator();
while (iterator_tHashInput_1.hasNext()) {
    row3Struct next_tHashInput_1 = iterator_tHashInput_1.next();

	row7.message = next_tHashInput_1.message;
 



/**
 * [tHashInput_1 begin ] stop
 */
	
	/**
	 * [tHashInput_1 main ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	

 


	tos_count_tHashInput_1++;

/**
 * [tHashInput_1 main ] stop
 */

	
	/**
	 * [tDenormalize_1_DenormalizeOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_DenormalizeOut";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

if(denormalize_result_tDenormalize_1_DenormalizeOut == null){
	denormalize_result_tDenormalize_1_DenormalizeOut = new DenormalizeStructtDenormalize_1_DenormalizeOut();		
	denormalize_result_tDenormalize_1_DenormalizeOut.message.append(row7.message);
			
}else{		
	denormalize_result_tDenormalize_1_DenormalizeOut.message.append("|").append(row7.message);
			
}

 


	tos_count_tDenormalize_1_DenormalizeOut++;

/**
 * [tDenormalize_1_DenormalizeOut main ] stop
 */



	
	/**
	 * [tHashInput_1 end ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	
    

		
			nb_line_tHashInput_1++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_Jb_Ingestion_Master_Job_" + pid +"_tHashOutput_2");
	


	globalMap.put("tHashInput_1_NB_LINE", nb_line_tHashInput_1);       

 

ok_Hash.put("tHashInput_1", true);
end_Hash.put("tHashInput_1", System.currentTimeMillis());




/**
 * [tHashInput_1 end ] stop
 */

	
	/**
	 * [tDenormalize_1_DenormalizeOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_DenormalizeOut";

	
java.util.List<OnRowsEndStructtDenormalize_1> result_list_tDenormalize_1_DenormalizeOut = new java.util.ArrayList<OnRowsEndStructtDenormalize_1>();
if (denormalize_result_tDenormalize_1_DenormalizeOut != null) {
//generate result begin
	OnRowsEndStructtDenormalize_1 denormalize_row_tDenormalize_1_DenormalizeOut = new OnRowsEndStructtDenormalize_1();
                
	denormalize_row_tDenormalize_1_DenormalizeOut.message = denormalize_result_tDenormalize_1_DenormalizeOut.message.toString();
	
	//in the deepest end
	
	result_list_tDenormalize_1_DenormalizeOut.add(denormalize_row_tDenormalize_1_DenormalizeOut);

}
//generate result end
globalMap.put("tDenormalize_1", result_list_tDenormalize_1_DenormalizeOut);
globalMap.put("tDenormalize_1_DenormalizeOut_NB_LINE", result_list_tDenormalize_1_DenormalizeOut.size()); 
	log.info("tDenormalize_1_DenormalizeOut - Generated records count: " + result_list_tDenormalize_1_DenormalizeOut.size() + " .");

        


			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tDenormalize_1_DenormalizeOut - "  + ("Done.") );

ok_Hash.put("tDenormalize_1_DenormalizeOut", true);
end_Hash.put("tDenormalize_1_DenormalizeOut", System.currentTimeMillis());




/**
 * [tDenormalize_1_DenormalizeOut end ] stop
 */


	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_2 = 0;
		
    	class BytesLimit65535_tJavaRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_2().limitLog4jByte();

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tDenormalize_1_ArrayIn begin ] start
	 */

	

	
		
		ok_Hash.put("tDenormalize_1_ArrayIn", false);
		start_Hash.put("tDenormalize_1_ArrayIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_ArrayIn";

	
		int tos_count_tDenormalize_1_ArrayIn = 0;
		
    	class BytesLimit65535_tDenormalize_1_ArrayIn{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tDenormalize_1_ArrayIn().limitLog4jByte();

        
        int nb_line_tDenormalize_1_ArrayIn = 0;
        java.util.List<OnRowsEndStructtDenormalize_1> list_tDenormalize_1_ArrayIn = (java.util.List<OnRowsEndStructtDenormalize_1>)globalMap.get("tDenormalize_1");
        if(list_tDenormalize_1_ArrayIn == null) {
            list_tDenormalize_1_ArrayIn = new java.util.ArrayList<OnRowsEndStructtDenormalize_1>();
        }        
        for(OnRowsEndStructtDenormalize_1 row_tDenormalize_1_ArrayIn : list_tDenormalize_1_ArrayIn){
        					
    						row8.message = row_tDenormalize_1_ArrayIn.message;
    						

 



/**
 * [tDenormalize_1_ArrayIn begin ] stop
 */
	
	/**
	 * [tDenormalize_1_ArrayIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_ArrayIn";

	

 


	tos_count_tDenormalize_1_ArrayIn++;

/**
 * [tDenormalize_1_ArrayIn main ] stop
 */

	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

    globalMap.put("EMAIL_MESSAGE", ((String)globalMap.get("EMAIL_MESSAGE")) + "The main job has failed with the following error:<br>" + row8.message);
    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */



	
	/**
	 * [tDenormalize_1_ArrayIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_ArrayIn";

	
	nb_line_tDenormalize_1_ArrayIn++;
}
globalMap.put("tDenormalize_1_ArrayIn_NB_LINE",nb_line_tDenormalize_1_ArrayIn);
 

ok_Hash.put("tDenormalize_1_ArrayIn", true);
end_Hash.put("tDenormalize_1_ArrayIn", System.currentTimeMillis());




/**
 * [tDenormalize_1_ArrayIn end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());




/**
 * [tJavaRow_2 end ] stop
 */









				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tDenormalize_1_ArrayIn"
							globalMap.remove("tDenormalize_1");
						
				try{
					
	
	/**
	 * [tHashInput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	

 



/**
 * [tHashInput_1 finally ] stop
 */

	
	/**
	 * [tDenormalize_1_DenormalizeOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_DenormalizeOut";

	

 



/**
 * [tDenormalize_1_DenormalizeOut finally ] stop
 */

	
	/**
	 * [tDenormalize_1_ArrayIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tDenormalize_1";
	
	currentComponent="tDenormalize_1_ArrayIn";

	

 



/**
 * [tDenormalize_1_ArrayIn finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

 



/**
 * [tJavaRow_2 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public Integer rank;

				public Integer getRank () {
					return this.rank;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
						this.rank = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// Integer
				
						writeInteger(this.rank,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",rank="+String.valueOf(rank));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(rank == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rank);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtSortRow_2 implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_2> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public Integer rank;

				public Integer getRank () {
					return this.rank;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
						this.rank = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// Integer
				
						writeInteger(this.rank,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",rank="+String.valueOf(rank));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(rank == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rank);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtSortRow_2 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public Integer rank;

				public Integer getRank () {
					return this.rank;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
						this.rank = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// Integer
				
						writeInteger(this.rank,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",rank="+String.valueOf(rank));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(rank == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rank);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtAggregateRow_1 implements routines.system.IPersistableRow<OnRowsEndStructtAggregateRow_1> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public Integer rank;

				public Integer getRank () {
					return this.rank;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
						this.rank = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// Integer
				
						writeInteger(this.rank,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",rank="+String.valueOf(rank));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(rank == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rank);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtAggregateRow_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public Integer src_sys_id;

				public Integer getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public Integer object_id;

				public Integer getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public Integer rank;

				public Integer getRank () {
					return this.rank;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
						this.src_sys_id = readInteger(dis);
					
					this.sub_sys_id = readString(dis);
					
						this.object_id = readInteger(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
						this.rank = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// Integer
				
						writeInteger(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// Integer
				
						writeInteger(this.rank,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+String.valueOf(src_sys_id));
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+String.valueOf(object_id));
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",rank="+String.valueOf(rank));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(rank == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rank);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class OnRowsEndStructtSortRow_1 implements routines.system.IPersistableRow<OnRowsEndStructtSortRow_1> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public Integer src_sys_id;

				public Integer getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public Integer object_id;

				public Integer getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public Integer rank;

				public Integer getRank () {
					return this.rank;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
						this.src_sys_id = readInteger(dis);
					
					this.sub_sys_id = readString(dis);
					
						this.object_id = readInteger(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
						this.rank = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// Integer
				
						writeInteger(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// Integer
				
						writeInteger(this.rank,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+String.valueOf(src_sys_id));
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+String.valueOf(object_id));
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",rank="+String.valueOf(rank));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(rank == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rank);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(OnRowsEndStructtSortRow_1 other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class out2Struct implements routines.system.IPersistableRow<out2Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public Integer src_sys_id;

				public Integer getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public Integer object_id;

				public Integer getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public Integer rank;

				public Integer getRank () {
					return this.rank;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
						this.src_sys_id = readInteger(dis);
					
					this.sub_sys_id = readString(dis);
					
						this.object_id = readInteger(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
						this.rank = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// Integer
				
						writeInteger(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// Integer
				
						writeInteger(this.rank,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+String.valueOf(src_sys_id));
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+String.valueOf(object_id));
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",rank="+String.valueOf(rank));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(rank == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rank);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.status = readString(dis);
					
					this.run_id = readString(dis);
					
					this.object_nm = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.err_msg = readString(dis);
					
						this.priority = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",status="+status);
		sb.append(",run_id="+run_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",priority="+String.valueOf(priority));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[0];

	
			    public String process_type;

				public String getProcess_type () {
					return this.process_type;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Ingestion_Master_Job.length == 0) {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Ingestion_Master_Job = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Ingestion_Master_Job, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Ingestion_Master_Job) {

        	try {

        		int length = 0;
		
					this.process_type = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.status = readString(dis);
					
					this.object_nm = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.process_type,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("process_type="+process_type);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",status="+status);
		sb.append(",object_nm="+object_nm);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(process_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(process_type);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
		String currentVirtualComponent = null;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();

		row9Struct row9 = new row9Struct();
out1Struct out1 = new out1Struct();

			row11Struct row11 = new row11Struct();
out2Struct out2 = new out2Struct();
row12Struct row12 = new row12Struct();
row16Struct row16 = new row16Struct();
row13Struct row13 = new row13Struct();





	
	/**
	 * [tSortRow_1_SortOut begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_1_SortOut", false);
		start_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSortRow_1_SortOut = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSortRow_1_SortOut - "  + ("Start to work.") );
    	class BytesLimit65535_tSortRow_1_SortOut{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSortRow_1_SortOut = new StringBuilder();
            log4jParamters_tSortRow_1_SortOut.append("Parameters:");
                    log4jParamters_tSortRow_1_SortOut.append("DESTINATION" + " = " + "tSortRow_1");
                log4jParamters_tSortRow_1_SortOut.append(" | ");
                    log4jParamters_tSortRow_1_SortOut.append("EXTERNAL" + " = " + "false");
                log4jParamters_tSortRow_1_SortOut.append(" | ");
                    log4jParamters_tSortRow_1_SortOut.append("CRITERIA" + " = " + "[{ORDER="+("asc")+", COLNAME="+("process_type")+", SORT="+("alpha")+"}, {ORDER="+("asc")+", COLNAME="+("src_sys_id")+", SORT="+("num")+"}, {ORDER="+("asc")+", COLNAME="+("sub_sys_id")+", SORT="+("alpha")+"}, {ORDER="+("asc")+", COLNAME="+("object_id")+", SORT="+("num")+"}, {ORDER="+("asc")+", COLNAME="+("rank")+", SORT="+("num")+"}, {ORDER="+("asc")+", COLNAME="+("priority")+", SORT="+("num")+"}]");
                log4jParamters_tSortRow_1_SortOut.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSortRow_1_SortOut - "  + (log4jParamters_tSortRow_1_SortOut) );
    		}
    	}
    	
        new BytesLimit65535_tSortRow_1_SortOut().limitLog4jByte();


class Comparableout2Struct extends out2Struct implements Comparable<Comparableout2Struct> {
	
	public int compareTo(Comparableout2Struct other) {

		if(this.process_type == null && other.process_type != null){
			return -1;
						
		}else if(this.process_type != null && other.process_type == null){
			return 1;
						
		}else if(this.process_type != null && other.process_type != null){
			if(!this.process_type.equals(other.process_type)){
				return this.process_type.compareTo(other.process_type);
			}
		}
		if(this.src_sys_id == null && other.src_sys_id != null){
			return -1;
						
		}else if(this.src_sys_id != null && other.src_sys_id == null){
			return 1;
						
		}else if(this.src_sys_id != null && other.src_sys_id != null){
			if(!this.src_sys_id.equals(other.src_sys_id)){
				return this.src_sys_id.compareTo(other.src_sys_id);
			}
		}
		if(this.sub_sys_id == null && other.sub_sys_id != null){
			return -1;
						
		}else if(this.sub_sys_id != null && other.sub_sys_id == null){
			return 1;
						
		}else if(this.sub_sys_id != null && other.sub_sys_id != null){
			if(!this.sub_sys_id.equals(other.sub_sys_id)){
				return this.sub_sys_id.compareTo(other.sub_sys_id);
			}
		}
		if(this.object_id == null && other.object_id != null){
			return -1;
						
		}else if(this.object_id != null && other.object_id == null){
			return 1;
						
		}else if(this.object_id != null && other.object_id != null){
			if(!this.object_id.equals(other.object_id)){
				return this.object_id.compareTo(other.object_id);
			}
		}
		if(this.rank == null && other.rank != null){
			return -1;
						
		}else if(this.rank != null && other.rank == null){
			return 1;
						
		}else if(this.rank != null && other.rank != null){
			if(!this.rank.equals(other.rank)){
				return this.rank.compareTo(other.rank);
			}
		}
		if(this.priority == null && other.priority != null){
			return -1;
						
		}else if(this.priority != null && other.priority == null){
			return 1;
						
		}else if(this.priority != null && other.priority != null){
			if(!this.priority.equals(other.priority)){
				return this.priority.compareTo(other.priority);
			}
		}
		return 0;
	}
}

java.util.List<Comparableout2Struct> list_tSortRow_1_SortOut = new java.util.ArrayList<Comparableout2Struct>();


 



/**
 * [tSortRow_1_SortOut begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row11" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_2 = new StringBuilder();
            log4jParamters_tMap_2.append("Parameters:");
                    log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
    		}
    	}
    	
        new BytesLimit65535_tMap_2().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row11_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
	int src_sys_id;
	String sub_sys_id;
	int object_id;
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out2_tMap_2 = 0;
				
out2Struct out2_tmp = new out2Struct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tUnite_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tUnite_1", false);
		start_Hash.put("tUnite_1", System.currentTimeMillis());
		
	
	currentComponent="tUnite_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out1" + iterateId, 0, 0);
					
				}
			} 

		
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row10" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tUnite_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tUnite_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tUnite_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tUnite_1 = new StringBuilder();
            log4jParamters_tUnite_1.append("Parameters:");
                if(log.isDebugEnabled())
            log.debug("tUnite_1 - "  + (log4jParamters_tUnite_1) );
    		}
    	}
    	
        new BytesLimit65535_tUnite_1().limitLog4jByte();

int nb_line_tUnite_1 = 0;

 



/**
 * [tUnite_1 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_1", false);
		start_Hash.put("tMSSqlInput_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_1";

	
		int tos_count_tMSSqlInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_1 = new StringBuilder();
            log4jParamters_tMSSqlInput_1.append("Parameters:");
                    log4jParamters_tMSSqlInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("QUERY" + " = " + "\"  SELECT DISTINCT CASE WHEN IT.STG_ID = '1' THEN 'INGESTION' WHEN IT.STG_ID = '2' THEN 'MERGE' ELSE '' END AS PROCESS_TYPE  	, COALESCE(LD.STATUS, IT.STATUS)  	, IT.RUN_ID  	, IT.OBJECT_NM  	, ISNULL(LD.SRC_RECORD_CNT, 0)  	, ISNULL(LD.LD_RECORD_CNT, 0)  	, ISNULL(LD.RJCT_RECORD_CNT, 0)  	, ISNULL(LD.ERR_RECORD_CNT, 0)  	, IT.SRC_SYS_ID  	, IT.SUB_SYS_ID  	, IT.OBJECT_ID  	, STUFF((SELECT '|' + ER.ERR_MSG  			 FROM DBO.T_ERROR_LOG_DTL ER  			 WHERE ER.RUN_ID = IT.RUN_ID  			 FOR XML PATH('')), 1, 1, '') AS ERR_MSG  	, 1 AS PRIORITY  FROM DBO.T_INGTN_TRCKNG_DTL IT  	INNER JOIN DBO.STATCATCHER ST  		ON IT.RUN_ID = ST.RUN_ID  	LEFT JOIN DBO.T_LOAD_STATUS_DTL LD  		ON IT.RUN_ID = LD.RUN_ID  			AND IT.OBJECT_ID = LD.OBJECT_ID  WHERE ST.ROOT_PID = '\" + pid + \"'  	AND UPPER(ST.MESSAGE_TYPE) = 'BEGIN'  	AND ST.MOMENT > '\" + TalendDate.formatDate(\"yyyy-MM-dd HH:mm:ss\", ((Date)globalMap.get(\"JOB_START_DTTM\"))) + \"'  \"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("process_type")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("status")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("run_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("object_nm")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("src_record_cnt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ld_record_cnt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("rjct_record_cnt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("err_record_cnt")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("src_sys_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("sub_sys_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("object_id")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("err_msg")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("priority")+"}]");
                log4jParamters_tMSSqlInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + (log4jParamters_tMSSqlInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_1().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_1, talendToDBArray_tMSSqlInput_1); 
		    int nb_line_tMSSqlInput_1 = 0;
		    java.sql.Connection conn_tMSSqlInput_1 = null;
		        conn_tMSSqlInput_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_1 != null) {
					if(conn_tMSSqlInput_1.getMetaData() != null) {
						
						log.debug("tMSSqlInput_1 - Uses an existing connection with username '" + conn_tMSSqlInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_1 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_1 = conn_tMSSqlInput_1.createStatement();

		    String dbquery_tMSSqlInput_1 = "\nSELECT DISTINCT CASE WHEN IT.STG_ID = '1' THEN 'INGESTION' WHEN IT.STG_ID = '2' THEN 'MERGE' ELSE '' END AS PROCESS_TYPE\n	, COALESCE(LD.STATUS, IT.STATUS)\n	, IT.RUN_ID\n	, IT.OBJECT_NM\n	, ISNULL(LD.SRC_RECORD_CNT, 0)\n	, ISNULL(LD.LD_RECORD_CNT, 0)\n	, ISNULL(LD.RJCT_RECORD_CNT, 0)\n	, ISNULL(LD.ERR_RECORD_CNT, 0)\n	, IT.SRC_SYS_ID\n	, IT.SUB_SYS_ID\n	, IT.OBJECT_ID\n	, STUFF((SELECT '|' + ER.ERR_MSG\n			 FROM DBO.T_ERROR_LOG_DTL ER\n			 WHERE ER.RUN_ID = IT.RUN_ID\n			 FOR XML PATH('')), 1, 1, '') AS ERR_MSG\n	, 1 AS PRIORITY\nFROM DBO.T_INGTN_TRCKNG_DTL IT\n	INNER JOIN DBO.STATCATCHER ST\n		ON IT.RUN_ID = ST.RUN_ID\n	LEFT JOIN DBO.T_LOAD_STATUS_DTL LD\n		ON IT.RUN_ID = LD.RUN_ID\n			AND IT.OBJECT_ID = LD.OBJECT_ID\nWHERE ST.ROOT_PID = '" + pid + "'\n	AND UPPER(ST.MESSAGE_TYPE) = 'BEGIN'\n	AND ST.MOMENT > '" + TalendDate.formatDate("yyyy-MM-dd HH:mm:ss", ((Date)globalMap.get("JOB_START_DTTM"))) + "'\n";
			
                log.debug("tMSSqlInput_1 - Executing the query: '"+dbquery_tMSSqlInput_1+"'.");
			

                       globalMap.put("tMSSqlInput_1_QUERY",dbquery_tMSSqlInput_1);

		    java.sql.ResultSet rs_tMSSqlInput_1 = null;
		try{
		    rs_tMSSqlInput_1 = stmt_tMSSqlInput_1.executeQuery(dbquery_tMSSqlInput_1);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_1 = rs_tMSSqlInput_1.getMetaData();
		    int colQtyInRs_tMSSqlInput_1 = rsmd_tMSSqlInput_1.getColumnCount();

		    String tmpContent_tMSSqlInput_1 = null;
		    
		    
		    	log.debug("tMSSqlInput_1 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_1.next()) {
		        nb_line_tMSSqlInput_1++;
		        
							if(colQtyInRs_tMSSqlInput_1 < 1) {
								row10.process_type = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(1);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.process_type = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.process_type = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.process_type = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 2) {
								row10.status = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(2);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.status = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.status = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.status = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 3) {
								row10.run_id = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(3);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.run_id = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.run_id = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.run_id = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 4) {
								row10.object_nm = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(4);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.object_nm = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.object_nm = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.object_nm = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 5) {
								row10.src_record_cnt = null;
							} else {
		                          
            if(rs_tMSSqlInput_1.getObject(5) != null) {
                row10.src_record_cnt = rs_tMSSqlInput_1.getLong(5);
            } else {
                    row10.src_record_cnt = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 6) {
								row10.ld_record_cnt = null;
							} else {
		                          
            if(rs_tMSSqlInput_1.getObject(6) != null) {
                row10.ld_record_cnt = rs_tMSSqlInput_1.getLong(6);
            } else {
                    row10.ld_record_cnt = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 7) {
								row10.rjct_record_cnt = null;
							} else {
		                          
            if(rs_tMSSqlInput_1.getObject(7) != null) {
                row10.rjct_record_cnt = rs_tMSSqlInput_1.getInt(7);
            } else {
                    row10.rjct_record_cnt = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 8) {
								row10.err_record_cnt = null;
							} else {
		                          
            if(rs_tMSSqlInput_1.getObject(8) != null) {
                row10.err_record_cnt = rs_tMSSqlInput_1.getInt(8);
            } else {
                    row10.err_record_cnt = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 9) {
								row10.src_sys_id = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(9);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.src_sys_id = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.src_sys_id = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.src_sys_id = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 10) {
								row10.sub_sys_id = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(10);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.sub_sys_id = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.sub_sys_id = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.sub_sys_id = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 11) {
								row10.object_id = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(11);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.object_id = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.object_id = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.object_id = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 12) {
								row10.err_msg = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(12);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
            		row10.err_msg = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row10.err_msg = tmpContent_tMSSqlInput_1;
                }
            } else {
                row10.err_msg = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 13) {
								row10.priority = null;
							} else {
		                          
            if(rs_tMSSqlInput_1.getObject(13) != null) {
                row10.priority = rs_tMSSqlInput_1.getInt(13);
            } else {
                    row10.priority = null;
            }
		                    }
					
						log.debug("tMSSqlInput_1 - Retrieving the record " + nb_line_tMSSqlInput_1 + ".");
					





 



/**
 * [tMSSqlInput_1 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

 


	tos_count_tMSSqlInput_1++;

/**
 * [tMSSqlInput_1 main ] stop
 */

	
	/**
	 * [tUnite_1 main ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

			//out1
			//row10


			

		

			//row10
			//row10


			
				if(execStat){
					runStat.updateStatOnConnection("row10"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out1 - " + (out1==null? "": out1.toLogString()));
    			}
    		
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		
//////////
 

// for output
			row11 = new row11Struct();
								
			row11.process_type = row10.process_type;								
			row11.status = row10.status;								
			row11.run_id = row10.run_id;								
			row11.object_nm = row10.object_nm;								
			row11.src_record_cnt = row10.src_record_cnt;								
			row11.ld_record_cnt = row10.ld_record_cnt;								
			row11.rjct_record_cnt = row10.rjct_record_cnt;								
			row11.err_record_cnt = row10.err_record_cnt;								
			row11.src_sys_id = row10.src_sys_id;								
			row11.sub_sys_id = row10.sub_sys_id;								
			row11.object_id = row10.object_id;								
			row11.err_msg = row10.err_msg;								
			row11.priority = row10.priority;			

			nb_line_tUnite_1++;

//////////
 


	tos_count_tUnite_1++;

/**
 * [tUnite_1 main ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

			//row11
			//row11


			
				if(execStat){
					runStat.updateStatOnConnection("row11"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;
Var.src_sys_id = Relational.ISNULL(row11.src_sys_id) ? 0 : Integer.parseInt(row11.src_sys_id) ;
Var.sub_sys_id = Relational.ISNULL(row11.sub_sys_id) ? "0" : row11.sub_sys_id;
Var.object_id = Relational.ISNULL(row11.object_id) ? 0 : Integer.parseInt(row11.object_id);// ###############################
        // ###############################
        // # Output tables

out2 = null;


// # Output table : 'out2'
count_out2_tMap_2++;

out2_tmp.process_type = row11.process_type ;
out2_tmp.status = row11.status;
out2_tmp.run_id = row11.run_id;
out2_tmp.object_nm = row11.object_nm;
out2_tmp.src_record_cnt = row11.src_record_cnt;
out2_tmp.ld_record_cnt = row11.ld_record_cnt;
out2_tmp.rjct_record_cnt = row11.rjct_record_cnt;
out2_tmp.err_record_cnt = row11.err_record_cnt;
out2_tmp.src_sys_id = Var.src_sys_id ;
out2_tmp.sub_sys_id = Var.sub_sys_id ;
out2_tmp.object_id = Var.object_id ;
out2_tmp.err_msg = row11.err_msg;
out2_tmp.priority = row11.priority;
out2_tmp.rank = Numeric.sequence("seq_" + Var.src_sys_id + Var.sub_sys_id + Var.object_id + row11.priority, 1, 1);
out2 = out2_tmp;
log.debug("tMap_2 - Outputting the record " + count_out2_tMap_2 + " of the output table 'out2'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
// Start of branch "out2"
if(out2 != null) { 



	
	/**
	 * [tSortRow_1_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

			//out2
			//out2


			
				if(execStat){
					runStat.updateStatOnConnection("out2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out2 - " + (out2==null? "": out2.toLogString()));
    			}
    		



	Comparableout2Struct arrayRowtSortRow_1_SortOut = new Comparableout2Struct();

	arrayRowtSortRow_1_SortOut.process_type = out2.process_type;
	arrayRowtSortRow_1_SortOut.status = out2.status;
	arrayRowtSortRow_1_SortOut.run_id = out2.run_id;
	arrayRowtSortRow_1_SortOut.object_nm = out2.object_nm;
	arrayRowtSortRow_1_SortOut.src_record_cnt = out2.src_record_cnt;
	arrayRowtSortRow_1_SortOut.ld_record_cnt = out2.ld_record_cnt;
	arrayRowtSortRow_1_SortOut.rjct_record_cnt = out2.rjct_record_cnt;
	arrayRowtSortRow_1_SortOut.err_record_cnt = out2.err_record_cnt;
	arrayRowtSortRow_1_SortOut.src_sys_id = out2.src_sys_id;
	arrayRowtSortRow_1_SortOut.sub_sys_id = out2.sub_sys_id;
	arrayRowtSortRow_1_SortOut.object_id = out2.object_id;
	arrayRowtSortRow_1_SortOut.err_msg = out2.err_msg;
	arrayRowtSortRow_1_SortOut.priority = out2.priority;
	arrayRowtSortRow_1_SortOut.rank = out2.rank;	
	list_tSortRow_1_SortOut.add(arrayRowtSortRow_1_SortOut);

 


	tos_count_tSortRow_1_SortOut++;

/**
 * [tSortRow_1_SortOut main ] stop
 */

} // End of branch "out2"










	
	/**
	 * [tMSSqlInput_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

	}
}finally{
	stmt_tMSSqlInput_1.close();

}
globalMap.put("tMSSqlInput_1_NB_LINE",nb_line_tMSSqlInput_1);
	    		log.debug("tMSSqlInput_1 - Retrieved records count: "+nb_line_tMSSqlInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_1", true);
end_Hash.put("tMSSqlInput_1", System.currentTimeMillis());




/**
 * [tMSSqlInput_1 end ] stop
 */

	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row9" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_1 = new StringBuilder();
            log4jParamters_tMap_1.append("Parameters:");
                    log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
    		}
    	}
    	
        new BytesLimit65535_tMap_1().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row9_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out1_tMap_1 = 0;
				
out1Struct out1_tmp = new out1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tHashInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_2", false);
		start_Hash.put("tHashInput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_2";

	
		int tos_count_tHashInput_2 = 0;
		
    	class BytesLimit65535_tHashInput_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashInput_2().limitLog4jByte();


int nb_line_tHashInput_2 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row18Struct> tHashFile_tHashInput_2 = mf_tHashInput_2.getAdvancedMemoryHashFile("tHashFile_Jb_Ingestion_Master_Job_" + pid +"_tHashOutput_4");
if(tHashFile_tHashInput_2==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row18Struct> iterator_tHashInput_2 = tHashFile_tHashInput_2.iterator();
while (iterator_tHashInput_2.hasNext()) {
    row18Struct next_tHashInput_2 = iterator_tHashInput_2.next();

	row9.process_type = next_tHashInput_2.process_type;
	row9.src_sys_id = next_tHashInput_2.src_sys_id;
	row9.sub_sys_id = next_tHashInput_2.sub_sys_id;
	row9.object_id = next_tHashInput_2.object_id;
	row9.status = next_tHashInput_2.status;
	row9.object_nm = next_tHashInput_2.object_nm;
 



/**
 * [tHashInput_2 begin ] stop
 */
	
	/**
	 * [tHashInput_2 main ] start
	 */

	

	
	
	currentComponent="tHashInput_2";

	

 


	tos_count_tHashInput_2++;

/**
 * [tHashInput_2 main ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

			//row9
			//row9


			
				if(execStat){
					runStat.updateStatOnConnection("row9"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

out1 = null;


// # Output table : 'out1'
count_out1_tMap_1++;

out1_tmp.process_type = row9.process_type ;
out1_tmp.status = row9.status;
out1_tmp.run_id = "Not created";
out1_tmp.object_nm = row9.object_nm;
out1_tmp.src_record_cnt = 0L;
out1_tmp.ld_record_cnt = 0L;
out1_tmp.rjct_record_cnt = 0;
out1_tmp.err_record_cnt = 0;
out1_tmp.src_sys_id = row9.src_sys_id ;
out1_tmp.sub_sys_id = row9.sub_sys_id ;
out1_tmp.object_id = row9.object_id ;
out1_tmp.err_msg = "The job has failed. Please check the log for more information.";
out1_tmp.priority = 2;
out1 = out1_tmp;
log.debug("tMap_1 - Outputting the record " + count_out1_tMap_1 + " of the output table 'out1'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
// Start of branch "out1"
if(out1 != null) { 



	
	/**
	 * [tUnite_1 main ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

			//out1
			//out1


			
				if(execStat){
					runStat.updateStatOnConnection("out1"+iterateId,1, 1);
				} 
			

		

			//row10
			//out1


			

		
    			if(log.isTraceEnabled()){
    				log.trace("out1 - " + (out1==null? "": out1.toLogString()));
    			}
    		
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		
//////////
 

// for output
			row11 = new row11Struct();
								
			row11.process_type = out1.process_type;								
			row11.status = out1.status;								
			row11.run_id = out1.run_id;								
			row11.object_nm = out1.object_nm;								
			row11.src_record_cnt = out1.src_record_cnt;								
			row11.ld_record_cnt = out1.ld_record_cnt;								
			row11.rjct_record_cnt = out1.rjct_record_cnt;								
			row11.err_record_cnt = out1.err_record_cnt;								
			row11.src_sys_id = out1.src_sys_id;								
			row11.sub_sys_id = out1.sub_sys_id;								
			row11.object_id = out1.object_id;								
			row11.err_msg = out1.err_msg;								
			row11.priority = out1.priority;			

			nb_line_tUnite_1++;

//////////
 


	tos_count_tUnite_1++;

/**
 * [tUnite_1 main ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

			//row11
			//row11


			
				if(execStat){
					runStat.updateStatOnConnection("row11"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;
Var.src_sys_id = Relational.ISNULL(row11.src_sys_id) ? 0 : Integer.parseInt(row11.src_sys_id) ;
Var.sub_sys_id = Relational.ISNULL(row11.sub_sys_id) ? "0" : row11.sub_sys_id;
Var.object_id = Relational.ISNULL(row11.object_id) ? 0 : Integer.parseInt(row11.object_id);// ###############################
        // ###############################
        // # Output tables

out2 = null;


// # Output table : 'out2'
count_out2_tMap_2++;

out2_tmp.process_type = row11.process_type ;
out2_tmp.status = row11.status;
out2_tmp.run_id = row11.run_id;
out2_tmp.object_nm = row11.object_nm;
out2_tmp.src_record_cnt = row11.src_record_cnt;
out2_tmp.ld_record_cnt = row11.ld_record_cnt;
out2_tmp.rjct_record_cnt = row11.rjct_record_cnt;
out2_tmp.err_record_cnt = row11.err_record_cnt;
out2_tmp.src_sys_id = Var.src_sys_id ;
out2_tmp.sub_sys_id = Var.sub_sys_id ;
out2_tmp.object_id = Var.object_id ;
out2_tmp.err_msg = row11.err_msg;
out2_tmp.priority = row11.priority;
out2_tmp.rank = Numeric.sequence("seq_" + Var.src_sys_id + Var.sub_sys_id + Var.object_id + row11.priority, 1, 1);
out2 = out2_tmp;
log.debug("tMap_2 - Outputting the record " + count_out2_tMap_2 + " of the output table 'out2'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
// Start of branch "out2"
if(out2 != null) { 



	
	/**
	 * [tSortRow_1_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

			//out2
			//out2


			
				if(execStat){
					runStat.updateStatOnConnection("out2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out2 - " + (out2==null? "": out2.toLogString()));
    			}
    		



	Comparableout2Struct arrayRowtSortRow_1_SortOut = new Comparableout2Struct();

	arrayRowtSortRow_1_SortOut.process_type = out2.process_type;
	arrayRowtSortRow_1_SortOut.status = out2.status;
	arrayRowtSortRow_1_SortOut.run_id = out2.run_id;
	arrayRowtSortRow_1_SortOut.object_nm = out2.object_nm;
	arrayRowtSortRow_1_SortOut.src_record_cnt = out2.src_record_cnt;
	arrayRowtSortRow_1_SortOut.ld_record_cnt = out2.ld_record_cnt;
	arrayRowtSortRow_1_SortOut.rjct_record_cnt = out2.rjct_record_cnt;
	arrayRowtSortRow_1_SortOut.err_record_cnt = out2.err_record_cnt;
	arrayRowtSortRow_1_SortOut.src_sys_id = out2.src_sys_id;
	arrayRowtSortRow_1_SortOut.sub_sys_id = out2.sub_sys_id;
	arrayRowtSortRow_1_SortOut.object_id = out2.object_id;
	arrayRowtSortRow_1_SortOut.err_msg = out2.err_msg;
	arrayRowtSortRow_1_SortOut.priority = out2.priority;
	arrayRowtSortRow_1_SortOut.rank = out2.rank;	
	list_tSortRow_1_SortOut.add(arrayRowtSortRow_1_SortOut);

 


	tos_count_tSortRow_1_SortOut++;

/**
 * [tSortRow_1_SortOut main ] stop
 */

} // End of branch "out2"








} // End of branch "out1"







	
	/**
	 * [tHashInput_2 end ] start
	 */

	

	
	
	currentComponent="tHashInput_2";

	
    

		
			nb_line_tHashInput_2++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_Jb_Ingestion_Master_Job_" + pid +"_tHashOutput_4");
	


	globalMap.put("tHashInput_2_NB_LINE", nb_line_tHashInput_2);       

 

ok_Hash.put("tHashInput_2", true);
end_Hash.put("tHashInput_2", System.currentTimeMillis());




/**
 * [tHashInput_2 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out1': " + count_out1_tMap_1 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row9"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */



	
	/**
	 * [tUnite_1 end ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

globalMap.put("tUnite_1_NB_LINE", nb_line_tUnite_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out1"+iterateId,2, 0); 
			 	}
			}
		
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row10"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tUnite_1 - "  + ("Done.") );

ok_Hash.put("tUnite_1", true);
end_Hash.put("tUnite_1", System.currentTimeMillis());




/**
 * [tUnite_1 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'out2': " + count_out2_tMap_2 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row11"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tSortRow_1_SortOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

out2Struct[] array_tSortRow_1_SortOut = list_tSortRow_1_SortOut.toArray(new Comparableout2Struct[0]);

java.util.Arrays.sort(array_tSortRow_1_SortOut);

globalMap.put("tSortRow_1",array_tSortRow_1_SortOut);


			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSortRow_1_SortOut - "  + ("Done.") );

ok_Hash.put("tSortRow_1_SortOut", true);
end_Hash.put("tSortRow_1_SortOut", System.currentTimeMillis());




/**
 * [tSortRow_1_SortOut end ] stop
 */


	
	/**
	 * [tAggregateRow_1_AGGOUT begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGOUT", false);
		start_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row12" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tAggregateRow_1_AGGOUT = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + ("Start to work.") );
    	class BytesLimit65535_tAggregateRow_1_AGGOUT{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAggregateRow_1_AGGOUT = new StringBuilder();
            log4jParamters_tAggregateRow_1_AGGOUT.append("Parameters:");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("DESTINATION" + " = " + "tAggregateRow_1");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("src_sys_id")+", INPUT_COLUMN="+("src_sys_id")+"}, {OUTPUT_COLUMN="+("sub_sys_id")+", INPUT_COLUMN="+("sub_sys_id")+"}, {OUTPUT_COLUMN="+("object_id")+", INPUT_COLUMN="+("object_id")+"}, {OUTPUT_COLUMN="+("rank")+", INPUT_COLUMN="+("rank")+"}]");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="+("status")+", INPUT_COLUMN="+("status")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("run_id")+", INPUT_COLUMN="+("run_id")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("object_nm")+", INPUT_COLUMN="+("object_nm")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("src_record_cnt")+", INPUT_COLUMN="+("src_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("ld_record_cnt")+", INPUT_COLUMN="+("ld_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("rjct_record_cnt")+", INPUT_COLUMN="+("rjct_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("err_record_cnt")+", INPUT_COLUMN="+("err_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("err_msg")+", INPUT_COLUMN="+("err_msg")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("priority")+", INPUT_COLUMN="+("priority")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}]");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("LIST_DELIMITER" + " = " + "\",\"");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("USE_FINANCIAL_PRECISION" + " = " + "true");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGOUT.append("CHECK_ULP" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGOUT.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + (log4jParamters_tAggregateRow_1_AGGOUT) );
    		}
    	}
    	
        new BytesLimit65535_tAggregateRow_1_AGGOUT().limitLog4jByte();

// ------------ Seems it is not used

java.util.Map hashAggreg_tAggregateRow_1 = new java.util.HashMap(); 

// ------------

	class UtilClass_tAggregateRow_1 { // G_OutBegin_AggR_144

		public double sd(Double[] data) {
	        final int n = data.length;
        	if (n < 2) {
	            return Double.NaN;
        	}
        	double d1 = 0d;
        	double d2 =0d;
	        
	        for (int i = 0; i < data.length; i++) {
            	d1 += (data[i]*data[i]);
            	d2 += data[i];
        	}
        
	        return Math.sqrt((n*d1 - d2*d2)/n/(n-1));
	    }
	    
		public void checkedIADD(byte a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		    byte r = (byte) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'short/Short'", "'byte/Byte'"));
		    }
		}
		
		public void checkedIADD(short a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		    short r = (short) (a + b);
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'int/Integer'", "'short/Short'"));
		    }
		}
		
		public void checkedIADD(int a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		    int r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'long/Long'", "'int/Integer'"));
		    }
		}
		
		public void checkedIADD(long a, long b, boolean checkTypeOverFlow, boolean checkUlp) {
		    long r = a + b;
		    if (checkTypeOverFlow && ((a ^ r) & (b ^ r)) < 0) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'long/Long'"));
		    }
		}
		
		public void checkedIADD(float a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    float minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
			    }
			}
			
		    if (checkTypeOverFlow && ((double) a + (double) b > (double) Float.MAX_VALUE) || ((double) a + (double) b < (double) -Float.MAX_VALUE)) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'double' or 'BigDecimal'", "'float/Float'"));
		    }
		}
		
		public void checkedIADD(double a, double b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, byte b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, short b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, int b, boolean checkTypeOverFlow, boolean checkUlp) {
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		public void checkedIADD(double a, float b, boolean checkTypeOverFlow, boolean checkUlp) {
		
			if(checkUlp) {
			    double minAddedValue = Math.ulp(a);
			    if (minAddedValue > Math.abs(b)) {
			        throw new RuntimeException(buildPrecisionMessage(String.valueOf(a), String.valueOf(a), "'BigDecimal'", "'double/Double'"));
			    }
			}
		
		    if (checkTypeOverFlow && (a + b > (double) Double.MAX_VALUE) || (a + b < -Double.MAX_VALUE )) {
		        throw new RuntimeException(buildOverflowMessage(String.valueOf(a), String.valueOf(b), "'BigDecimal'", "'double/Double'"));
		    }
		}
		
		private String buildOverflowMessage(String a, String b, String advicedTypes, String originalType) {
		    return "Type overflow when adding " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}
		
		private String buildPrecisionMessage(String a, String b, String advicedTypes, String originalType) {
		    return "The double precision is unsufficient to add the value " + b + " to " + a
		    + ", to resolve this problem, increase the precision by using "+ advicedTypes +" type in place of "+ originalType +".";
		}

	} // G_OutBegin_AggR_144

	UtilClass_tAggregateRow_1 utilClass_tAggregateRow_1 = new UtilClass_tAggregateRow_1();

	

	class AggOperationStruct_tAggregateRow_1 { // G_OutBegin_AggR_100

		private static final int DEFAULT_HASHCODE = 1;
	    private static final int PRIME = 31;
	    private int hashCode = DEFAULT_HASHCODE;
	    public boolean hashCodeDirty = true;

    				Integer src_sys_id;
    				String sub_sys_id;
    				Integer object_id;
    				Integer rank;
         			String status_first;
         			String run_id_first;
         			String object_nm_first;
         			Long src_record_cnt_first;
         			Long ld_record_cnt_first;
         			Integer rjct_record_cnt_first;
         			Integer err_record_cnt_first;
         			String err_msg_first;
         			Integer priority_first;
        
	    @Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;
		
							result = prime * result + ((this.src_sys_id == null) ? 0 : this.src_sys_id.hashCode());
							
							result = prime * result + ((this.sub_sys_id == null) ? 0 : this.sub_sys_id.hashCode());
							
							result = prime * result + ((this.object_id == null) ? 0 : this.object_id.hashCode());
							
							result = prime * result + ((this.rank == null) ? 0 : this.rank.hashCode());
							
	    		this.hashCode = result;
	    		this.hashCodeDirty = false;		
			}
			return this.hashCode;
		}
		
		@Override
		public boolean equals(Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			final AggOperationStruct_tAggregateRow_1 other = (AggOperationStruct_tAggregateRow_1) obj;
			
							if (this.src_sys_id == null) {
								if (other.src_sys_id != null) 
									return false;
							} else if (!this.src_sys_id.equals(other.src_sys_id)) 
								return false;
						
							if (this.sub_sys_id == null) {
								if (other.sub_sys_id != null) 
									return false;
							} else if (!this.sub_sys_id.equals(other.sub_sys_id)) 
								return false;
						
							if (this.object_id == null) {
								if (other.object_id != null) 
									return false;
							} else if (!this.object_id.equals(other.object_id)) 
								return false;
						
							if (this.rank == null) {
								if (other.rank != null) 
									return false;
							} else if (!this.rank.equals(other.rank)) 
								return false;
						
			
			return true;
		}
  
        
	} // G_OutBegin_AggR_100

	AggOperationStruct_tAggregateRow_1 operation_result_tAggregateRow_1 = null;
	AggOperationStruct_tAggregateRow_1 operation_finder_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();
	java.util.Map<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1> hash_tAggregateRow_1 = new java.util.HashMap<AggOperationStruct_tAggregateRow_1,AggOperationStruct_tAggregateRow_1>();
	

 



/**
 * [tAggregateRow_1_AGGOUT begin ] stop
 */



	
	/**
	 * [tSortRow_1_SortIn begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_1_SortIn", false);
		start_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	
		int tos_count_tSortRow_1_SortIn = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSortRow_1_SortIn - "  + ("Start to work.") );
    	class BytesLimit65535_tSortRow_1_SortIn{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSortRow_1_SortIn = new StringBuilder();
            log4jParamters_tSortRow_1_SortIn.append("Parameters:");
                    log4jParamters_tSortRow_1_SortIn.append("ORIGIN" + " = " + "tSortRow_1");
                log4jParamters_tSortRow_1_SortIn.append(" | ");
                    log4jParamters_tSortRow_1_SortIn.append("EXTERNAL" + " = " + "false");
                log4jParamters_tSortRow_1_SortIn.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSortRow_1_SortIn - "  + (log4jParamters_tSortRow_1_SortIn) );
    		}
    	}
    	
        new BytesLimit65535_tSortRow_1_SortIn().limitLog4jByte();


out2Struct[] array_tSortRow_1_SortIn = (out2Struct[]) globalMap.get("tSortRow_1");

int nb_line_tSortRow_1_SortIn = 0;

out2Struct current_tSortRow_1_SortIn = null;

for(int i_tSortRow_1_SortIn = 0; i_tSortRow_1_SortIn < array_tSortRow_1_SortIn.length; i_tSortRow_1_SortIn++){
	current_tSortRow_1_SortIn = array_tSortRow_1_SortIn[i_tSortRow_1_SortIn];
	row12.process_type = current_tSortRow_1_SortIn.process_type;
	row12.status = current_tSortRow_1_SortIn.status;
	row12.run_id = current_tSortRow_1_SortIn.run_id;
	row12.object_nm = current_tSortRow_1_SortIn.object_nm;
	row12.src_record_cnt = current_tSortRow_1_SortIn.src_record_cnt;
	row12.ld_record_cnt = current_tSortRow_1_SortIn.ld_record_cnt;
	row12.rjct_record_cnt = current_tSortRow_1_SortIn.rjct_record_cnt;
	row12.err_record_cnt = current_tSortRow_1_SortIn.err_record_cnt;
	row12.src_sys_id = current_tSortRow_1_SortIn.src_sys_id;
	row12.sub_sys_id = current_tSortRow_1_SortIn.sub_sys_id;
	row12.object_id = current_tSortRow_1_SortIn.object_id;
	row12.err_msg = current_tSortRow_1_SortIn.err_msg;
	row12.priority = current_tSortRow_1_SortIn.priority;
	row12.rank = current_tSortRow_1_SortIn.rank;
	// increase number of line sorted
	nb_line_tSortRow_1_SortIn++;

 



/**
 * [tSortRow_1_SortIn begin ] stop
 */
	
	/**
	 * [tSortRow_1_SortIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 


	tos_count_tSortRow_1_SortIn++;

/**
 * [tSortRow_1_SortIn main ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

			//row12
			//row12


			
				if(execStat){
					runStat.updateStatOnConnection("row12"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		
	
operation_finder_tAggregateRow_1.src_sys_id = row12.src_sys_id;
			operation_finder_tAggregateRow_1.sub_sys_id = row12.sub_sys_id;
			operation_finder_tAggregateRow_1.object_id = row12.object_id;
			operation_finder_tAggregateRow_1.rank = row12.rank;
			

	operation_finder_tAggregateRow_1.hashCodeDirty = true;
	
	operation_result_tAggregateRow_1 = hash_tAggregateRow_1.get(operation_finder_tAggregateRow_1);

	
		boolean isFirstAdd_tAggregateRow_1 = false;
	

	if(operation_result_tAggregateRow_1 == null) { // G_OutMain_AggR_001

		operation_result_tAggregateRow_1 = new AggOperationStruct_tAggregateRow_1();

		operation_result_tAggregateRow_1.src_sys_id = operation_finder_tAggregateRow_1.src_sys_id;
				operation_result_tAggregateRow_1.sub_sys_id = operation_finder_tAggregateRow_1.sub_sys_id;
				operation_result_tAggregateRow_1.object_id = operation_finder_tAggregateRow_1.object_id;
				operation_result_tAggregateRow_1.rank = operation_finder_tAggregateRow_1.rank;
				
		
		
			isFirstAdd_tAggregateRow_1 = true;
		

		hash_tAggregateRow_1.put(operation_result_tAggregateRow_1, operation_result_tAggregateRow_1);
	
	} // G_OutMain_AggR_001


	
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.status_first = row12.status;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.run_id_first = row12.run_id;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.object_nm_first = row12.object_nm;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.src_record_cnt_first = row12.src_record_cnt;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.ld_record_cnt_first = row12.ld_record_cnt;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.rjct_record_cnt_first = row12.rjct_record_cnt;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.err_record_cnt_first = row12.err_record_cnt;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.err_msg_first = row12.err_msg;
				}
				
				if(isFirstAdd_tAggregateRow_1 ) {
					operation_result_tAggregateRow_1.priority_first = row12.priority;
				}
				


 


	tos_count_tAggregateRow_1_AGGOUT++;

/**
 * [tAggregateRow_1_AGGOUT main ] stop
 */



	
	/**
	 * [tSortRow_1_SortIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	


}

globalMap.put("tSortRow_1_SortIn_NB_LINE",nb_line_tSortRow_1_SortIn);

 
                if(log.isDebugEnabled())
            log.debug("tSortRow_1_SortIn - "  + ("Done.") );

ok_Hash.put("tSortRow_1_SortIn", true);
end_Hash.put("tSortRow_1_SortIn", System.currentTimeMillis());




/**
 * [tSortRow_1_SortIn end ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row12"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGOUT - "  + ("Done.") );

ok_Hash.put("tAggregateRow_1_AGGOUT", true);
end_Hash.put("tAggregateRow_1_AGGOUT", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGOUT end ] stop
 */


	
	/**
	 * [tSortRow_2_SortOut begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_2_SortOut", false);
		start_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row16" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSortRow_2_SortOut = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSortRow_2_SortOut - "  + ("Start to work.") );
    	class BytesLimit65535_tSortRow_2_SortOut{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSortRow_2_SortOut = new StringBuilder();
            log4jParamters_tSortRow_2_SortOut.append("Parameters:");
                    log4jParamters_tSortRow_2_SortOut.append("DESTINATION" + " = " + "tSortRow_2");
                log4jParamters_tSortRow_2_SortOut.append(" | ");
                    log4jParamters_tSortRow_2_SortOut.append("EXTERNAL" + " = " + "false");
                log4jParamters_tSortRow_2_SortOut.append(" | ");
                    log4jParamters_tSortRow_2_SortOut.append("CRITERIA" + " = " + "[{ORDER="+("desc")+", COLNAME="+("status")+", SORT="+("alpha")+"}, {ORDER="+("asc")+", COLNAME="+("process_type")+", SORT="+("alpha")+"}, {ORDER="+("asc")+", COLNAME="+("object_nm")+", SORT="+("alpha")+"}]");
                log4jParamters_tSortRow_2_SortOut.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSortRow_2_SortOut - "  + (log4jParamters_tSortRow_2_SortOut) );
    		}
    	}
    	
        new BytesLimit65535_tSortRow_2_SortOut().limitLog4jByte();


class Comparablerow16Struct extends row16Struct implements Comparable<Comparablerow16Struct> {
	
	public int compareTo(Comparablerow16Struct other) {

		if(this.status == null && other.status != null){
			return 1;
						
		}else if(this.status != null && other.status == null){
			return -1;
						
		}else if(this.status != null && other.status != null){
			if(!this.status.equals(other.status)){
				return other.status.compareTo(this.status);
			}
		}
		if(this.process_type == null && other.process_type != null){
			return -1;
						
		}else if(this.process_type != null && other.process_type == null){
			return 1;
						
		}else if(this.process_type != null && other.process_type != null){
			if(!this.process_type.equals(other.process_type)){
				return this.process_type.compareTo(other.process_type);
			}
		}
		if(this.object_nm == null && other.object_nm != null){
			return -1;
						
		}else if(this.object_nm != null && other.object_nm == null){
			return 1;
						
		}else if(this.object_nm != null && other.object_nm != null){
			if(!this.object_nm.equals(other.object_nm)){
				return this.object_nm.compareTo(other.object_nm);
			}
		}
		return 0;
	}
}

java.util.List<Comparablerow16Struct> list_tSortRow_2_SortOut = new java.util.ArrayList<Comparablerow16Struct>();


 



/**
 * [tSortRow_2_SortOut begin ] stop
 */



	
	/**
	 * [tAggregateRow_1_AGGIN begin ] start
	 */

	

	
		
		ok_Hash.put("tAggregateRow_1_AGGIN", false);
		start_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	
		int tos_count_tAggregateRow_1_AGGIN = 0;
		
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Start to work.") );
    	class BytesLimit65535_tAggregateRow_1_AGGIN{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tAggregateRow_1_AGGIN = new StringBuilder();
            log4jParamters_tAggregateRow_1_AGGIN.append("Parameters:");
                    log4jParamters_tAggregateRow_1_AGGIN.append("ORIGIN" + " = " + "tAggregateRow_1");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("GROUPBYS" + " = " + "[{OUTPUT_COLUMN="+("src_sys_id")+", INPUT_COLUMN="+("src_sys_id")+"}, {OUTPUT_COLUMN="+("sub_sys_id")+", INPUT_COLUMN="+("sub_sys_id")+"}, {OUTPUT_COLUMN="+("object_id")+", INPUT_COLUMN="+("object_id")+"}, {OUTPUT_COLUMN="+("rank")+", INPUT_COLUMN="+("rank")+"}]");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("OPERATIONS" + " = " + "[{OUTPUT_COLUMN="+("status")+", INPUT_COLUMN="+("status")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("run_id")+", INPUT_COLUMN="+("run_id")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("object_nm")+", INPUT_COLUMN="+("object_nm")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("src_record_cnt")+", INPUT_COLUMN="+("src_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("ld_record_cnt")+", INPUT_COLUMN="+("ld_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("rjct_record_cnt")+", INPUT_COLUMN="+("rjct_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("err_record_cnt")+", INPUT_COLUMN="+("err_record_cnt")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("err_msg")+", INPUT_COLUMN="+("err_msg")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}, {OUTPUT_COLUMN="+("priority")+", INPUT_COLUMN="+("priority")+", IGNORE_NULL="+("false")+", FUNCTION="+("first")+"}]");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("LIST_DELIMITER" + " = " + "\",\"");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("USE_FINANCIAL_PRECISION" + " = " + "true");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_TYPE_OVERFLOW" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                    log4jParamters_tAggregateRow_1_AGGIN.append("CHECK_ULP" + " = " + "false");
                log4jParamters_tAggregateRow_1_AGGIN.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + (log4jParamters_tAggregateRow_1_AGGIN) );
    		}
    	}
    	
        new BytesLimit65535_tAggregateRow_1_AGGIN().limitLog4jByte();

java.util.Collection<AggOperationStruct_tAggregateRow_1> values_tAggregateRow_1 = hash_tAggregateRow_1.values();

globalMap.put("tAggregateRow_1_NB_LINE", values_tAggregateRow_1.size());

                if(log.isInfoEnabled())
            log.info("tAggregateRow_1_AGGIN - "  + ("Retrieving the aggregation results.") );
for(AggOperationStruct_tAggregateRow_1 aggregated_row_tAggregateRow_1 : values_tAggregateRow_1) { // G_AggR_600



 



/**
 * [tAggregateRow_1_AGGIN begin ] stop
 */
	
	/**
	 * [tAggregateRow_1_AGGIN main ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

                                row16.status = aggregated_row_tAggregateRow_1.status_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'status'.") );
                                row16.run_id = aggregated_row_tAggregateRow_1.run_id_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'run_id'.") );
                                row16.object_nm = aggregated_row_tAggregateRow_1.object_nm_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'object_nm'.") );
                                row16.src_record_cnt = aggregated_row_tAggregateRow_1.src_record_cnt_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'src_record_cnt'.") );
                                row16.ld_record_cnt = aggregated_row_tAggregateRow_1.ld_record_cnt_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'ld_record_cnt'.") );
                                row16.rjct_record_cnt = aggregated_row_tAggregateRow_1.rjct_record_cnt_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'rjct_record_cnt'.") );
                                row16.err_record_cnt = aggregated_row_tAggregateRow_1.err_record_cnt_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'err_record_cnt'.") );
            				    String s_src_sys_id_src_sys_id_tAggregateRow_1 = String.valueOf(aggregated_row_tAggregateRow_1.src_sys_id);
            				    row16.src_sys_id = s_src_sys_id_src_sys_id_tAggregateRow_1;
            				    
            				    row16.sub_sys_id = aggregated_row_tAggregateRow_1.sub_sys_id;
            				    
            				    String s_object_id_object_id_tAggregateRow_1 = String.valueOf(aggregated_row_tAggregateRow_1.object_id);
            				    row16.object_id = s_object_id_object_id_tAggregateRow_1;
            				    
                                row16.err_msg = aggregated_row_tAggregateRow_1.err_msg_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'err_msg'.") );
                                row16.priority = aggregated_row_tAggregateRow_1.priority_first;
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Operation function: 'first' on the column 'priority'.") );
            				    row16.rank = aggregated_row_tAggregateRow_1.rank;
            				    

 


	tos_count_tAggregateRow_1_AGGIN++;

/**
 * [tAggregateRow_1_AGGIN main ] stop
 */

	
	/**
	 * [tSortRow_2_SortOut main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

			//row16
			//row16


			
				if(execStat){
					runStat.updateStatOnConnection("row16"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row16 - " + (row16==null? "": row16.toLogString()));
    			}
    		



	Comparablerow16Struct arrayRowtSortRow_2_SortOut = new Comparablerow16Struct();

	arrayRowtSortRow_2_SortOut.process_type = row16.process_type;
	arrayRowtSortRow_2_SortOut.status = row16.status;
	arrayRowtSortRow_2_SortOut.run_id = row16.run_id;
	arrayRowtSortRow_2_SortOut.object_nm = row16.object_nm;
	arrayRowtSortRow_2_SortOut.src_record_cnt = row16.src_record_cnt;
	arrayRowtSortRow_2_SortOut.ld_record_cnt = row16.ld_record_cnt;
	arrayRowtSortRow_2_SortOut.rjct_record_cnt = row16.rjct_record_cnt;
	arrayRowtSortRow_2_SortOut.err_record_cnt = row16.err_record_cnt;
	arrayRowtSortRow_2_SortOut.src_sys_id = row16.src_sys_id;
	arrayRowtSortRow_2_SortOut.sub_sys_id = row16.sub_sys_id;
	arrayRowtSortRow_2_SortOut.object_id = row16.object_id;
	arrayRowtSortRow_2_SortOut.err_msg = row16.err_msg;
	arrayRowtSortRow_2_SortOut.priority = row16.priority;
	arrayRowtSortRow_2_SortOut.rank = row16.rank;	
	list_tSortRow_2_SortOut.add(arrayRowtSortRow_2_SortOut);

 


	tos_count_tSortRow_2_SortOut++;

/**
 * [tSortRow_2_SortOut main ] stop
 */



	
	/**
	 * [tAggregateRow_1_AGGIN end ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

} // G_AggR_600

 
                if(log.isDebugEnabled())
            log.debug("tAggregateRow_1_AGGIN - "  + ("Done.") );

ok_Hash.put("tAggregateRow_1_AGGIN", true);
end_Hash.put("tAggregateRow_1_AGGIN", System.currentTimeMillis());




/**
 * [tAggregateRow_1_AGGIN end ] stop
 */

	
	/**
	 * [tSortRow_2_SortOut end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

row16Struct[] array_tSortRow_2_SortOut = list_tSortRow_2_SortOut.toArray(new Comparablerow16Struct[0]);

java.util.Arrays.sort(array_tSortRow_2_SortOut);

globalMap.put("tSortRow_2",array_tSortRow_2_SortOut);


			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row16"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSortRow_2_SortOut - "  + ("Done.") );

ok_Hash.put("tSortRow_2_SortOut", true);
end_Hash.put("tSortRow_2_SortOut", System.currentTimeMillis());




/**
 * [tSortRow_2_SortOut end ] stop
 */


	
	/**
	 * [tJavaFlex_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaFlex_1", false);
		start_Hash.put("tJavaFlex_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaFlex_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row13" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaFlex_1 = 0;
		
    	class BytesLimit65535_tJavaFlex_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaFlex_1().limitLog4jByte();


globalMap.put("EMAIL_MESSAGE", ((String)globalMap.get("EMAIL_MESSAGE")) + "<table border=\"1\"><tr><th>Status</th><th>Run ID</th><th>Object Name</th><th>Source Count</th><th>Load Count</th><th>Reject Count</th><th>Error Count</th><th>Message</th></tr>");
      


 



/**
 * [tJavaFlex_1 begin ] stop
 */



	
	/**
	 * [tSortRow_2_SortIn begin ] start
	 */

	

	
		
		ok_Hash.put("tSortRow_2_SortIn", false);
		start_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());
		
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	
		int tos_count_tSortRow_2_SortIn = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSortRow_2_SortIn - "  + ("Start to work.") );
    	class BytesLimit65535_tSortRow_2_SortIn{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSortRow_2_SortIn = new StringBuilder();
            log4jParamters_tSortRow_2_SortIn.append("Parameters:");
                    log4jParamters_tSortRow_2_SortIn.append("ORIGIN" + " = " + "tSortRow_2");
                log4jParamters_tSortRow_2_SortIn.append(" | ");
                    log4jParamters_tSortRow_2_SortIn.append("EXTERNAL" + " = " + "false");
                log4jParamters_tSortRow_2_SortIn.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSortRow_2_SortIn - "  + (log4jParamters_tSortRow_2_SortIn) );
    		}
    	}
    	
        new BytesLimit65535_tSortRow_2_SortIn().limitLog4jByte();


row16Struct[] array_tSortRow_2_SortIn = (row16Struct[]) globalMap.get("tSortRow_2");

int nb_line_tSortRow_2_SortIn = 0;

row16Struct current_tSortRow_2_SortIn = null;

for(int i_tSortRow_2_SortIn = 0; i_tSortRow_2_SortIn < array_tSortRow_2_SortIn.length; i_tSortRow_2_SortIn++){
	current_tSortRow_2_SortIn = array_tSortRow_2_SortIn[i_tSortRow_2_SortIn];
	row13.process_type = current_tSortRow_2_SortIn.process_type;
	row13.status = current_tSortRow_2_SortIn.status;
	row13.run_id = current_tSortRow_2_SortIn.run_id;
	row13.object_nm = current_tSortRow_2_SortIn.object_nm;
	row13.src_record_cnt = current_tSortRow_2_SortIn.src_record_cnt;
	row13.ld_record_cnt = current_tSortRow_2_SortIn.ld_record_cnt;
	row13.rjct_record_cnt = current_tSortRow_2_SortIn.rjct_record_cnt;
	row13.err_record_cnt = current_tSortRow_2_SortIn.err_record_cnt;
	row13.src_sys_id = current_tSortRow_2_SortIn.src_sys_id;
	row13.sub_sys_id = current_tSortRow_2_SortIn.sub_sys_id;
	row13.object_id = current_tSortRow_2_SortIn.object_id;
	row13.err_msg = current_tSortRow_2_SortIn.err_msg;
	row13.priority = current_tSortRow_2_SortIn.priority;
	row13.rank = current_tSortRow_2_SortIn.rank;
	// increase number of line sorted
	nb_line_tSortRow_2_SortIn++;

 



/**
 * [tSortRow_2_SortIn begin ] stop
 */
	
	/**
	 * [tSortRow_2_SortIn main ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 


	tos_count_tSortRow_2_SortIn++;

/**
 * [tSortRow_2_SortIn main ] stop
 */

	
	/**
	 * [tJavaFlex_1 main ] start
	 */

	

	
	
	currentComponent="tJavaFlex_1";

	

			//row13
			//row13


			
				if(execStat){
					runStat.updateStatOnConnection("row13"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		



globalMap.put("EMAIL_MESSAGE", ((String)globalMap.get("EMAIL_MESSAGE")) + "<tr>" + ("C".equals(row13.status) ? "<td bgcolor=\"#00FF00\">" : "F".equals(row13.status) ? "<td bgcolor=\"#FF0000\">" : "<td>" + row13.status) + "</td><td>" + row13.run_id + "</td><td>" + row13.object_nm + "</td><td>" + row13.src_record_cnt + "</td><td>" + row13.ld_record_cnt + "</td><td>" + row13.rjct_record_cnt + "</td><td>" + row13.err_record_cnt + "</td><td>" + (Relational.ISNULL(row13.err_msg) ? "" : row13.err_msg) + "</td></tr>");


 


	tos_count_tJavaFlex_1++;

/**
 * [tJavaFlex_1 main ] stop
 */



	
	/**
	 * [tSortRow_2_SortIn end ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	


}

globalMap.put("tSortRow_2_SortIn_NB_LINE",nb_line_tSortRow_2_SortIn);

 
                if(log.isDebugEnabled())
            log.debug("tSortRow_2_SortIn - "  + ("Done.") );

ok_Hash.put("tSortRow_2_SortIn", true);
end_Hash.put("tSortRow_2_SortIn", System.currentTimeMillis());




/**
 * [tSortRow_2_SortIn end ] stop
 */

	
	/**
	 * [tJavaFlex_1 end ] start
	 */

	

	
	
	currentComponent="tJavaFlex_1";

	


globalMap.put("EMAIL_MESSAGE", ((String)globalMap.get("EMAIL_MESSAGE")) + "</table>");
      

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row13"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaFlex_1", true);
end_Hash.put("tJavaFlex_1", System.currentTimeMillis());




/**
 * [tJavaFlex_1 end ] stop
 */
























				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
					te.setVirtualComponentName(currentVirtualComponent);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
							//free memory for "tSortRow_2_SortIn"
							globalMap.remove("tSortRow_2");
						
							//free memory for "tAggregateRow_1_AGGIN"
							globalMap.remove("tAggregateRow_1");
						
							//free memory for "tSortRow_1_SortIn"
							globalMap.remove("tSortRow_1");
						
				try{
					
	
	/**
	 * [tMSSqlInput_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

 



/**
 * [tMSSqlInput_1 finally ] stop
 */
	
	/**
	 * [tHashInput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_2";

	

 



/**
 * [tHashInput_2 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */



	
	/**
	 * [tUnite_1 finally ] start
	 */

	

	
	
	currentComponent="tUnite_1";

	

 



/**
 * [tUnite_1 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tSortRow_1_SortOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortOut";

	

 



/**
 * [tSortRow_1_SortOut finally ] stop
 */

	
	/**
	 * [tSortRow_1_SortIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_1";
	
	currentComponent="tSortRow_1_SortIn";

	

 



/**
 * [tSortRow_1_SortIn finally ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGOUT finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGOUT";

	

 



/**
 * [tAggregateRow_1_AGGOUT finally ] stop
 */

	
	/**
	 * [tAggregateRow_1_AGGIN finally ] start
	 */

	

	
	
		currentVirtualComponent = "tAggregateRow_1";
	
	currentComponent="tAggregateRow_1_AGGIN";

	

 



/**
 * [tAggregateRow_1_AGGIN finally ] stop
 */

	
	/**
	 * [tSortRow_2_SortOut finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortOut";

	

 



/**
 * [tSortRow_2_SortOut finally ] stop
 */

	
	/**
	 * [tSortRow_2_SortIn finally ] start
	 */

	

	
	
		currentVirtualComponent = "tSortRow_2";
	
	currentComponent="tSortRow_2_SortIn";

	

 



/**
 * [tSortRow_2_SortIn finally ] stop
 */

	
	/**
	 * [tJavaFlex_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaFlex_1";

	

 



/**
 * [tJavaFlex_1 finally ] stop
 */
























				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_8", false);
		start_Hash.put("tJava_8", System.currentTimeMillis());
		
	
	currentComponent="tJava_8";

	
		int tos_count_tJava_8 = 0;
		
    	class BytesLimit65535_tJava_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_8().limitLog4jByte();



 



/**
 * [tJava_8 begin ] stop
 */
	
	/**
	 * [tJava_8 main ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 


	tos_count_tJava_8++;

/**
 * [tJava_8 main ] stop
 */
	
	/**
	 * [tJava_8 end ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 

ok_Hash.put("tJava_8", true);
end_Hash.put("tJava_8", System.currentTimeMillis());

   			if ("Y".equals((String)globalMap.get("RERUN_FAILED"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "true");
					}
				
    			tMSSqlRow_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If9", 0, "false");
					}   	 
   				}



/**
 * [tJava_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk6", 0, "ok");
								} 
							
							tFileList_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_8 finally ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 



/**
 * [tJava_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_8_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tMSSqlRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_1", false);
		start_Hash.put("tMSSqlRow_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_1";

	
		int tos_count_tMSSqlRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_1 = new StringBuilder();
            log4jParamters_tMSSqlRow_1.append("Parameters:");
                    log4jParamters_tMSSqlRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("QUERY" + " = " + "\"  UPDATE DBO.T_TALEND_CONTEXT_LOAD  SET CONTEXT_VALUE = 'N'  WHERE CONTEXT_KEY = 'RERUN_FAILED'  	AND CONTEXT_ID = (SELECT CONTEXT_ID  					  FROM DBO.T_SRC_SYS_DCT_TBL  					  WHERE SRC_SYS_ID = '\" + context.src_sys_id + \"'  \" + (Relational.ISNULL(globalMap.get(\"MERGE_SUBSYTEM_FILES\")) ?   \"					  	AND SUB_SYS_ID = '\" + context.sub_sys_id + \"')\"  :  \"\"  ) + \"  \"");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("DIE_ON_ERROR" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + (log4jParamters_tMSSqlRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_1().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_1 = null;
	String query_tMSSqlRow_1 = "";
	boolean whetherReject_tMSSqlRow_1 = false;
				conn_tMSSqlRow_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_1 != null) {
					if(conn_tMSSqlRow_1.getMetaData() != null) {
						
						log.debug("tMSSqlRow_1 - Uses an existing connection with username '" + conn_tMSSqlRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_1 = conn_tMSSqlRow_1.createStatement();
	

 



/**
 * [tMSSqlRow_1 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

	    		log.debug("tMSSqlRow_1 - Executing the query: '" + "  UPDATE DBO.T_TALEND_CONTEXT_LOAD  SET CONTEXT_VALUE = 'N'  WHERE CONTEXT_KEY = 'RERUN_FAILED'  	AND CONTEXT_ID = (SELECT CONTEXT_ID  					  FROM DBO.T_SRC_SYS_DCT_TBL  					  WHERE SRC_SYS_ID = '" + context.src_sys_id + "'  " + (Relational.ISNULL(globalMap.get("MERGE_SUBSYTEM_FILES")) ?   "					  	AND SUB_SYS_ID = '" + context.sub_sys_id + "')"  :  ""  ) + "  " + "'.");
			
query_tMSSqlRow_1 = "\nUPDATE DBO.T_TALEND_CONTEXT_LOAD\nSET CONTEXT_VALUE = 'N'\nWHERE CONTEXT_KEY = 'RERUN_FAILED'\n	AND CONTEXT_ID = (SELECT CONTEXT_ID\n					  FROM DBO.T_SRC_SYS_DCT_TBL\n					  WHERE SRC_SYS_ID = '" + context.src_sys_id + "'\n" + (Relational.ISNULL(globalMap.get("MERGE_SUBSYTEM_FILES")) ? 
"					  	AND SUB_SYS_ID = '" + context.sub_sys_id + "')"
:
""
) + "\n";
whetherReject_tMSSqlRow_1 = false;
globalMap.put("tMSSqlRow_1_QUERY",query_tMSSqlRow_1);
try {
		stmt_tMSSqlRow_1.execute(query_tMSSqlRow_1);
		
	    		log.debug("tMSSqlRow_1 - Execute the query: '" + "\nUPDATE DBO.T_TALEND_CONTEXT_LOAD\nSET CONTEXT_VALUE = 'N'\nWHERE CONTEXT_KEY = 'RERUN_FAILED'\n	AND CONTEXT_ID = (SELECT CONTEXT_ID\n					  FROM DBO.T_SRC_SYS_DCT_TBL\n					  WHERE SRC_SYS_ID = '" + context.src_sys_id + "'\n" + (Relational.ISNULL(globalMap.get("MERGE_SUBSYTEM_FILES")) ? 
"					  	AND SUB_SYS_ID = '" + context.sub_sys_id + "')"
:
""
) + "\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_1 = true;
		
				log.error("tMSSqlRow_1 - " + e.getMessage());
			
				System.err.print(e.getMessage());
				
	}
	

 


	tos_count_tMSSqlRow_1++;

/**
 * [tMSSqlRow_1 main ] stop
 */
	
	/**
	 * [tMSSqlRow_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

	
	stmt_tMSSqlRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_1", true);
end_Hash.put("tMSSqlRow_1", System.currentTimeMillis());




/**
 * [tMSSqlRow_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

 



/**
 * [tMSSqlRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tFileList_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileList_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tFileList_1 begin ] start
	 */

				
			int NB_ITERATE_tFileDelete_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFileList_1", false);
		start_Hash.put("tFileList_1", System.currentTimeMillis());
		
	
	currentComponent="tFileList_1";

	
		int tos_count_tFileList_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileList_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileList_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileList_1 = new StringBuilder();
            log4jParamters_tFileList_1.append("Parameters:");
                    log4jParamters_tFileList_1.append("DIRECTORY" + " = " + "((String)globalMap.get(\"TALEND_FILE_PATH\"))");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("LIST_MODE" + " = " + "DIRECTORIES");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("INCLUDSUBDIR" + " = " + "true");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("CASE_SENSITIVE" + " = " + "YES");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("ERROR" + " = " + "false");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("GLOBEXPRESSIONS" + " = " + "true");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("FILES" + " = " + "[{FILEMASK="+("pid")+"}]");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("ORDER_BY_NOTHING" + " = " + "true");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("ORDER_BY_FILENAME" + " = " + "false");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("ORDER_BY_FILESIZE" + " = " + "false");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("ORDER_BY_MODIFIEDDATE" + " = " + "false");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("ORDER_ACTION_ASC" + " = " + "true");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("ORDER_ACTION_DESC" + " = " + "false");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("IFEXCLUDE" + " = " + "false");
                log4jParamters_tFileList_1.append(" | ");
                    log4jParamters_tFileList_1.append("FORMAT_FILEPATH_TO_SLASH" + " = " + "false");
                log4jParamters_tFileList_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileList_1 - "  + (log4jParamters_tFileList_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileList_1().limitLog4jByte();
	
 
  
				final StringBuffer log4jSb_tFileList_1 = new StringBuffer();
			   
    
  String directory_tFileList_1 = ((String)globalMap.get("TALEND_FILE_PATH"));
  final java.util.List<String> maskList_tFileList_1 = new java.util.ArrayList<String>();
  final java.util.List<java.util.regex.Pattern> patternList_tFileList_1 = new java.util.ArrayList<java.util.regex.Pattern>(); 
    maskList_tFileList_1.add(pid);  
  for (final String filemask_tFileList_1 : maskList_tFileList_1) {
	String filemask_compile_tFileList_1 = filemask_tFileList_1;
	
		filemask_compile_tFileList_1 = org.apache.oro.text.GlobCompiler.globToPerl5(filemask_tFileList_1.toCharArray(), org.apache.oro.text.GlobCompiler.DEFAULT_MASK);
	
		java.util.regex.Pattern fileNamePattern_tFileList_1 = java.util.regex.Pattern.compile(filemask_compile_tFileList_1);
	patternList_tFileList_1.add(fileNamePattern_tFileList_1);
  }
  int NB_FILEtFileList_1 = 0;

  final boolean case_sensitive_tFileList_1 = true;
    final java.util.List<java.io.File> list_tFileList_1 = new java.util.ArrayList<java.io.File>();
    final java.util.Set<String> filePath_tFileList_1 = new java.util.HashSet<String>();
	java.io.File file_tFileList_1 = new java.io.File(directory_tFileList_1);
    
		file_tFileList_1.listFiles(new java.io.FilenameFilter() {
			public boolean accept(java.io.File dir, String name) {
				java.io.File file = new java.io.File(dir, name);
				
	                if (!file.isDirectory()) {
	                  return true;
	                } else {
	                	
    	String fileName_tFileList_1 = file.getName();
		for (final java.util.regex.Pattern fileNamePattern_tFileList_1 : patternList_tFileList_1) {
          	if (fileNamePattern_tFileList_1.matcher(fileName_tFileList_1).matches()){
					if(!filePath_tFileList_1.contains(file.getAbsolutePath())) {
			          list_tFileList_1.add(file);
			          filePath_tFileList_1.add(file.getAbsolutePath());
			        }
			}
		}
	                  	file.listFiles(this);
	                }
				
				return false;
			}
		}
		); 
      java.util.Collections.sort(list_tFileList_1);
    
		log.info("tFileList_1 - Start to list files");
	
    for (int i_tFileList_1 = 0; i_tFileList_1 < list_tFileList_1.size(); i_tFileList_1++){
      java.io.File files_tFileList_1 = list_tFileList_1.get(i_tFileList_1);
      String fileName_tFileList_1 = files_tFileList_1.getName();
      
      String currentFileName_tFileList_1 = files_tFileList_1.getName(); 
      String currentFilePath_tFileList_1 = files_tFileList_1.getAbsolutePath();
      String currentFileDirectory_tFileList_1 = files_tFileList_1.getParent();
      String currentFileExtension_tFileList_1 = null;
      
      if (files_tFileList_1.getName().contains(".") && files_tFileList_1.isFile()){
        currentFileExtension_tFileList_1 = files_tFileList_1.getName().substring(files_tFileList_1.getName().lastIndexOf(".") + 1);
      } else{
        currentFileExtension_tFileList_1 = "";
      }
      
      NB_FILEtFileList_1 ++;
      globalMap.put("tFileList_1_CURRENT_FILE", currentFileName_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEPATH", currentFilePath_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEDIRECTORY", currentFileDirectory_tFileList_1);
      globalMap.put("tFileList_1_CURRENT_FILEEXTENSION", currentFileExtension_tFileList_1);
      globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);
      
		log.info("tFileList_1 - Current file or directory path : " + currentFilePath_tFileList_1);
	  
 



/**
 * [tFileList_1 begin ] stop
 */
	
	/**
	 * [tFileList_1 main ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

 


	tos_count_tFileList_1++;

/**
 * [tFileList_1 main ] stop
 */
	NB_ITERATE_tFileDelete_1++;
	
	
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tFileDelete_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tFileDelete_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileDelete_1", false);
		start_Hash.put("tFileDelete_1", System.currentTimeMillis());
		
	
	currentComponent="tFileDelete_1";

	
		int tos_count_tFileDelete_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileDelete_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileDelete_1 = new StringBuilder();
            log4jParamters_tFileDelete_1.append("Parameters:");
                    log4jParamters_tFileDelete_1.append("DIRECTORY" + " = " + "((String)globalMap.get(\"tFileList_1_CURRENT_FILEPATH\"))");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FAILON" + " = " + "true");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FOLDER" + " = " + "true");
                log4jParamters_tFileDelete_1.append(" | ");
                    log4jParamters_tFileDelete_1.append("FOLDER_FILE" + " = " + "false");
                log4jParamters_tFileDelete_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + (log4jParamters_tFileDelete_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileDelete_1().limitLog4jByte();

 



/**
 * [tFileDelete_1 begin ] stop
 */
	
	/**
	 * [tFileDelete_1 main ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 

				final StringBuffer log4jSb_tFileDelete_1 = new StringBuffer();
			
class DeleteFoldertFileDelete_1{
	 /**
     * delete all the sub-files in 'file'
     * 
     * @param file
     */
	public boolean delete(java.io.File file) {
        java.io.File[] files = file.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (files[i].isFile()) {
                files[i].delete();
            } else if (files[i].isDirectory()) {
                if (!files[i].delete()) {
                    delete(files[i]);
                }
            }
        }
        deleteDirectory(file);
        return file.delete();
    }

    /**
     * delete all the sub-folders in 'file'
     * 
     * @param file
     */
    private void deleteDirectory(java.io.File file) {
        java.io.File[] filed = file.listFiles();
        for (int i = 0; i < filed.length; i++) {
        	if(filed[i].isDirectory()) {
            	deleteDirectory(filed[i]);
            }
            filed[i].delete();
        }
    }

}

	java.io.File filetFileDelete_1 = new java.io.File(((String)globalMap.get("tFileList_1_CURRENT_FILEPATH")));

	if(filetFileDelete_1.exists()&& filetFileDelete_1.isDirectory()){
		DeleteFoldertFileDelete_1 dftFileDelete_1 = new DeleteFoldertFileDelete_1();
		if(dftFileDelete_1.delete(filetFileDelete_1)){
			globalMap.put("tFileDelete_1_CURRENT_STATUS", "Path deleted.");
    		log.info("tFileDelete_1 - Directory : "+ filetFileDelete_1.getAbsolutePath() + " is deleted.");
		}else{
			globalMap.put("tFileDelete_1_CURRENT_STATUS", "No path deleted.");
			throw new RuntimeException("Directory " + filetFileDelete_1.getAbsolutePath() + " can not be deleted.");
		}
	}else{
		globalMap.put("tFileDelete_1_CURRENT_STATUS", "Path does not exist or is invalid.");
			throw new RuntimeException("Directory " + filetFileDelete_1.getAbsolutePath() + " does not exist or is invalid or is not a directory.");
    }
    globalMap.put("tFileDelete_1_DELETE_PATH",((String)globalMap.get("tFileList_1_CURRENT_FILEPATH")));
    
     
 

 


	tos_count_tFileDelete_1++;

/**
 * [tFileDelete_1 main ] stop
 */
	
	/**
	 * [tFileDelete_1 end ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tFileDelete_1 - "  + ("Done.") );

ok_Hash.put("tFileDelete_1", true);
end_Hash.put("tFileDelete_1", System.currentTimeMillis());




/**
 * [tFileDelete_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tFileDelete_1);
						}				
					




	
	/**
	 * [tFileList_1 end ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

  
    }
  globalMap.put("tFileList_1_NB_FILE", NB_FILEtFileList_1);
  
    log.info("tFileList_1 - File or directory count : " + NB_FILEtFileList_1);

  
 

 
                if(log.isDebugEnabled())
            log.debug("tFileList_1 - "  + ("Done.") );

ok_Hash.put("tFileList_1", true);
end_Hash.put("tFileList_1", System.currentTimeMillis());




/**
 * [tFileList_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileList_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tJava_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileList_1 finally ] start
	 */

	

	
	
	currentComponent="tFileList_1";

	

 



/**
 * [tFileList_1 finally ] stop
 */

	
	/**
	 * [tFileDelete_1 finally ] start
	 */

	

	
	
	currentComponent="tFileDelete_1";

	

 



/**
 * [tFileDelete_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileList_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";

	
		int tos_count_tJava_3 = 0;
		
    	class BytesLimit65535_tJava_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_3().limitLog4jByte();


globalMap.put("EMAIL_MESSAGE", globalMap.get("EMAIL_MESSAGE") + "</body></html>");

 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk5", 0, "ok");
				}
				tSendMail_1Process(globalMap);



/**
 * [tJava_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}
	

public void tSendMail_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSendMail_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_1", false);
		start_Hash.put("tSendMail_1", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_1";

	
		int tos_count_tSendMail_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSendMail_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSendMail_1 = new StringBuilder();
            log4jParamters_tSendMail_1.append("Parameters:");
                    log4jParamters_tSendMail_1.append("TO" + " = " + "((String)globalMap.get(\"EMAIL_TO\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("FROM" + " = " + "((String)globalMap.get(\"EMAIL_FROM\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("NEED_PERSONAL_NAME" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("CC" + " = " + "((String)globalMap.get(\"EMAIL_CC\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("BCC" + " = " + "\"\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SUBJECT" + " = " + "contextStr + \" - \" + (Relational.ISNULL(globalMap.get(\"row1.src_sys_desc\")) ? (Relational.ISNULL(globalMap.get(\"JOB_NAME_QUALIFIER\")) ? \"\" : ((String)globalMap.get(\"JOB_NAME_QUALIFIER\"))) : ((String)globalMap.get(\"row1.src_sys_desc\"))) + \" - Status\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("MESSAGE" + " = " + "((String)globalMap.get(\"EMAIL_MESSAGE\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("CHECK_ATTACHMENT" + " = " + "true");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("ATTACHMENTS" + " = " + "[]");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("HEADERS" + " = " + "[]");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SMTP_HOST" + " = " + "((String)globalMap.get(\"SMTP_HOST\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SMTP_PORT" + " = " + "((String)globalMap.get(\"SMTP_PORT\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SSL" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("STARTTLS" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("IMPORTANCE" + " = " + "Normal");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("NEED_AUTH" + " = " + "true");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("AUTH_USERNAME" + " = " + "((String)globalMap.get(\"SMTP_USERNAME\"))");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("AUTH_PASSWORD" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(((String)globalMap.get("SMTP_PASSWORD")))).substring(0, 4) + "...");     
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("TEXT_SUBTYPE" + " = " + "html");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                log4jParamters_tSendMail_1.append(" | ");
                    log4jParamters_tSendMail_1.append("SET_LOCALHOST" + " = " + "false");
                log4jParamters_tSendMail_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + (log4jParamters_tSendMail_1) );
    		}
    	}
    	
        new BytesLimit65535_tSendMail_1().limitLog4jByte();

 



/**
 * [tSendMail_1 begin ] stop
 */
	
	/**
	 * [tSendMail_1 main ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 

	String smtpHost_tSendMail_1 = ((String)globalMap.get("SMTP_HOST"));
        String smtpPort_tSendMail_1 = ((String)globalMap.get("SMTP_PORT"));
	String from_tSendMail_1 = (((String)globalMap.get("EMAIL_FROM")));
    String to_tSendMail_1 = (((String)globalMap.get("EMAIL_TO"))).replace(";",",");
    String cc_tSendMail_1 = ((((String)globalMap.get("EMAIL_CC")))==null || "".equals(((String)globalMap.get("EMAIL_CC"))))?null:(((String)globalMap.get("EMAIL_CC"))).replace(";",",");
    String bcc_tSendMail_1 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String subject_tSendMail_1 = (contextStr + " - " + (Relational.ISNULL(globalMap.get("row1.src_sys_desc")) ? (Relational.ISNULL(globalMap.get("JOB_NAME_QUALIFIER")) ? "" : ((String)globalMap.get("JOB_NAME_QUALIFIER"))) : ((String)globalMap.get("row1.src_sys_desc"))) + " - Status");
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_1 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_1 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_1 = new java.util.ArrayList<String>();

	String message_tSendMail_1 = ((((String)globalMap.get("EMAIL_MESSAGE"))) == null || "".equals(((String)globalMap.get("EMAIL_MESSAGE")))) ? "\"\"" : (((String)globalMap.get("EMAIL_MESSAGE"))) ;
	java.util.Properties props_tSendMail_1 = System.getProperties();     
	props_tSendMail_1.put("mail.smtp.host", smtpHost_tSendMail_1);
	props_tSendMail_1.put("mail.smtp.port", smtpPort_tSendMail_1);
		props_tSendMail_1.put("mail.mime.encodefilename", "true");     
	try {
		
			log.info("tSendMail_1 - Connection attempt to '" + smtpHost_tSendMail_1 +"'.");
		
		
			props_tSendMail_1.put("mail.smtp.auth", "true");
			javax.mail.Session session_tSendMail_1 = javax.mail.Session.getInstance(props_tSendMail_1, new javax.mail.Authenticator(){         
				protected javax.mail.PasswordAuthentication getPasswordAuthentication() {
				
                
	final String decryptedPassword_tSendMail_1 = ((String)globalMap.get("SMTP_PASSWORD")); 
				
				
				return new javax.mail.PasswordAuthentication(((String)globalMap.get("SMTP_USERNAME")), decryptedPassword_tSendMail_1); 
				}         
			});   
		
		
			log.info("tSendMail_1 - Connection to '" + smtpHost_tSendMail_1 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_1 = new javax.mail.internet.MimeMessage(session_tSendMail_1);
		msg_tSendMail_1.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_1, null));
		msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_1, false));
		if (cc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_1, false));
		if (bcc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_1, false));
		msg_tSendMail_1.setSubject(subject_tSendMail_1);

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < headers_tSendMail_1.size(); i_tSendMail_1++) {
			java.util.Map<String, String> header_tSendMail_1 = headers_tSendMail_1.get(i_tSendMail_1);
			msg_tSendMail_1.setHeader(header_tSendMail_1.get("KEY"), header_tSendMail_1.get("VALUE"));    
		}  
		msg_tSendMail_1.setSentDate(new Date());
		msg_tSendMail_1.setHeader("X-Priority", "3"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_1 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_1.setText(message_tSendMail_1,"ISO-8859-15", "html");
		mp_tSendMail_1.addBodyPart(mbpText_tSendMail_1);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_1 = null;

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < attachments_tSendMail_1.size(); i_tSendMail_1++){
			String filename_tSendMail_1 = attachments_tSendMail_1.get(i_tSendMail_1);
			javax.activation.FileDataSource fds_tSendMail_1 = null;
			java.io.File file_tSendMail_1 = new java.io.File(filename_tSendMail_1);
			
    		if (file_tSendMail_1.isDirectory()){
				java.io.File[] subFiles_tSendMail_1 = file_tSendMail_1.listFiles();
				for(java.io.File subFile_tSendMail_1 : subFiles_tSendMail_1){
					if (subFile_tSendMail_1.isFile()){
						fds_tSendMail_1 = new javax.activation.FileDataSource(subFile_tSendMail_1.getAbsolutePath());
						mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1));
						mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
						if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
					}
				}
    		}else{
				mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_1 = new javax.activation.FileDataSource(filename_tSendMail_1);
				mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1)); 
				mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
				if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
			}
		}
		// -- set the content --
		msg_tSendMail_1.setContent(mp_tSendMail_1);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_1 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_1.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_1.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_1.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_1.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_1.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_1);
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_1);
	} catch(java.lang.Exception e){
  		
			throw(e);
		
	}finally{
		props_tSendMail_1.remove("mail.smtp.host");
		props_tSendMail_1.remove("mail.smtp.port");
		
		props_tSendMail_1.remove("mail.mime.encodefilename");
		
		props_tSendMail_1.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_1++;

/**
 * [tSendMail_1 main ] stop
 */
	
	/**
	 * [tSendMail_1 end ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Done.") );

ok_Hash.put("tSendMail_1", true);
end_Hash.put("tSendMail_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk22", 0, "ok");
				}
				tMSSqlClose_1Process(globalMap);



/**
 * [tSendMail_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_1 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 



/**
 * [tSendMail_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tMSSqlClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlClose_1", false);
		start_Hash.put("tMSSqlClose_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlClose_1";

	
		int tos_count_tMSSqlClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlClose_1 = new StringBuilder();
            log4jParamters_tMSSqlClose_1.append("Parameters:");
                    log4jParamters_tMSSqlClose_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + (log4jParamters_tMSSqlClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlClose_1().limitLog4jByte();

 



/**
 * [tMSSqlClose_1 begin ] stop
 */
	
	/**
	 * [tMSSqlClose_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_1";

	



	java.sql.Connection conn_tMSSqlClose_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	if(conn_tMSSqlClose_1 != null && !conn_tMSSqlClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Closing the connection ")  + ("conn_tMSSqlConnection_1")  + (" to the database.") );
        conn_tMSSqlClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Connection ")  + ("conn_tMSSqlConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tMSSqlClose_1++;

/**
 * [tMSSqlClose_1 main ] stop
 */
	
	/**
	 * [tMSSqlClose_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlClose_1", true);
end_Hash.put("tMSSqlClose_1", System.currentTimeMillis());




/**
 * [tMSSqlClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlClose_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_1";

	

 



/**
 * [tMSSqlClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlClose_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "PROD";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final Jb_Ingestion_Master_Job Jb_Ingestion_Master_JobClass = new Jb_Ingestion_Master_Job();

        int exitCode = Jb_Ingestion_Master_JobClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Jb_Ingestion_Master_Job' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'Jb_Ingestion_Master_Job' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Jb_Ingestion_Master_Job.class.getClassLoader().getResourceAsStream("cerebro/jb_ingestion_master_job_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
				    context.setContextType("keyfile_path", "id_String");
				
                context.keyfile_path=(String) context.getProperty("keyfile_path");
				    context.setContextType("prop_file_path", "id_String");
				
                context.prop_file_path=(String) context.getProperty("prop_file_path");
				    context.setContextType("group_id", "id_String");
				
                context.group_id=(String) context.getProperty("group_id");
				    context.setContextType("job_type", "id_String");
				
                context.job_type=(String) context.getProperty("job_type");
				    context.setContextType("override_parallel", "id_String");
				
                context.override_parallel=(String) context.getProperty("override_parallel");
				    context.setContextType("parallel_executions", "id_Integer");
				
             try{
                 context.parallel_executions=routines.system.ParserUtils.parseTo_Integer (context.getProperty("parallel_executions"));
             }catch(NumberFormatException e){
                 context.parallel_executions=null;
              }
				    context.setContextType("src_sys_id", "id_String");
				
                context.src_sys_id=(String) context.getProperty("src_sys_id");
				    context.setContextType("sub_sys_id", "id_String");
				
                context.sub_sys_id=(String) context.getProperty("sub_sys_id");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("keyfile_path")) {
                context.keyfile_path = (String) parentContextMap.get("keyfile_path");
            }if (parentContextMap.containsKey("prop_file_path")) {
                context.prop_file_path = (String) parentContextMap.get("prop_file_path");
            }if (parentContextMap.containsKey("group_id")) {
                context.group_id = (String) parentContextMap.get("group_id");
            }if (parentContextMap.containsKey("job_type")) {
                context.job_type = (String) parentContextMap.get("job_type");
            }if (parentContextMap.containsKey("override_parallel")) {
                context.override_parallel = (String) parentContextMap.get("override_parallel");
            }if (parentContextMap.containsKey("parallel_executions")) {
                context.parallel_executions = (Integer) parentContextMap.get("parallel_executions");
            }if (parentContextMap.containsKey("src_sys_id")) {
                context.src_sys_id = (String) parentContextMap.get("src_sys_id");
            }if (parentContextMap.containsKey("sub_sys_id")) {
                context.sub_sys_id = (String) parentContextMap.get("sub_sys_id");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tJava_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tJava_1) {
globalMap.put("tJava_1_SUBPROCESS_STATE", -1);

e_tJava_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Jb_Ingestion_Master_Job");
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tMSSqlConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tMSSqlConnection_1", globalMap.get("conn_tMSSqlConnection_1"));







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     595188 characters generated by Talend Real-time Big Data Platform 
 *     on the November 13, 2018 12:06:13 PM EST
 ************************************************************************************************/