
package cerebro.jb_merge_adls_staging_child_0_1;

import routines.DataCleanser;
import routines.DataOperation;
import routines.TalendEncrypt;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.DQTechnical;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.rccl_common_routine;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaRow_1
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_6
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJava_9
	//import java.util.List;

	//the import part of tJava_7
	//import java.util.List;

	//the import part of tJava_10
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJava_4
	//import java.util.List;

	//the import part of tJava_8
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: Jb_Merge_ADLS_Staging_Child Purpose: Loads data from source table into ADLS<br>
 * Description: Loads data from source table into ADLS including pre-merge data from multiple ships data <br>
 * @author Ganguly, Soumya
 * @version 6.4.1.20170623_1246
 * @status 
 */
public class Jb_Merge_ADLS_Staging_Child implements TalendJob {
	static {System.setProperty("TalendJob.log", "Jb_Merge_ADLS_Staging_Child.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(Jb_Merge_ADLS_Staging_Child.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(batch_id != null){
				
					this.setProperty("batch_id", batch_id.toString());
				
			}
			
			if(object_id != null){
				
					this.setProperty("object_id", object_id.toString());
				
			}
			
			if(object_nm != null){
				
					this.setProperty("object_nm", object_nm.toString());
				
			}
			
			if(object_position != null){
				
					this.setProperty("object_position", object_position.toString());
				
			}
			
			if(root_pid != null){
				
					this.setProperty("root_pid", root_pid.toString());
				
			}
			
			if(src_sys_id != null){
				
					this.setProperty("src_sys_id", src_sys_id.toString());
				
			}
			
			if(sub_sys_id != null){
				
					this.setProperty("sub_sys_id", sub_sys_id.toString());
				
			}
			
			if(keyfile_path != null){
				
					this.setProperty("keyfile_path", keyfile_path.toString());
				
			}
			
			if(prop_file_path != null){
				
					this.setProperty("prop_file_path", prop_file_path.toString());
				
			}
			
			if(rerun_failed != null){
				
					this.setProperty("rerun_failed", rerun_failed.toString());
				
			}
			
			if(NO_ITERATION != null){
				
					this.setProperty("NO_ITERATION", NO_ITERATION.toString());
				
			}
			
		}

public String batch_id;
public String getBatch_id(){
	return this.batch_id;
}
public String object_id;
public String getObject_id(){
	return this.object_id;
}
public String object_nm;
public String getObject_nm(){
	return this.object_nm;
}
public String object_position;
public String getObject_position(){
	return this.object_position;
}
public String root_pid;
public String getRoot_pid(){
	return this.root_pid;
}
public String src_sys_id;
public String getSrc_sys_id(){
	return this.src_sys_id;
}
public String sub_sys_id;
public String getSub_sys_id(){
	return this.sub_sys_id;
}
public String keyfile_path;
public String getKeyfile_path(){
	return this.keyfile_path;
}
public String prop_file_path;
public String getProp_file_path(){
	return this.prop_file_path;
}
public String rerun_failed;
public String getRerun_failed(){
	return this.rerun_failed;
}
public Integer NO_ITERATION;
public Integer getNO_ITERATION(){
	return this.NO_ITERATION;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Jb_Merge_ADLS_Staging_Child";
	private final String projectName = "CEREBRO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Jb_Merge_ADLS_Staging_Child.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Jb_Merge_ADLS_Staging_Child.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				tLogCatcher_1.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				tLogCatcher_1Process(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputProperties_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlRow_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSystem_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSystem_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSystem_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSystem_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSystem_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tSystem_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDie_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDie_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlRow_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_14_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_14_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputProperties_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError1", 0, "error");
						}
					
					errorCode = null;
					tWarn_1Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError2", 0, "error");
						}
					
					errorCode = null;
					tWarn_3Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError5", 0, "error");
						}
					
					errorCode = null;
					tWarn_5Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError4", 0, "error");
						}
					
					errorCode = null;
					tWarn_4Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tMSSqlRow_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError15", 0, "error");
						}
					
					errorCode = null;
					tWarn_11Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tFixedFlowInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError6", 0, "error");
						}
					
					errorCode = null;
					tWarn_6Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tFixedFlowInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError7", 0, "error");
						}
					
					errorCode = null;
					tWarn_7Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError8", 0, "error");
						}
					
					errorCode = null;
					tWarn_8Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tJava_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError3", 0, "error");
						}
					
					errorCode = null;
					tWarn_2Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSystem_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSystem_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSystem_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLogCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDie_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError13", 0, "error");
						}
					
					errorCode = null;
					tWarn_13Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tMSSqlRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlRow_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError14", 0, "error");
						}
					
					errorCode = null;
					tWarn_14Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_14_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}







			


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		
    	class BytesLimit65535_tPrejob_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tPrejob_1().limitLog4jByte();

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tFileInputProperties_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputProperties_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputProperties_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();
row6Struct row6 = new row6Struct();





	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
            log4jParamters_tSetGlobalVar_2.append("Parameters:");
                    log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("row6.value")+", KEY="+("row6.key")+"}]");
                log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */



	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_1 = 0;
		
    	class BytesLimit65535_tJavaRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_1().limitLog4jByte();

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tFileInputProperties_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputProperties_1", false);
		start_Hash.put("tFileInputProperties_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputProperties_1";

	
		int tos_count_tFileInputProperties_1 = 0;
		
    	class BytesLimit65535_tFileInputProperties_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFileInputProperties_1().limitLog4jByte();

	java.io.File file_tFileInputProperties_1 = new java.io.File(context.prop_file_path);
	int nb_line_tFileInputProperties_1 = 0;				log.debug("tFileInputProperties_1 - Retrieving records from the datasource.");
			
	java.util.Properties properties_tFileInputProperties_1 = new java.util.Properties();
	java.io.FileInputStream fis_tFileInputProperties_1=new java.io.FileInputStream(file_tFileInputProperties_1);
   	try{
		properties_tFileInputProperties_1.load(fis_tFileInputProperties_1);
		java.util.Enumeration enumeration_tFileInputProperties_1 = properties_tFileInputProperties_1.propertyNames();
		while (enumeration_tFileInputProperties_1.hasMoreElements()) {
			nb_line_tFileInputProperties_1++;
				log.debug("tFileInputProperties_1 - Retrieving the record " + (nb_line_tFileInputProperties_1) + ".");
			
			row5.key = (String)enumeration_tFileInputProperties_1.nextElement();
			row5.value = (String)properties_tFileInputProperties_1.getProperty(row5.key);

 



/**
 * [tFileInputProperties_1 begin ] stop
 */
	
	/**
	 * [tFileInputProperties_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

 


	tos_count_tFileInputProperties_1++;

/**
 * [tFileInputProperties_1 main ] stop
 */

	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

			//row5
			//row5


			
				if(execStat){
					runStat.updateStatOnConnection("row5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

    row6.key = row5.key; 
if (row5.key.toLowerCase ().contains("password")) { 
	routines.TalendEncrypt enc = new routines.TalendEncrypt();
	row6.value = enc.decryptText(row5.value, enc.getPrivate(context.keyfile_path));
} else { 
  row6.value = row5.value; 
}
    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

globalMap.put(row6.key, row6.value);

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */






	
	/**
	 * [tFileInputProperties_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

		}
	}finally{
		if(fis_tFileInputProperties_1!=null){
			fis_tFileInputProperties_1.close();
		}
	}
globalMap.put("tFileInputProperties_1_NB_LINE", nb_line_tFileInputProperties_1);
				log.debug("tFileInputProperties_1 - Retrieved records count: "+ nb_line_tFileInputProperties_1 + " .");
			
 

ok_Hash.put("tFileInputProperties_1", true);
end_Hash.put("tFileInputProperties_1", System.currentTimeMillis());




/**
 * [tFileInputProperties_1 end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row5"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());




/**
 * [tJavaRow_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());




/**
 * [tSetGlobalVar_2 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputProperties_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tMSSqlConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputProperties_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

 



/**
 * [tFileInputProperties_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

 



/**
 * [tJavaRow_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputProperties_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tMSSqlConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlConnection_1", false);
		start_Hash.put("tMSSqlConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlConnection_1";

	
		int tos_count_tMSSqlConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlConnection_1 = new StringBuilder();
            log4jParamters_tMSSqlConnection_1.append("Parameters:");
                    log4jParamters_tMSSqlConnection_1.append("DRIVER" + " = " + "JTDS");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("HOST" + " = " + "((String)globalMap.get(\"AUDIT_HOSTNAME\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PORT" + " = " + "((String)globalMap.get(\"AUDIT_PORT\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SCHEMA_DB" + " = " + "((String)globalMap.get(\"AUDIT_SCHEMA\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("DBNAME" + " = " + "((String)globalMap.get(\"AUDIT_DATABASE\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("USER" + " = " + "((String)globalMap.get(\"AUDIT_USERNAME\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(((String)globalMap.get("AUDIT_PASSWORD")))).substring(0, 4) + "...");     
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PROPERTIES" + " = " + "((String)globalMap.get(\"AUDIT_ADDITIONAL_PARAMETERS\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + (log4jParamters_tMSSqlConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlConnection_1().limitLog4jByte();
	

	
			String url_tMSSqlConnection_1 = "jdbc:jtds:sqlserver://" + ((String)globalMap.get("AUDIT_HOSTNAME")) ;
		String port_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_PORT"));
		String dbname_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_DATABASE")) ;
    	if (!"".equals(port_tMSSqlConnection_1)) {
    		url_tMSSqlConnection_1 += ":" + ((String)globalMap.get("AUDIT_PORT"));
    	}
    	if (!"".equals(dbname_tMSSqlConnection_1)) {
    		
				url_tMSSqlConnection_1 += "//" + ((String)globalMap.get("AUDIT_DATABASE")); 
    	}
		url_tMSSqlConnection_1 += ";appName=" + projectName + ";" + ((String)globalMap.get("AUDIT_ADDITIONAL_PARAMETERS"));  

	String dbUser_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_USERNAME"));
	
	
		
	final String decryptedPassword_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_PASSWORD")); 
		String dbPwd_tMSSqlConnection_1 = decryptedPassword_tMSSqlConnection_1;
	

	java.sql.Connection conn_tMSSqlConnection_1 = null;
	
		
			String driverClass_tMSSqlConnection_1 = "net.sourceforge.jtds.jdbc.Driver";
			java.lang.Class.forName(driverClass_tMSSqlConnection_1);
		
	    		log.debug("tMSSqlConnection_1 - Driver ClassName: "+driverClass_tMSSqlConnection_1+".");
			
	    		log.debug("tMSSqlConnection_1 - Connection attempt to '" + url_tMSSqlConnection_1 + "' with the username '" + dbUser_tMSSqlConnection_1 + "'.");
			
		conn_tMSSqlConnection_1 = java.sql.DriverManager.getConnection(url_tMSSqlConnection_1,dbUser_tMSSqlConnection_1,dbPwd_tMSSqlConnection_1);
	    		log.debug("tMSSqlConnection_1 - Connection to '" + url_tMSSqlConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tMSSqlConnection_1", conn_tMSSqlConnection_1);
	if (null != conn_tMSSqlConnection_1) {
		
			log.debug("tMSSqlConnection_1 - Connection is set auto commit to 'true'.");
			conn_tMSSqlConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tMSSqlConnection_1", ((String)globalMap.get("AUDIT_SCHEMA")));

	globalMap.put("db_tMSSqlConnection_1",  ((String)globalMap.get("AUDIT_DATABASE")));

	globalMap.put("conn_tMSSqlConnection_1",conn_tMSSqlConnection_1);
	
	globalMap.put("shareIdentitySetting_tMSSqlConnection_1",  false);

 



/**
 * [tMSSqlConnection_1 begin ] stop
 */
	
	/**
	 * [tMSSqlConnection_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 


	tos_count_tMSSqlConnection_1++;

/**
 * [tMSSqlConnection_1 main ] stop
 */
	
	/**
	 * [tMSSqlConnection_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlConnection_1", true);
end_Hash.put("tMSSqlConnection_1", System.currentTimeMillis());




/**
 * [tMSSqlConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tMSSqlConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tMSSqlInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 



/**
 * [tMSSqlConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";

	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
            log4jParamters_tWarn_1.append("Parameters:");
                    log4jParamters_tWarn_1.append("MESSAGE" + " = " + "\"300|Audit connection failed\"");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("CODE" + " = " + "999");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_1().limitLog4jByte();

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "ERROR","","300|Audit connection failed","", "");
            log.error("tWarn_1 - "  + ("Message: ")  + ("300|Audit connection failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_1", 5, "300|Audit connection failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_1_WARN_MESSAGES", "300|Audit connection failed"); 
globalMap.put("tWarn_1_WARN_PRIORITY", 5);
globalMap.put("tWarn_1_WARN_CODE", 999);


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());




/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();
row8Struct row8 = new row8Struct();





	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
            log4jParamters_tSetGlobalVar_3.append("Parameters:");
                    log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("row8.value")+", KEY="+("row8.key")+"}]");
                log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */



	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_2 = 0;
		
    	class BytesLimit65535_tJavaRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_2().limitLog4jByte();

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_3", false);
		start_Hash.put("tMSSqlInput_3", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_3";

	
		int tos_count_tMSSqlInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_3 = new StringBuilder();
            log4jParamters_tMSSqlInput_3.append("Parameters:");
                    log4jParamters_tMSSqlInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("QUERY" + " = " + "\"  SELECT CONTEXT_KEY, CONTEXT_VALUE FROM (  SELECT UPPER(CONTEXT_KEY) AS CONTEXT_KEY  	, CONTEXT_VALUE  	, RANK () OVER(PARTITION BY CONTEXT_KEY ORDER BY PRIORITY) AS RNK  FROM DBO.T_TALEND_CONTEXT_LOAD CT  INNER JOIN (SELECT DISTINCT CONTEXT_ID, 2 AS PRIORITY  						FROM DBO.T_SRC_SYS_DCT_TBL  						WHERE SRC_SYS_ID = '\" + context.src_sys_id + \"'  							AND SUB_SYS_ID = '\" + context.sub_sys_id + \"'  						UNION  						SELECT DISTINCT CONTEXT_ID, 1 AS PRIORITY  						FROM DBO.T_LOAD_CTL_DTL  						WHERE SRC_SYS_ID = '\" + context.src_sys_id + \"'  							AND SUB_SYS_ID = '\" + context.sub_sys_id + \"'  							AND OBJECT_ID = '\" + context.object_id + \"') T  	ON CT.CONTEXT_ID = T.CONTEXT_ID) X  WHERE RNK = 1  \"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("key")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("value")+"}]");
                log4jParamters_tMSSqlInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + (log4jParamters_tMSSqlInput_3) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_3().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_3, talendToDBArray_tMSSqlInput_3); 
		    int nb_line_tMSSqlInput_3 = 0;
		    java.sql.Connection conn_tMSSqlInput_3 = null;
		        conn_tMSSqlInput_3 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_3 != null) {
					if(conn_tMSSqlInput_3.getMetaData() != null) {
						
						log.debug("tMSSqlInput_3 - Uses an existing connection with username '" + conn_tMSSqlInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_3 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_3 = conn_tMSSqlInput_3.createStatement();

		    String dbquery_tMSSqlInput_3 = "\nSELECT CONTEXT_KEY, CONTEXT_VALUE FROM (\nSELECT UPPER(CONTEXT_KEY) AS CONTEXT_KEY\n	, CONTEXT_VALUE\n	, RANK () OVER(PARTITION BY CONTEXT_KEY ORDER BY PRIORITY) AS RNK\nFROM DBO.T_TALEND_CONTEXT_LOAD CT\nINNER JOIN (SELECT DISTINCT CONTEXT_ID, 2 AS PRIORITY\n						FROM DBO.T_SRC_SYS_DCT_TBL\n						WHERE SRC_SYS_ID = '" + context.src_sys_id + "'\n							AND SUB_SYS_ID = '" + context.sub_sys_id + "'\n						UNION\n						SELECT DISTINCT CONTEXT_ID, 1 AS PRIORITY\n						FROM DBO.T_LOAD_CTL_DTL\n						WHERE SRC_SYS_ID = '" + context.src_sys_id + "'\n							AND SUB_SYS_ID = '" + context.sub_sys_id + "'\n							AND OBJECT_ID = '" + context.object_id + "') T\n	ON CT.CONTEXT_ID = T.CONTEXT_ID) X\nWHERE RNK = 1\n";
			
                log.debug("tMSSqlInput_3 - Executing the query: '"+dbquery_tMSSqlInput_3+"'.");
			

                       globalMap.put("tMSSqlInput_3_QUERY",dbquery_tMSSqlInput_3);

		    java.sql.ResultSet rs_tMSSqlInput_3 = null;
		try{
		    rs_tMSSqlInput_3 = stmt_tMSSqlInput_3.executeQuery(dbquery_tMSSqlInput_3);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_3 = rs_tMSSqlInput_3.getMetaData();
		    int colQtyInRs_tMSSqlInput_3 = rsmd_tMSSqlInput_3.getColumnCount();

		    String tmpContent_tMSSqlInput_3 = null;
		    
		    
		    	log.debug("tMSSqlInput_3 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_3.next()) {
		        nb_line_tMSSqlInput_3++;
		        
							if(colQtyInRs_tMSSqlInput_3 < 1) {
								row7.key = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3.getString(1);
            if(tmpContent_tMSSqlInput_3 != null) {
            	if (talendToDBList_tMSSqlInput_3 .contains(rsmd_tMSSqlInput_3.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row7.key = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_3);
            	} else {
                	row7.key = tmpContent_tMSSqlInput_3;
                }
            } else {
                row7.key = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_3 < 2) {
								row7.value = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3.getString(2);
            if(tmpContent_tMSSqlInput_3 != null) {
            	if (talendToDBList_tMSSqlInput_3 .contains(rsmd_tMSSqlInput_3.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row7.value = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_3);
            	} else {
                	row7.value = tmpContent_tMSSqlInput_3;
                }
            } else {
                row7.value = null;
            }
		                    }
					
						log.debug("tMSSqlInput_3 - Retrieving the record " + nb_line_tMSSqlInput_3 + ".");
					





 



/**
 * [tMSSqlInput_3 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_3 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

 


	tos_count_tMSSqlInput_3++;

/**
 * [tMSSqlInput_3 main ] stop
 */

	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

    row8.key = row7.key; 
if (row7.key.toLowerCase ().contains("password")) { 
	routines.TalendEncrypt enc = new routines.TalendEncrypt();
	row8.value = enc.decryptText(row7.value, enc.getPrivate(context.keyfile_path));
} else { 
  row8.value = row7.value; 
}
    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

globalMap.put(row8.key, row8.value);

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */






	
	/**
	 * [tMSSqlInput_3 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

	}
}finally{
	stmt_tMSSqlInput_3.close();

}
globalMap.put("tMSSqlInput_3_NB_LINE",nb_line_tMSSqlInput_3);
	    		log.debug("tMSSqlInput_3 - Retrieved records count: "+nb_line_tMSSqlInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_3", true);
end_Hash.put("tMSSqlInput_3", System.currentTimeMillis());




/**
 * [tMSSqlInput_3 end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());




/**
 * [tJavaRow_2 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_3 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

 



/**
 * [tMSSqlInput_3 finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

 



/**
 * [tJavaRow_2 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_3", false);
		start_Hash.put("tWarn_3", System.currentTimeMillis());
		
	
	currentComponent="tWarn_3";

	
		int tos_count_tWarn_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_3 = new StringBuilder();
            log4jParamters_tWarn_3.append("Parameters:");
                    log4jParamters_tWarn_3.append("MESSAGE" + " = " + "\"301|Load context variables failed\"");
                log4jParamters_tWarn_3.append(" | ");
                    log4jParamters_tWarn_3.append("CODE" + " = " + "999");
                log4jParamters_tWarn_3.append(" | ");
                    log4jParamters_tWarn_3.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + (log4jParamters_tWarn_3) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_3().limitLog4jByte();

 



/**
 * [tWarn_3 begin ] stop
 */
	
	/**
	 * [tWarn_3 main ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_3", "", Thread.currentThread().getId() + "", "ERROR","","301|Load context variables failed","", "");
            log.error("tWarn_3 - "  + ("Message: ")  + ("301|Load context variables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_3", 5, "301|Load context variables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_3_WARN_MESSAGES", "301|Load context variables failed"); 
globalMap.put("tWarn_3_WARN_PRIORITY", 5);
globalMap.put("tWarn_3_WARN_CODE", 999);


 


	tos_count_tWarn_3++;

/**
 * [tWarn_3 main ] stop
 */
	
	/**
	 * [tWarn_3 end ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Done.") );

ok_Hash.put("tWarn_3", true);
end_Hash.put("tWarn_3", System.currentTimeMillis());




/**
 * [tWarn_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_3 finally ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

 



/**
 * [tWarn_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
    	class BytesLimit65535_tJava_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_1().limitLog4jByte();



 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());

   			if (!("F".equals((String)globalMap.get("LOAD_STATUS")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				
    			tJava_6Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_6", false);
		start_Hash.put("tJava_6", System.currentTimeMillis());
		
	
	currentComponent="tJava_6";

	
		int tos_count_tJava_6 = 0;
		
    	class BytesLimit65535_tJava_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_6().limitLog4jByte();


if (!Relational.ISNULL(globalMap.get("MERGE_SCHEDULE")) && ((String)globalMap.get("MERGE_SCHEDULE")).length() > 0) {

String [] eachTimes = ((String)globalMap.get("MERGE_SCHEDULE")).trim().split("\\s*,[,\\s]*");

long timeDiff = 3600;

String leastTime = eachTimes[0];

for (int i=0; i<eachTimes.length; i++) {

	long currTimeDiff = TalendDate.diffDate(TalendDate.getCurrentDate(), TalendDate.parseDate("yyyyMMddHHmmss", TalendDate.formatDate("yyyyMMdd", TalendDate.getCurrentDate()) + eachTimes[i] + "00"), "mm");

	if (currTimeDiff > 0 && currTimeDiff < timeDiff) {

		timeDiff = currTimeDiff;
		leastTime = eachTimes[i];
		
	}

}

globalMap.put("MERGE_SCHEDULED_DATE", TalendDate.formatDate("yyyy-MM-dd HH:mm:ss.SSS", TalendDate.parseDate("yyyyMMddHHmmss", TalendDate.formatDate("yyyyMMdd", TalendDate.getCurrentDate()) + leastTime + "00")));

}
 



/**
 * [tJava_6 begin ] stop
 */
	
	/**
	 * [tJava_6 main ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 


	tos_count_tJava_6++;

/**
 * [tJava_6 main ] stop
 */
	
	/**
	 * [tJava_6 end ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 

ok_Hash.put("tJava_6", true);
end_Hash.put("tJava_6", System.currentTimeMillis());

   			if (!Relational.ISNULL(globalMap.get("MERGE_SCHEDULED_DATE"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If12", 0, "true");
					}
				
    			tMSSqlInput_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If12", 0, "false");
					}   	 
   				}



/**
 * [tJava_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tFixedFlowInput_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_6 finally ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_6_SUBPROCESS_STATE", 1);
	}
	


public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String FILE_NM;

				public String getFILE_NM () {
					return this.FILE_NM;
				}
				
			    public String CURRENT_RUN_ID;

				public String getCURRENT_RUN_ID () {
					return this.CURRENT_RUN_ID;
				}
				
			    public String INGTN_TYP;

				public String getINGTN_TYP () {
					return this.INGTN_TYP;
				}
				
			    public String STATUS;

				public String getSTATUS () {
					return this.STATUS;
				}
				
			    public String JOB_INSTANCE_ID;

				public String getJOB_INSTANCE_ID () {
					return this.JOB_INSTANCE_ID;
				}
				
			    public String RUN_ID;

				public String getRUN_ID () {
					return this.RUN_ID;
				}
				
			    public String ADLS_FILE_LOCTN;

				public String getADLS_FILE_LOCTN () {
					return this.ADLS_FILE_LOCTN;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.FILE_NM = readString(dis);
					
					this.CURRENT_RUN_ID = readString(dis);
					
					this.INGTN_TYP = readString(dis);
					
					this.STATUS = readString(dis);
					
					this.JOB_INSTANCE_ID = readString(dis);
					
					this.RUN_ID = readString(dis);
					
					this.ADLS_FILE_LOCTN = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.FILE_NM,dos);
					
					// String
				
						writeString(this.CURRENT_RUN_ID,dos);
					
					// String
				
						writeString(this.INGTN_TYP,dos);
					
					// String
				
						writeString(this.STATUS,dos);
					
					// String
				
						writeString(this.JOB_INSTANCE_ID,dos);
					
					// String
				
						writeString(this.RUN_ID,dos);
					
					// String
				
						writeString(this.ADLS_FILE_LOCTN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("FILE_NM="+FILE_NM);
		sb.append(",CURRENT_RUN_ID="+CURRENT_RUN_ID);
		sb.append(",INGTN_TYP="+INGTN_TYP);
		sb.append(",STATUS="+STATUS);
		sb.append(",JOB_INSTANCE_ID="+JOB_INSTANCE_ID);
		sb.append(",RUN_ID="+RUN_ID);
		sb.append(",ADLS_FILE_LOCTN="+ADLS_FILE_LOCTN);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(FILE_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FILE_NM);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENT_RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENT_RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(INGTN_TYP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INGTN_TYP);
            			}
            		
        			sb.append("|");
        		
        				if(STATUS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(STATUS);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_INSTANCE_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_INSTANCE_ID);
            			}
            		
        			sb.append("|");
        		
        				if(RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(ADLS_FILE_LOCTN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ADLS_FILE_LOCTN);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row10Struct row10 = new row10Struct();




	
	/**
	 * [tHashOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_2", false);
		start_Hash.put("tHashOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row10" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_2 = 0;
		
    	class BytesLimit65535_tHashOutput_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_2().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct> tHashFile_tHashOutput_2 = null;
		String hashKey_tHashOutput_2 = "tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid + "_tHashOutput_2";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_2)){
			    if(mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2) == null){
	      		    mf_tHashOutput_2.getResourceMap().put(hashKey_tHashOutput_2, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
			    }else{
			    	tHashFile_tHashOutput_2 = mf_tHashOutput_2.getResourceMap().get(hashKey_tHashOutput_2);
			    }
			}
        int nb_line_tHashOutput_2 = 0;
 



/**
 * [tHashOutput_2 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_4", false);
		start_Hash.put("tFixedFlowInput_4", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_4";

	
		int tos_count_tFixedFlowInput_4 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_4().limitLog4jByte();

	    for (int i_tFixedFlowInput_4 = 0 ; i_tFixedFlowInput_4 < 0 ; i_tFixedFlowInput_4++) {
	                	            	
    	            		row10.FILE_NM = null;        	            	
    	            	        	            	
    	            		row10.CURRENT_RUN_ID = null;        	            	
    	            	        	            	
    	            		row10.INGTN_TYP = null;        	            	
    	            	        	            	
    	            		row10.STATUS = null;        	            	
    	            	        	            	
    	            		row10.JOB_INSTANCE_ID = null;        	            	
    	            	        	            	
    	            		row10.RUN_ID = null;        	            	
    	            	        	            	
    	            		row10.ADLS_FILE_LOCTN = null;        	            	
    	            	
 



/**
 * [tFixedFlowInput_4 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_4 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_4";

	

 


	tos_count_tFixedFlowInput_4++;

/**
 * [tFixedFlowInput_4 main ] stop
 */

	
	/**
	 * [tHashOutput_2 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	

			//row10
			//row10


			
				if(execStat){
					runStat.updateStatOnConnection("row10"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		



    
		row10Struct oneRow_tHashOutput_2 = new row10Struct();
				
					oneRow_tHashOutput_2.FILE_NM = row10.FILE_NM;
					oneRow_tHashOutput_2.CURRENT_RUN_ID = row10.CURRENT_RUN_ID;
					oneRow_tHashOutput_2.INGTN_TYP = row10.INGTN_TYP;
					oneRow_tHashOutput_2.STATUS = row10.STATUS;
					oneRow_tHashOutput_2.JOB_INSTANCE_ID = row10.JOB_INSTANCE_ID;
					oneRow_tHashOutput_2.RUN_ID = row10.RUN_ID;
					oneRow_tHashOutput_2.ADLS_FILE_LOCTN = row10.ADLS_FILE_LOCTN;
		
        tHashFile_tHashOutput_2.put(oneRow_tHashOutput_2);
        nb_line_tHashOutput_2 ++;
 


	tos_count_tHashOutput_2++;

/**
 * [tHashOutput_2 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_4 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_4";

	

        }
        globalMap.put("tFixedFlowInput_4_NB_LINE", 0);        

 

ok_Hash.put("tFixedFlowInput_4", true);
end_Hash.put("tFixedFlowInput_4", System.currentTimeMillis());

   			if ((Relational.ISNULL(globalMap.get("MERGE_COMPLETED_COUNT")) ? 0 : ((Integer)globalMap.get("MERGE_COMPLETED_COUNT"))) == 0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "true");
					}
				
    			tJava_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If8", 0, "false");
					}   	 
   				}



/**
 * [tFixedFlowInput_4 end ] stop
 */

	
	/**
	 * [tHashOutput_2 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	
globalMap.put("tHashOutput_2_NB_LINE", nb_line_tHashOutput_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row10"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_2", true);
end_Hash.put("tHashOutput_2", System.currentTimeMillis());




/**
 * [tHashOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_4 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_4";

	

 



/**
 * [tFixedFlowInput_4 finally ] stop
 */

	
	/**
	 * [tHashOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	

 



/**
 * [tHashOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
    	class BytesLimit65535_tJava_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_2().limitLog4jByte();


globalMap.put("SRC_SYS_ID", context.src_sys_id);
globalMap.put("SUB_SYS_ID", context.sub_sys_id);
globalMap.put("OBJECT_ID", context.object_id);
globalMap.put("OBJECT_NM", context.object_nm);


globalMap.put("JOB_FQ_NAME", jobName + (Relational.ISNULL(globalMap.get("JOB_NAME_QUALIFIER")) ? "" : "_" + ((String)globalMap.get("JOB_NAME_QUALIFIER"))));

globalMap.put("BATCH_ID", context.batch_id);

// ******************* Get start time & job instance id ******************
globalMap.put("JOB_STARTTIME", TalendDate.getCurrentDate());
globalMap.put("JOB_STARTTIME_STRING", TalendDate.formatDate("yyyyMMddhhmmssSSS",((Date)globalMap.get("JOB_STARTTIME"))));



// ********************* Set job root directory ********************** 
globalMap.put("JOB_ROOT_DIR", ((String)globalMap.get("ENV_TALEND_ROOT_DIR")) + "/job-exec/" + projectName.toLowerCase() + "/" + ((String)globalMap.get("JOB_FQ_NAME")) + "/" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "_" + ((String)globalMap.get("JOB_INSTANCE_ID")));

// ********************* Set TAC Project execution directory ********************** 
globalMap.put("JOB_PROJECT_DIR", ((String)globalMap.get("ENV_TALEND_ROOT_DIR")) + "/job-exec/" + projectName.toLowerCase());

// ************* Get user executing job **********************
globalMap.put("JOB_USER", System.getProperty("user.name"));

// ************* Get execution server name **********************
globalMap.put("JOB_EXEC_SERVER_NAME_LONG", rccl_common_routine.getServerName("long"));
globalMap.put("JOB_EXEC_SERVER_NAME_SHORT", rccl_common_routine.getServerName("short"));


 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());




/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tMSSqlInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_5", false);
		start_Hash.put("tWarn_5", System.currentTimeMillis());
		
	
	currentComponent="tWarn_5";

	
		int tos_count_tWarn_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_5 = new StringBuilder();
            log4jParamters_tWarn_5.append("Parameters:");
                    log4jParamters_tWarn_5.append("MESSAGE" + " = " + "\"303|Setting up init variables failed\"");
                log4jParamters_tWarn_5.append(" | ");
                    log4jParamters_tWarn_5.append("CODE" + " = " + "999");
                log4jParamters_tWarn_5.append(" | ");
                    log4jParamters_tWarn_5.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + (log4jParamters_tWarn_5) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_5().limitLog4jByte();

 



/**
 * [tWarn_5 begin ] stop
 */
	
	/**
	 * [tWarn_5 main ] start
	 */

	

	
	
	currentComponent="tWarn_5";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_5", "", Thread.currentThread().getId() + "", "ERROR","","303|Setting up init variables failed","", "");
            log.error("tWarn_5 - "  + ("Message: ")  + ("303|Setting up init variables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_5", 5, "303|Setting up init variables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_5_WARN_MESSAGES", "303|Setting up init variables failed"); 
globalMap.put("tWarn_5_WARN_PRIORITY", 5);
globalMap.put("tWarn_5_WARN_CODE", 999);


 


	tos_count_tWarn_5++;

/**
 * [tWarn_5 main ] stop
 */
	
	/**
	 * [tWarn_5 end ] start
	 */

	

	
	
	currentComponent="tWarn_5";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + ("Done.") );

ok_Hash.put("tWarn_5", true);
end_Hash.put("tWarn_5", System.currentTimeMillis());




/**
 * [tWarn_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_5 finally ] start
	 */

	

	
	
	currentComponent="tWarn_5";

	

 



/**
 * [tWarn_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_5_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String SRC_SYS_ID;

				public String getSRC_SYS_ID () {
					return this.SRC_SYS_ID;
				}
				
			    public String SUB_SYS_ID;

				public String getSUB_SYS_ID () {
					return this.SUB_SYS_ID;
				}
				
			    public String SRC_SYS_NM;

				public String getSRC_SYS_NM () {
					return this.SRC_SYS_NM;
				}
				
			    public String SUB_SYS_NM;

				public String getSUB_SYS_NM () {
					return this.SUB_SYS_NM;
				}
				
			    public String OBJECT_ID;

				public String getOBJECT_ID () {
					return this.OBJECT_ID;
				}
				
			    public String OBJECT_NM;

				public String getOBJECT_NM () {
					return this.OBJECT_NM;
				}
				
			    public String ADLS_FILE_LOCTN;

				public String getADLS_FILE_LOCTN () {
					return this.ADLS_FILE_LOCTN;
				}
				
			    public String MRGD_FILE_LOCTN;

				public String getMRGD_FILE_LOCTN () {
					return this.MRGD_FILE_LOCTN;
				}
				
			    public String OUT_FILE_LOCTN;

				public String getOUT_FILE_LOCTN () {
					return this.OUT_FILE_LOCTN;
				}
				
			    public String INGTN_TYP;

				public String getINGTN_TYP () {
					return this.INGTN_TYP;
				}
				
			    public String FILE_NM;

				public String getFILE_NM () {
					return this.FILE_NM;
				}
				
			    public String PRMRY_K;

				public String getPRMRY_K () {
					return this.PRMRY_K;
				}
				
			    public String TMSTMP_K;

				public String getTMSTMP_K () {
					return this.TMSTMP_K;
				}
				
			    public String INIT_LD;

				public String getINIT_LD () {
					return this.INIT_LD;
				}
				
			    public String CHR_ENCODE;

				public String getCHR_ENCODE () {
					return this.CHR_ENCODE;
				}
				
			    public String TIER;

				public String getTIER () {
					return this.TIER;
				}
				
			    public String PARTITION_FLG;

				public String getPARTITION_FLG () {
					return this.PARTITION_FLG;
				}
				
			    public String PARTITION_RULE;

				public String getPARTITION_RULE () {
					return this.PARTITION_RULE;
				}
				
			    public String PARTITION_COL;

				public String getPARTITION_COL () {
					return this.PARTITION_COL;
				}
				
			    public String IS_PARQUET;

				public String getIS_PARQUET () {
					return this.IS_PARQUET;
				}
				
			    public String CURRENT_RUN_ID;

				public String getCURRENT_RUN_ID () {
					return this.CURRENT_RUN_ID;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.SRC_SYS_ID = readString(dis);
					
					this.SUB_SYS_ID = readString(dis);
					
					this.SRC_SYS_NM = readString(dis);
					
					this.SUB_SYS_NM = readString(dis);
					
					this.OBJECT_ID = readString(dis);
					
					this.OBJECT_NM = readString(dis);
					
					this.ADLS_FILE_LOCTN = readString(dis);
					
					this.MRGD_FILE_LOCTN = readString(dis);
					
					this.OUT_FILE_LOCTN = readString(dis);
					
					this.INGTN_TYP = readString(dis);
					
					this.FILE_NM = readString(dis);
					
					this.PRMRY_K = readString(dis);
					
					this.TMSTMP_K = readString(dis);
					
					this.INIT_LD = readString(dis);
					
					this.CHR_ENCODE = readString(dis);
					
					this.TIER = readString(dis);
					
					this.PARTITION_FLG = readString(dis);
					
					this.PARTITION_RULE = readString(dis);
					
					this.PARTITION_COL = readString(dis);
					
					this.IS_PARQUET = readString(dis);
					
					this.CURRENT_RUN_ID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.SRC_SYS_ID,dos);
					
					// String
				
						writeString(this.SUB_SYS_ID,dos);
					
					// String
				
						writeString(this.SRC_SYS_NM,dos);
					
					// String
				
						writeString(this.SUB_SYS_NM,dos);
					
					// String
				
						writeString(this.OBJECT_ID,dos);
					
					// String
				
						writeString(this.OBJECT_NM,dos);
					
					// String
				
						writeString(this.ADLS_FILE_LOCTN,dos);
					
					// String
				
						writeString(this.MRGD_FILE_LOCTN,dos);
					
					// String
				
						writeString(this.OUT_FILE_LOCTN,dos);
					
					// String
				
						writeString(this.INGTN_TYP,dos);
					
					// String
				
						writeString(this.FILE_NM,dos);
					
					// String
				
						writeString(this.PRMRY_K,dos);
					
					// String
				
						writeString(this.TMSTMP_K,dos);
					
					// String
				
						writeString(this.INIT_LD,dos);
					
					// String
				
						writeString(this.CHR_ENCODE,dos);
					
					// String
				
						writeString(this.TIER,dos);
					
					// String
				
						writeString(this.PARTITION_FLG,dos);
					
					// String
				
						writeString(this.PARTITION_RULE,dos);
					
					// String
				
						writeString(this.PARTITION_COL,dos);
					
					// String
				
						writeString(this.IS_PARQUET,dos);
					
					// String
				
						writeString(this.CURRENT_RUN_ID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("SRC_SYS_ID="+SRC_SYS_ID);
		sb.append(",SUB_SYS_ID="+SUB_SYS_ID);
		sb.append(",SRC_SYS_NM="+SRC_SYS_NM);
		sb.append(",SUB_SYS_NM="+SUB_SYS_NM);
		sb.append(",OBJECT_ID="+OBJECT_ID);
		sb.append(",OBJECT_NM="+OBJECT_NM);
		sb.append(",ADLS_FILE_LOCTN="+ADLS_FILE_LOCTN);
		sb.append(",MRGD_FILE_LOCTN="+MRGD_FILE_LOCTN);
		sb.append(",OUT_FILE_LOCTN="+OUT_FILE_LOCTN);
		sb.append(",INGTN_TYP="+INGTN_TYP);
		sb.append(",FILE_NM="+FILE_NM);
		sb.append(",PRMRY_K="+PRMRY_K);
		sb.append(",TMSTMP_K="+TMSTMP_K);
		sb.append(",INIT_LD="+INIT_LD);
		sb.append(",CHR_ENCODE="+CHR_ENCODE);
		sb.append(",TIER="+TIER);
		sb.append(",PARTITION_FLG="+PARTITION_FLG);
		sb.append(",PARTITION_RULE="+PARTITION_RULE);
		sb.append(",PARTITION_COL="+PARTITION_COL);
		sb.append(",IS_PARQUET="+IS_PARQUET);
		sb.append(",CURRENT_RUN_ID="+CURRENT_RUN_ID);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(SRC_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SRC_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(SUB_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SUB_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(SRC_SYS_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SRC_SYS_NM);
            			}
            		
        			sb.append("|");
        		
        				if(SUB_SYS_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SUB_SYS_NM);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_ID);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_NM);
            			}
            		
        			sb.append("|");
        		
        				if(ADLS_FILE_LOCTN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ADLS_FILE_LOCTN);
            			}
            		
        			sb.append("|");
        		
        				if(MRGD_FILE_LOCTN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MRGD_FILE_LOCTN);
            			}
            		
        			sb.append("|");
        		
        				if(OUT_FILE_LOCTN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OUT_FILE_LOCTN);
            			}
            		
        			sb.append("|");
        		
        				if(INGTN_TYP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INGTN_TYP);
            			}
            		
        			sb.append("|");
        		
        				if(FILE_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FILE_NM);
            			}
            		
        			sb.append("|");
        		
        				if(PRMRY_K == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PRMRY_K);
            			}
            		
        			sb.append("|");
        		
        				if(TMSTMP_K == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TMSTMP_K);
            			}
            		
        			sb.append("|");
        		
        				if(INIT_LD == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INIT_LD);
            			}
            		
        			sb.append("|");
        		
        				if(CHR_ENCODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CHR_ENCODE);
            			}
            		
        			sb.append("|");
        		
        				if(TIER == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TIER);
            			}
            		
        			sb.append("|");
        		
        				if(PARTITION_FLG == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PARTITION_FLG);
            			}
            		
        			sb.append("|");
        		
        				if(PARTITION_RULE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PARTITION_RULE);
            			}
            		
        			sb.append("|");
        		
        				if(PARTITION_COL == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PARTITION_COL);
            			}
            		
        			sb.append("|");
        		
        				if(IS_PARQUET == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IS_PARQUET);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENT_RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENT_RUN_ID);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tFlowToIterate_5 begin ] start
	 */

				
			int NB_ITERATE_tJava_9 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_5", false);
		start_Hash.put("tFlowToIterate_5", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_5 = new StringBuilder();
            log4jParamters_tFlowToIterate_5.append("Parameters:");
                    log4jParamters_tFlowToIterate_5.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + (log4jParamters_tFlowToIterate_5) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_5().limitLog4jByte();

int nb_line_tFlowToIterate_5 = 0;
int counter_tFlowToIterate_5 = 0;

 



/**
 * [tFlowToIterate_5 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_1", false);
		start_Hash.put("tMSSqlInput_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_1";

	
		int tos_count_tMSSqlInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_1 = new StringBuilder();
            log4jParamters_tMSSqlInput_1.append("Parameters:");
                    log4jParamters_tMSSqlInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("QUERY" + " = " + "\"  \" + (\"MULTI_MERGE\".equals((String)globalMap.get(\"MERGE_TYPE\")) ? \"  SELECT T.SRC_SYS_ID  	, T.SUB_SYS_ID  	, T.SRC_SYS_DESC  	, T.SUB_SYS_NM  	, T.OBJECT_ID  	, T.OBJECT_NM  	, T.ADLS_FILE_LOCTN  	, T.MRGD_FILE_LOCTN  	, T.OUT_FILE_LOCTN  	, T.INGTN_TYP  	, T.FILE_NM  	, T.PRMRY_K  	, T.TMSTMP_K  	, T.INIT_LD  	, T.CHR_ENCODE  	, T.TIER  	, T.PARTITION_FLG  	, T.PARTITION_RULE  	, T.PARTITION_COL  	, T.IS_PARQUET  	, T.RUN_ID  FROM (  \" : \"\") + \"  SELECT FL.SRC_SYS_ID  	, FL.SUB_SYS_ID  	, SR.SRC_SYS_DESC  	, CASE WHEN SR.SUB_SYS_DESC = SR.SRC_SYS_DESC THEN NULL ELSE SR.SUB_SYS_DESC END AS SUB_SYS_NM  	, FL.OBJECT_ID  	, IT.OBJECT_NM  	, FL.ADLS_FILE_LOCTN  	, FL.MRGD_FILE_LOCTN  	, FL.OUT_FILE_LOCTN  	, FL.INGTN_TYP  	, FL.FILE_NM  	, OB.PRMRY_K  	, OB.TMSTMP_K  	, IT.INIT_LD  	, IT.CHR_ENCODE  	, IT.TIER  	, IT.PARTITION_FLG  	, IT.PARTITION_RULE  	, IT.PARTITION_COL  	, IT.IS_PARQUET  	, FL.RUN_ID\" +  (\"MULTI_MERGE\".equals((String)globalMap.get(\"MERGE_TYPE\")) ? \"  	, FL.CRTD_DTTM  	, RANK () OVER(PARTITION BY REPLACE(FL.ADLS_FILE_LOCTN, FILE_NM, '') ORDER BY FL.CRTD_DTTM DESC) AS RNK  \" : \"\") + \"  FROM DBO.T_FILE_TRCKR_DTL FL  	INNER JOIN DBO.T_INIT_LOAD_DTL IT  		ON FL.SRC_SYS_ID = IT.SRC_SYS_ID  			AND FL.SUB_SYS_ID = IT.SUB_SYS_ID  			AND FL.OBJECT_ID = IT.OBJECT_ID  	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR  		ON IT.SRC_SYS_ID = SR.SRC_SYS_ID  			AND IT.SUB_SYS_ID = SR.SUB_SYS_ID  	LEFT JOIN DBO.T_OBJCT_KEY_DTL OB  		ON IT.SRC_SYS_ID = OB.SRC_SYS_ID  			AND IT.SUB_SYS_ID = OB.SUB_SYS_ID  			AND IT.OBJECT_ID = OB.OBJECT_ID  WHERE FL.SRC_SYS_ID = '\" + ((String)globalMap.get(\"SRC_SYS_ID\")) + \"'  	AND FL.SUB_SYS_ID = '\" + ((String)globalMap.get(\"SUB_SYS_ID\")) + \"'  	AND FL.OBJECT_ID = '\" + ((String)globalMap.get(\"OBJECT_ID\")) + \"'  	AND IT.STG_ID = '2'  	AND FL.IS_MERGED IN (\" + (\"Y\".equals(context.rerun_failed) ? \"'F'\" : \"'N', 'NR', 'F'\") + \")  	AND (SELECT COUNT(1) FROM DBO.T_FILE_TRCKR_DTL  				WHERE SRC_SYS_ID = '\" + ((String)globalMap.get(\"SRC_SYS_ID\")) + \"'  					AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"SUB_SYS_ID\")) + \"'  					AND OBJECT_ID = '\" + ((String)globalMap.get(\"OBJECT_ID\")) + \"'  					AND IS_MERGED = 'IP') = 0\" +  (\"MULTI_MERGE\".equals((String)globalMap.get(\"MERGE_TYPE\")) ? \"  ) T  WHERE T.RNK = 1  \" : \"\") + \"  ORDER BY \" + (\"MULTI_MERGE\".equals((String)globalMap.get(\"MERGE_TYPE\")) ? \"T\" : \"FL\") + \".CRTD_DTTM  \"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("SRC_SYS_ID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SUB_SYS_ID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SRC_SYS_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SUB_SYS_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OBJECT_ID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OBJECT_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("ADLS_FILE_LOCTN")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("MRGD_FILE_LOCTN")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OUT_FILE_LOCTN")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("INGTN_TYP")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("FILE_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PRMRY_K")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TMSTMP_K")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("INIT_LD")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CHR_ENCODE")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TIER")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PARTITION_FLG")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PARTITION_RULE")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PARTITION_COL")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IS_PARQUET")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CURRENT_RUN_ID")+"}]");
                log4jParamters_tMSSqlInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + (log4jParamters_tMSSqlInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_1().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_1, talendToDBArray_tMSSqlInput_1); 
		    int nb_line_tMSSqlInput_1 = 0;
		    java.sql.Connection conn_tMSSqlInput_1 = null;
		        conn_tMSSqlInput_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_1 != null) {
					if(conn_tMSSqlInput_1.getMetaData() != null) {
						
						log.debug("tMSSqlInput_1 - Uses an existing connection with username '" + conn_tMSSqlInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_1 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_1 = conn_tMSSqlInput_1.createStatement();

		    String dbquery_tMSSqlInput_1 = "\n" + ("MULTI_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "\nSELECT T.SRC_SYS_ID\n	, T.SUB_SYS_ID\n	, T.SRC_SYS_DESC\n	, T.SUB_SYS_NM\n	, T.OBJECT_ID\n	, T.OBJECT_NM\n	, T.ADLS_FILE_LOCTN\n	, T.MRGD_FILE_LOCTN\n	, T.OUT_FILE_LOCTN\n	, T.INGTN_TYP\n	, T.FILE_NM\n	, T.PRMRY_K\n	, T.TMSTMP_K\n	, T.INIT_LD\n	, T.CHR_ENCODE\n	, T.TIER\n	, T.PARTITION_FLG\n	, T.PARTITION_RULE\n	, T.PARTITION_COL\n	, T.IS_PARQUET\n	, T.RUN_ID\nFROM (\n" : "") + "\nSELECT FL.SRC_SYS_ID\n	, FL.SUB_SYS_ID\n	, SR.SRC_SYS_DESC\n	, CASE WHEN SR.SUB_SYS_DESC = SR.SRC_SYS_DESC THEN NULL ELSE SR.SUB_SYS_DESC END AS SUB_SYS_NM\n	, FL.OBJECT_ID\n	, IT.OBJECT_NM\n	, FL.ADLS_FILE_LOCTN\n	, FL.MRGD_FILE_LOCTN\n	, FL.OUT_FILE_LOCTN\n	, FL.INGTN_TYP\n	, FL.FILE_NM\n	, OB.PRMRY_K\n	, OB.TMSTMP_K\n	, IT.INIT_LD\n	, IT.CHR_ENCODE\n	, IT.TIER\n	, IT.PARTITION_FLG\n	, IT.PARTITION_RULE\n	, IT.PARTITION_COL\n	, IT.IS_PARQUET\n	, FL.RUN_ID" +
("MULTI_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "\n	, FL.CRTD_DTTM\n	, RANK () OVER(PARTITION BY REPLACE(FL.ADLS_FILE_LOCTN, FILE_NM, '') ORDER BY FL.CRTD_DTTM DESC) AS RNK\n" : "") + "\nFROM DBO.T_FILE_TRCKR_DTL FL\n	INNER JOIN DBO.T_INIT_LOAD_DTL IT\n		ON FL.SRC_SYS_ID = IT.SRC_SYS_ID\n			AND FL.SUB_SYS_ID = IT.SUB_SYS_ID\n			AND FL.OBJECT_ID = IT.OBJECT_ID\n	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR\n		ON IT.SRC_SYS_ID = SR.SRC_SYS_ID\n			AND IT.SUB_SYS_ID = SR.SUB_SYS_ID\n	LEFT JOIN DBO.T_OBJCT_KEY_DTL OB\n		ON IT.SRC_SYS_ID = OB.SRC_SYS_ID\n			AND IT.SUB_SYS_ID = OB.SUB_SYS_ID\n			AND IT.OBJECT_ID = OB.OBJECT_ID\nWHERE FL.SRC_SYS_ID = '" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n	AND FL.SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n	AND FL.OBJECT_ID = '" + ((String)globalMap.get("OBJECT_ID")) + "'\n	AND IT.STG_ID = '2'\n	AND FL.IS_MERGED IN (" + ("Y".equals(context.rerun_failed) ? "'F'" : "'N', 'NR', 'F'") + ")\n	AND (SELECT COUNT(1) FROM DBO.T_FILE_TRCKR_DTL\n				WHERE SRC_SYS_ID = '" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n					AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n					AND OBJECT_ID = '" + ((String)globalMap.get("OBJECT_ID")) + "'\n					AND IS_MERGED = 'IP') = 0" +
("MULTI_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "\n) T\nWHERE T.RNK = 1\n" : "") + "\nORDER BY " + ("MULTI_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "T" : "FL") + ".CRTD_DTTM\n";
			
                log.debug("tMSSqlInput_1 - Executing the query: '"+dbquery_tMSSqlInput_1+"'.");
			

                       globalMap.put("tMSSqlInput_1_QUERY",dbquery_tMSSqlInput_1);

		    java.sql.ResultSet rs_tMSSqlInput_1 = null;
		try{
		    rs_tMSSqlInput_1 = stmt_tMSSqlInput_1.executeQuery(dbquery_tMSSqlInput_1);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_1 = rs_tMSSqlInput_1.getMetaData();
		    int colQtyInRs_tMSSqlInput_1 = rsmd_tMSSqlInput_1.getColumnCount();

		    String tmpContent_tMSSqlInput_1 = null;
		    
		    
		    	log.debug("tMSSqlInput_1 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_1.next()) {
		        nb_line_tMSSqlInput_1++;
		        
							if(colQtyInRs_tMSSqlInput_1 < 1) {
								row1.SRC_SYS_ID = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(1);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SRC_SYS_ID = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SRC_SYS_ID = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SRC_SYS_ID = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 2) {
								row1.SUB_SYS_ID = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(2);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SUB_SYS_ID = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SUB_SYS_ID = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SUB_SYS_ID = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 3) {
								row1.SRC_SYS_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(3);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SRC_SYS_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SRC_SYS_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SRC_SYS_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 4) {
								row1.SUB_SYS_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(4);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SUB_SYS_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SUB_SYS_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SUB_SYS_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 5) {
								row1.OBJECT_ID = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(5);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OBJECT_ID = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.OBJECT_ID = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.OBJECT_ID = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 6) {
								row1.OBJECT_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(6);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OBJECT_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.OBJECT_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.OBJECT_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 7) {
								row1.ADLS_FILE_LOCTN = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(7);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.ADLS_FILE_LOCTN = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.ADLS_FILE_LOCTN = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.ADLS_FILE_LOCTN = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 8) {
								row1.MRGD_FILE_LOCTN = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(8);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.MRGD_FILE_LOCTN = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.MRGD_FILE_LOCTN = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.MRGD_FILE_LOCTN = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 9) {
								row1.OUT_FILE_LOCTN = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(9);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OUT_FILE_LOCTN = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.OUT_FILE_LOCTN = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.OUT_FILE_LOCTN = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 10) {
								row1.INGTN_TYP = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(10);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(10).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.INGTN_TYP = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.INGTN_TYP = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.INGTN_TYP = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 11) {
								row1.FILE_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(11);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(11).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.FILE_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.FILE_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.FILE_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 12) {
								row1.PRMRY_K = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(12);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.PRMRY_K = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.PRMRY_K = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.PRMRY_K = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 13) {
								row1.TMSTMP_K = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(13);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.TMSTMP_K = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.TMSTMP_K = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.TMSTMP_K = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 14) {
								row1.INIT_LD = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(14);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.INIT_LD = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.INIT_LD = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.INIT_LD = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 15) {
								row1.CHR_ENCODE = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(15);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.CHR_ENCODE = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.CHR_ENCODE = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.CHR_ENCODE = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 16) {
								row1.TIER = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(16);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(16).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.TIER = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.TIER = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.TIER = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 17) {
								row1.PARTITION_FLG = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(17);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.PARTITION_FLG = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.PARTITION_FLG = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.PARTITION_FLG = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 18) {
								row1.PARTITION_RULE = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(18);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.PARTITION_RULE = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.PARTITION_RULE = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.PARTITION_RULE = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 19) {
								row1.PARTITION_COL = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(19);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(19).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.PARTITION_COL = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.PARTITION_COL = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.PARTITION_COL = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 20) {
								row1.IS_PARQUET = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(20);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(20).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.IS_PARQUET = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.IS_PARQUET = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.IS_PARQUET = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 21) {
								row1.CURRENT_RUN_ID = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(21);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(21).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.CURRENT_RUN_ID = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.CURRENT_RUN_ID = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.CURRENT_RUN_ID = null;
            }
		                    }
					
						log.debug("tMSSqlInput_1 - Retrieving the record " + nb_line_tMSSqlInput_1 + ".");
					





 



/**
 * [tMSSqlInput_1 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

 


	tos_count_tMSSqlInput_1++;

/**
 * [tMSSqlInput_1 main ] stop
 */

	
	/**
	 * [tFlowToIterate_5 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.SRC_SYS_ID, value=")  + (row1.SRC_SYS_ID)  + (".") );            
            globalMap.put("row1.SRC_SYS_ID", row1.SRC_SYS_ID);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.SUB_SYS_ID, value=")  + (row1.SUB_SYS_ID)  + (".") );            
            globalMap.put("row1.SUB_SYS_ID", row1.SUB_SYS_ID);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.SRC_SYS_NM, value=")  + (row1.SRC_SYS_NM)  + (".") );            
            globalMap.put("row1.SRC_SYS_NM", row1.SRC_SYS_NM);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.SUB_SYS_NM, value=")  + (row1.SUB_SYS_NM)  + (".") );            
            globalMap.put("row1.SUB_SYS_NM", row1.SUB_SYS_NM);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.OBJECT_ID, value=")  + (row1.OBJECT_ID)  + (".") );            
            globalMap.put("row1.OBJECT_ID", row1.OBJECT_ID);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.OBJECT_NM, value=")  + (row1.OBJECT_NM)  + (".") );            
            globalMap.put("row1.OBJECT_NM", row1.OBJECT_NM);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.ADLS_FILE_LOCTN, value=")  + (row1.ADLS_FILE_LOCTN)  + (".") );            
            globalMap.put("row1.ADLS_FILE_LOCTN", row1.ADLS_FILE_LOCTN);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.MRGD_FILE_LOCTN, value=")  + (row1.MRGD_FILE_LOCTN)  + (".") );            
            globalMap.put("row1.MRGD_FILE_LOCTN", row1.MRGD_FILE_LOCTN);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.OUT_FILE_LOCTN, value=")  + (row1.OUT_FILE_LOCTN)  + (".") );            
            globalMap.put("row1.OUT_FILE_LOCTN", row1.OUT_FILE_LOCTN);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.INGTN_TYP, value=")  + (row1.INGTN_TYP)  + (".") );            
            globalMap.put("row1.INGTN_TYP", row1.INGTN_TYP);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.FILE_NM, value=")  + (row1.FILE_NM)  + (".") );            
            globalMap.put("row1.FILE_NM", row1.FILE_NM);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.PRMRY_K, value=")  + (row1.PRMRY_K)  + (".") );            
            globalMap.put("row1.PRMRY_K", row1.PRMRY_K);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.TMSTMP_K, value=")  + (row1.TMSTMP_K)  + (".") );            
            globalMap.put("row1.TMSTMP_K", row1.TMSTMP_K);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.INIT_LD, value=")  + (row1.INIT_LD)  + (".") );            
            globalMap.put("row1.INIT_LD", row1.INIT_LD);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.CHR_ENCODE, value=")  + (row1.CHR_ENCODE)  + (".") );            
            globalMap.put("row1.CHR_ENCODE", row1.CHR_ENCODE);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.TIER, value=")  + (row1.TIER)  + (".") );            
            globalMap.put("row1.TIER", row1.TIER);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.PARTITION_FLG, value=")  + (row1.PARTITION_FLG)  + (".") );            
            globalMap.put("row1.PARTITION_FLG", row1.PARTITION_FLG);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.PARTITION_RULE, value=")  + (row1.PARTITION_RULE)  + (".") );            
            globalMap.put("row1.PARTITION_RULE", row1.PARTITION_RULE);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.PARTITION_COL, value=")  + (row1.PARTITION_COL)  + (".") );            
            globalMap.put("row1.PARTITION_COL", row1.PARTITION_COL);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.IS_PARQUET, value=")  + (row1.IS_PARQUET)  + (".") );            
            globalMap.put("row1.IS_PARQUET", row1.IS_PARQUET);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row1.CURRENT_RUN_ID, value=")  + (row1.CURRENT_RUN_ID)  + (".") );            
            globalMap.put("row1.CURRENT_RUN_ID", row1.CURRENT_RUN_ID);
    	
 
	   nb_line_tFlowToIterate_5++;  
       counter_tFlowToIterate_5++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_5)  + (".") );
       globalMap.put("tFlowToIterate_5_CURRENT_ITERATION", counter_tFlowToIterate_5);
 


	tos_count_tFlowToIterate_5++;

/**
 * [tFlowToIterate_5 main ] stop
 */
	NB_ITERATE_tJava_9++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("If2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If7", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk10", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If5", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row20", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk6", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk11", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate7", 1, "exec" + NB_ITERATE_tJava_9);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tJava_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_9", false);
		start_Hash.put("tJava_9", System.currentTimeMillis());
		
	
	currentComponent="tJava_9";

	
		int tos_count_tJava_9 = 0;
		
    	class BytesLimit65535_tJava_9{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_9().limitLog4jByte();


context.NO_ITERATION=context.NO_ITERATION+1;

if ( "D".equals((String)globalMap.get("row1.INGTN_TYP")) && "Y".equals((String)globalMap.get("row1.INIT_LD")) && context.NO_ITERATION>1 )

{

globalMap.put("row1.INIT_LD","N");

System.out.println("INIT_LD :" + ((String)globalMap.get("row1.INIT_LD")));
}

// ********************* Set job final Job Instance ID  **********************
globalMap.put("JOB_INSTANCE_ID", rccl_common_routine.getJobRunInstanceID()); // generate a new InstanceID

//*************** Set Audit Context Variable ***************
globalMap.put("RUN_ID", ((String)globalMap.get("JOB_INSTANCE_ID")) + "_" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "_" + ((String)globalMap.get("SRC_SYS_ID")) + "_" + ((String)globalMap.get("OBJECT_NM")));
 



/**
 * [tJava_9 begin ] stop
 */
	
	/**
	 * [tJava_9 main ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 


	tos_count_tJava_9++;

/**
 * [tJava_9 main ] stop
 */
	
	/**
	 * [tJava_9 end ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 

ok_Hash.put("tJava_9", true);
end_Hash.put("tJava_9", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk12", 0, "ok");
				}
				tMSSqlRow_4Process(globalMap);



/**
 * [tJava_9 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate7", 2, "exec" + NB_ITERATE_tJava_9);
						}				
					







	
	/**
	 * [tMSSqlInput_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

	}
}finally{
	stmt_tMSSqlInput_1.close();

}
globalMap.put("tMSSqlInput_1_NB_LINE",nb_line_tMSSqlInput_1);
	    		log.debug("tMSSqlInput_1 - Retrieved records count: "+nb_line_tMSSqlInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_1", true);
end_Hash.put("tMSSqlInput_1", System.currentTimeMillis());




/**
 * [tMSSqlInput_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_5 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";

	

globalMap.put("tFlowToIterate_5_NB_LINE",nb_line_tFlowToIterate_5);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_5", true);
end_Hash.put("tFlowToIterate_5", System.currentTimeMillis());




/**
 * [tFlowToIterate_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

 



/**
 * [tMSSqlInput_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_5 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";

	

 



/**
 * [tFlowToIterate_5 finally ] stop
 */

	
	/**
	 * [tJava_9 finally ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 



/**
 * [tJava_9 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tMSSqlRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_4", false);
		start_Hash.put("tMSSqlRow_4", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_4";

	
		int tos_count_tMSSqlRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_4 = new StringBuilder();
            log4jParamters_tMSSqlRow_4.append("Parameters:");
                    log4jParamters_tMSSqlRow_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("QUERY" + " = " + "\"  UPDATE DBO.T_FILE_TRCKR_DTL  SET IS_MERGED = 'IP'  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'  \" + (\"SINGLE_MERGE\".equals((String)globalMap.get(\"MERGE_TYPE\")) ? \"  WHERE RUN_ID = '\" + ((String)globalMap.get(\"row1.CURRENT_RUN_ID\")) + \"'  	AND FILE_NM = '\" + ((String)globalMap.get(\"row1.FILE_NM\")) + \"'  \" : \"  WHERE SRC_SYS_ID = '\" + ((String)globalMap.get(\"row1.SRC_SYS_ID\")) + \"'  	AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"row1.SUB_SYS_ID\")) + \"'  	AND OBJECT_ID = '\" + ((String)globalMap.get(\"row1.OBJECT_ID\")) + \"'  	AND IS_MERGED IN ('N', 'NR')  	AND ADLS_FILE_LOCTN LIKE '\" + (((String)globalMap.get(\"row1.ADLS_FILE_LOCTN\")).replaceAll(((String)globalMap.get(\"row1.FILE_NM\")), \"\")) + \"%'  \")");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_4 - "  + (log4jParamters_tMSSqlRow_4) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_4().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_4 = null;
	String query_tMSSqlRow_4 = "";
	boolean whetherReject_tMSSqlRow_4 = false;
				conn_tMSSqlRow_4 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_4 != null) {
					if(conn_tMSSqlRow_4.getMetaData() != null) {
						
						log.debug("tMSSqlRow_4 - Uses an existing connection with username '" + conn_tMSSqlRow_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_4.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_4 = conn_tMSSqlRow_4.createStatement();
	

 



/**
 * [tMSSqlRow_4 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_4 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_4";

	

	    		log.debug("tMSSqlRow_4 - Executing the query: '" + "  UPDATE DBO.T_FILE_TRCKR_DTL  SET IS_MERGED = 'IP'  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'  " + ("SINGLE_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "  WHERE RUN_ID = '" + ((String)globalMap.get("row1.CURRENT_RUN_ID")) + "'  	AND FILE_NM = '" + ((String)globalMap.get("row1.FILE_NM")) + "'  " : "  WHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'  	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'  	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'  	AND IS_MERGED IN ('N', 'NR')  	AND ADLS_FILE_LOCTN LIKE '" + (((String)globalMap.get("row1.ADLS_FILE_LOCTN")).replaceAll(((String)globalMap.get("row1.FILE_NM")), "")) + "%'  ") + "'.");
			
query_tMSSqlRow_4 = "\nUPDATE DBO.T_FILE_TRCKR_DTL\nSET IS_MERGED = 'IP'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\n" + ("SINGLE_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "\nWHERE RUN_ID = '" + ((String)globalMap.get("row1.CURRENT_RUN_ID")) + "'\n	AND FILE_NM = '" + ((String)globalMap.get("row1.FILE_NM")) + "'\n" : "\nWHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n	AND IS_MERGED IN ('N', 'NR')\n	AND ADLS_FILE_LOCTN LIKE '" + (((String)globalMap.get("row1.ADLS_FILE_LOCTN")).replaceAll(((String)globalMap.get("row1.FILE_NM")), "")) + "%'\n");
whetherReject_tMSSqlRow_4 = false;
globalMap.put("tMSSqlRow_4_QUERY",query_tMSSqlRow_4);
try {
		stmt_tMSSqlRow_4.execute(query_tMSSqlRow_4);
		
	    		log.debug("tMSSqlRow_4 - Execute the query: '" + "\nUPDATE DBO.T_FILE_TRCKR_DTL\nSET IS_MERGED = 'IP'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\n" + ("SINGLE_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "\nWHERE RUN_ID = '" + ((String)globalMap.get("row1.CURRENT_RUN_ID")) + "'\n	AND FILE_NM = '" + ((String)globalMap.get("row1.FILE_NM")) + "'\n" : "\nWHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n	AND IS_MERGED IN ('N', 'NR')\n	AND ADLS_FILE_LOCTN LIKE '" + (((String)globalMap.get("row1.ADLS_FILE_LOCTN")).replaceAll(((String)globalMap.get("row1.FILE_NM")), "")) + "%'\n") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_4 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tMSSqlRow_4) {
		
	}
	

 


	tos_count_tMSSqlRow_4++;

/**
 * [tMSSqlRow_4 main ] stop
 */
	
	/**
	 * [tMSSqlRow_4 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_4";

	

	
	stmt_tMSSqlRow_4.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_4 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_4", true);
end_Hash.put("tMSSqlRow_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk13", 0, "ok");
				}
				tMSSqlInput_6Process(globalMap);



/**
 * [tMSSqlRow_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_4 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_4";

	

 



/**
 * [tMSSqlRow_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_4_SUBPROCESS_STATE", 1);
	}
	


public static class row20Struct implements routines.system.IPersistableRow<row20Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public Integer LD_RECORD_CNT;

				public Integer getLD_RECORD_CNT () {
					return this.LD_RECORD_CNT;
				}
				
			    public Integer SRC_RECORD_CNT;

				public Integer getSRC_RECORD_CNT () {
					return this.SRC_RECORD_CNT;
				}
				
			    public String FILE_TYPE;

				public String getFILE_TYPE () {
					return this.FILE_TYPE;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
						this.LD_RECORD_CNT = readInteger(dis);
					
						this.SRC_RECORD_CNT = readInteger(dis);
					
					this.FILE_TYPE = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.LD_RECORD_CNT,dos);
					
					// Integer
				
						writeInteger(this.SRC_RECORD_CNT,dos);
					
					// String
				
						writeString(this.FILE_TYPE,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("LD_RECORD_CNT="+String.valueOf(LD_RECORD_CNT));
		sb.append(",SRC_RECORD_CNT="+String.valueOf(SRC_RECORD_CNT));
		sb.append(",FILE_TYPE="+FILE_TYPE);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(LD_RECORD_CNT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LD_RECORD_CNT);
            			}
            		
        			sb.append("|");
        		
        				if(SRC_RECORD_CNT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SRC_RECORD_CNT);
            			}
            		
        			sb.append("|");
        		
        				if(FILE_TYPE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FILE_TYPE);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row20Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row20Struct row20 = new row20Struct();




	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row20" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("row20.LD_RECORD_CNT")+", KEY="+("\"LD_RECORD_CNT\"")+"}, {VALUE="+("row20.SRC_RECORD_CNT")+", KEY="+("\"SRC_RECORD_CNT\"")+"}, {VALUE="+("row20.FILE_TYPE")+", KEY="+("\"FILE_TYPE\"")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_6", false);
		start_Hash.put("tMSSqlInput_6", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_6";

	
		int tos_count_tMSSqlInput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_6 = new StringBuilder();
            log4jParamters_tMSSqlInput_6.append("Parameters:");
                    log4jParamters_tMSSqlInput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_6.append(" | ");
                    log4jParamters_tMSSqlInput_6.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_6.append(" | ");
                    log4jParamters_tMSSqlInput_6.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_6.append(" | ");
                    log4jParamters_tMSSqlInput_6.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_6.append(" | ");
                    log4jParamters_tMSSqlInput_6.append("QUERY" + " = " + "\"  SELECT COALESCE(A.LD_RECORD_CNT, 0) AS LD_RECORD_CNT  	, COALESCE(B.LD_RECORD_CNT, 0) AS SRC_RECORD_CNT  	, CASE WHEN (COALESCE(\" + (\"D\".equals((String)globalMap.get(\"row1.INGTN_TYP\")) ? \"A\" : \"B\") + \".LD_RECORD_CNT, 0) > \" + ((String)globalMap.get(\"COALESCE_CUTOFF\")) + \") THEN 'M' ELSE 'S' END AS FILE_TYPE  FROM (SELECT TOP 1 LD_RECORD_CNT  			  FROM DBO.T_LOAD_STATUS_DTL  			  WHERE STG_ID = '2'  				  AND SRC_SYS_ID = '\" + ((String)globalMap.get(\"row1.SRC_SYS_ID\")) + \"'  				  AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"row1.SUB_SYS_ID\")) + \"'  				  AND OBJECT_ID = '\" + ((String)globalMap.get(\"row1.OBJECT_ID\")) + \"'  				  AND STATUS = 'C'  			  ORDER BY CRTD_DTTM DESC) A  RIGHT JOIN  \" + ( \"MULTI_MERGE\".equals((String)globalMap.get(\"MERGE_TYPE\")) &&  \"D\".equals((String)globalMap.get(\"row1.INGTN_TYP\"))  ? \"  			 (SELECT SUM(LD_RECORD_CNT) AS LD_RECORD_CNT  			  FROM DBO.T_LOAD_STATUS_DTL  			  WHERE SRC_SYS_ID = '\" + ((String)globalMap.get(\"row1.SRC_SYS_ID\")) + \"'  				  AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"row1.SUB_SYS_ID\")) + \"'  				  AND OBJECT_ID = '\" + ((String)globalMap.get(\"row1.OBJECT_ID\")) + \"'  			  	  AND RUN_ID in (SELECT RUN_ID FROM DBO.T_FILE_TRCKR_DTL  												WHERE SRC_SYS_ID = '\" + ((String)globalMap.get(\"row1.SRC_SYS_ID\")) + \"'  				  									AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"row1.SUB_SYS_ID\")) + \"'  				  									AND OBJECT_ID = '\" + ((String)globalMap.get(\"row1.OBJECT_ID\")) + \"'  													AND IS_MERGED = 'IP')  				  AND STG_ID = '1') B  \" : \"  			 (SELECT TOP 1 LD_RECORD_CNT  			  FROM DBO.T_LOAD_STATUS_DTL  			  WHERE RUN_ID = '\" + ((String)globalMap.get(\"row1.CURRENT_RUN_ID\")) + \"'  			  ORDER BY CRTD_DTTM) B  \") + \"  ON 1 = 1  \"");
                log4jParamters_tMSSqlInput_6.append(" | ");
                    log4jParamters_tMSSqlInput_6.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_6.append(" | ");
                    log4jParamters_tMSSqlInput_6.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("LD_RECORD_CNT")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SRC_RECORD_CNT")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("FILE_TYPE")+"}]");
                log4jParamters_tMSSqlInput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_6 - "  + (log4jParamters_tMSSqlInput_6) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_6().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_6 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_6 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_6  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_6, talendToDBArray_tMSSqlInput_6); 
		    int nb_line_tMSSqlInput_6 = 0;
		    java.sql.Connection conn_tMSSqlInput_6 = null;
		        conn_tMSSqlInput_6 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_6 != null) {
					if(conn_tMSSqlInput_6.getMetaData() != null) {
						
						log.debug("tMSSqlInput_6 - Uses an existing connection with username '" + conn_tMSSqlInput_6.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_6.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_6 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_6 = conn_tMSSqlInput_6.createStatement();

		    String dbquery_tMSSqlInput_6 = "\nSELECT COALESCE(A.LD_RECORD_CNT, 0) AS LD_RECORD_CNT\n	, COALESCE(B.LD_RECORD_CNT, 0) AS SRC_RECORD_CNT\n	, CASE WHEN (COALESCE(" + ("D".equals((String)globalMap.get("row1.INGTN_TYP")) ? "A" : "B") + ".LD_RECORD_CNT, 0) > " + ((String)globalMap.get("COALESCE_CUTOFF")) + ") THEN 'M' ELSE 'S' END AS FILE_TYPE\nFROM (SELECT TOP 1 LD_RECORD_CNT\n			  FROM DBO.T_LOAD_STATUS_DTL\n			  WHERE STG_ID = '2'\n				  AND SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n				  AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n				  AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n				  AND STATUS = 'C'\n			  ORDER BY CRTD_DTTM DESC) A\nRIGHT JOIN\n" + ( "MULTI_MERGE".equals((String)globalMap.get("MERGE_TYPE")) &&  "D".equals((String)globalMap.get("row1.INGTN_TYP"))  ? "\n			 (SELECT SUM(LD_RECORD_CNT) AS LD_RECORD_CNT\n			  FROM DBO.T_LOAD_STATUS_DTL\n			  WHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n				  AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n				  AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n			  	  AND RUN_ID in (SELECT RUN_ID FROM DBO.T_FILE_TRCKR_DTL\n												WHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n				  									AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n				  									AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n													AND IS_MERGED = 'IP')\n				  AND STG_ID = '1') B\n" : "\n			 (SELECT TOP 1 LD_RECORD_CNT\n			  FROM DBO.T_LOAD_STATUS_DTL\n			  WHERE RUN_ID = '" + ((String)globalMap.get("row1.CURRENT_RUN_ID")) + "'\n			  ORDER BY CRTD_DTTM) B\n") + "\nON 1 = 1\n";
			
                log.debug("tMSSqlInput_6 - Executing the query: '"+dbquery_tMSSqlInput_6+"'.");
			

                       globalMap.put("tMSSqlInput_6_QUERY",dbquery_tMSSqlInput_6);

		    java.sql.ResultSet rs_tMSSqlInput_6 = null;
		try{
		    rs_tMSSqlInput_6 = stmt_tMSSqlInput_6.executeQuery(dbquery_tMSSqlInput_6);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_6 = rs_tMSSqlInput_6.getMetaData();
		    int colQtyInRs_tMSSqlInput_6 = rsmd_tMSSqlInput_6.getColumnCount();

		    String tmpContent_tMSSqlInput_6 = null;
		    
		    
		    	log.debug("tMSSqlInput_6 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_6.next()) {
		        nb_line_tMSSqlInput_6++;
		        
							if(colQtyInRs_tMSSqlInput_6 < 1) {
								row20.LD_RECORD_CNT = null;
							} else {
		                          
            if(rs_tMSSqlInput_6.getObject(1) != null) {
                row20.LD_RECORD_CNT = rs_tMSSqlInput_6.getInt(1);
            } else {
                    row20.LD_RECORD_CNT = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_6 < 2) {
								row20.SRC_RECORD_CNT = null;
							} else {
		                          
            if(rs_tMSSqlInput_6.getObject(2) != null) {
                row20.SRC_RECORD_CNT = rs_tMSSqlInput_6.getInt(2);
            } else {
                    row20.SRC_RECORD_CNT = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_6 < 3) {
								row20.FILE_TYPE = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_6 = rs_tMSSqlInput_6.getString(3);
            if(tmpContent_tMSSqlInput_6 != null) {
            	if (talendToDBList_tMSSqlInput_6 .contains(rsmd_tMSSqlInput_6.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row20.FILE_TYPE = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_6);
            	} else {
                	row20.FILE_TYPE = tmpContent_tMSSqlInput_6;
                }
            } else {
                row20.FILE_TYPE = null;
            }
		                    }
					
						log.debug("tMSSqlInput_6 - Retrieving the record " + nb_line_tMSSqlInput_6 + ".");
					





 



/**
 * [tMSSqlInput_6 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_6 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_6";

	

 


	tos_count_tMSSqlInput_6++;

/**
 * [tMSSqlInput_6 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			//row20
			//row20


			
				if(execStat){
					runStat.updateStatOnConnection("row20"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row20 - " + (row20==null? "": row20.toLogString()));
    			}
    		

globalMap.put("LD_RECORD_CNT", row20.LD_RECORD_CNT);
globalMap.put("SRC_RECORD_CNT", row20.SRC_RECORD_CNT);
globalMap.put("FILE_TYPE", row20.FILE_TYPE);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */



	
	/**
	 * [tMSSqlInput_6 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_6";

	

	}
}finally{
	stmt_tMSSqlInput_6.close();

}
globalMap.put("tMSSqlInput_6_NB_LINE",nb_line_tMSSqlInput_6);
	    		log.debug("tMSSqlInput_6 - Retrieved records count: "+nb_line_tMSSqlInput_6 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_6 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_6", true);
end_Hash.put("tMSSqlInput_6", System.currentTimeMillis());




/**
 * [tMSSqlInput_6 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row20"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tMSSqlInput_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tFixedFlowInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_6 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_6";

	

 



/**
 * [tMSSqlInput_6 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_6_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String batch_id;

				public String getBatch_id () {
					return this.batch_id;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String Jb_instnce_id;

				public String getJb_instnce_id () {
					return this.Jb_instnce_id;
				}
				
			    public String frequency;

				public String getFrequency () {
					return this.frequency;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_set_id;

				public String getObject_set_id () {
					return this.object_set_id;
				}
				
			    public String Info_dtl;

				public String getInfo_dtl () {
					return this.Info_dtl;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String JB_task_nm;

				public String getJB_task_nm () {
					return this.JB_task_nm;
				}
				
			    public String stg_id;

				public String getStg_id () {
					return this.stg_id;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.batch_id = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.Jb_instnce_id = readString(dis);
					
					this.frequency = readString(dis);
					
					this.object_id = readString(dis);
					
					this.object_set_id = readString(dis);
					
					this.Info_dtl = readString(dis);
					
					this.status = readString(dis);
					
					this.JB_task_nm = readString(dis);
					
					this.stg_id = readString(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_by = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.updt_dttm = readDate(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_nm = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.batch_id,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.Jb_instnce_id,dos);
					
					// String
				
						writeString(this.frequency,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_set_id,dos);
					
					// String
				
						writeString(this.Info_dtl,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.JB_task_nm,dos);
					
					// String
				
						writeString(this.stg_id,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("batch_id="+batch_id);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",run_id="+run_id);
		sb.append(",Jb_instnce_id="+Jb_instnce_id);
		sb.append(",frequency="+frequency);
		sb.append(",object_id="+object_id);
		sb.append(",object_set_id="+object_set_id);
		sb.append(",Info_dtl="+Info_dtl);
		sb.append(",status="+status);
		sb.append(",JB_task_nm="+JB_task_nm);
		sb.append(",stg_id="+stg_id);
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_by="+updt_by);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_nm="+object_nm);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(batch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(batch_id);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(Jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(frequency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(frequency);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_set_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_set_id);
            			}
            		
        			sb.append("|");
        		
        				if(Info_dtl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Info_dtl);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(JB_task_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JB_task_nm);
            			}
            		
        			sb.append("|");
        		
        				if(stg_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stg_id);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tMSSqlOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_1", false);
		start_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_1 = new StringBuilder();
            log4jParamters_tMSSqlOutput_1.append("Parameters:");
                    log4jParamters_tMSSqlOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("TABLE" + " = " + "\"t_ingtn_trckng_dtl\"");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + (log4jParamters_tMSSqlOutput_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_1().limitLog4jByte();



int nb_line_tMSSqlOutput_1 = 0;
int nb_line_update_tMSSqlOutput_1 = 0;
int nb_line_inserted_tMSSqlOutput_1 = 0;
int nb_line_deleted_tMSSqlOutput_1 = 0;
int nb_line_rejected_tMSSqlOutput_1 = 0;

int deletedCount_tMSSqlOutput_1=0;
int updatedCount_tMSSqlOutput_1=0;
int insertedCount_tMSSqlOutput_1=0;
int rejectedCount_tMSSqlOutput_1=0;
String dbschema_tMSSqlOutput_1 = null;
String tableName_tMSSqlOutput_1 = null;
boolean whetherReject_tMSSqlOutput_1 = false;

java.util.Calendar calendar_tMSSqlOutput_1 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_1;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_1 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_1 = null;
String dbUser_tMSSqlOutput_1 = null;
	dbschema_tMSSqlOutput_1 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_1.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_1.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_1 == null || dbschema_tMSSqlOutput_1.trim().length() == 0) {
    tableName_tMSSqlOutput_1 = "t_ingtn_trckng_dtl";
} else {
    tableName_tMSSqlOutput_1 = dbschema_tMSSqlOutput_1 + "].[" + "t_ingtn_trckng_dtl";
}
	int count_tMSSqlOutput_1=0;

        String insert_tMSSqlOutput_1 = "INSERT INTO [" + tableName_tMSSqlOutput_1 + "] ([batch_id],[src_sys_id],[run_id],[Jb_instnce_id],[frequency],[object_id],[object_set_id],[Info_dtl],[status],[JB_task_nm],[stg_id],[crtd_by],[updt_by],[crtd_dttm],[updt_dttm],[sub_sys_id],[object_nm]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_1 = conn_tMSSqlOutput_1.prepareStatement(insert_tMSSqlOutput_1);

 	boolean isShareIdentity_tMSSqlOutput_1 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_1 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_1", false);
		start_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_1";

	
		int tos_count_tFixedFlowInput_1 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_1().limitLog4jByte();

	    for (int i_tFixedFlowInput_1 = 0 ; i_tFixedFlowInput_1 < 1 ; i_tFixedFlowInput_1++) {
	                	            	
    	            		row2.batch_id = ((String)globalMap.get("BATCH_ID"));
    	            	        	            	
    	            		row2.src_sys_id = ((String)globalMap.get("row1.SRC_SYS_ID"));
    	            	        	            	
    	            		row2.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row2.Jb_instnce_id = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row2.frequency = Relational.ISNULL(globalMap.get("FREQUENCY")) ? "0" : ((String)globalMap.get("FREQUENCY"));
    	            	        	            	
    	            		row2.object_id = ((String)globalMap.get("row1.OBJECT_ID"));
    	            	        	            	
    	            		row2.object_set_id = ((String)globalMap.get("OBJECT_SET_ID"));
    	            	        	            	
    	            		row2.Info_dtl = ((String)globalMap.get("INFO_DTL"));
    	            	        	            	
    	            		row2.status = "P";
    	            	        	            	
    	            		row2.JB_task_nm = ((String)globalMap.get("JOB_FQ_NAME"));
    	            	        	            	
    	            		row2.stg_id = Relational.ISNULL(globalMap.get("STG_ID")) ? "2" : ((String)globalMap.get("STG_ID"));
    	            	        	            	
    	            		row2.crtd_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row2.updt_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row2.crtd_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row2.updt_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row2.sub_sys_id = ((String)globalMap.get("row1.SUB_SYS_ID"));
    	            	        	            	
    	            		row2.object_nm = ((String)globalMap.get("row1.OBJECT_NM"));
    	            	
 



/**
 * [tFixedFlowInput_1 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 


	tos_count_tFixedFlowInput_1++;

/**
 * [tFixedFlowInput_1 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_1";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_1 = false;
                    if(row2.batch_id == null) {
pstmt_tMSSqlOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(1, row2.batch_id);
}

                    if(row2.src_sys_id == null) {
pstmt_tMSSqlOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(2, row2.src_sys_id);
}

                    if(row2.run_id == null) {
pstmt_tMSSqlOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(3, row2.run_id);
}

                    if(row2.Jb_instnce_id == null) {
pstmt_tMSSqlOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(4, row2.Jb_instnce_id);
}

                    if(row2.frequency == null) {
pstmt_tMSSqlOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(5, row2.frequency);
}

                    if(row2.object_id == null) {
pstmt_tMSSqlOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(6, row2.object_id);
}

                    if(row2.object_set_id == null) {
pstmt_tMSSqlOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(7, row2.object_set_id);
}

                    if(row2.Info_dtl == null) {
pstmt_tMSSqlOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(8, row2.Info_dtl);
}

                    if(row2.status == null) {
pstmt_tMSSqlOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(9, row2.status);
}

                    if(row2.JB_task_nm == null) {
pstmt_tMSSqlOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(10, row2.JB_task_nm);
}

                    if(row2.stg_id == null) {
pstmt_tMSSqlOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(11, row2.stg_id);
}

                    if(row2.crtd_by == null) {
pstmt_tMSSqlOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(12, row2.crtd_by);
}

                    if(row2.updt_by == null) {
pstmt_tMSSqlOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(13, row2.updt_by);
}

                    if(row2.crtd_dttm != null) {
pstmt_tMSSqlOutput_1.setTimestamp(14, new java.sql.Timestamp(row2.crtd_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_1.setNull(14, java.sql.Types.DATE);
}

                    if(row2.updt_dttm != null) {
pstmt_tMSSqlOutput_1.setTimestamp(15, new java.sql.Timestamp(row2.updt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_1.setNull(15, java.sql.Types.DATE);
}

                    if(row2.sub_sys_id == null) {
pstmt_tMSSqlOutput_1.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(16, row2.sub_sys_id);
}

                    if(row2.object_nm == null) {
pstmt_tMSSqlOutput_1.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(17, row2.object_nm);
}


            try {
                nb_line_tMSSqlOutput_1++;
                insertedCount_tMSSqlOutput_1 = insertedCount_tMSSqlOutput_1 + pstmt_tMSSqlOutput_1.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_1)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_1 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_1{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_1) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_1: pstmt_tMSSqlOutput_1.executeBatch()) {
							if(countEach_tMSSqlOutput_1 == -2 || countEach_tMSSqlOutput_1 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_1;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_1) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_1: pstmt_tMSSqlOutput_1.executeBatch()) {
							if(countEach_tMSSqlOutput_1 == -2 || countEach_tMSSqlOutput_1 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_1;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_1++;

/**
 * [tMSSqlOutput_1 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

        }
        globalMap.put("tFixedFlowInput_1_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_1", true);
end_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());




/**
 * [tFixedFlowInput_1 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_1";

	



        if(pstmt_tMSSqlOutput_1 != null) {
			
				pstmt_tMSSqlOutput_1.close();
			
        }


	nb_line_deleted_tMSSqlOutput_1=nb_line_deleted_tMSSqlOutput_1+ deletedCount_tMSSqlOutput_1;
	nb_line_update_tMSSqlOutput_1=nb_line_update_tMSSqlOutput_1 + updatedCount_tMSSqlOutput_1;
	nb_line_inserted_tMSSqlOutput_1=nb_line_inserted_tMSSqlOutput_1 + insertedCount_tMSSqlOutput_1;
	nb_line_rejected_tMSSqlOutput_1=nb_line_rejected_tMSSqlOutput_1 + rejectedCount_tMSSqlOutput_1;
	
        globalMap.put("tMSSqlOutput_1_NB_LINE",nb_line_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_1);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_1)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_1", true);
end_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());




/**
 * [tMSSqlOutput_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tFixedFlowInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_1 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 



/**
 * [tFixedFlowInput_1 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_1";

	



	

 



/**
 * [tMSSqlOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public java.util.Date MOMENT;

				public java.util.Date getMOMENT () {
					return this.MOMENT;
				}
				
			    public String PID;

				public String getPID () {
					return this.PID;
				}
				
			    public String FATHER_PID;

				public String getFATHER_PID () {
					return this.FATHER_PID;
				}
				
			    public String ROOT_PID;

				public String getROOT_PID () {
					return this.ROOT_PID;
				}
				
			    public Long SYSTEM_PID;

				public Long getSYSTEM_PID () {
					return this.SYSTEM_PID;
				}
				
			    public String PROJECT;

				public String getPROJECT () {
					return this.PROJECT;
				}
				
			    public String JOB;

				public String getJOB () {
					return this.JOB;
				}
				
			    public String JOB_REPOSITORY_ID;

				public String getJOB_REPOSITORY_ID () {
					return this.JOB_REPOSITORY_ID;
				}
				
			    public String JOB_VERSION;

				public String getJOB_VERSION () {
					return this.JOB_VERSION;
				}
				
			    public String CONTEXT;

				public String getCONTEXT () {
					return this.CONTEXT;
				}
				
			    public String ORIGIN;

				public String getORIGIN () {
					return this.ORIGIN;
				}
				
			    public String MESSAGE_TYPE;

				public String getMESSAGE_TYPE () {
					return this.MESSAGE_TYPE;
				}
				
			    public String MESSAGE;

				public String getMESSAGE () {
					return this.MESSAGE;
				}
				
			    public Long DURATION;

				public Long getDURATION () {
					return this.DURATION;
				}
				
			    public String SRC_SYS_ID;

				public String getSRC_SYS_ID () {
					return this.SRC_SYS_ID;
				}
				
			    public String SUB_SYS_ID;

				public String getSUB_SYS_ID () {
					return this.SUB_SYS_ID;
				}
				
			    public String OBJECT_NM;

				public String getOBJECT_NM () {
					return this.OBJECT_NM;
				}
				
			    public String RUN_ID;

				public String getRUN_ID () {
					return this.RUN_ID;
				}
				
			    public String JB_INSTNCE_ID;

				public String getJB_INSTNCE_ID () {
					return this.JB_INSTNCE_ID;
				}
				
			    public String OBJECT_ID;

				public String getOBJECT_ID () {
					return this.OBJECT_ID;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.MOMENT = readDate(dis);
					
					this.PID = readString(dis);
					
					this.FATHER_PID = readString(dis);
					
					this.ROOT_PID = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SYSTEM_PID = null;
           				} else {
           			    	this.SYSTEM_PID = dis.readLong();
           				}
					
					this.PROJECT = readString(dis);
					
					this.JOB = readString(dis);
					
					this.JOB_REPOSITORY_ID = readString(dis);
					
					this.JOB_VERSION = readString(dis);
					
					this.CONTEXT = readString(dis);
					
					this.ORIGIN = readString(dis);
					
					this.MESSAGE_TYPE = readString(dis);
					
					this.MESSAGE = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DURATION = null;
           				} else {
           			    	this.DURATION = dis.readLong();
           				}
					
					this.SRC_SYS_ID = readString(dis);
					
					this.SUB_SYS_ID = readString(dis);
					
					this.OBJECT_NM = readString(dis);
					
					this.RUN_ID = readString(dis);
					
					this.JB_INSTNCE_ID = readString(dis);
					
					this.OBJECT_ID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.MOMENT,dos);
					
					// String
				
						writeString(this.PID,dos);
					
					// String
				
						writeString(this.FATHER_PID,dos);
					
					// String
				
						writeString(this.ROOT_PID,dos);
					
					// Long
				
						if(this.SYSTEM_PID == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.SYSTEM_PID);
		            	}
					
					// String
				
						writeString(this.PROJECT,dos);
					
					// String
				
						writeString(this.JOB,dos);
					
					// String
				
						writeString(this.JOB_REPOSITORY_ID,dos);
					
					// String
				
						writeString(this.JOB_VERSION,dos);
					
					// String
				
						writeString(this.CONTEXT,dos);
					
					// String
				
						writeString(this.ORIGIN,dos);
					
					// String
				
						writeString(this.MESSAGE_TYPE,dos);
					
					// String
				
						writeString(this.MESSAGE,dos);
					
					// Long
				
						if(this.DURATION == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.DURATION);
		            	}
					
					// String
				
						writeString(this.SRC_SYS_ID,dos);
					
					// String
				
						writeString(this.SUB_SYS_ID,dos);
					
					// String
				
						writeString(this.OBJECT_NM,dos);
					
					// String
				
						writeString(this.RUN_ID,dos);
					
					// String
				
						writeString(this.JB_INSTNCE_ID,dos);
					
					// String
				
						writeString(this.OBJECT_ID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("MOMENT="+String.valueOf(MOMENT));
		sb.append(",PID="+PID);
		sb.append(",FATHER_PID="+FATHER_PID);
		sb.append(",ROOT_PID="+ROOT_PID);
		sb.append(",SYSTEM_PID="+String.valueOf(SYSTEM_PID));
		sb.append(",PROJECT="+PROJECT);
		sb.append(",JOB="+JOB);
		sb.append(",JOB_REPOSITORY_ID="+JOB_REPOSITORY_ID);
		sb.append(",JOB_VERSION="+JOB_VERSION);
		sb.append(",CONTEXT="+CONTEXT);
		sb.append(",ORIGIN="+ORIGIN);
		sb.append(",MESSAGE_TYPE="+MESSAGE_TYPE);
		sb.append(",MESSAGE="+MESSAGE);
		sb.append(",DURATION="+String.valueOf(DURATION));
		sb.append(",SRC_SYS_ID="+SRC_SYS_ID);
		sb.append(",SUB_SYS_ID="+SUB_SYS_ID);
		sb.append(",OBJECT_NM="+OBJECT_NM);
		sb.append(",RUN_ID="+RUN_ID);
		sb.append(",JB_INSTNCE_ID="+JB_INSTNCE_ID);
		sb.append(",OBJECT_ID="+OBJECT_ID);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(MOMENT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MOMENT);
            			}
            		
        			sb.append("|");
        		
        				if(PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PID);
            			}
            		
        			sb.append("|");
        		
        				if(FATHER_PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FATHER_PID);
            			}
            		
        			sb.append("|");
        		
        				if(ROOT_PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ROOT_PID);
            			}
            		
        			sb.append("|");
        		
        				if(SYSTEM_PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SYSTEM_PID);
            			}
            		
        			sb.append("|");
        		
        				if(PROJECT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PROJECT);
            			}
            		
        			sb.append("|");
        		
        				if(JOB == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_REPOSITORY_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_REPOSITORY_ID);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_VERSION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_VERSION);
            			}
            		
        			sb.append("|");
        		
        				if(CONTEXT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CONTEXT);
            			}
            		
        			sb.append("|");
        		
        				if(ORIGIN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ORIGIN);
            			}
            		
        			sb.append("|");
        		
        				if(MESSAGE_TYPE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MESSAGE_TYPE);
            			}
            		
        			sb.append("|");
        		
        				if(MESSAGE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MESSAGE);
            			}
            		
        			sb.append("|");
        		
        				if(DURATION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DURATION);
            			}
            		
        			sb.append("|");
        		
        				if(SRC_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SRC_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(SUB_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SUB_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_NM);
            			}
            		
        			sb.append("|");
        		
        				if(RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(JB_INSTNCE_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JB_INSTNCE_ID);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_ID);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tMSSqlOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_2", false);
		start_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_2 = new StringBuilder();
            log4jParamters_tMSSqlOutput_2.append("Parameters:");
                    log4jParamters_tMSSqlOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("TABLE" + " = " + "\"statcatcher\"");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + (log4jParamters_tMSSqlOutput_2) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_2().limitLog4jByte();



int nb_line_tMSSqlOutput_2 = 0;
int nb_line_update_tMSSqlOutput_2 = 0;
int nb_line_inserted_tMSSqlOutput_2 = 0;
int nb_line_deleted_tMSSqlOutput_2 = 0;
int nb_line_rejected_tMSSqlOutput_2 = 0;

int deletedCount_tMSSqlOutput_2=0;
int updatedCount_tMSSqlOutput_2=0;
int insertedCount_tMSSqlOutput_2=0;
int rejectedCount_tMSSqlOutput_2=0;
String dbschema_tMSSqlOutput_2 = null;
String tableName_tMSSqlOutput_2 = null;
boolean whetherReject_tMSSqlOutput_2 = false;

java.util.Calendar calendar_tMSSqlOutput_2 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_2;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_2 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_2 = null;
String dbUser_tMSSqlOutput_2 = null;
	dbschema_tMSSqlOutput_2 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_2 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_2.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_2.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_2 == null || dbschema_tMSSqlOutput_2.trim().length() == 0) {
    tableName_tMSSqlOutput_2 = "statcatcher";
} else {
    tableName_tMSSqlOutput_2 = dbschema_tMSSqlOutput_2 + "].[" + "statcatcher";
}
	int count_tMSSqlOutput_2=0;

        String insert_tMSSqlOutput_2 = "INSERT INTO [" + tableName_tMSSqlOutput_2 + "] ([MOMENT],[PID],[FATHER_PID],[ROOT_PID],[SYSTEM_PID],[PROJECT],[JOB],[JOB_REPOSITORY_ID],[JOB_VERSION],[CONTEXT],[ORIGIN],[MESSAGE_TYPE],[MESSAGE],[DURATION],[SRC_SYS_ID],[SUB_SYS_ID],[OBJECT_NM],[RUN_ID],[JB_INSTNCE_ID],[OBJECT_ID]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_2 = conn_tMSSqlOutput_2.prepareStatement(insert_tMSSqlOutput_2);

 	boolean isShareIdentity_tMSSqlOutput_2 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_2 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_2", false);
		start_Hash.put("tFixedFlowInput_2", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_2";

	
		int tos_count_tFixedFlowInput_2 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_2().limitLog4jByte();

	    for (int i_tFixedFlowInput_2 = 0 ; i_tFixedFlowInput_2 < 1 ; i_tFixedFlowInput_2++) {
	                	            	
    	            		row3.MOMENT = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row3.PID = pid;
    	            	        	            	
    	            		row3.FATHER_PID = context.root_pid;
    	            	        	            	
    	            		row3.ROOT_PID = context.root_pid;
    	            	        	            	
    	            		row3.SYSTEM_PID = null;
    	            	        	            	
    	            		row3.PROJECT = projectName;
    	            	        	            	
    	            		row3.JOB = jobName;
    	            	        	            	
    	            		row3.JOB_REPOSITORY_ID = null;
    	            	        	            	
    	            		row3.JOB_VERSION = jobVersion;
    	            	        	            	
    	            		row3.CONTEXT = contextStr ;
    	            	        	            	
    	            		row3.ORIGIN = null;
    	            	        	            	
    	            		row3.MESSAGE_TYPE = "begin";
    	            	        	            	
    	            		row3.MESSAGE = null;
    	            	        	            	
    	            		row3.DURATION = null;
    	            	        	            	
    	            		row3.SRC_SYS_ID = ((String)globalMap.get("row1.SRC_SYS_ID"));
    	            	        	            	
    	            		row3.SUB_SYS_ID = ((String)globalMap.get("row1.SUB_SYS_ID"));
    	            	        	            	
    	            		row3.OBJECT_NM = ((String)globalMap.get("row1.OBJECT_NM"));
    	            	        	            	
    	            		row3.RUN_ID = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row3.JB_INSTNCE_ID = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row3.OBJECT_ID = ((String)globalMap.get("row1.OBJECT_ID"));
    	            	
 



/**
 * [tFixedFlowInput_2 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_2 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";

	

 


	tos_count_tFixedFlowInput_2++;

/**
 * [tFixedFlowInput_2 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_2 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_2";

	

			//row3
			//row3


			
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_2 = false;
                    if(row3.MOMENT != null) {
pstmt_tMSSqlOutput_2.setTimestamp(1, new java.sql.Timestamp(row3.MOMENT.getTime()));
} else {
pstmt_tMSSqlOutput_2.setNull(1, java.sql.Types.DATE);
}

                    if(row3.PID == null) {
pstmt_tMSSqlOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(2, row3.PID);
}

                    if(row3.FATHER_PID == null) {
pstmt_tMSSqlOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(3, row3.FATHER_PID);
}

                    if(row3.ROOT_PID == null) {
pstmt_tMSSqlOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(4, row3.ROOT_PID);
}

                    if(row3.SYSTEM_PID == null) {
pstmt_tMSSqlOutput_2.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_2.setLong(5, row3.SYSTEM_PID);
}

                    if(row3.PROJECT == null) {
pstmt_tMSSqlOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(6, row3.PROJECT);
}

                    if(row3.JOB == null) {
pstmt_tMSSqlOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(7, row3.JOB);
}

                    if(row3.JOB_REPOSITORY_ID == null) {
pstmt_tMSSqlOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(8, row3.JOB_REPOSITORY_ID);
}

                    if(row3.JOB_VERSION == null) {
pstmt_tMSSqlOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(9, row3.JOB_VERSION);
}

                    if(row3.CONTEXT == null) {
pstmt_tMSSqlOutput_2.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(10, row3.CONTEXT);
}

                    if(row3.ORIGIN == null) {
pstmt_tMSSqlOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(11, row3.ORIGIN);
}

                    if(row3.MESSAGE_TYPE == null) {
pstmt_tMSSqlOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(12, row3.MESSAGE_TYPE);
}

                    if(row3.MESSAGE == null) {
pstmt_tMSSqlOutput_2.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(13, row3.MESSAGE);
}

                    if(row3.DURATION == null) {
pstmt_tMSSqlOutput_2.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_2.setLong(14, row3.DURATION);
}

                    if(row3.SRC_SYS_ID == null) {
pstmt_tMSSqlOutput_2.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(15, row3.SRC_SYS_ID);
}

                    if(row3.SUB_SYS_ID == null) {
pstmt_tMSSqlOutput_2.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(16, row3.SUB_SYS_ID);
}

                    if(row3.OBJECT_NM == null) {
pstmt_tMSSqlOutput_2.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(17, row3.OBJECT_NM);
}

                    if(row3.RUN_ID == null) {
pstmt_tMSSqlOutput_2.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(18, row3.RUN_ID);
}

                    if(row3.JB_INSTNCE_ID == null) {
pstmt_tMSSqlOutput_2.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(19, row3.JB_INSTNCE_ID);
}

                    if(row3.OBJECT_ID == null) {
pstmt_tMSSqlOutput_2.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(20, row3.OBJECT_ID);
}


            try {
                nb_line_tMSSqlOutput_2++;
                insertedCount_tMSSqlOutput_2 = insertedCount_tMSSqlOutput_2 + pstmt_tMSSqlOutput_2.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_2)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_2 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_2{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_2) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_2: pstmt_tMSSqlOutput_2.executeBatch()) {
							if(countEach_tMSSqlOutput_2 == -2 || countEach_tMSSqlOutput_2 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_2;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_2) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_2: pstmt_tMSSqlOutput_2.executeBatch()) {
							if(countEach_tMSSqlOutput_2 == -2 || countEach_tMSSqlOutput_2 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_2;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_2++;

/**
 * [tMSSqlOutput_2 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_2 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";

	

        }
        globalMap.put("tFixedFlowInput_2_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_2", true);
end_Hash.put("tFixedFlowInput_2", System.currentTimeMillis());




/**
 * [tFixedFlowInput_2 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_2 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_2";

	



        if(pstmt_tMSSqlOutput_2 != null) {
			
				pstmt_tMSSqlOutput_2.close();
			
        }


	nb_line_deleted_tMSSqlOutput_2=nb_line_deleted_tMSSqlOutput_2+ deletedCount_tMSSqlOutput_2;
	nb_line_update_tMSSqlOutput_2=nb_line_update_tMSSqlOutput_2 + updatedCount_tMSSqlOutput_2;
	nb_line_inserted_tMSSqlOutput_2=nb_line_inserted_tMSSqlOutput_2 + insertedCount_tMSSqlOutput_2;
	nb_line_rejected_tMSSqlOutput_2=nb_line_rejected_tMSSqlOutput_2 + rejectedCount_tMSSqlOutput_2;
	
        globalMap.put("tMSSqlOutput_2_NB_LINE",nb_line_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_2);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_2)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row3"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_2", true);
end_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());




/**
 * [tMSSqlOutput_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tJava_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_2 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";

	

 



/**
 * [tFixedFlowInput_2 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_2";

	



	

 



/**
 * [tMSSqlOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_7", false);
		start_Hash.put("tWarn_7", System.currentTimeMillis());
		
	
	currentComponent="tWarn_7";

	
		int tos_count_tWarn_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_7 = new StringBuilder();
            log4jParamters_tWarn_7.append("Parameters:");
                    log4jParamters_tWarn_7.append("MESSAGE" + " = " + "\"307|Insert into stats table failed\"");
                log4jParamters_tWarn_7.append(" | ");
                    log4jParamters_tWarn_7.append("CODE" + " = " + "999");
                log4jParamters_tWarn_7.append(" | ");
                    log4jParamters_tWarn_7.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + (log4jParamters_tWarn_7) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_7().limitLog4jByte();

 



/**
 * [tWarn_7 begin ] stop
 */
	
	/**
	 * [tWarn_7 main ] start
	 */

	

	
	
	currentComponent="tWarn_7";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_7", "", Thread.currentThread().getId() + "", "ERROR","","307|Insert into stats table failed","", "");
            log.error("tWarn_7 - "  + ("Message: ")  + ("307|Insert into stats table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_7", 5, "307|Insert into stats table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_7_WARN_MESSAGES", "307|Insert into stats table failed"); 
globalMap.put("tWarn_7_WARN_PRIORITY", 5);
globalMap.put("tWarn_7_WARN_CODE", 999);


 


	tos_count_tWarn_7++;

/**
 * [tWarn_7 main ] stop
 */
	
	/**
	 * [tWarn_7 end ] start
	 */

	

	
	
	currentComponent="tWarn_7";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + ("Done.") );

ok_Hash.put("tWarn_7", true);
end_Hash.put("tWarn_7", System.currentTimeMillis());




/**
 * [tWarn_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_7 finally ] start
	 */

	

	
	
	currentComponent="tWarn_7";

	

 



/**
 * [tWarn_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_7_SUBPROCESS_STATE", 1);
	}
	

public void tJava_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_7", false);
		start_Hash.put("tJava_7", System.currentTimeMillis());
		
	
	currentComponent="tJava_7";

	
		int tos_count_tJava_7 = 0;
		
    	class BytesLimit65535_tJava_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_7().limitLog4jByte();


globalMap.put("APPLICATION_NAME",  ((String)globalMap.get("row1.SRC_SYS_NM")) + "_" + (Relational.ISNULL(globalMap.get("row1.SUB_SYS_NM")) ? "" : ((String)globalMap.get("row1.SUB_SYS_NM")) + "_") + ((String)globalMap.get("row1.OBJECT_NM")) + "_" + TalendDate.getDate("dd-MM-yyyy-HH:mm"));




globalMap.put("INITIAL_FILE_LOCTN", ((String)globalMap.get("ADLS_URL")) + ((String)globalMap.get("row1.MRGD_FILE_LOCTN")));
globalMap.put("DELTA_FILE_LOCTN", ((String)globalMap.get("ADLS_URL")) + ((String)globalMap.get("row1.ADLS_FILE_LOCTN")));
globalMap.put("INTRM_FILE_LOCTN", ((String)globalMap.get("ADLS_URL")) + ((String)globalMap.get("row1.OUT_FILE_LOCTN")));
globalMap.put("FINAL_FILE_LOCTN", ((String)globalMap.get("INITIAL_FILE_LOCTN")));

if ("F".equals((String)globalMap.get("row1.INGTN_TYP")))
{

//[Single/Multiple Files S/M] [CSV Delimiter] [Application Name] [Spark Master] [Master File] [Output Directory] [encoding] [partition_flg] [partition_col] [partition_rule] [yarn_tier] [custom_merge]
//sh /home/deploy/spark-applications/merge/SparkCopyDataFiles_yarn_v2.sh S '|' UCM_S_ADDR_PER_INIT_LD yarn "adl://qacerebroadls.azuredatalakestore.net/RAW/LANDING/UCM/S_UCM_ADDR_PER/2018/08/24/S_UCM_ADDR_PER_20180824200514639.csv" "adl://qacerebroadls.azuredatalakestore.net/RAW/STAGING/UCM/S_UCM_ADDR_PER_2" "UTF-8" "Y" "ROW_ID" "UCM_SDH_RULE" "T4" "Y"

	globalMap.put("RAW_MRGD_SCRIPT", "sh " + ((String)globalMap.get("SPARK_JOB_PATH")) + "/" + ((String)globalMap.get("COPY_SCRIPT_NAME")) + " " + ((String)globalMap.get("FILE_TYPE")) + " '" + ((String)globalMap.get("FIELD_SEPARATOR")) + "' " + ((String)globalMap.get("APPLICATION_NAME")) + " " + ((String)globalMap.get("SPARK_MASTER")) + " " + ((String)globalMap.get("DELTA_FILE_LOCTN")) + " " + ((String)globalMap.get("FINAL_FILE_LOCTN")) + " " + ((String)globalMap.get("row1.CHR_ENCODE")) + " " + ((String)globalMap.get("row1.PARTITION_FLG")) + " " + ((String)globalMap.get("row1.PARTITION_COL")) + " " + ((String)globalMap.get("row1.PARTITION_RULE")) + " " + ("Y".equals((String)globalMap.get("CUSTOM_MERGE")) ? (!Relational.ISNULL((String)globalMap.get("CUSTOM_FILE_TIER")) ? ((String)globalMap.get("CUSTOM_FILE_TIER")) :"T1" ) : ((String)globalMap.get("row1.TIER")) ) + " " + ("Y".equals((String)globalMap.get("CUSTOM_MERGE")) ? "Y" : "N"));

} else if ("D".equals((String)globalMap.get("row1.INGTN_TYP"))) {

//[Single/Multiple Files S/M] [CSV Delimiter] [Application Name] [Spark Master] [Master File] [Output Directory] [encoding] [partition_flg] [partition_col] [partition_rule] [yarn_tier] [custom_merge]
//sh /home/deploy/spark-applications/merge/SparkCopyDataFiles_yarn_v2.sh S '|' UCM_S_ADDR_PER_INIT_LD yarn "adl://qacerebroadls.azuredatalakestore.net/RAW/LANDING/UCM/S_UCM_ADDR_PER/2018/08/24/S_UCM_ADDR_PER_20180824200514639.csv" "adl://qacerebroadls.azuredatalakestore.net/RAW/STAGING/UCM/S_UCM_ADDR_PER_2" "UTF-8" "Y" "ROW_ID" "UCM_SDH_RULE" "T4" "Y"

	if ("Y".equals((String)globalMap.get("row1.INIT_LD"))) {
		globalMap.put("RAW_COPY_SCRIPT", "sh " + ((String)globalMap.get("SPARK_JOB_PATH")) + "/" + ((String)globalMap.get("COPY_SCRIPT_NAME")) + " " + ((String)globalMap.get("FILE_TYPE")) + " '" + ((String)globalMap.get("FIELD_SEPARATOR")) + "' " + ((String)globalMap.get("APPLICATION_NAME")) + " " + ((String)globalMap.get("SPARK_MASTER")) + " " + ((String)globalMap.get("DELTA_FILE_LOCTN"))+ " " + ((String)globalMap.get("FINAL_FILE_LOCTN")) + " " + ((String)globalMap.get("row1.CHR_ENCODE")) + " " + ((String)globalMap.get("row1.PARTITION_FLG")) + " " + ((String)globalMap.get("row1.PARTITION_COL")) + " " + ((String)globalMap.get("row1.PARTITION_RULE")) + " " + ("Y".equals((String)globalMap.get("CUSTOM_MERGE")) ? (!Relational.ISNULL((String)globalMap.get("CUSTOM_FILE_TIER")) ? ((String)globalMap.get("CUSTOM_FILE_TIER")) :"T1" ) : ((String)globalMap.get("row1.TIER")) ) + " " + ("Y".equals((String)globalMap.get("CUSTOM_MERGE")) ? "Y" : "N"));
	}
	
//[Single/Multiple Files S/M] [CSV Delimiter] [Application Name] [Spark Master] [Master File] [Delta File] [key Columns] [Update Timestamp Column] [Output Directory] [encoding] [partition_reqd_flg] [partition_col] [partition_rule] [yarn_tier]
//sh /home/deploy/spark-applications/merge/SparkMergeDataFiles_yarn_v2.sh M '|' UCM_S_ADDR_PER_MRG_LD yarn adl://qacerebroadls.azuredatalakestore.net/RAW/STAGING/UCM/S_UCM_ADDR_PER_2/*.csv adl://qacerebroadls.azuredatalakestore.net//RAW/LANDING/UCM/S_UCM_ADDR_PER/2018/08/28/*.csv "ROW_ID" "LAST_UPD" "adl://qacerebroadls.azuredatalakestore.net/RAW/LANDING/UCM/S_UCM_ADDR_PER_TEMP" UTF-8 Y "ROW_ID" UCM_SDH_RULE T4
if ("MULTI_MERGE".equals((String)globalMap.get("MERGE_TYPE"))) {
	
	globalMap.put("DELTA_FILE_LOCTN_TEMP", ((String)globalMap.get("row1.ADLS_FILE_LOCTN")).replaceAll(((String)globalMap.get("row1.FILE_NM")), "*.csv"));
	globalMap.put("DELTA_FILE_LOCTN", ((String)globalMap.get("ADLS_URL")) + ((String)globalMap.get("DELTA_FILE_LOCTN_TEMP")));

}

	globalMap.put("RAW_MRGD_SCRIPT", "sh " + ((String)globalMap.get("SPARK_JOB_PATH")) + "/" + ((String)globalMap.get("MERGE_SCRIPT_NAME")) + " " + ((String)globalMap.get("FILE_TYPE")) + " '" + ((String)globalMap.get("FIELD_SEPARATOR")) + "' " + ((String)globalMap.get("APPLICATION_NAME")) + " " + ((String)globalMap.get("SPARK_MASTER")) + " " + ((String)globalMap.get("INITIAL_FILE_LOCTN")) + " " + ((String)globalMap.get("DELTA_FILE_LOCTN")) + " '" + ((String)globalMap.get("row1.PRMRY_K")) + "' " + ((String)globalMap.get("row1.TMSTMP_K")) + " " + ((String)globalMap.get("INTRM_FILE_LOCTN")) + " " + ((String)globalMap.get("row1.CHR_ENCODE")) + " " + ((String)globalMap.get("row1.PARTITION_FLG")) + " " + ((String)globalMap.get("row1.PARTITION_COL")) + " " + ((String)globalMap.get("row1.PARTITION_RULE")) + " " + ((String)globalMap.get("row1.TIER")));

}

globalMap.put("OBJECT_NAME_EXT", StringHandling.TRIM(((String)globalMap.get("FINAL_FILE_LOCTN")).lastIndexOf("/") >= 1 ?  ((String)globalMap.get("FINAL_FILE_LOCTN")).substring(((String)globalMap.get("FINAL_FILE_LOCTN")).lastIndexOf("/") + 1, ((String)globalMap.get("FINAL_FILE_LOCTN")).length()) :
((String)globalMap.get("FINAL_FILE_LOCTN")))) ;

System.out.println("RAW_MRGD_SCRIPT : "+((String)globalMap.get("RAW_MRGD_SCRIPT")));


if ("MULTI_MERGE".equals((String)globalMap.get("MERGE_TYPE")) && "Y".equals((String)globalMap.get("row1.INIT_LD")))
{
System.out.println("RAW_COPY_SCRIPT : "+((String)globalMap.get("RAW_COPY_SCRIPT")) );
}

 



/**
 * [tJava_7 begin ] stop
 */
	
	/**
	 * [tJava_7 main ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 


	tos_count_tJava_7++;

/**
 * [tJava_7 main ] stop
 */
	
	/**
	 * [tJava_7 end ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 

ok_Hash.put("tJava_7", true);
end_Hash.put("tJava_7", System.currentTimeMillis());

   			if ("D".equals((String)globalMap.get("row1.INGTN_TYP")) && "Y".equals((String)globalMap.get("row1.INIT_LD"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "true");
					}
				
    			tSystem_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "false");
					}   	 
   				}



/**
 * [tJava_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk11", 0, "ok");
								} 
							
							tJava_10Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_7 finally ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 



/**
 * [tJava_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_7_SUBPROCESS_STATE", 1);
	}
	

public void tJava_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_10", false);
		start_Hash.put("tJava_10", System.currentTimeMillis());
		
	
	currentComponent="tJava_10";

	
		int tos_count_tJava_10 = 0;
		
    	class BytesLimit65535_tJava_10{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_10().limitLog4jByte();


if (((Integer)globalMap.get("SRC_RECORD_CNT")) == 0) {
	globalMap.put("LOAD_STATUS", "C");
}
 



/**
 * [tJava_10 begin ] stop
 */
	
	/**
	 * [tJava_10 main ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 


	tos_count_tJava_10++;

/**
 * [tJava_10 main ] stop
 */
	
	/**
	 * [tJava_10 end ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 

ok_Hash.put("tJava_10", true);
end_Hash.put("tJava_10", System.currentTimeMillis());

   			if (((Integer)globalMap.get("SRC_RECORD_CNT")) > 0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				
    			tSystem_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}



/**
 * [tJava_10 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_10:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tFixedFlowInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_10 finally ] start
	 */

	

	
	
	currentComponent="tJava_10";

	

 



/**
 * [tJava_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_10_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";

	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
            log4jParamters_tWarn_2.append("Parameters:");
                    log4jParamters_tWarn_2.append("MESSAGE" + " = " + "\"309|Merge into ADLS Staging failed\"");
                log4jParamters_tWarn_2.append(" | ");
                    log4jParamters_tWarn_2.append("CODE" + " = " + "999");
                log4jParamters_tWarn_2.append(" | ");
                    log4jParamters_tWarn_2.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_2().limitLog4jByte();

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "ERROR","","309|Merge into ADLS Staging failed","", "");
            log.error("tWarn_2 - "  + ("Message: ")  + ("309|Merge into ADLS Staging failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_2", 5, "309|Merge into ADLS Staging failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_2_WARN_MESSAGES", "309|Merge into ADLS Staging failed"); 
globalMap.put("tWarn_2_WARN_PRIORITY", 5);
globalMap.put("tWarn_2_WARN_CODE", 999);


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	

public void tSystem_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSystem_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSystem_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSystem_1", false);
		start_Hash.put("tSystem_1", System.currentTimeMillis());
		
	
	currentComponent="tSystem_1";

	
		int tos_count_tSystem_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSystem_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSystem_1 = new StringBuilder();
            log4jParamters_tSystem_1.append("Parameters:");
                    log4jParamters_tSystem_1.append("ROOTDIR" + " = " + "false");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("USE_SINGLE_COMMAND" + " = " + "false");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("USE_ARRAY_COMMAND" + " = " + "true");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("ARRAY_COMMAND" + " = " + "[{VALUE="+("\"/bin/bash\"")+"}, {VALUE="+("\"-c\"")+"}, {VALUE="+("((String)globalMap.get(\"RAW_MRGD_SCRIPT\"))")+"}]");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("OUTPUT" + " = " + "OUTPUT_TO_CONSOLE_AND_RETRIVE_OUTPUT");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("ERROROUTPUT" + " = " + "OUTPUT_TO_CONSOLE_AND_RETRIVE_OUTPUT");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("PARAMS" + " = " + "[]");
                log4jParamters_tSystem_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + (log4jParamters_tSystem_1) );
    		}
    	}
    	
        new BytesLimit65535_tSystem_1().limitLog4jByte();

		
			String commandArrayForLog_tSystem_1 ="";
		
		String[] command_tSystem_1 = new String[3];
		
			command_tSystem_1[0] = "/bin/bash";
			
				if(("/bin/bash").contains(" "))
					commandArrayForLog_tSystem_1+="\"" + "/bin/bash" + "\" ";
				else
					commandArrayForLog_tSystem_1+="/bin/bash" + " ";
			
			command_tSystem_1[1] = "-c";
			
				if(("-c").contains(" "))
					commandArrayForLog_tSystem_1+="\"" + "-c" + "\" ";
				else
					commandArrayForLog_tSystem_1+="-c" + " ";
			
			command_tSystem_1[2] = ((String)globalMap.get("RAW_MRGD_SCRIPT"));
			
				if((((String)globalMap.get("RAW_MRGD_SCRIPT"))).contains(" "))
					commandArrayForLog_tSystem_1+="\"" + ((String)globalMap.get("RAW_MRGD_SCRIPT")) + "\" ";
				else
					commandArrayForLog_tSystem_1+=((String)globalMap.get("RAW_MRGD_SCRIPT")) + " ";
			
Runtime runtime_tSystem_1 = Runtime.getRuntime();

String[] env_tSystem_1= null;
java.util.Map<String,String> envMap_tSystem_1= System.getenv();
java.util.Map<String,String> envMapClone_tSystem_1= new java.util.HashMap();
envMapClone_tSystem_1.putAll(envMap_tSystem_1);

	log.info("tSystem_1 - Setting the parameters.");
final Process ps_tSystem_1 = runtime_tSystem_1.exec(command_tSystem_1 ,env_tSystem_1);

globalMap.remove("tSystem_1_OUTPUT");
globalMap.remove("tSystem_1_ERROROUTPUT");

Thread normal_tSystem_1 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_1.getInputStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
		
			log.debug("tSystem_1 - Sending the standard output to both the console and the global variable 'tSystem_1_OUTPUT'.");
		
        System.out.println(line);
        
        	if (globalMap.get("tSystem_1_OUTPUT") != null) {
						globalMap.put("tSystem_1_OUTPUT", (String)globalMap.get("tSystem_1_OUTPUT")+"\n"+line);
					} else {
						globalMap.put("tSystem_1_OUTPUT", line);
					}
					
    	 
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_1 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
	log.info("tSystem_1 - Executing the command.");
	log.info("tSystem_1 - Command to execute: '" + commandArrayForLog_tSystem_1  + "'.");
normal_tSystem_1.start();
	log.info("tSystem_1 - The command has been executed successfully.");

Thread error_tSystem_1 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_1.getErrorStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
		
			log.debug("tSystem_1 - Sending the error output to both the console and the global variable 'tSystem_1_ERROROUTPUT'.");
		
        System.err.println(line);
        
        	if (globalMap.get("tSystem_1_ERROROUTPUT") != null) {
						globalMap.put("tSystem_1_ERROROUTPUT", (String)globalMap.get("tSystem_1_ERROROUTPUT")+"\n"+line);
					} else {
						globalMap.put("tSystem_1_ERROROUTPUT", line);
					}
					
    	 
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_1 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
error_tSystem_1.start();
if(ps_tSystem_1.getOutputStream()!=null){
    ps_tSystem_1.getOutputStream().close();
}
ps_tSystem_1.waitFor();
normal_tSystem_1.join(10000);
error_tSystem_1.join(10000);


 



/**
 * [tSystem_1 begin ] stop
 */
	
	/**
	 * [tSystem_1 main ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	


 


	tos_count_tSystem_1++;

/**
 * [tSystem_1 main ] stop
 */
	
	/**
	 * [tSystem_1 end ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	

globalMap.put("tSystem_1_EXIT_VALUE", ps_tSystem_1.exitValue());

 
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + ("Done.") );

ok_Hash.put("tSystem_1", true);
end_Hash.put("tSystem_1", System.currentTimeMillis());

   			if (((Integer)globalMap.get("tSystem_1_EXIT_VALUE")) == 0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "true");
					}
				
    			tJava_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "false");
					}   	 
   				}
   			if (((Integer)globalMap.get("tSystem_1_EXIT_VALUE")) != 0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "true");
					}
				
    			tJava_8Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If5", 0, "false");
					}   	 
   				}



/**
 * [tSystem_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSystem_1 finally ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	

 



/**
 * [tSystem_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSystem_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";

	
		int tos_count_tJava_3 = 0;
		
    	class BytesLimit65535_tJava_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_3().limitLog4jByte();


//***************** Application id  from Standard Output

String mergOut = (Relational.ISNULL(globalMap.get("tSystem_1_OUTPUT")) ? "" : ((String)globalMap.get("tSystem_1_OUTPUT")));

globalMap.put("MERGE_APPLICATION_ID", mergOut.indexOf("|application_") > 0 ? (mergOut.substring(mergOut.indexOf("|application_") + 1, mergOut.length())) : "We are not getting application id from Logs,Please check the logs once ");

//sh /home/deploy/spark-applications/merge/CountCSVFileRecords_yarn_v2.sh UCM_2_S_UCM_CONTACT_27-09-2018-05:21 yarn '|' adl://qacerebroadls.azuredatalakestore.net/RAW/STAGING/UCM/S_UCM_CONTACT UTF-8 219779 260577844_20180927052013516_11_S_UCM_CONTACT T6 Y Y 

globalMap.put("RAW_CNT_SCRIPT", "sh "+ ((String)globalMap.get("SPARK_JOB_PATH")) + "/" + ((String)globalMap.get("COUNT_SCRIPT_NAME")) + " "  + ((String)globalMap.get("APPLICATION_NAME")) + " " + ((String)globalMap.get("SPARK_MASTER")) + " '" + ((String)globalMap.get("FIELD_SEPARATOR")) + "' " + ((String)globalMap.get("FINAL_FILE_LOCTN")) + " " + ((String)globalMap.get("row1.CHR_ENCODE")) + " " + ((Integer)globalMap.get("SRC_RECORD_CNT")) + " " + ((String)globalMap.get("RUN_ID")) + " " + ((String)globalMap.get("row1.TIER")) + " " + ((String)globalMap.get("row1.IS_PARQUET"))  + " " + ((String)globalMap.get("row1.PARTITION_FLG")));

System.out.println("RAW_CNT_SCRIPT : "+((String)globalMap.get("RAW_CNT_SCRIPT")));

 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());




/**
 * [tJava_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk6", 0, "ok");
								} 
							
							tSystem_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}
	

public void tSystem_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSystem_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSystem_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSystem_2", false);
		start_Hash.put("tSystem_2", System.currentTimeMillis());
		
	
	currentComponent="tSystem_2";

	
		int tos_count_tSystem_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSystem_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSystem_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSystem_2 = new StringBuilder();
            log4jParamters_tSystem_2.append("Parameters:");
                    log4jParamters_tSystem_2.append("ROOTDIR" + " = " + "false");
                log4jParamters_tSystem_2.append(" | ");
                    log4jParamters_tSystem_2.append("USE_SINGLE_COMMAND" + " = " + "false");
                log4jParamters_tSystem_2.append(" | ");
                    log4jParamters_tSystem_2.append("USE_ARRAY_COMMAND" + " = " + "true");
                log4jParamters_tSystem_2.append(" | ");
                    log4jParamters_tSystem_2.append("ARRAY_COMMAND" + " = " + "[{VALUE="+("\"/bin/bash\"")+"}, {VALUE="+("\"-c\"")+"}, {VALUE="+("((String)globalMap.get(\"RAW_CNT_SCRIPT\"))")+"}]");
                log4jParamters_tSystem_2.append(" | ");
                    log4jParamters_tSystem_2.append("OUTPUT" + " = " + "OUTPUT_TO_CONSOLE_AND_RETRIVE_OUTPUT");
                log4jParamters_tSystem_2.append(" | ");
                    log4jParamters_tSystem_2.append("ERROROUTPUT" + " = " + "OUTPUT_TO_CONSOLE_AND_RETRIVE_OUTPUT");
                log4jParamters_tSystem_2.append(" | ");
                    log4jParamters_tSystem_2.append("PARAMS" + " = " + "[]");
                log4jParamters_tSystem_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSystem_2 - "  + (log4jParamters_tSystem_2) );
    		}
    	}
    	
        new BytesLimit65535_tSystem_2().limitLog4jByte();

		
			String commandArrayForLog_tSystem_2 ="";
		
		String[] command_tSystem_2 = new String[3];
		
			command_tSystem_2[0] = "/bin/bash";
			
				if(("/bin/bash").contains(" "))
					commandArrayForLog_tSystem_2+="\"" + "/bin/bash" + "\" ";
				else
					commandArrayForLog_tSystem_2+="/bin/bash" + " ";
			
			command_tSystem_2[1] = "-c";
			
				if(("-c").contains(" "))
					commandArrayForLog_tSystem_2+="\"" + "-c" + "\" ";
				else
					commandArrayForLog_tSystem_2+="-c" + " ";
			
			command_tSystem_2[2] = ((String)globalMap.get("RAW_CNT_SCRIPT"));
			
				if((((String)globalMap.get("RAW_CNT_SCRIPT"))).contains(" "))
					commandArrayForLog_tSystem_2+="\"" + ((String)globalMap.get("RAW_CNT_SCRIPT")) + "\" ";
				else
					commandArrayForLog_tSystem_2+=((String)globalMap.get("RAW_CNT_SCRIPT")) + " ";
			
Runtime runtime_tSystem_2 = Runtime.getRuntime();

String[] env_tSystem_2= null;
java.util.Map<String,String> envMap_tSystem_2= System.getenv();
java.util.Map<String,String> envMapClone_tSystem_2= new java.util.HashMap();
envMapClone_tSystem_2.putAll(envMap_tSystem_2);

	log.info("tSystem_2 - Setting the parameters.");
final Process ps_tSystem_2 = runtime_tSystem_2.exec(command_tSystem_2 ,env_tSystem_2);

globalMap.remove("tSystem_2_OUTPUT");
globalMap.remove("tSystem_2_ERROROUTPUT");

Thread normal_tSystem_2 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_2.getInputStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
		
			log.debug("tSystem_2 - Sending the standard output to both the console and the global variable 'tSystem_2_OUTPUT'.");
		
        System.out.println(line);
        
        	if (globalMap.get("tSystem_2_OUTPUT") != null) {
						globalMap.put("tSystem_2_OUTPUT", (String)globalMap.get("tSystem_2_OUTPUT")+"\n"+line);
					} else {
						globalMap.put("tSystem_2_OUTPUT", line);
					}
					
    	 
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_2 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
	log.info("tSystem_2 - Executing the command.");
	log.info("tSystem_2 - Command to execute: '" + commandArrayForLog_tSystem_2  + "'.");
normal_tSystem_2.start();
	log.info("tSystem_2 - The command has been executed successfully.");

Thread error_tSystem_2 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_2.getErrorStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
		
			log.debug("tSystem_2 - Sending the error output to both the console and the global variable 'tSystem_2_ERROROUTPUT'.");
		
        System.err.println(line);
        
        	if (globalMap.get("tSystem_2_ERROROUTPUT") != null) {
						globalMap.put("tSystem_2_ERROROUTPUT", (String)globalMap.get("tSystem_2_ERROROUTPUT")+"\n"+line);
					} else {
						globalMap.put("tSystem_2_ERROROUTPUT", line);
					}
					
    	 
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_2 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
error_tSystem_2.start();
if(ps_tSystem_2.getOutputStream()!=null){
    ps_tSystem_2.getOutputStream().close();
}
ps_tSystem_2.waitFor();
normal_tSystem_2.join(10000);
error_tSystem_2.join(10000);


 



/**
 * [tSystem_2 begin ] stop
 */
	
	/**
	 * [tSystem_2 main ] start
	 */

	

	
	
	currentComponent="tSystem_2";

	


 


	tos_count_tSystem_2++;

/**
 * [tSystem_2 main ] stop
 */
	
	/**
	 * [tSystem_2 end ] start
	 */

	

	
	
	currentComponent="tSystem_2";

	

globalMap.put("tSystem_2_EXIT_VALUE", ps_tSystem_2.exitValue());

 
                if(log.isDebugEnabled())
            log.debug("tSystem_2 - "  + ("Done.") );

ok_Hash.put("tSystem_2", true);
end_Hash.put("tSystem_2", System.currentTimeMillis());

   			if (((Integer)globalMap.get("tSystem_2_EXIT_VALUE")) != 0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				
    			tJava_5Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}
   			if ( ((Integer)globalMap.get("tSystem_2_EXIT_VALUE")) ==0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "true");
					}
				
    			tJava_4Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "false");
					}   	 
   				}



/**
 * [tSystem_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSystem_2 finally ] start
	 */

	

	
	
	currentComponent="tSystem_2";

	

 



/**
 * [tSystem_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSystem_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";

	
		int tos_count_tJava_5 = 0;
		
    	class BytesLimit65535_tJava_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_5().limitLog4jByte();


//***************** Application id  from Standard Output
String cntOut = (Relational.ISNULL(globalMap.get("tSystem_2_OUTPUT")) ? "" : ((String)globalMap.get("tSystem_2_OUTPUT")));

globalMap.put("CNT_APPLICATION_ID", cntOut.indexOf("|application_")>0 ? 
(cntOut.substring(cntOut.indexOf("|application_") + 1, cntOut.length())) : "We are not getting application id from Logs,Please check the logs once ");

globalMap.put("COUNT_ERROR_MSG", ((cntOut.indexOf("ERROR ApplicationMaster:") >= 0 &&  cntOut.indexOf("ERROR ApplicationMaster:") < cntOut.indexOf("|application")) ? cntOut.substring(cntOut.indexOf("ERROR ApplicationMaster:"), cntOut.indexOf("|application")) : cntOut));
 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk11", 0, "ok");
				}
				tWarn_10Process(globalMap);



/**
 * [tJava_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_5_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_10", false);
		start_Hash.put("tWarn_10", System.currentTimeMillis());
		
	
	currentComponent="tWarn_10";

	
		int tos_count_tWarn_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_10{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_10 = new StringBuilder();
            log4jParamters_tWarn_10.append("Parameters:");
                    log4jParamters_tWarn_10.append("MESSAGE" + " = " + "\"311|\" + ((String)globalMap.get(\"COUNT_ERROR_MSG\"))");
                log4jParamters_tWarn_10.append(" | ");
                    log4jParamters_tWarn_10.append("CODE" + " = " + "999");
                log4jParamters_tWarn_10.append(" | ");
                    log4jParamters_tWarn_10.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + (log4jParamters_tWarn_10) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_10().limitLog4jByte();

 



/**
 * [tWarn_10 begin ] stop
 */
	
	/**
	 * [tWarn_10 main ] start
	 */

	

	
	
	currentComponent="tWarn_10";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_10", "", Thread.currentThread().getId() + "", "ERROR","","311|" + ((String)globalMap.get("COUNT_ERROR_MSG")),"", "");
            log.error("tWarn_10 - "  + ("Message: ")  + ("311|" + ((String)globalMap.get("COUNT_ERROR_MSG")))  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_10", 5, "311|" + ((String)globalMap.get("COUNT_ERROR_MSG")), 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_10_WARN_MESSAGES", "311|" + ((String)globalMap.get("COUNT_ERROR_MSG"))); 
globalMap.put("tWarn_10_WARN_PRIORITY", 5);
globalMap.put("tWarn_10_WARN_CODE", 999);


 


	tos_count_tWarn_10++;

/**
 * [tWarn_10 main ] stop
 */
	
	/**
	 * [tWarn_10 end ] start
	 */

	

	
	
	currentComponent="tWarn_10";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + ("Done.") );

ok_Hash.put("tWarn_10", true);
end_Hash.put("tWarn_10", System.currentTimeMillis());




/**
 * [tWarn_10 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_10 finally ] start
	 */

	

	
	
	currentComponent="tWarn_10";

	

 



/**
 * [tWarn_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_10_SUBPROCESS_STATE", 1);
	}
	

public void tJava_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_4", false);
		start_Hash.put("tJava_4", System.currentTimeMillis());
		
	
	currentComponent="tJava_4";

	
		int tos_count_tJava_4 = 0;
		
    	class BytesLimit65535_tJava_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_4().limitLog4jByte();


//***************** Application id  from Standard Output
String cntOut=((String)globalMap.get("tSystem_2_OUTPUT"));

globalMap.put("CNT_APPLICATION_ID", cntOut.indexOf("|application_") > 0 ? 
(cntOut.substring(cntOut.indexOf("|application_") + 1,cntOut.length())) : "We are not getting application id from Logs,Please check the logs once ");

globalMap.put("INIT_LD", "D".equals((String)globalMap.get("row1.INGTN_TYP")) ? "N":"Y");
globalMap.put("LOAD_STATUS", "C");


 



/**
 * [tJava_4 begin ] stop
 */
	
	/**
	 * [tJava_4 main ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 


	tos_count_tJava_4++;

/**
 * [tJava_4 main ] stop
 */
	
	/**
	 * [tJava_4 end ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 

ok_Hash.put("tJava_4", true);
end_Hash.put("tJava_4", System.currentTimeMillis());




/**
 * [tJava_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_4 finally ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_8", false);
		start_Hash.put("tJava_8", System.currentTimeMillis());
		
	
	currentComponent="tJava_8";

	
		int tos_count_tJava_8 = 0;
		
    	class BytesLimit65535_tJava_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_8().limitLog4jByte();


//***************** Application id  from Standard Output
String mergOut = (Relational.ISNULL(globalMap.get("tSystem_1_OUTPUT")) ? "" :((String)globalMap.get("tSystem_1_OUTPUT")));

globalMap.put("MERGE_APPLICATION_ID", mergOut.indexOf("|application_") > 0 ? ( mergOut.substring(mergOut.indexOf("|application_") + 1, mergOut.length())) : "We are not getting application id from Logs,Please check the logs once");

globalMap.put("MERGE_ERROR_MSG", "Error : " + ((mergOut.indexOf("ERROR ApplicationMaster:") >= 0 &&  mergOut.indexOf("ERROR ApplicationMaster:") < mergOut.indexOf("|application")) ? mergOut.substring(mergOut.indexOf("ERROR ApplicationMaster:"), mergOut.indexOf("|application")) : mergOut));
 



/**
 * [tJava_8 begin ] stop
 */
	
	/**
	 * [tJava_8 main ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 


	tos_count_tJava_8++;

/**
 * [tJava_8 main ] stop
 */
	
	/**
	 * [tJava_8 end ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 

ok_Hash.put("tJava_8", true);
end_Hash.put("tJava_8", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk10", 0, "ok");
				}
				tWarn_9Process(globalMap);



/**
 * [tJava_8 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_8 finally ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 



/**
 * [tJava_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_8_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_9", false);
		start_Hash.put("tWarn_9", System.currentTimeMillis());
		
	
	currentComponent="tWarn_9";

	
		int tos_count_tWarn_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_9 = new StringBuilder();
            log4jParamters_tWarn_9.append("Parameters:");
                    log4jParamters_tWarn_9.append("MESSAGE" + " = " + "\"310|\" + ((String)globalMap.get(\"MERGE_ERROR_MSG\"))");
                log4jParamters_tWarn_9.append(" | ");
                    log4jParamters_tWarn_9.append("CODE" + " = " + "999");
                log4jParamters_tWarn_9.append(" | ");
                    log4jParamters_tWarn_9.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + (log4jParamters_tWarn_9) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_9().limitLog4jByte();

 



/**
 * [tWarn_9 begin ] stop
 */
	
	/**
	 * [tWarn_9 main ] start
	 */

	

	
	
	currentComponent="tWarn_9";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_9", "", Thread.currentThread().getId() + "", "ERROR","","310|" + ((String)globalMap.get("MERGE_ERROR_MSG")),"", "");
            log.error("tWarn_9 - "  + ("Message: ")  + ("310|" + ((String)globalMap.get("MERGE_ERROR_MSG")))  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_9", 5, "310|" + ((String)globalMap.get("MERGE_ERROR_MSG")), 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_9_WARN_MESSAGES", "310|" + ((String)globalMap.get("MERGE_ERROR_MSG"))); 
globalMap.put("tWarn_9_WARN_PRIORITY", 5);
globalMap.put("tWarn_9_WARN_CODE", 999);


 


	tos_count_tWarn_9++;

/**
 * [tWarn_9 main ] stop
 */
	
	/**
	 * [tWarn_9 end ] start
	 */

	

	
	
	currentComponent="tWarn_9";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + ("Done.") );

ok_Hash.put("tWarn_9", true);
end_Hash.put("tWarn_9", System.currentTimeMillis());




/**
 * [tWarn_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_9 finally ] start
	 */

	

	
	
	currentComponent="tWarn_9";

	

 



/**
 * [tWarn_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_9_SUBPROCESS_STATE", 1);
	}
	


public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String FILE_NM;

				public String getFILE_NM () {
					return this.FILE_NM;
				}
				
			    public String CURRENT_RUN_ID;

				public String getCURRENT_RUN_ID () {
					return this.CURRENT_RUN_ID;
				}
				
			    public String INGTN_TYP;

				public String getINGTN_TYP () {
					return this.INGTN_TYP;
				}
				
			    public String STATUS;

				public String getSTATUS () {
					return this.STATUS;
				}
				
			    public String JOB_INSTANCE_ID;

				public String getJOB_INSTANCE_ID () {
					return this.JOB_INSTANCE_ID;
				}
				
			    public String RUN_ID;

				public String getRUN_ID () {
					return this.RUN_ID;
				}
				
			    public String ADLS_FILE_LOCTN;

				public String getADLS_FILE_LOCTN () {
					return this.ADLS_FILE_LOCTN;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.FILE_NM = readString(dis);
					
					this.CURRENT_RUN_ID = readString(dis);
					
					this.INGTN_TYP = readString(dis);
					
					this.STATUS = readString(dis);
					
					this.JOB_INSTANCE_ID = readString(dis);
					
					this.RUN_ID = readString(dis);
					
					this.ADLS_FILE_LOCTN = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.FILE_NM,dos);
					
					// String
				
						writeString(this.CURRENT_RUN_ID,dos);
					
					// String
				
						writeString(this.INGTN_TYP,dos);
					
					// String
				
						writeString(this.STATUS,dos);
					
					// String
				
						writeString(this.JOB_INSTANCE_ID,dos);
					
					// String
				
						writeString(this.RUN_ID,dos);
					
					// String
				
						writeString(this.ADLS_FILE_LOCTN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("FILE_NM="+FILE_NM);
		sb.append(",CURRENT_RUN_ID="+CURRENT_RUN_ID);
		sb.append(",INGTN_TYP="+INGTN_TYP);
		sb.append(",STATUS="+STATUS);
		sb.append(",JOB_INSTANCE_ID="+JOB_INSTANCE_ID);
		sb.append(",RUN_ID="+RUN_ID);
		sb.append(",ADLS_FILE_LOCTN="+ADLS_FILE_LOCTN);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(FILE_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FILE_NM);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENT_RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENT_RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(INGTN_TYP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INGTN_TYP);
            			}
            		
        			sb.append("|");
        		
        				if(STATUS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(STATUS);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_INSTANCE_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_INSTANCE_ID);
            			}
            		
        			sb.append("|");
        		
        				if(RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(ADLS_FILE_LOCTN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ADLS_FILE_LOCTN);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();




	
	/**
	 * [tHashOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_1", false);
		start_Hash.put("tHashOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_1 = 0;
		
    	class BytesLimit65535_tHashOutput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_1().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct> tHashFile_tHashOutput_1 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_1.getKeyMap().put("tHashFile_Jb_Merge_ADLS_Staging_Child_" +pid + "_tHashOutput_1", "tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid + "_tHashOutput_2");
        int nb_line_tHashOutput_1 = 0;
 



/**
 * [tHashOutput_1 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_3", false);
		start_Hash.put("tFixedFlowInput_3", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_3";

	
		int tos_count_tFixedFlowInput_3 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_3().limitLog4jByte();

	    for (int i_tFixedFlowInput_3 = 0 ; i_tFixedFlowInput_3 < 1 ; i_tFixedFlowInput_3++) {
	                	            	
    	            		row4.FILE_NM = ((String)globalMap.get("row1.FILE_NM"));
    	            	        	            	
    	            		row4.CURRENT_RUN_ID = ((String)globalMap.get("row1.CURRENT_RUN_ID"));
    	            	        	            	
    	            		row4.INGTN_TYP = ((String)globalMap.get("row1.INGTN_TYP"));
    	            	        	            	
    	            		row4.STATUS = "C";
    	            	        	            	
    	            		row4.JOB_INSTANCE_ID = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row4.RUN_ID = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row4.ADLS_FILE_LOCTN = ((String)globalMap.get("row1.ADLS_FILE_LOCTN"));
    	            	
 



/**
 * [tFixedFlowInput_3 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_3 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

 


	tos_count_tFixedFlowInput_3++;

/**
 * [tFixedFlowInput_3 main ] stop
 */

	
	/**
	 * [tHashOutput_1 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	

			//row4
			//row4


			
				if(execStat){
					runStat.updateStatOnConnection("row4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_1 == null){
			tHashFile_tHashOutput_1 = mf_tHashOutput_1.getAdvancedMemoryHashFile("tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid +"_tHashOutput_2");
			mf_tHashOutput_1.getResourceMap().put("tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid +"_tHashOutput_1", tHashFile_tHashOutput_1);
		}
		row10Struct oneRow_tHashOutput_1 = new row10Struct();
			oneRow_tHashOutput_1.FILE_NM = row4.FILE_NM;
			oneRow_tHashOutput_1.CURRENT_RUN_ID = row4.CURRENT_RUN_ID;
			oneRow_tHashOutput_1.INGTN_TYP = row4.INGTN_TYP;
			oneRow_tHashOutput_1.STATUS = row4.STATUS;
			oneRow_tHashOutput_1.JOB_INSTANCE_ID = row4.JOB_INSTANCE_ID;
			oneRow_tHashOutput_1.RUN_ID = row4.RUN_ID;
			oneRow_tHashOutput_1.ADLS_FILE_LOCTN = row4.ADLS_FILE_LOCTN;
        tHashFile_tHashOutput_1.put(oneRow_tHashOutput_1);
        nb_line_tHashOutput_1 ++;	
 


	tos_count_tHashOutput_1++;

/**
 * [tHashOutput_1 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_3 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

        }
        globalMap.put("tFixedFlowInput_3_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_3", true);
end_Hash.put("tFixedFlowInput_3", System.currentTimeMillis());




/**
 * [tFixedFlowInput_3 end ] stop
 */

	
	/**
	 * [tHashOutput_1 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	
globalMap.put("tHashOutput_1_NB_LINE", nb_line_tHashOutput_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row4"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_1", true);
end_Hash.put("tHashOutput_1", System.currentTimeMillis());




/**
 * [tHashOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_3 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

 



/**
 * [tFixedFlowInput_3 finally ] stop
 */

	
	/**
	 * [tHashOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	

 



/**
 * [tHashOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_8", false);
		start_Hash.put("tWarn_8", System.currentTimeMillis());
		
	
	currentComponent="tWarn_8";

	
		int tos_count_tWarn_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_8 = new StringBuilder();
            log4jParamters_tWarn_8.append("Parameters:");
                    log4jParamters_tWarn_8.append("MESSAGE" + " = " + "\"308|Initial copy into staging for multi-merge failed\"");
                log4jParamters_tWarn_8.append(" | ");
                    log4jParamters_tWarn_8.append("CODE" + " = " + "999");
                log4jParamters_tWarn_8.append(" | ");
                    log4jParamters_tWarn_8.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + (log4jParamters_tWarn_8) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_8().limitLog4jByte();

 



/**
 * [tWarn_8 begin ] stop
 */
	
	/**
	 * [tWarn_8 main ] start
	 */

	

	
	
	currentComponent="tWarn_8";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_8", "", Thread.currentThread().getId() + "", "ERROR","","308|Initial copy into staging for multi-merge failed","", "");
            log.error("tWarn_8 - "  + ("Message: ")  + ("308|Initial copy into staging for multi-merge failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_8", 5, "308|Initial copy into staging for multi-merge failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_8_WARN_MESSAGES", "308|Initial copy into staging for multi-merge failed"); 
globalMap.put("tWarn_8_WARN_PRIORITY", 5);
globalMap.put("tWarn_8_WARN_CODE", 999);


 


	tos_count_tWarn_8++;

/**
 * [tWarn_8 main ] stop
 */
	
	/**
	 * [tWarn_8 end ] start
	 */

	

	
	
	currentComponent="tWarn_8";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + ("Done.") );

ok_Hash.put("tWarn_8", true);
end_Hash.put("tWarn_8", System.currentTimeMillis());




/**
 * [tWarn_8 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_8 finally ] start
	 */

	

	
	
	currentComponent="tWarn_8";

	

 



/**
 * [tWarn_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_8_SUBPROCESS_STATE", 1);
	}
	

public void tSystem_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSystem_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tSystem_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSystem_3", false);
		start_Hash.put("tSystem_3", System.currentTimeMillis());
		
	
	currentComponent="tSystem_3";

	
		int tos_count_tSystem_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSystem_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tSystem_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSystem_3 = new StringBuilder();
            log4jParamters_tSystem_3.append("Parameters:");
                    log4jParamters_tSystem_3.append("ROOTDIR" + " = " + "false");
                log4jParamters_tSystem_3.append(" | ");
                    log4jParamters_tSystem_3.append("USE_SINGLE_COMMAND" + " = " + "false");
                log4jParamters_tSystem_3.append(" | ");
                    log4jParamters_tSystem_3.append("USE_ARRAY_COMMAND" + " = " + "true");
                log4jParamters_tSystem_3.append(" | ");
                    log4jParamters_tSystem_3.append("ARRAY_COMMAND" + " = " + "[{VALUE="+("\"/bin/bash\"")+"}, {VALUE="+("\"-c\"")+"}, {VALUE="+("((String)globalMap.get(\"RAW_COPY_SCRIPT\"))")+"}]");
                log4jParamters_tSystem_3.append(" | ");
                    log4jParamters_tSystem_3.append("OUTPUT" + " = " + "OUTPUT_TO_CONSOLE_AND_RETRIVE_OUTPUT");
                log4jParamters_tSystem_3.append(" | ");
                    log4jParamters_tSystem_3.append("ERROROUTPUT" + " = " + "OUTPUT_TO_CONSOLE_AND_RETRIVE_OUTPUT");
                log4jParamters_tSystem_3.append(" | ");
                    log4jParamters_tSystem_3.append("PARAMS" + " = " + "[]");
                log4jParamters_tSystem_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSystem_3 - "  + (log4jParamters_tSystem_3) );
    		}
    	}
    	
        new BytesLimit65535_tSystem_3().limitLog4jByte();

		
			String commandArrayForLog_tSystem_3 ="";
		
		String[] command_tSystem_3 = new String[3];
		
			command_tSystem_3[0] = "/bin/bash";
			
				if(("/bin/bash").contains(" "))
					commandArrayForLog_tSystem_3+="\"" + "/bin/bash" + "\" ";
				else
					commandArrayForLog_tSystem_3+="/bin/bash" + " ";
			
			command_tSystem_3[1] = "-c";
			
				if(("-c").contains(" "))
					commandArrayForLog_tSystem_3+="\"" + "-c" + "\" ";
				else
					commandArrayForLog_tSystem_3+="-c" + " ";
			
			command_tSystem_3[2] = ((String)globalMap.get("RAW_COPY_SCRIPT"));
			
				if((((String)globalMap.get("RAW_COPY_SCRIPT"))).contains(" "))
					commandArrayForLog_tSystem_3+="\"" + ((String)globalMap.get("RAW_COPY_SCRIPT")) + "\" ";
				else
					commandArrayForLog_tSystem_3+=((String)globalMap.get("RAW_COPY_SCRIPT")) + " ";
			
Runtime runtime_tSystem_3 = Runtime.getRuntime();

String[] env_tSystem_3= null;
java.util.Map<String,String> envMap_tSystem_3= System.getenv();
java.util.Map<String,String> envMapClone_tSystem_3= new java.util.HashMap();
envMapClone_tSystem_3.putAll(envMap_tSystem_3);

	log.info("tSystem_3 - Setting the parameters.");
final Process ps_tSystem_3 = runtime_tSystem_3.exec(command_tSystem_3 ,env_tSystem_3);

globalMap.remove("tSystem_3_OUTPUT");
globalMap.remove("tSystem_3_ERROROUTPUT");

Thread normal_tSystem_3 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_3.getInputStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
		
			log.debug("tSystem_3 - Sending the standard output to both the console and the global variable 'tSystem_3_OUTPUT'.");
		
        System.out.println(line);
        
        	if (globalMap.get("tSystem_3_OUTPUT") != null) {
						globalMap.put("tSystem_3_OUTPUT", (String)globalMap.get("tSystem_3_OUTPUT")+"\n"+line);
					} else {
						globalMap.put("tSystem_3_OUTPUT", line);
					}
					
    	 
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_3 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
	log.info("tSystem_3 - Executing the command.");
	log.info("tSystem_3 - Command to execute: '" + commandArrayForLog_tSystem_3  + "'.");
normal_tSystem_3.start();
	log.info("tSystem_3 - The command has been executed successfully.");

Thread error_tSystem_3 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_3.getErrorStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
		
			log.debug("tSystem_3 - Sending the error output to both the console and the global variable 'tSystem_3_ERROROUTPUT'.");
		
        System.err.println(line);
        
        	if (globalMap.get("tSystem_3_ERROROUTPUT") != null) {
						globalMap.put("tSystem_3_ERROROUTPUT", (String)globalMap.get("tSystem_3_ERROROUTPUT")+"\n"+line);
					} else {
						globalMap.put("tSystem_3_ERROROUTPUT", line);
					}
					
    	 
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_3 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
error_tSystem_3.start();
if(ps_tSystem_3.getOutputStream()!=null){
    ps_tSystem_3.getOutputStream().close();
}
ps_tSystem_3.waitFor();
normal_tSystem_3.join(10000);
error_tSystem_3.join(10000);


 



/**
 * [tSystem_3 begin ] stop
 */
	
	/**
	 * [tSystem_3 main ] start
	 */

	

	
	
	currentComponent="tSystem_3";

	


 


	tos_count_tSystem_3++;

/**
 * [tSystem_3 main ] stop
 */
	
	/**
	 * [tSystem_3 end ] start
	 */

	

	
	
	currentComponent="tSystem_3";

	

globalMap.put("tSystem_3_EXIT_VALUE", ps_tSystem_3.exitValue());

 
                if(log.isDebugEnabled())
            log.debug("tSystem_3 - "  + ("Done.") );

ok_Hash.put("tSystem_3", true);
end_Hash.put("tSystem_3", System.currentTimeMillis());




/**
 * [tSystem_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSystem_3 finally ] start
	 */

	

	
	
	currentComponent="tSystem_3";

	

 



/**
 * [tSystem_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSystem_3_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_6", false);
		start_Hash.put("tWarn_6", System.currentTimeMillis());
		
	
	currentComponent="tWarn_6";

	
		int tos_count_tWarn_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_6 = new StringBuilder();
            log4jParamters_tWarn_6.append("Parameters:");
                    log4jParamters_tWarn_6.append("MESSAGE" + " = " + "\"306|Insert into ingestion tracking table failed\"");
                log4jParamters_tWarn_6.append(" | ");
                    log4jParamters_tWarn_6.append("CODE" + " = " + "999");
                log4jParamters_tWarn_6.append(" | ");
                    log4jParamters_tWarn_6.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + (log4jParamters_tWarn_6) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_6().limitLog4jByte();

 



/**
 * [tWarn_6 begin ] stop
 */
	
	/**
	 * [tWarn_6 main ] start
	 */

	

	
	
	currentComponent="tWarn_6";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_6", "", Thread.currentThread().getId() + "", "ERROR","","306|Insert into ingestion tracking table failed","", "");
            log.error("tWarn_6 - "  + ("Message: ")  + ("306|Insert into ingestion tracking table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_6", 5, "306|Insert into ingestion tracking table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_6_WARN_MESSAGES", "306|Insert into ingestion tracking table failed"); 
globalMap.put("tWarn_6_WARN_PRIORITY", 5);
globalMap.put("tWarn_6_WARN_CODE", 999);


 


	tos_count_tWarn_6++;

/**
 * [tWarn_6 main ] stop
 */
	
	/**
	 * [tWarn_6 end ] start
	 */

	

	
	
	currentComponent="tWarn_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + ("Done.") );

ok_Hash.put("tWarn_6", true);
end_Hash.put("tWarn_6", System.currentTimeMillis());




/**
 * [tWarn_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_6 finally ] start
	 */

	

	
	
	currentComponent="tWarn_6";

	

 



/**
 * [tWarn_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_6_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_11", false);
		start_Hash.put("tWarn_11", System.currentTimeMillis());
		
	
	currentComponent="tWarn_11";

	
		int tos_count_tWarn_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_11{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_11 = new StringBuilder();
            log4jParamters_tWarn_11.append("Parameters:");
                    log4jParamters_tWarn_11.append("MESSAGE" + " = " + "\"305|Getting record counts failed\"");
                log4jParamters_tWarn_11.append(" | ");
                    log4jParamters_tWarn_11.append("CODE" + " = " + "999");
                log4jParamters_tWarn_11.append(" | ");
                    log4jParamters_tWarn_11.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + (log4jParamters_tWarn_11) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_11().limitLog4jByte();

 



/**
 * [tWarn_11 begin ] stop
 */
	
	/**
	 * [tWarn_11 main ] start
	 */

	

	
	
	currentComponent="tWarn_11";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_11", "", Thread.currentThread().getId() + "", "ERROR","","305|Getting record counts failed","", "");
            log.error("tWarn_11 - "  + ("Message: ")  + ("305|Getting record counts failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_11", 5, "305|Getting record counts failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_11_WARN_MESSAGES", "305|Getting record counts failed"); 
globalMap.put("tWarn_11_WARN_PRIORITY", 5);
globalMap.put("tWarn_11_WARN_CODE", 999);


 


	tos_count_tWarn_11++;

/**
 * [tWarn_11 main ] stop
 */
	
	/**
	 * [tWarn_11 end ] start
	 */

	

	
	
	currentComponent="tWarn_11";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + ("Done.") );

ok_Hash.put("tWarn_11", true);
end_Hash.put("tWarn_11", System.currentTimeMillis());




/**
 * [tWarn_11 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_11 finally ] start
	 */

	

	
	
	currentComponent="tWarn_11";

	

 



/**
 * [tWarn_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_11_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_4", false);
		start_Hash.put("tWarn_4", System.currentTimeMillis());
		
	
	currentComponent="tWarn_4";

	
		int tos_count_tWarn_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_4 = new StringBuilder();
            log4jParamters_tWarn_4.append("Parameters:");
                    log4jParamters_tWarn_4.append("MESSAGE" + " = " + "\"304|Looping through objects failed\"");
                log4jParamters_tWarn_4.append(" | ");
                    log4jParamters_tWarn_4.append("CODE" + " = " + "999");
                log4jParamters_tWarn_4.append(" | ");
                    log4jParamters_tWarn_4.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + (log4jParamters_tWarn_4) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_4().limitLog4jByte();

 



/**
 * [tWarn_4 begin ] stop
 */
	
	/**
	 * [tWarn_4 main ] start
	 */

	

	
	
	currentComponent="tWarn_4";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_4", "", Thread.currentThread().getId() + "", "ERROR","","304|Looping through objects failed","", "");
            log.error("tWarn_4 - "  + ("Message: ")  + ("304|Looping through objects failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_4", 5, "304|Looping through objects failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_4_WARN_MESSAGES", "304|Looping through objects failed"); 
globalMap.put("tWarn_4_WARN_PRIORITY", 5);
globalMap.put("tWarn_4_WARN_CODE", 999);


 


	tos_count_tWarn_4++;

/**
 * [tWarn_4 main ] stop
 */
	
	/**
	 * [tWarn_4 end ] start
	 */

	

	
	
	currentComponent="tWarn_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Done.") );

ok_Hash.put("tWarn_4", true);
end_Hash.put("tWarn_4", System.currentTimeMillis());




/**
 * [tWarn_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_4 finally ] start
	 */

	

	
	
	currentComponent="tWarn_4";

	

 



/**
 * [tWarn_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_4_SUBPROCESS_STATE", 1);
	}
	


public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public Integer MERGE_COMPLETED_COUNT;

				public Integer getMERGE_COMPLETED_COUNT () {
					return this.MERGE_COMPLETED_COUNT;
				}
				


	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
						this.MERGE_COMPLETED_COUNT = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Integer
				
						writeInteger(this.MERGE_COMPLETED_COUNT,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("MERGE_COMPLETED_COUNT="+String.valueOf(MERGE_COMPLETED_COUNT));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(MERGE_COMPLETED_COUNT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MERGE_COMPLETED_COUNT);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row14Struct row14 = new row14Struct();




	
	/**
	 * [tSetGlobalVar_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_5", false);
		start_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row14" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_5 = new StringBuilder();
            log4jParamters_tSetGlobalVar_5.append("Parameters:");
                    log4jParamters_tSetGlobalVar_5.append("VARIABLES" + " = " + "[{VALUE="+("row14.MERGE_COMPLETED_COUNT")+", KEY="+("\"MERGE_COMPLETED_COUNT\"")+"}]");
                log4jParamters_tSetGlobalVar_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + (log4jParamters_tSetGlobalVar_5) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_5().limitLog4jByte();

 



/**
 * [tSetGlobalVar_5 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_2", false);
		start_Hash.put("tMSSqlInput_2", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_2";

	
		int tos_count_tMSSqlInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_2 = new StringBuilder();
            log4jParamters_tMSSqlInput_2.append("Parameters:");
                    log4jParamters_tMSSqlInput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("QUERY" + " = " + "\"  SELECT COUNT(1) AS MERGE_COMPLETED_COUNT  FROM DBO.T_INGTN_TRCKNG_DTL  WHERE SRC_SYS_ID = '\" + context.src_sys_id + \"'  	AND SUB_SYS_ID = '\" + context.sub_sys_id + \"'  	AND OBJECT_ID = '\" + context.object_id + \"'  	AND STG_ID = '2'  	AND STATUS IN ('C', 'F')  	AND CRTD_DTTM > CAST('\" + ((String)globalMap.get(\"MERGE_SCHEDULED_DATE\")) + \"' AS DATETIME2)  \"");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_2.append(" | ");
                    log4jParamters_tMSSqlInput_2.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("MERGE_COMPLETED_COUNT")+"}]");
                log4jParamters_tMSSqlInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_2 - "  + (log4jParamters_tMSSqlInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_2().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_2 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_2 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_2  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_2, talendToDBArray_tMSSqlInput_2); 
		    int nb_line_tMSSqlInput_2 = 0;
		    java.sql.Connection conn_tMSSqlInput_2 = null;
		        conn_tMSSqlInput_2 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_2 != null) {
					if(conn_tMSSqlInput_2.getMetaData() != null) {
						
						log.debug("tMSSqlInput_2 - Uses an existing connection with username '" + conn_tMSSqlInput_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_2.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_2 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_2 = conn_tMSSqlInput_2.createStatement();

		    String dbquery_tMSSqlInput_2 = "\nSELECT COUNT(1) AS MERGE_COMPLETED_COUNT\nFROM DBO.T_INGTN_TRCKNG_DTL\nWHERE SRC_SYS_ID = '" + context.src_sys_id + "'\n	AND SUB_SYS_ID = '" + context.sub_sys_id + "'\n	AND OBJECT_ID = '" + context.object_id + "'\n	AND STG_ID = '2'\n	AND STATUS IN ('C', 'F')\n	AND CRTD_DTTM > CAST('" + ((String)globalMap.get("MERGE_SCHEDULED_DATE")) + "' AS DATETIME2)\n";
			
                log.debug("tMSSqlInput_2 - Executing the query: '"+dbquery_tMSSqlInput_2+"'.");
			

                       globalMap.put("tMSSqlInput_2_QUERY",dbquery_tMSSqlInput_2);

		    java.sql.ResultSet rs_tMSSqlInput_2 = null;
		try{
		    rs_tMSSqlInput_2 = stmt_tMSSqlInput_2.executeQuery(dbquery_tMSSqlInput_2);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_2 = rs_tMSSqlInput_2.getMetaData();
		    int colQtyInRs_tMSSqlInput_2 = rsmd_tMSSqlInput_2.getColumnCount();

		    String tmpContent_tMSSqlInput_2 = null;
		    
		    
		    	log.debug("tMSSqlInput_2 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_2.next()) {
		        nb_line_tMSSqlInput_2++;
		        
							if(colQtyInRs_tMSSqlInput_2 < 1) {
								row14.MERGE_COMPLETED_COUNT = null;
							} else {
		                          
            if(rs_tMSSqlInput_2.getObject(1) != null) {
                row14.MERGE_COMPLETED_COUNT = rs_tMSSqlInput_2.getInt(1);
            } else {
                    row14.MERGE_COMPLETED_COUNT = null;
            }
		                    }
					
						log.debug("tMSSqlInput_2 - Retrieving the record " + nb_line_tMSSqlInput_2 + ".");
					





 



/**
 * [tMSSqlInput_2 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_2 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_2";

	

 


	tos_count_tMSSqlInput_2++;

/**
 * [tMSSqlInput_2 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			//row14
			//row14


			
				if(execStat){
					runStat.updateStatOnConnection("row14"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row14 - " + (row14==null? "": row14.toLogString()));
    			}
    		

globalMap.put("MERGE_COMPLETED_COUNT", row14.MERGE_COMPLETED_COUNT);

 


	tos_count_tSetGlobalVar_5++;

/**
 * [tSetGlobalVar_5 main ] stop
 */



	
	/**
	 * [tMSSqlInput_2 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_2";

	

	}
}finally{
	stmt_tMSSqlInput_2.close();

}
globalMap.put("tMSSqlInput_2_NB_LINE",nb_line_tMSSqlInput_2);
	    		log.debug("tMSSqlInput_2 - Retrieved records count: "+nb_line_tMSSqlInput_2 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_2 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_2", true);
end_Hash.put("tMSSqlInput_2", System.currentTimeMillis());




/**
 * [tMSSqlInput_2 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row14"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_5 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_5", true);
end_Hash.put("tSetGlobalVar_5", System.currentTimeMillis());




/**
 * [tSetGlobalVar_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_2 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_2";

	

 



/**
 * [tMSSqlInput_2 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_5 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_5";

	

 



/**
 * [tSetGlobalVar_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tLogCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row13Struct row13 = new row13Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tSetGlobalVar_4 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row13" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
            log4jParamters_tFlowToIterate_1.append("Parameters:");
                    log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + (log4jParamters_tFlowToIterate_1) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_1().limitLog4jByte();

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tLogCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogCatcher_1", false);
		start_Hash.put("tLogCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tLogCatcher_1";

	
		int tos_count_tLogCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogCatcher_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogCatcher_1 = new StringBuilder();
            log4jParamters_tLogCatcher_1.append("Parameters:");
                    log4jParamters_tLogCatcher_1.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TDIE" + " = " + "false");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TACTIONFAILURE" + " = " + "false");
                log4jParamters_tLogCatcher_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + (log4jParamters_tLogCatcher_1) );
    		}
    	}
    	
        new BytesLimit65535_tLogCatcher_1().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1.getMessages()) {
		row13.type = lcm.getType();
		row13.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row13.priority = lcm.getPriority();
		row13.message = lcm.getMessage();
		row13.code = lcm.getCode();
		
		row13.moment = java.util.Calendar.getInstance().getTime();
	
    	row13.pid = pid;
		row13.root_pid = rootPid;
		row13.father_pid = fatherPid;
	
    	row13.project = projectName;
    	row13.job = jobName;
    	row13.context = contextStr;
    		
 



/**
 * [tLogCatcher_1 begin ] stop
 */
	
	/**
	 * [tLogCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 


	tos_count_tLogCatcher_1++;

/**
 * [tLogCatcher_1 main ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

			//row13
			//row13


			
				if(execStat){
					runStat.updateStatOnConnection("row13"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.moment, value=")  + (row13.moment)  + (".") );            
            globalMap.put("row13.moment", row13.moment);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.pid, value=")  + (row13.pid)  + (".") );            
            globalMap.put("row13.pid", row13.pid);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.root_pid, value=")  + (row13.root_pid)  + (".") );            
            globalMap.put("row13.root_pid", row13.root_pid);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.father_pid, value=")  + (row13.father_pid)  + (".") );            
            globalMap.put("row13.father_pid", row13.father_pid);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.project, value=")  + (row13.project)  + (".") );            
            globalMap.put("row13.project", row13.project);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.job, value=")  + (row13.job)  + (".") );            
            globalMap.put("row13.job", row13.job);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.context, value=")  + (row13.context)  + (".") );            
            globalMap.put("row13.context", row13.context);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.priority, value=")  + (row13.priority)  + (".") );            
            globalMap.put("row13.priority", row13.priority);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.type, value=")  + (row13.type)  + (".") );            
            globalMap.put("row13.type", row13.type);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.origin, value=")  + (row13.origin)  + (".") );            
            globalMap.put("row13.origin", row13.origin);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.message, value=")  + (row13.message)  + (".") );            
            globalMap.put("row13.message", row13.message);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.code, value=")  + (row13.code)  + (".") );            
            globalMap.put("row13.code", row13.code);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_1)  + (".") );
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	NB_ITERATE_tSetGlobalVar_4++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk13", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tSetGlobalVar_4);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tSetGlobalVar_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_4", false);
		start_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_4";

	
		int tos_count_tSetGlobalVar_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_4 = new StringBuilder();
            log4jParamters_tSetGlobalVar_4.append("Parameters:");
                    log4jParamters_tSetGlobalVar_4.append("VARIABLES" + " = " + "[{VALUE="+("\"F\"")+", KEY="+("\"LOAD_STATUS\"")+"}]");
                log4jParamters_tSetGlobalVar_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + (log4jParamters_tSetGlobalVar_4) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_4().limitLog4jByte();

 



/**
 * [tSetGlobalVar_4 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_4 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

globalMap.put("LOAD_STATUS", "F");

 


	tos_count_tSetGlobalVar_4++;

/**
 * [tSetGlobalVar_4 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_4 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_4", true);
end_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tFixedFlowInput_6Process(globalMap);



/**
 * [tSetGlobalVar_4 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tSetGlobalVar_4);
						}				
					







	
	/**
	 * [tLogCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Done.") );

ok_Hash.put("tLogCatcher_1", true);
end_Hash.put("tLogCatcher_1", System.currentTimeMillis());




/**
 * [tLogCatcher_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row13"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLogCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

 



/**
 * [tSetGlobalVar_4 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String stg_id;

				public String getStg_id () {
					return this.stg_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public String batch_id;

				public String getBatch_id () {
					return this.batch_id;
				}
				
			    public String Jb_instnce_id;

				public String getJb_instnce_id () {
					return this.Jb_instnce_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public String info_dtl;

				public String getInfo_dtl () {
					return this.info_dtl;
				}
				
			    public java.util.Date run_dttm;

				public java.util.Date getRun_dttm () {
					return this.run_dttm;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.stg_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
					this.batch_id = readString(dis);
					
					this.Jb_instnce_id = readString(dis);
					
					this.err_msg = readString(dis);
					
					this.info_dtl = readString(dis);
					
					this.run_dttm = readDate(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_by = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.updt_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.stg_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// String
				
						writeString(this.batch_id,dos);
					
					// String
				
						writeString(this.Jb_instnce_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// String
				
						writeString(this.info_dtl,dos);
					
					// java.util.Date
				
						writeDate(this.run_dttm,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("stg_id="+stg_id);
		sb.append(",run_id="+run_id);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",batch_id="+batch_id);
		sb.append(",Jb_instnce_id="+Jb_instnce_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",info_dtl="+info_dtl);
		sb.append(",run_dttm="+String.valueOf(run_dttm));
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_by="+updt_by);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(stg_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stg_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(batch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(batch_id);
            			}
            		
        			sb.append("|");
        		
        				if(Jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(info_dtl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(info_dtl);
            			}
            		
        			sb.append("|");
        		
        				if(run_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();




	
	/**
	 * [tMSSqlOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_6", false);
		start_Hash.put("tMSSqlOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row12" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_6 = new StringBuilder();
            log4jParamters_tMSSqlOutput_6.append("Parameters:");
                    log4jParamters_tMSSqlOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("TABLE" + " = " + "\"t_error_log_dtl\"");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + (log4jParamters_tMSSqlOutput_6) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_6().limitLog4jByte();



int nb_line_tMSSqlOutput_6 = 0;
int nb_line_update_tMSSqlOutput_6 = 0;
int nb_line_inserted_tMSSqlOutput_6 = 0;
int nb_line_deleted_tMSSqlOutput_6 = 0;
int nb_line_rejected_tMSSqlOutput_6 = 0;

int deletedCount_tMSSqlOutput_6=0;
int updatedCount_tMSSqlOutput_6=0;
int insertedCount_tMSSqlOutput_6=0;
int rejectedCount_tMSSqlOutput_6=0;
String dbschema_tMSSqlOutput_6 = null;
String tableName_tMSSqlOutput_6 = null;
boolean whetherReject_tMSSqlOutput_6 = false;

java.util.Calendar calendar_tMSSqlOutput_6 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_6 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_6 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_6 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_6;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_6 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_6 = null;
String dbUser_tMSSqlOutput_6 = null;
	dbschema_tMSSqlOutput_6 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_6 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_6.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_6.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_6.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_6 == null || dbschema_tMSSqlOutput_6.trim().length() == 0) {
    tableName_tMSSqlOutput_6 = "t_error_log_dtl";
} else {
    tableName_tMSSqlOutput_6 = dbschema_tMSSqlOutput_6 + "].[" + "t_error_log_dtl";
}
	int count_tMSSqlOutput_6=0;

        String insert_tMSSqlOutput_6 = "INSERT INTO [" + tableName_tMSSqlOutput_6 + "] ([stg_id],[run_id],[src_sys_id],[sub_sys_id],[object_id],[object_nm],[batch_id],[Jb_instnce_id],[err_msg],[info_dtl],[run_dttm],[crtd_by],[updt_by],[crtd_dttm],[updt_dttm]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_6 = conn_tMSSqlOutput_6.prepareStatement(insert_tMSSqlOutput_6);

 	boolean isShareIdentity_tMSSqlOutput_6 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_6 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_6", false);
		start_Hash.put("tFixedFlowInput_6", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_6";

	
		int tos_count_tFixedFlowInput_6 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_6().limitLog4jByte();

	    for (int i_tFixedFlowInput_6 = 0 ; i_tFixedFlowInput_6 < 1 ; i_tFixedFlowInput_6++) {
	                	            	
    	            		row12.stg_id = Relational.ISNULL(globalMap.get("STG_ID")) ? "1" : ((String)globalMap.get("STG_ID"));
    	            	        	            	
    	            		row12.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row12.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row12.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row12.object_id = ((String)globalMap.get("OBJECT_ID"));
    	            	        	            	
    	            		row12.object_nm = ((String)globalMap.get("OBJECT_NM"));
    	            	        	            	
    	            		row12.batch_id = ((String)globalMap.get("BATCH_ID"));
    	            	        	            	
    	            		row12.Jb_instnce_id = null;        	            	
    	            	        	            	
    	            		row12.err_msg = ((String)globalMap.get("row13.message"));
    	            	        	            	
    	            		row12.info_dtl = ((String)globalMap.get("INFO_DTL"));
    	            	        	            	
    	            		row12.run_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row12.crtd_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row12.updt_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row12.crtd_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row12.updt_dttm = TalendDate.getCurrentDate();
    	            	
 



/**
 * [tFixedFlowInput_6 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_6 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_6";

	

 


	tos_count_tFixedFlowInput_6++;

/**
 * [tFixedFlowInput_6 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_6 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_6";

	

			//row12
			//row12


			
				if(execStat){
					runStat.updateStatOnConnection("row12"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_6 = false;
                    if(row12.stg_id == null) {
pstmt_tMSSqlOutput_6.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(1, row12.stg_id);
}

                    if(row12.run_id == null) {
pstmt_tMSSqlOutput_6.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(2, row12.run_id);
}

                    if(row12.src_sys_id == null) {
pstmt_tMSSqlOutput_6.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(3, row12.src_sys_id);
}

                    if(row12.sub_sys_id == null) {
pstmt_tMSSqlOutput_6.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(4, row12.sub_sys_id);
}

                    if(row12.object_id == null) {
pstmt_tMSSqlOutput_6.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(5, row12.object_id);
}

                    if(row12.object_nm == null) {
pstmt_tMSSqlOutput_6.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(6, row12.object_nm);
}

                    if(row12.batch_id == null) {
pstmt_tMSSqlOutput_6.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(7, row12.batch_id);
}

                    if(row12.Jb_instnce_id == null) {
pstmt_tMSSqlOutput_6.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(8, row12.Jb_instnce_id);
}

                    if(row12.err_msg == null) {
pstmt_tMSSqlOutput_6.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(9, row12.err_msg);
}

                    if(row12.info_dtl == null) {
pstmt_tMSSqlOutput_6.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(10, row12.info_dtl);
}

                    if(row12.run_dttm != null) {
pstmt_tMSSqlOutput_6.setTimestamp(11, new java.sql.Timestamp(row12.run_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_6.setNull(11, java.sql.Types.DATE);
}

                    if(row12.crtd_by == null) {
pstmt_tMSSqlOutput_6.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(12, row12.crtd_by);
}

                    if(row12.updt_by == null) {
pstmt_tMSSqlOutput_6.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(13, row12.updt_by);
}

                    if(row12.crtd_dttm != null) {
pstmt_tMSSqlOutput_6.setTimestamp(14, new java.sql.Timestamp(row12.crtd_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_6.setNull(14, java.sql.Types.DATE);
}

                    if(row12.updt_dttm != null) {
pstmt_tMSSqlOutput_6.setTimestamp(15, new java.sql.Timestamp(row12.updt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_6.setNull(15, java.sql.Types.DATE);
}


            try {
                nb_line_tMSSqlOutput_6++;
                insertedCount_tMSSqlOutput_6 = insertedCount_tMSSqlOutput_6 + pstmt_tMSSqlOutput_6.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_6)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_6 = true;
                    throw(e);
            }
            if(!whetherReject_tMSSqlOutput_6) {
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_6{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_6) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_6: pstmt_tMSSqlOutput_6.executeBatch()) {
							if(countEach_tMSSqlOutput_6 == -2 || countEach_tMSSqlOutput_6 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_6;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_6) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_6: pstmt_tMSSqlOutput_6.executeBatch()) {
							if(countEach_tMSSqlOutput_6 == -2 || countEach_tMSSqlOutput_6 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_6;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_6++;

/**
 * [tMSSqlOutput_6 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_6 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_6";

	

        }
        globalMap.put("tFixedFlowInput_6_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_6", true);
end_Hash.put("tFixedFlowInput_6", System.currentTimeMillis());




/**
 * [tFixedFlowInput_6 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_6 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_6";

	



        if(pstmt_tMSSqlOutput_6 != null) {
			
				pstmt_tMSSqlOutput_6.close();
			
        }


	nb_line_deleted_tMSSqlOutput_6=nb_line_deleted_tMSSqlOutput_6+ deletedCount_tMSSqlOutput_6;
	nb_line_update_tMSSqlOutput_6=nb_line_update_tMSSqlOutput_6 + updatedCount_tMSSqlOutput_6;
	nb_line_inserted_tMSSqlOutput_6=nb_line_inserted_tMSSqlOutput_6 + insertedCount_tMSSqlOutput_6;
	nb_line_rejected_tMSSqlOutput_6=nb_line_rejected_tMSSqlOutput_6 + rejectedCount_tMSSqlOutput_6;
	
        globalMap.put("tMSSqlOutput_6_NB_LINE",nb_line_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_6);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_6)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row12"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_6", true);
end_Hash.put("tMSSqlOutput_6", System.currentTimeMillis());

   			if (Numeric.sequence("SEQ_ERROR_MESSAGE", 1, 1) == 1) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "true");
					}
				
    			tFixedFlowInput_7Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "false");
					}   	 
   				}



/**
 * [tMSSqlOutput_6 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk13", 0, "ok");
								} 
							
							tFixedFlowInput_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_6 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_6";

	

 



/**
 * [tFixedFlowInput_6 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_6";

	



	

 



/**
 * [tMSSqlOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_6_SUBPROCESS_STATE", 1);
	}
	


public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String FILE_NM;

				public String getFILE_NM () {
					return this.FILE_NM;
				}
				
			    public String CURRENT_RUN_ID;

				public String getCURRENT_RUN_ID () {
					return this.CURRENT_RUN_ID;
				}
				
			    public String INGTN_TYP;

				public String getINGTN_TYP () {
					return this.INGTN_TYP;
				}
				
			    public String STATUS;

				public String getSTATUS () {
					return this.STATUS;
				}
				
			    public String JOB_INSTANCE_ID;

				public String getJOB_INSTANCE_ID () {
					return this.JOB_INSTANCE_ID;
				}
				
			    public String RUN_ID;

				public String getRUN_ID () {
					return this.RUN_ID;
				}
				
			    public String ADLS_FILE_LOCTN;

				public String getADLS_FILE_LOCTN () {
					return this.ADLS_FILE_LOCTN;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.FILE_NM = readString(dis);
					
					this.CURRENT_RUN_ID = readString(dis);
					
					this.INGTN_TYP = readString(dis);
					
					this.STATUS = readString(dis);
					
					this.JOB_INSTANCE_ID = readString(dis);
					
					this.RUN_ID = readString(dis);
					
					this.ADLS_FILE_LOCTN = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.FILE_NM,dos);
					
					// String
				
						writeString(this.CURRENT_RUN_ID,dos);
					
					// String
				
						writeString(this.INGTN_TYP,dos);
					
					// String
				
						writeString(this.STATUS,dos);
					
					// String
				
						writeString(this.JOB_INSTANCE_ID,dos);
					
					// String
				
						writeString(this.RUN_ID,dos);
					
					// String
				
						writeString(this.ADLS_FILE_LOCTN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("FILE_NM="+FILE_NM);
		sb.append(",CURRENT_RUN_ID="+CURRENT_RUN_ID);
		sb.append(",INGTN_TYP="+INGTN_TYP);
		sb.append(",STATUS="+STATUS);
		sb.append(",JOB_INSTANCE_ID="+JOB_INSTANCE_ID);
		sb.append(",RUN_ID="+RUN_ID);
		sb.append(",ADLS_FILE_LOCTN="+ADLS_FILE_LOCTN);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(FILE_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FILE_NM);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENT_RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENT_RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(INGTN_TYP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INGTN_TYP);
            			}
            		
        			sb.append("|");
        		
        				if(STATUS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(STATUS);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_INSTANCE_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_INSTANCE_ID);
            			}
            		
        			sb.append("|");
        		
        				if(RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(ADLS_FILE_LOCTN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ADLS_FILE_LOCTN);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row15Struct row15 = new row15Struct();




	
	/**
	 * [tHashOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_3", false);
		start_Hash.put("tHashOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row15" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_3 = 0;
		
    	class BytesLimit65535_tHashOutput_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_3().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_3=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct> tHashFile_tHashOutput_3 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_3.getKeyMap().put("tHashFile_Jb_Merge_ADLS_Staging_Child_" +pid + "_tHashOutput_3", "tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid + "_tHashOutput_2");
        int nb_line_tHashOutput_3 = 0;
 



/**
 * [tHashOutput_3 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_7", false);
		start_Hash.put("tFixedFlowInput_7", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_7";

	
		int tos_count_tFixedFlowInput_7 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_7().limitLog4jByte();

	    for (int i_tFixedFlowInput_7 = 0 ; i_tFixedFlowInput_7 < 1 ; i_tFixedFlowInput_7++) {
	                	            	
    	            		row15.FILE_NM = ((String)globalMap.get("row1.FILE_NM"));
    	            	        	            	
    	            		row15.CURRENT_RUN_ID = ((String)globalMap.get("row1.CURRENT_RUN_ID"));
    	            	        	            	
    	            		row15.INGTN_TYP = ((String)globalMap.get("row1.INGTN_TYP"));
    	            	        	            	
    	            		row15.STATUS = "F";
    	            	        	            	
    	            		row15.JOB_INSTANCE_ID = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row15.RUN_ID = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row15.ADLS_FILE_LOCTN = ((String)globalMap.get("row1.ADLS_FILE_LOCTN"));
    	            	
 



/**
 * [tFixedFlowInput_7 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_7 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_7";

	

 


	tos_count_tFixedFlowInput_7++;

/**
 * [tFixedFlowInput_7 main ] stop
 */

	
	/**
	 * [tHashOutput_3 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";

	

			//row15
			//row15


			
				if(execStat){
					runStat.updateStatOnConnection("row15"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row15 - " + (row15==null? "": row15.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_3 == null){
			tHashFile_tHashOutput_3 = mf_tHashOutput_3.getAdvancedMemoryHashFile("tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid +"_tHashOutput_2");
			mf_tHashOutput_3.getResourceMap().put("tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid +"_tHashOutput_3", tHashFile_tHashOutput_3);
		}
		row10Struct oneRow_tHashOutput_3 = new row10Struct();
			oneRow_tHashOutput_3.FILE_NM = row15.FILE_NM;
			oneRow_tHashOutput_3.CURRENT_RUN_ID = row15.CURRENT_RUN_ID;
			oneRow_tHashOutput_3.INGTN_TYP = row15.INGTN_TYP;
			oneRow_tHashOutput_3.STATUS = row15.STATUS;
			oneRow_tHashOutput_3.JOB_INSTANCE_ID = row15.JOB_INSTANCE_ID;
			oneRow_tHashOutput_3.RUN_ID = row15.RUN_ID;
			oneRow_tHashOutput_3.ADLS_FILE_LOCTN = row15.ADLS_FILE_LOCTN;
        tHashFile_tHashOutput_3.put(oneRow_tHashOutput_3);
        nb_line_tHashOutput_3 ++;	
 


	tos_count_tHashOutput_3++;

/**
 * [tHashOutput_3 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_7 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_7";

	

        }
        globalMap.put("tFixedFlowInput_7_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_7", true);
end_Hash.put("tFixedFlowInput_7", System.currentTimeMillis());




/**
 * [tFixedFlowInput_7 end ] stop
 */

	
	/**
	 * [tHashOutput_3 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";

	
globalMap.put("tHashOutput_3_NB_LINE", nb_line_tHashOutput_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row15"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_3", true);
end_Hash.put("tHashOutput_3", System.currentTimeMillis());




/**
 * [tHashOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_7 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_7";

	

 



/**
 * [tFixedFlowInput_7 finally ] stop
 */

	
	/**
	 * [tHashOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";

	

 



/**
 * [tHashOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_7_SUBPROCESS_STATE", 1);
	}
	


public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String Submtn_mode_id;

				public String getSubmtn_mode_id () {
					return this.Submtn_mode_id;
				}
				
			    public String batch_id;

				public String getBatch_id () {
					return this.batch_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String stg_id;

				public String getStg_id () {
					return this.stg_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String Status;

				public String getStatus () {
					return this.Status;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				
			    public java.util.Date cdc_strt_dttm;

				public java.util.Date getCdc_strt_dttm () {
					return this.cdc_strt_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				
			    public String info_dtl;

				public String getInfo_dtl () {
					return this.info_dtl;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.Submtn_mode_id = readString(dis);
					
					this.batch_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.stg_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.Status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_by = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.updt_dttm = readDate(dis);
					
					this.cdc_strt_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
					this.info_dtl = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Submtn_mode_id,dos);
					
					// String
				
						writeString(this.batch_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.stg_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.Status,dos);
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_strt_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
					// String
				
						writeString(this.info_dtl,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Submtn_mode_id="+Submtn_mode_id);
		sb.append(",batch_id="+batch_id);
		sb.append(",run_id="+run_id);
		sb.append(",stg_id="+stg_id);
		sb.append(",object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",Status="+Status);
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_by="+updt_by);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
		sb.append(",cdc_strt_dttm="+String.valueOf(cdc_strt_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
		sb.append(",info_dtl="+info_dtl);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Submtn_mode_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Submtn_mode_id);
            			}
            		
        			sb.append("|");
        		
        				if(batch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(batch_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(stg_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stg_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(Status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Status);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_strt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_strt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(info_dtl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(info_dtl);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row16Struct row16 = new row16Struct();




	
	/**
	 * [tMSSqlOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_3", false);
		start_Hash.put("tMSSqlOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row16" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_3 = new StringBuilder();
            log4jParamters_tMSSqlOutput_3.append("Parameters:");
                    log4jParamters_tMSSqlOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("TABLE" + " = " + "\"t_load_status_dtl\"");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + (log4jParamters_tMSSqlOutput_3) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_3().limitLog4jByte();



int nb_line_tMSSqlOutput_3 = 0;
int nb_line_update_tMSSqlOutput_3 = 0;
int nb_line_inserted_tMSSqlOutput_3 = 0;
int nb_line_deleted_tMSSqlOutput_3 = 0;
int nb_line_rejected_tMSSqlOutput_3 = 0;

int deletedCount_tMSSqlOutput_3=0;
int updatedCount_tMSSqlOutput_3=0;
int insertedCount_tMSSqlOutput_3=0;
int rejectedCount_tMSSqlOutput_3=0;
String dbschema_tMSSqlOutput_3 = null;
String tableName_tMSSqlOutput_3 = null;
boolean whetherReject_tMSSqlOutput_3 = false;

java.util.Calendar calendar_tMSSqlOutput_3 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_3;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_3 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_3 = null;
String dbUser_tMSSqlOutput_3 = null;
	dbschema_tMSSqlOutput_3 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_3 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_3.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_3.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_3 == null || dbschema_tMSSqlOutput_3.trim().length() == 0) {
    tableName_tMSSqlOutput_3 = "t_load_status_dtl";
} else {
    tableName_tMSSqlOutput_3 = dbschema_tMSSqlOutput_3 + "].[" + "t_load_status_dtl";
}
	int count_tMSSqlOutput_3=0;

        String insert_tMSSqlOutput_3 = "INSERT INTO [" + tableName_tMSSqlOutput_3 + "] ([Submtn_mode_id],[batch_id],[run_id],[stg_id],[object_id],[object_nm],[src_sys_id],[sub_sys_id],[Status],[ld_record_cnt],[src_record_cnt],[rjct_record_cnt],[err_record_cnt],[crtd_by],[updt_by],[crtd_dttm],[updt_dttm],[cdc_strt_dttm],[cdc_end_dttm],[info_dtl]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_3 = conn_tMSSqlOutput_3.prepareStatement(insert_tMSSqlOutput_3);

 	boolean isShareIdentity_tMSSqlOutput_3 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_3 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_8", false);
		start_Hash.put("tFixedFlowInput_8", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_8";

	
		int tos_count_tFixedFlowInput_8 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_8().limitLog4jByte();

	    for (int i_tFixedFlowInput_8 = 0 ; i_tFixedFlowInput_8 < 1 ; i_tFixedFlowInput_8++) {
	                	            	
    	            		row16.Submtn_mode_id = ((String)globalMap.get("SUBMTN_MODE_ID"));
    	            	        	            	
    	            		row16.batch_id = ((String)globalMap.get("BATCH_ID"));
    	            	        	            	
    	            		row16.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row16.stg_id = Relational.ISNULL(globalMap.get("STG_ID")) ? "1" : ((String)globalMap.get("STG_ID"));
    	            	        	            	
    	            		row16.object_id = ((String)globalMap.get("OBJECT_ID"));
    	            	        	            	
    	            		row16.object_nm = ((String)globalMap.get("OBJECT_NM"));
    	            	        	            	
    	            		row16.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row16.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row16.Status = "F";
    	            	        	            	
    	            		row16.ld_record_cnt = null;
    	            	        	            	
    	            		row16.src_record_cnt = null;
    	            	        	            	
    	            		row16.rjct_record_cnt = null;
    	            	        	            	
    	            		row16.err_record_cnt = null;
    	            	        	            	
    	            		row16.crtd_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row16.updt_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row16.crtd_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row16.updt_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row16.cdc_strt_dttm = null;
    	            	        	            	
    	            		row16.cdc_end_dttm = null;
    	            	        	            	
    	            		row16.info_dtl = ((String)globalMap.get("INFO_DTL"));
    	            	
 



/**
 * [tFixedFlowInput_8 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_8 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_8";

	

 


	tos_count_tFixedFlowInput_8++;

/**
 * [tFixedFlowInput_8 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_3 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_3";

	

			//row16
			//row16


			
				if(execStat){
					runStat.updateStatOnConnection("row16"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row16 - " + (row16==null? "": row16.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_3 = false;
                    if(row16.Submtn_mode_id == null) {
pstmt_tMSSqlOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(1, row16.Submtn_mode_id);
}

                    if(row16.batch_id == null) {
pstmt_tMSSqlOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(2, row16.batch_id);
}

                    if(row16.run_id == null) {
pstmt_tMSSqlOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(3, row16.run_id);
}

                    if(row16.stg_id == null) {
pstmt_tMSSqlOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(4, row16.stg_id);
}

                    if(row16.object_id == null) {
pstmt_tMSSqlOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(5, row16.object_id);
}

                    if(row16.object_nm == null) {
pstmt_tMSSqlOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(6, row16.object_nm);
}

                    if(row16.src_sys_id == null) {
pstmt_tMSSqlOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(7, row16.src_sys_id);
}

                    if(row16.sub_sys_id == null) {
pstmt_tMSSqlOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(8, row16.sub_sys_id);
}

                    if(row16.Status == null) {
pstmt_tMSSqlOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(9, row16.Status);
}

                    if(row16.ld_record_cnt == null) {
pstmt_tMSSqlOutput_3.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_3.setLong(10, row16.ld_record_cnt);
}

                    if(row16.src_record_cnt == null) {
pstmt_tMSSqlOutput_3.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_3.setLong(11, row16.src_record_cnt);
}

                    if(row16.rjct_record_cnt == null) {
pstmt_tMSSqlOutput_3.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_3.setInt(12, row16.rjct_record_cnt);
}

                    if(row16.err_record_cnt == null) {
pstmt_tMSSqlOutput_3.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_3.setInt(13, row16.err_record_cnt);
}

                    if(row16.crtd_by == null) {
pstmt_tMSSqlOutput_3.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(14, row16.crtd_by);
}

                    if(row16.updt_by == null) {
pstmt_tMSSqlOutput_3.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(15, row16.updt_by);
}

                    if(row16.crtd_dttm != null) {
pstmt_tMSSqlOutput_3.setTimestamp(16, new java.sql.Timestamp(row16.crtd_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_3.setNull(16, java.sql.Types.DATE);
}

                    if(row16.updt_dttm != null) {
pstmt_tMSSqlOutput_3.setTimestamp(17, new java.sql.Timestamp(row16.updt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_3.setNull(17, java.sql.Types.DATE);
}

                    if(row16.cdc_strt_dttm != null) {
pstmt_tMSSqlOutput_3.setTimestamp(18, new java.sql.Timestamp(row16.cdc_strt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_3.setNull(18, java.sql.Types.DATE);
}

                    if(row16.cdc_end_dttm != null) {
pstmt_tMSSqlOutput_3.setTimestamp(19, new java.sql.Timestamp(row16.cdc_end_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_3.setNull(19, java.sql.Types.DATE);
}

                    if(row16.info_dtl == null) {
pstmt_tMSSqlOutput_3.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(20, row16.info_dtl);
}


            try {
                nb_line_tMSSqlOutput_3++;
                insertedCount_tMSSqlOutput_3 = insertedCount_tMSSqlOutput_3 + pstmt_tMSSqlOutput_3.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_3)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_3 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_3{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_3) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_3: pstmt_tMSSqlOutput_3.executeBatch()) {
							if(countEach_tMSSqlOutput_3 == -2 || countEach_tMSSqlOutput_3 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_3;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_3) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_3: pstmt_tMSSqlOutput_3.executeBatch()) {
							if(countEach_tMSSqlOutput_3 == -2 || countEach_tMSSqlOutput_3 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_3;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_3++;

/**
 * [tMSSqlOutput_3 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_8 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_8";

	

        }
        globalMap.put("tFixedFlowInput_8_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_8", true);
end_Hash.put("tFixedFlowInput_8", System.currentTimeMillis());




/**
 * [tFixedFlowInput_8 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_3 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_3";

	



        if(pstmt_tMSSqlOutput_3 != null) {
			
				pstmt_tMSSqlOutput_3.close();
			
        }


	nb_line_deleted_tMSSqlOutput_3=nb_line_deleted_tMSSqlOutput_3+ deletedCount_tMSSqlOutput_3;
	nb_line_update_tMSSqlOutput_3=nb_line_update_tMSSqlOutput_3 + updatedCount_tMSSqlOutput_3;
	nb_line_inserted_tMSSqlOutput_3=nb_line_inserted_tMSSqlOutput_3 + insertedCount_tMSSqlOutput_3;
	nb_line_rejected_tMSSqlOutput_3=nb_line_rejected_tMSSqlOutput_3 + rejectedCount_tMSSqlOutput_3;
	
        globalMap.put("tMSSqlOutput_3_NB_LINE",nb_line_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_3);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_3)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row16"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_3", true);
end_Hash.put("tMSSqlOutput_3", System.currentTimeMillis());




/**
 * [tMSSqlOutput_3 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk19", 0, "ok");
								} 
							
							tDie_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_8 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_8";

	

 



/**
 * [tFixedFlowInput_8 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_3";

	



	

 



/**
 * [tMSSqlOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_8_SUBPROCESS_STATE", 1);
	}
	

public void tDie_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDie_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDie_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDie_1", false);
		start_Hash.put("tDie_1", System.currentTimeMillis());
		
	
	currentComponent="tDie_1";

	
		int tos_count_tDie_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tDie_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tDie_1 = new StringBuilder();
            log4jParamters_tDie_1.append("Parameters:");
                    log4jParamters_tDie_1.append("MESSAGE" + " = " + "\"the end is near\"");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("CODE" + " = " + "4");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("PRIORITY" + " = " + "5");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("EXIT_JVM" + " = " + "false");
                log4jParamters_tDie_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + (log4jParamters_tDie_1) );
    		}
    	}
    	
        new BytesLimit65535_tDie_1().limitLog4jByte();

 



/**
 * [tDie_1 begin ] stop
 */
	
	/**
	 * [tDie_1 main ] start
	 */

	

	
	
	currentComponent="tDie_1";

	


	globalMap.put("tDie_1_DIE_PRIORITY", 5);
	System.err.println("the end is near");
	
		log.error("tDie_1 - The die message: "+"the end is near");
	
	globalMap.put("tDie_1_DIE_MESSAGE", "the end is near");
	globalMap.put("tDie_1_DIE_MESSAGES", "the end is near");
	currentComponent = "tDie_1";
	status = "failure";
        errorCode = new Integer(4);
        globalMap.put("tDie_1_DIE_CODE", errorCode);        
    
	if(true){	
	    throw new TDieException();
	}

 


	tos_count_tDie_1++;

/**
 * [tDie_1 main ] stop
 */
	
	/**
	 * [tDie_1 end ] start
	 */

	

	
	
	currentComponent="tDie_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + ("Done.") );

ok_Hash.put("tDie_1", true);
end_Hash.put("tDie_1", System.currentTimeMillis());




/**
 * [tDie_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDie_1 finally ] start
	 */

	

	
	
	currentComponent="tDie_1";

	

 



/**
 * [tDie_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDie_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";

	
		int tos_count_tPostjob_1 = 0;
		
    	class BytesLimit65535_tPostjob_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tPostjob_1().limitLog4jByte();

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk7", 0, "ok");
				}
				tHashInput_1Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	


public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public String FILE_NM;

				public String getFILE_NM () {
					return this.FILE_NM;
				}
				
			    public String CURRENT_RUN_ID;

				public String getCURRENT_RUN_ID () {
					return this.CURRENT_RUN_ID;
				}
				
			    public String INGTN_TYP;

				public String getINGTN_TYP () {
					return this.INGTN_TYP;
				}
				
			    public String STATUS;

				public String getSTATUS () {
					return this.STATUS;
				}
				
			    public String JOB_INSTANCE_ID;

				public String getJOB_INSTANCE_ID () {
					return this.JOB_INSTANCE_ID;
				}
				
			    public String RUN_ID;

				public String getRUN_ID () {
					return this.RUN_ID;
				}
				
			    public String ADLS_FILE_LOCTN;

				public String getADLS_FILE_LOCTN () {
					return this.ADLS_FILE_LOCTN;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.FILE_NM = readString(dis);
					
					this.CURRENT_RUN_ID = readString(dis);
					
					this.INGTN_TYP = readString(dis);
					
					this.STATUS = readString(dis);
					
					this.JOB_INSTANCE_ID = readString(dis);
					
					this.RUN_ID = readString(dis);
					
					this.ADLS_FILE_LOCTN = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.FILE_NM,dos);
					
					// String
				
						writeString(this.CURRENT_RUN_ID,dos);
					
					// String
				
						writeString(this.INGTN_TYP,dos);
					
					// String
				
						writeString(this.STATUS,dos);
					
					// String
				
						writeString(this.JOB_INSTANCE_ID,dos);
					
					// String
				
						writeString(this.RUN_ID,dos);
					
					// String
				
						writeString(this.ADLS_FILE_LOCTN,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("FILE_NM="+FILE_NM);
		sb.append(",CURRENT_RUN_ID="+CURRENT_RUN_ID);
		sb.append(",INGTN_TYP="+INGTN_TYP);
		sb.append(",STATUS="+STATUS);
		sb.append(",JOB_INSTANCE_ID="+JOB_INSTANCE_ID);
		sb.append(",RUN_ID="+RUN_ID);
		sb.append(",ADLS_FILE_LOCTN="+ADLS_FILE_LOCTN);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(FILE_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FILE_NM);
            			}
            		
        			sb.append("|");
        		
        				if(CURRENT_RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CURRENT_RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(INGTN_TYP == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INGTN_TYP);
            			}
            		
        			sb.append("|");
        		
        				if(STATUS == null){
        					sb.append("<null>");
        				}else{
            				sb.append(STATUS);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_INSTANCE_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_INSTANCE_ID);
            			}
            		
        			sb.append("|");
        		
        				if(RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(ADLS_FILE_LOCTN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ADLS_FILE_LOCTN);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tHashInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row9Struct row9 = new row9Struct();




	
	/**
	 * [tFlowToIterate_3 begin ] start
	 */

				
			int NB_ITERATE_tMSSqlRow_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_3", false);
		start_Hash.put("tFlowToIterate_3", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row9" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_3 = new StringBuilder();
            log4jParamters_tFlowToIterate_3.append("Parameters:");
                    log4jParamters_tFlowToIterate_3.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + (log4jParamters_tFlowToIterate_3) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_3().limitLog4jByte();

int nb_line_tFlowToIterate_3 = 0;
int counter_tFlowToIterate_3 = 0;

 



/**
 * [tFlowToIterate_3 begin ] stop
 */



	
	/**
	 * [tHashInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_1", false);
		start_Hash.put("tHashInput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_1";

	
		int tos_count_tHashInput_1 = 0;
		
    	class BytesLimit65535_tHashInput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashInput_1().limitLog4jByte();


int nb_line_tHashInput_1 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row10Struct> tHashFile_tHashInput_1 = mf_tHashInput_1.getAdvancedMemoryHashFile("tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid +"_tHashOutput_2");
if(tHashFile_tHashInput_1==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row10Struct> iterator_tHashInput_1 = tHashFile_tHashInput_1.iterator();
while (iterator_tHashInput_1.hasNext()) {
    row10Struct next_tHashInput_1 = iterator_tHashInput_1.next();

	row9.FILE_NM = next_tHashInput_1.FILE_NM;
	row9.CURRENT_RUN_ID = next_tHashInput_1.CURRENT_RUN_ID;
	row9.INGTN_TYP = next_tHashInput_1.INGTN_TYP;
	row9.STATUS = next_tHashInput_1.STATUS;
	row9.JOB_INSTANCE_ID = next_tHashInput_1.JOB_INSTANCE_ID;
	row9.RUN_ID = next_tHashInput_1.RUN_ID;
	row9.ADLS_FILE_LOCTN = next_tHashInput_1.ADLS_FILE_LOCTN;
 



/**
 * [tHashInput_1 begin ] stop
 */
	
	/**
	 * [tHashInput_1 main ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	

 


	tos_count_tHashInput_1++;

/**
 * [tHashInput_1 main ] stop
 */

	
	/**
	 * [tFlowToIterate_3 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

			//row9
			//row9


			
				if(execStat){
					runStat.updateStatOnConnection("row9"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row9.FILE_NM, value=")  + (row9.FILE_NM)  + (".") );            
            globalMap.put("row9.FILE_NM", row9.FILE_NM);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row9.CURRENT_RUN_ID, value=")  + (row9.CURRENT_RUN_ID)  + (".") );            
            globalMap.put("row9.CURRENT_RUN_ID", row9.CURRENT_RUN_ID);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row9.INGTN_TYP, value=")  + (row9.INGTN_TYP)  + (".") );            
            globalMap.put("row9.INGTN_TYP", row9.INGTN_TYP);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row9.STATUS, value=")  + (row9.STATUS)  + (".") );            
            globalMap.put("row9.STATUS", row9.STATUS);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row9.JOB_INSTANCE_ID, value=")  + (row9.JOB_INSTANCE_ID)  + (".") );            
            globalMap.put("row9.JOB_INSTANCE_ID", row9.JOB_INSTANCE_ID);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row9.RUN_ID, value=")  + (row9.RUN_ID)  + (".") );            
            globalMap.put("row9.RUN_ID", row9.RUN_ID);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row9.ADLS_FILE_LOCTN, value=")  + (row9.ADLS_FILE_LOCTN)  + (".") );            
            globalMap.put("row9.ADLS_FILE_LOCTN", row9.ADLS_FILE_LOCTN);
    	
 
	   nb_line_tFlowToIterate_3++;  
       counter_tFlowToIterate_3++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_3)  + (".") );
       globalMap.put("tFlowToIterate_3_CURRENT_ITERATION", counter_tFlowToIterate_3);
 


	tos_count_tFlowToIterate_3++;

/**
 * [tFlowToIterate_3 main ] stop
 */
	NB_ITERATE_tMSSqlRow_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row11", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobError14", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk8", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk4", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tMSSqlRow_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tMSSqlRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_1", false);
		start_Hash.put("tMSSqlRow_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_1";

	
		int tos_count_tMSSqlRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_1 = new StringBuilder();
            log4jParamters_tMSSqlRow_1.append("Parameters:");
                    log4jParamters_tMSSqlRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("QUERY" + " = " + "\"  UPDATE DBO.T_INGTN_TRCKNG_DTL  SET STATUS = '\" + (Relational.ISNULL(globalMap.get(\"row9.STATUS\")) ? (Relational.ISNULL(globalMap.get(\"LOAD_STATUS\")) ? \"F\" : ((String)globalMap.get(\"LOAD_STATUS\"))) : ((String)globalMap.get(\"row9.STATUS\"))) + \"'  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'  WHERE JB_INSTNCE_ID = '\" + ((String)globalMap.get(\"row9.JOB_INSTANCE_ID\"))+ \"'  	AND STATUS = 'P'  \"");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + (log4jParamters_tMSSqlRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_1().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_1 = null;
	String query_tMSSqlRow_1 = "";
	boolean whetherReject_tMSSqlRow_1 = false;
				conn_tMSSqlRow_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_1 != null) {
					if(conn_tMSSqlRow_1.getMetaData() != null) {
						
						log.debug("tMSSqlRow_1 - Uses an existing connection with username '" + conn_tMSSqlRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_1 = conn_tMSSqlRow_1.createStatement();
	

 



/**
 * [tMSSqlRow_1 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

	    		log.debug("tMSSqlRow_1 - Executing the query: '" + "  UPDATE DBO.T_INGTN_TRCKNG_DTL  SET STATUS = '" + (Relational.ISNULL(globalMap.get("row9.STATUS")) ? (Relational.ISNULL(globalMap.get("LOAD_STATUS")) ? "F" : ((String)globalMap.get("LOAD_STATUS"))) : ((String)globalMap.get("row9.STATUS"))) + "'  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'  WHERE JB_INSTNCE_ID = '" + ((String)globalMap.get("row9.JOB_INSTANCE_ID"))+ "'  	AND STATUS = 'P'  " + "'.");
			
query_tMSSqlRow_1 = "\nUPDATE DBO.T_INGTN_TRCKNG_DTL\nSET STATUS = '" + (Relational.ISNULL(globalMap.get("row9.STATUS")) ? (Relational.ISNULL(globalMap.get("LOAD_STATUS")) ? "F" : ((String)globalMap.get("LOAD_STATUS"))) : ((String)globalMap.get("row9.STATUS"))) + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE JB_INSTNCE_ID = '" + ((String)globalMap.get("row9.JOB_INSTANCE_ID"))+ "'\n	AND STATUS = 'P'\n";
whetherReject_tMSSqlRow_1 = false;
globalMap.put("tMSSqlRow_1_QUERY",query_tMSSqlRow_1);
try {
		stmt_tMSSqlRow_1.execute(query_tMSSqlRow_1);
		
	    		log.debug("tMSSqlRow_1 - Execute the query: '" + "\nUPDATE DBO.T_INGTN_TRCKNG_DTL\nSET STATUS = '" + (Relational.ISNULL(globalMap.get("row9.STATUS")) ? (Relational.ISNULL(globalMap.get("LOAD_STATUS")) ? "F" : ((String)globalMap.get("LOAD_STATUS"))) : ((String)globalMap.get("row9.STATUS"))) + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE JB_INSTNCE_ID = '" + ((String)globalMap.get("row9.JOB_INSTANCE_ID"))+ "'\n	AND STATUS = 'P'\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_1 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tMSSqlRow_1) {
		
	}
	

 


	tos_count_tMSSqlRow_1++;

/**
 * [tMSSqlRow_1 main ] stop
 */
	
	/**
	 * [tMSSqlRow_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

	
	stmt_tMSSqlRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_1", true);
end_Hash.put("tMSSqlRow_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tMSSqlRow_2Process(globalMap);
				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk14", 0, "ok");
				}
				tFixedFlowInput_5Process(globalMap);



/**
 * [tMSSqlRow_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tMSSqlRow_1);
						}				
					







	
	/**
	 * [tHashInput_1 end ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	
    

		
			nb_line_tHashInput_1++;
		}	
    		
    		mf_tHashInput_1.clearCache("tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid +"_tHashOutput_2");
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_Jb_Merge_ADLS_Staging_Child_" + pid +"_tHashOutput_2");
	


	globalMap.put("tHashInput_1_NB_LINE", nb_line_tHashInput_1);       

 

ok_Hash.put("tHashInput_1", true);
end_Hash.put("tHashInput_1", System.currentTimeMillis());




/**
 * [tHashInput_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_3 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

globalMap.put("tFlowToIterate_3_NB_LINE",nb_line_tFlowToIterate_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row9"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_3", true);
end_Hash.put("tFlowToIterate_3", System.currentTimeMillis());




/**
 * [tFlowToIterate_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tHashInput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	

 



/**
 * [tHashInput_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_3 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

 



/**
 * [tFlowToIterate_3 finally ] stop
 */

	
	/**
	 * [tMSSqlRow_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

 



/**
 * [tMSSqlRow_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tMSSqlRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_2", false);
		start_Hash.put("tMSSqlRow_2", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_2";

	
		int tos_count_tMSSqlRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_2 = new StringBuilder();
            log4jParamters_tMSSqlRow_2.append("Parameters:");
                    log4jParamters_tMSSqlRow_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("QUERY" + " = " + "\"  UPDATE DBO.T_FILE_TRCKR_DTL  SET IS_MERGED = '\" + (Relational.ISNULL(globalMap.get(\"row9.STATUS\")) ? (Relational.ISNULL(globalMap.get(\"LOAD_STATUS\")) ? \"F\" : ((String)globalMap.get(\"LOAD_STATUS\"))) : ((String)globalMap.get(\"row9.STATUS\"))) + \"'  	, MRG_JB_INSTNCE_ID = '\" + ((String)globalMap.get(\"row9.JOB_INSTANCE_ID\")) + \"'  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'       WHERE SRC_SYS_ID ='\" + ((String)globalMap.get(\"row1.SRC_SYS_ID\")) + \"'  	AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"row1.SUB_SYS_ID\")) + \"'  	AND OBJECT_ID = '\" + ((String)globalMap.get(\"row1.OBJECT_ID\")) + \"'  \" + (\"SINGLE_MERGE\".equals((String)globalMap.get(\"MERGE_TYPE\")) ? \"  	AND RUN_ID = '\" + ((String)globalMap.get(\"row9.CURRENT_RUN_ID\")) + \"'  	AND FILE_NM = '\" + ((String)globalMap.get(\"row9.FILE_NM\")) + \"'  \" : \"  	AND IS_MERGED = 'IP'  	AND ADLS_FILE_LOCTN LIKE '\" + (((String)globalMap.get(\"row9.ADLS_FILE_LOCTN\")).replaceAll(((String)globalMap.get(\"row9.FILE_NM\")), \"\")) + \"%'  \")");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_2 - "  + (log4jParamters_tMSSqlRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_2().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_2 = null;
	String query_tMSSqlRow_2 = "";
	boolean whetherReject_tMSSqlRow_2 = false;
				conn_tMSSqlRow_2 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_2 != null) {
					if(conn_tMSSqlRow_2.getMetaData() != null) {
						
						log.debug("tMSSqlRow_2 - Uses an existing connection with username '" + conn_tMSSqlRow_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_2.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_2 = conn_tMSSqlRow_2.createStatement();
	

 



/**
 * [tMSSqlRow_2 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_2 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_2";

	

	    		log.debug("tMSSqlRow_2 - Executing the query: '" + "  UPDATE DBO.T_FILE_TRCKR_DTL  SET IS_MERGED = '" + (Relational.ISNULL(globalMap.get("row9.STATUS")) ? (Relational.ISNULL(globalMap.get("LOAD_STATUS")) ? "F" : ((String)globalMap.get("LOAD_STATUS"))) : ((String)globalMap.get("row9.STATUS"))) + "'  	, MRG_JB_INSTNCE_ID = '" + ((String)globalMap.get("row9.JOB_INSTANCE_ID")) + "'  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'       WHERE SRC_SYS_ID ='" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'  	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'  	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'  " + ("SINGLE_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "  	AND RUN_ID = '" + ((String)globalMap.get("row9.CURRENT_RUN_ID")) + "'  	AND FILE_NM = '" + ((String)globalMap.get("row9.FILE_NM")) + "'  " : "  	AND IS_MERGED = 'IP'  	AND ADLS_FILE_LOCTN LIKE '" + (((String)globalMap.get("row9.ADLS_FILE_LOCTN")).replaceAll(((String)globalMap.get("row9.FILE_NM")), "")) + "%'  ") + "'.");
			
query_tMSSqlRow_2 = "\nUPDATE DBO.T_FILE_TRCKR_DTL\nSET IS_MERGED = '" + (Relational.ISNULL(globalMap.get("row9.STATUS")) ? (Relational.ISNULL(globalMap.get("LOAD_STATUS")) ? "F" : ((String)globalMap.get("LOAD_STATUS"))) : ((String)globalMap.get("row9.STATUS"))) + "'\n	, MRG_JB_INSTNCE_ID = '" + ((String)globalMap.get("row9.JOB_INSTANCE_ID")) + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\n     WHERE SRC_SYS_ID ='" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n" + ("SINGLE_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "\n	AND RUN_ID = '" + ((String)globalMap.get("row9.CURRENT_RUN_ID")) + "'\n	AND FILE_NM = '" + ((String)globalMap.get("row9.FILE_NM")) + "'\n" : "\n	AND IS_MERGED = 'IP'\n	AND ADLS_FILE_LOCTN LIKE '" + (((String)globalMap.get("row9.ADLS_FILE_LOCTN")).replaceAll(((String)globalMap.get("row9.FILE_NM")), "")) + "%'\n");
whetherReject_tMSSqlRow_2 = false;
globalMap.put("tMSSqlRow_2_QUERY",query_tMSSqlRow_2);
try {
		stmt_tMSSqlRow_2.execute(query_tMSSqlRow_2);
		
	    		log.debug("tMSSqlRow_2 - Execute the query: '" + "\nUPDATE DBO.T_FILE_TRCKR_DTL\nSET IS_MERGED = '" + (Relational.ISNULL(globalMap.get("row9.STATUS")) ? (Relational.ISNULL(globalMap.get("LOAD_STATUS")) ? "F" : ((String)globalMap.get("LOAD_STATUS"))) : ((String)globalMap.get("row9.STATUS"))) + "'\n	, MRG_JB_INSTNCE_ID = '" + ((String)globalMap.get("row9.JOB_INSTANCE_ID")) + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\n     WHERE SRC_SYS_ID ='" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n" + ("SINGLE_MERGE".equals((String)globalMap.get("MERGE_TYPE")) ? "\n	AND RUN_ID = '" + ((String)globalMap.get("row9.CURRENT_RUN_ID")) + "'\n	AND FILE_NM = '" + ((String)globalMap.get("row9.FILE_NM")) + "'\n" : "\n	AND IS_MERGED = 'IP'\n	AND ADLS_FILE_LOCTN LIKE '" + (((String)globalMap.get("row9.ADLS_FILE_LOCTN")).replaceAll(((String)globalMap.get("row9.FILE_NM")), "")) + "%'\n") + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_2 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tMSSqlRow_2) {
		
	}
	

 


	tos_count_tMSSqlRow_2++;

/**
 * [tMSSqlRow_2 main ] stop
 */
	
	/**
	 * [tMSSqlRow_2 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_2";

	

	
	stmt_tMSSqlRow_2.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_2 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_2", true);
end_Hash.put("tMSSqlRow_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tMSSqlRow_3Process(globalMap);



/**
 * [tMSSqlRow_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_2 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_2";

	

 



/**
 * [tMSSqlRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_2_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tMSSqlRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_3", false);
		start_Hash.put("tMSSqlRow_3", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_3";

	
		int tos_count_tMSSqlRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_3 = new StringBuilder();
            log4jParamters_tMSSqlRow_3.append("Parameters:");
                    log4jParamters_tMSSqlRow_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("QUERY" + " = " + "\"  UPDATE DBO.T_INIT_LOAD_DTL  SET INIT_LD = '\" + (Relational.ISNULL(globalMap.get(\"INIT_LD\")) ? ((String)globalMap.get(\"row1.INIT_LD\")) : ((String)globalMap.get(\"INIT_LD\"))) + \"'  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'  WHERE SRC_SYS_ID = '\" + ((String)globalMap.get(\"row1.SRC_SYS_ID\")) + \"'  	AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"row1.SUB_SYS_ID\")) + \"'  	AND OBJECT_ID = '\" + ((String)globalMap.get(\"row1.OBJECT_ID\")) + \"'  	AND STG_ID = '2'  \" ");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_3 - "  + (log4jParamters_tMSSqlRow_3) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_3().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_3 = null;
	String query_tMSSqlRow_3 = "";
	boolean whetherReject_tMSSqlRow_3 = false;
				conn_tMSSqlRow_3 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_3 != null) {
					if(conn_tMSSqlRow_3.getMetaData() != null) {
						
						log.debug("tMSSqlRow_3 - Uses an existing connection with username '" + conn_tMSSqlRow_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_3.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_3 = conn_tMSSqlRow_3.createStatement();
	

 



/**
 * [tMSSqlRow_3 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_3 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_3";

	

	    		log.debug("tMSSqlRow_3 - Executing the query: '" + "  UPDATE DBO.T_INIT_LOAD_DTL  SET INIT_LD = '" + (Relational.ISNULL(globalMap.get("INIT_LD")) ? ((String)globalMap.get("row1.INIT_LD")) : ((String)globalMap.get("INIT_LD"))) + "'  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'  WHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'  	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'  	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'  	AND STG_ID = '2'  "  + "'.");
			
query_tMSSqlRow_3 = "\nUPDATE DBO.T_INIT_LOAD_DTL\nSET INIT_LD = '" + (Relational.ISNULL(globalMap.get("INIT_LD")) ? ((String)globalMap.get("row1.INIT_LD")) : ((String)globalMap.get("INIT_LD"))) + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n	AND STG_ID = '2'\n" ;
whetherReject_tMSSqlRow_3 = false;
globalMap.put("tMSSqlRow_3_QUERY",query_tMSSqlRow_3);
try {
		stmt_tMSSqlRow_3.execute(query_tMSSqlRow_3);
		
	    		log.debug("tMSSqlRow_3 - Execute the query: '" + "\nUPDATE DBO.T_INIT_LOAD_DTL\nSET INIT_LD = '" + (Relational.ISNULL(globalMap.get("INIT_LD")) ? ((String)globalMap.get("row1.INIT_LD")) : ((String)globalMap.get("INIT_LD"))) + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE SRC_SYS_ID = '" + ((String)globalMap.get("row1.SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("row1.SUB_SYS_ID")) + "'\n	AND OBJECT_ID = '" + ((String)globalMap.get("row1.OBJECT_ID")) + "'\n	AND STG_ID = '2'\n"  + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_3 = true;
		
			throw(e);
			
	}
	

 


	tos_count_tMSSqlRow_3++;

/**
 * [tMSSqlRow_3 main ] stop
 */
	
	/**
	 * [tMSSqlRow_3 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_3";

	

	
	stmt_tMSSqlRow_3.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_3 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_3", true);
end_Hash.put("tMSSqlRow_3", System.currentTimeMillis());




/**
 * [tMSSqlRow_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_3 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_3";

	

 



/**
 * [tMSSqlRow_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_3_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String Jb_instnce_id;

				public String getJb_instnce_id () {
					return this.Jb_instnce_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Merge_ADLS_Staging_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Merge_ADLS_Staging_Child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_nm = readString(dis);
					
					this.run_id = readString(dis);
					
					this.Jb_instnce_id = readString(dis);
					
					this.object_id = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.Jb_instnce_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",run_id="+run_id);
		sb.append(",Jb_instnce_id="+Jb_instnce_id);
		sb.append(",object_id="+object_id);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(Jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tMSSqlOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_5", false);
		start_Hash.put("tMSSqlOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row11" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_5 = new StringBuilder();
            log4jParamters_tMSSqlOutput_5.append("Parameters:");
                    log4jParamters_tMSSqlOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("TABLE" + " = " + "\"statcatcher\"");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + (log4jParamters_tMSSqlOutput_5) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_5().limitLog4jByte();



int nb_line_tMSSqlOutput_5 = 0;
int nb_line_update_tMSSqlOutput_5 = 0;
int nb_line_inserted_tMSSqlOutput_5 = 0;
int nb_line_deleted_tMSSqlOutput_5 = 0;
int nb_line_rejected_tMSSqlOutput_5 = 0;

int deletedCount_tMSSqlOutput_5=0;
int updatedCount_tMSSqlOutput_5=0;
int insertedCount_tMSSqlOutput_5=0;
int rejectedCount_tMSSqlOutput_5=0;
String dbschema_tMSSqlOutput_5 = null;
String tableName_tMSSqlOutput_5 = null;
boolean whetherReject_tMSSqlOutput_5 = false;

java.util.Calendar calendar_tMSSqlOutput_5 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_5 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_5 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_5 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_5;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_5 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_5 = null;
String dbUser_tMSSqlOutput_5 = null;
	dbschema_tMSSqlOutput_5 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_5 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_5.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_5.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_5 == null || dbschema_tMSSqlOutput_5.trim().length() == 0) {
    tableName_tMSSqlOutput_5 = "statcatcher";
} else {
    tableName_tMSSqlOutput_5 = dbschema_tMSSqlOutput_5 + "].[" + "statcatcher";
}
	int count_tMSSqlOutput_5=0;

        String insert_tMSSqlOutput_5 = "INSERT INTO [" + tableName_tMSSqlOutput_5 + "] ([moment],[pid],[father_pid],[root_pid],[system_pid],[project],[job],[job_repository_id],[job_version],[context],[origin],[message_type],[message],[duration],[src_sys_id],[sub_sys_id],[object_nm],[run_id],[Jb_instnce_id],[object_id]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_5 = conn_tMSSqlOutput_5.prepareStatement(insert_tMSSqlOutput_5);

 	boolean isShareIdentity_tMSSqlOutput_5 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_5 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_5", false);
		start_Hash.put("tFixedFlowInput_5", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_5";

	
		int tos_count_tFixedFlowInput_5 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_5().limitLog4jByte();

	    for (int i_tFixedFlowInput_5 = 0 ; i_tFixedFlowInput_5 < 1 ; i_tFixedFlowInput_5++) {
	                	            	
    	            		row11.moment = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row11.pid = pid;
    	            	        	            	
    	            		row11.father_pid = context.root_pid;
    	            	        	            	
    	            		row11.root_pid = context.root_pid;
    	            	        	            	
    	            		row11.system_pid = null;
    	            	        	            	
    	            		row11.project = projectName;
    	            	        	            	
    	            		row11.job = jobName;
    	            	        	            	
    	            		row11.job_repository_id = null;
    	            	        	            	
    	            		row11.job_version = jobVersion;
    	            	        	            	
    	            		row11.context = contextStr ;
    	            	        	            	
    	            		row11.origin = null;
    	            	        	            	
    	            		row11.message_type = "end";
    	            	        	            	
    	            		row11.message = "F".equals(((String)globalMap.get("LOAD_STATUS"))) ? "failure" : "C".equals(((String)globalMap.get("LOAD_STATUS"))) ? "success" : null;
    	            	        	            	
    	            		row11.duration = ("C".equals(((String)globalMap.get("LOAD_STATUS"))) || "F".equals(((String)globalMap.get("LOAD_STATUS")))) ? TalendDate.diffDate(TalendDate.getCurrentDate(), ((Date)globalMap.get("JOB_STARTTIME")), "SSS") : null;
    	            	        	            	
    	            		row11.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row11.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row11.object_nm = ((String)globalMap.get("OBJECT_NM"));
    	            	        	            	
    	            		row11.run_id = ((String)globalMap.get("row9.RUN_ID"));
    	            	        	            	
    	            		row11.Jb_instnce_id = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row11.object_id = ((String)globalMap.get("OBJECT_ID"));
    	            	
 



/**
 * [tFixedFlowInput_5 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_5 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_5";

	

 


	tos_count_tFixedFlowInput_5++;

/**
 * [tFixedFlowInput_5 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_5 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_5";

	

			//row11
			//row11


			
				if(execStat){
					runStat.updateStatOnConnection("row11"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_5 = false;
                    if(row11.moment != null) {
pstmt_tMSSqlOutput_5.setTimestamp(1, new java.sql.Timestamp(row11.moment.getTime()));
} else {
pstmt_tMSSqlOutput_5.setNull(1, java.sql.Types.DATE);
}

                    if(row11.pid == null) {
pstmt_tMSSqlOutput_5.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(2, row11.pid);
}

                    if(row11.father_pid == null) {
pstmt_tMSSqlOutput_5.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(3, row11.father_pid);
}

                    if(row11.root_pid == null) {
pstmt_tMSSqlOutput_5.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(4, row11.root_pid);
}

                    if(row11.system_pid == null) {
pstmt_tMSSqlOutput_5.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_5.setLong(5, row11.system_pid);
}

                    if(row11.project == null) {
pstmt_tMSSqlOutput_5.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(6, row11.project);
}

                    if(row11.job == null) {
pstmt_tMSSqlOutput_5.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(7, row11.job);
}

                    if(row11.job_repository_id == null) {
pstmt_tMSSqlOutput_5.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(8, row11.job_repository_id);
}

                    if(row11.job_version == null) {
pstmt_tMSSqlOutput_5.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(9, row11.job_version);
}

                    if(row11.context == null) {
pstmt_tMSSqlOutput_5.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(10, row11.context);
}

                    if(row11.origin == null) {
pstmt_tMSSqlOutput_5.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(11, row11.origin);
}

                    if(row11.message_type == null) {
pstmt_tMSSqlOutput_5.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(12, row11.message_type);
}

                    if(row11.message == null) {
pstmt_tMSSqlOutput_5.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(13, row11.message);
}

                    if(row11.duration == null) {
pstmt_tMSSqlOutput_5.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_5.setLong(14, row11.duration);
}

                    if(row11.src_sys_id == null) {
pstmt_tMSSqlOutput_5.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(15, row11.src_sys_id);
}

                    if(row11.sub_sys_id == null) {
pstmt_tMSSqlOutput_5.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(16, row11.sub_sys_id);
}

                    if(row11.object_nm == null) {
pstmt_tMSSqlOutput_5.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(17, row11.object_nm);
}

                    if(row11.run_id == null) {
pstmt_tMSSqlOutput_5.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(18, row11.run_id);
}

                    if(row11.Jb_instnce_id == null) {
pstmt_tMSSqlOutput_5.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(19, row11.Jb_instnce_id);
}

                    if(row11.object_id == null) {
pstmt_tMSSqlOutput_5.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(20, row11.object_id);
}


            try {
                nb_line_tMSSqlOutput_5++;
                insertedCount_tMSSqlOutput_5 = insertedCount_tMSSqlOutput_5 + pstmt_tMSSqlOutput_5.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_5)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_5 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_5{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_5) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_5: pstmt_tMSSqlOutput_5.executeBatch()) {
							if(countEach_tMSSqlOutput_5 == -2 || countEach_tMSSqlOutput_5 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_5;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_5) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_5: pstmt_tMSSqlOutput_5.executeBatch()) {
							if(countEach_tMSSqlOutput_5 == -2 || countEach_tMSSqlOutput_5 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_5;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_5++;

/**
 * [tMSSqlOutput_5 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_5 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_5";

	

        }
        globalMap.put("tFixedFlowInput_5_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_5", true);
end_Hash.put("tFixedFlowInput_5", System.currentTimeMillis());




/**
 * [tFixedFlowInput_5 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_5 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_5";

	



        if(pstmt_tMSSqlOutput_5 != null) {
			
				pstmt_tMSSqlOutput_5.close();
			
        }


	nb_line_deleted_tMSSqlOutput_5=nb_line_deleted_tMSSqlOutput_5+ deletedCount_tMSSqlOutput_5;
	nb_line_update_tMSSqlOutput_5=nb_line_update_tMSSqlOutput_5 + updatedCount_tMSSqlOutput_5;
	nb_line_inserted_tMSSqlOutput_5=nb_line_inserted_tMSSqlOutput_5 + insertedCount_tMSSqlOutput_5;
	nb_line_rejected_tMSSqlOutput_5=nb_line_rejected_tMSSqlOutput_5 + rejectedCount_tMSSqlOutput_5;
	
        globalMap.put("tMSSqlOutput_5_NB_LINE",nb_line_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_5);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_5)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row11"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_5", true);
end_Hash.put("tMSSqlOutput_5", System.currentTimeMillis());




/**
 * [tMSSqlOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_5 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_5";

	

 



/**
 * [tFixedFlowInput_5 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_5";

	



	

 



/**
 * [tMSSqlOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_5_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_14Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_14_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_14 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_14", false);
		start_Hash.put("tWarn_14", System.currentTimeMillis());
		
	
	currentComponent="tWarn_14";

	
		int tos_count_tWarn_14 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_14{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_14 = new StringBuilder();
            log4jParamters_tWarn_14.append("Parameters:");
                    log4jParamters_tWarn_14.append("MESSAGE" + " = " + "\"313|Insert Stats Catcher table failed\"");
                log4jParamters_tWarn_14.append(" | ");
                    log4jParamters_tWarn_14.append("CODE" + " = " + "999");
                log4jParamters_tWarn_14.append(" | ");
                    log4jParamters_tWarn_14.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_14.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + (log4jParamters_tWarn_14) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_14().limitLog4jByte();

 



/**
 * [tWarn_14 begin ] stop
 */
	
	/**
	 * [tWarn_14 main ] start
	 */

	

	
	
	currentComponent="tWarn_14";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_14", "", Thread.currentThread().getId() + "", "ERROR","","313|Insert Stats Catcher table failed","", "");
            log.error("tWarn_14 - "  + ("Message: ")  + ("313|Insert Stats Catcher table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_14", 5, "313|Insert Stats Catcher table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_14_WARN_MESSAGES", "313|Insert Stats Catcher table failed"); 
globalMap.put("tWarn_14_WARN_PRIORITY", 5);
globalMap.put("tWarn_14_WARN_CODE", 999);


 


	tos_count_tWarn_14++;

/**
 * [tWarn_14 main ] stop
 */
	
	/**
	 * [tWarn_14 end ] start
	 */

	

	
	
	currentComponent="tWarn_14";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + ("Done.") );

ok_Hash.put("tWarn_14", true);
end_Hash.put("tWarn_14", System.currentTimeMillis());




/**
 * [tWarn_14 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_14 finally ] start
	 */

	

	
	
	currentComponent="tWarn_14";

	

 



/**
 * [tWarn_14 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_14_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_13", false);
		start_Hash.put("tWarn_13", System.currentTimeMillis());
		
	
	currentComponent="tWarn_13";

	
		int tos_count_tWarn_13 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_13{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_13 = new StringBuilder();
            log4jParamters_tWarn_13.append("Parameters:");
                    log4jParamters_tWarn_13.append("MESSAGE" + " = " + "\"312|Status updates to tracking tables failed\"");
                log4jParamters_tWarn_13.append(" | ");
                    log4jParamters_tWarn_13.append("CODE" + " = " + "999");
                log4jParamters_tWarn_13.append(" | ");
                    log4jParamters_tWarn_13.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_13.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + (log4jParamters_tWarn_13) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_13().limitLog4jByte();

 



/**
 * [tWarn_13 begin ] stop
 */
	
	/**
	 * [tWarn_13 main ] start
	 */

	

	
	
	currentComponent="tWarn_13";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_13", "", Thread.currentThread().getId() + "", "ERROR","","312|Status updates to tracking tables failed","", "");
            log.error("tWarn_13 - "  + ("Message: ")  + ("312|Status updates to tracking tables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_13", 5, "312|Status updates to tracking tables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_13_WARN_MESSAGES", "312|Status updates to tracking tables failed"); 
globalMap.put("tWarn_13_WARN_PRIORITY", 5);
globalMap.put("tWarn_13_WARN_CODE", 999);


 


	tos_count_tWarn_13++;

/**
 * [tWarn_13 main ] stop
 */
	
	/**
	 * [tWarn_13 end ] start
	 */

	

	
	
	currentComponent="tWarn_13";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + ("Done.") );

ok_Hash.put("tWarn_13", true);
end_Hash.put("tWarn_13", System.currentTimeMillis());




/**
 * [tWarn_13 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_13 finally ] start
	 */

	

	
	
	currentComponent="tWarn_13";

	

 



/**
 * [tWarn_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_13_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "PROD";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final Jb_Merge_ADLS_Staging_Child Jb_Merge_ADLS_Staging_ChildClass = new Jb_Merge_ADLS_Staging_Child();

        int exitCode = Jb_Merge_ADLS_Staging_ChildClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Jb_Merge_ADLS_Staging_Child' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'Jb_Merge_ADLS_Staging_Child' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Jb_Merge_ADLS_Staging_Child.class.getClassLoader().getResourceAsStream("cerebro/jb_merge_adls_staging_child_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
				    context.setContextType("batch_id", "id_String");
				
                context.batch_id=(String) context.getProperty("batch_id");
				    context.setContextType("object_id", "id_String");
				
                context.object_id=(String) context.getProperty("object_id");
				    context.setContextType("object_nm", "id_String");
				
                context.object_nm=(String) context.getProperty("object_nm");
				    context.setContextType("object_position", "id_String");
				
                context.object_position=(String) context.getProperty("object_position");
				    context.setContextType("root_pid", "id_String");
				
                context.root_pid=(String) context.getProperty("root_pid");
				    context.setContextType("src_sys_id", "id_String");
				
                context.src_sys_id=(String) context.getProperty("src_sys_id");
				    context.setContextType("sub_sys_id", "id_String");
				
                context.sub_sys_id=(String) context.getProperty("sub_sys_id");
				    context.setContextType("keyfile_path", "id_String");
				
                context.keyfile_path=(String) context.getProperty("keyfile_path");
				    context.setContextType("prop_file_path", "id_String");
				
                context.prop_file_path=(String) context.getProperty("prop_file_path");
				    context.setContextType("rerun_failed", "id_String");
				
                context.rerun_failed=(String) context.getProperty("rerun_failed");
				    context.setContextType("NO_ITERATION", "id_Integer");
				
             try{
                 context.NO_ITERATION=routines.system.ParserUtils.parseTo_Integer (context.getProperty("NO_ITERATION"));
             }catch(NumberFormatException e){
                 context.NO_ITERATION=null;
              }
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("batch_id")) {
                context.batch_id = (String) parentContextMap.get("batch_id");
            }if (parentContextMap.containsKey("object_id")) {
                context.object_id = (String) parentContextMap.get("object_id");
            }if (parentContextMap.containsKey("object_nm")) {
                context.object_nm = (String) parentContextMap.get("object_nm");
            }if (parentContextMap.containsKey("object_position")) {
                context.object_position = (String) parentContextMap.get("object_position");
            }if (parentContextMap.containsKey("root_pid")) {
                context.root_pid = (String) parentContextMap.get("root_pid");
            }if (parentContextMap.containsKey("src_sys_id")) {
                context.src_sys_id = (String) parentContextMap.get("src_sys_id");
            }if (parentContextMap.containsKey("sub_sys_id")) {
                context.sub_sys_id = (String) parentContextMap.get("sub_sys_id");
            }if (parentContextMap.containsKey("keyfile_path")) {
                context.keyfile_path = (String) parentContextMap.get("keyfile_path");
            }if (parentContextMap.containsKey("prop_file_path")) {
                context.prop_file_path = (String) parentContextMap.get("prop_file_path");
            }if (parentContextMap.containsKey("rerun_failed")) {
                context.rerun_failed = (String) parentContextMap.get("rerun_failed");
            }if (parentContextMap.containsKey("NO_ITERATION")) {
                context.NO_ITERATION = (Integer) parentContextMap.get("NO_ITERATION");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tJava_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tJava_1) {
globalMap.put("tJava_1_SUBPROCESS_STATE", -1);

e_tJava_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Jb_Merge_ADLS_Staging_Child");
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tMSSqlConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tMSSqlConnection_1", globalMap.get("conn_tMSSqlConnection_1"));







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     596517 characters generated by Talend Real-time Big Data Platform 
 *     on the November 13, 2018 12:06:07 PM EST
 ************************************************************************************************/