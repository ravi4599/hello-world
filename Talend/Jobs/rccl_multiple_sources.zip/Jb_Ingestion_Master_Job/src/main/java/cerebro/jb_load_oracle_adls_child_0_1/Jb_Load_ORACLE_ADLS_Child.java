
package cerebro.jb_load_oracle_adls_child_0_1;

import routines.DataCleanser;
import routines.DataOperation;
import routines.TalendEncrypt;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.DataQualityDependencies;
import routines.Mathematical;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.DQTechnical;
import routines.StringHandling;
import routines.DataMasking;
import routines.TalendDate;
import routines.DqStringHandling;
import routines.rccl_common_routine;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJavaRow_1
	//import java.util.List;

	//the import part of tJavaRow_2
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;

	//the import part of tJava_8
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJavaFlex_3
	//import java.util.List;

	//the import part of tJava_6
	//import java.util.List;

	//the import part of tJava_4
	//import java.util.List;

	//the import part of tJava_7
	//import java.util.List;

	//the import part of tJavaFlex_2
	//import java.util.List;

	//the import part of tLibraryLoad_1
	//import java.util.List;

	//the import part of tJava_9
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: Jb_Load_ORACLE_ADLS_Child Purpose: Loads data from source table into ADLS<br>
 * Description: Loads data from source table into ADLS <br>
 * @author CapGemini, GUTeam1
 * @version 6.4.1.20170623_1246
 * @status 
 */
public class Jb_Load_ORACLE_ADLS_Child implements TalendJob {
	static {System.setProperty("TalendJob.log", "Jb_Load_ORACLE_ADLS_Child.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(Jb_Load_ORACLE_ADLS_Child.class);



	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(batch_id != null){
				
					this.setProperty("batch_id", batch_id.toString());
				
			}
			
			if(object_id != null){
				
					this.setProperty("object_id", object_id.toString());
				
			}
			
			if(object_nm != null){
				
					this.setProperty("object_nm", object_nm.toString());
				
			}
			
			if(object_position != null){
				
					this.setProperty("object_position", object_position.toString());
				
			}
			
			if(root_pid != null){
				
					this.setProperty("root_pid", root_pid.toString());
				
			}
			
			if(src_sys_id != null){
				
					this.setProperty("src_sys_id", src_sys_id.toString());
				
			}
			
			if(sub_sys_id != null){
				
					this.setProperty("sub_sys_id", sub_sys_id.toString());
				
			}
			
			if(keyfile_path != null){
				
					this.setProperty("keyfile_path", keyfile_path.toString());
				
			}
			
			if(prop_file_path != null){
				
					this.setProperty("prop_file_path", prop_file_path.toString());
				
			}
			
		}

public String batch_id;
public String getBatch_id(){
	return this.batch_id;
}
public String object_id;
public String getObject_id(){
	return this.object_id;
}
public String object_nm;
public String getObject_nm(){
	return this.object_nm;
}
public String object_position;
public String getObject_position(){
	return this.object_position;
}
public String root_pid;
public String getRoot_pid(){
	return this.root_pid;
}
public String src_sys_id;
public String getSrc_sys_id(){
	return this.src_sys_id;
}
public String sub_sys_id;
public String getSub_sys_id(){
	return this.sub_sys_id;
}
public String keyfile_path;
public String getKeyfile_path(){
	return this.keyfile_path;
}
public String prop_file_path;
public String getProp_file_path(){
	return this.prop_file_path;
}
	}
	private ContextProperties context = new ContextProperties();
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Jb_Load_ORACLE_ADLS_Child";
	private final String projectName = "CEREBRO";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Jb_Load_ORACLE_ADLS_Child.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Jb_Load_ORACLE_ADLS_Child.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				tLogCatcher_1.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				tLogCatcher_1Process(globalMap);
			}
				} catch (TalendException e) {
					// do nothing
				
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputProperties_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFileInputProperties_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tOracleConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleSP_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSplitRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaFlex_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_15_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_15_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tJava_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_29_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSystem_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tHashInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFilterRow_31_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleSP_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSplitRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJavaFlex_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleSP_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_16_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_16_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_7_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_7_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLibraryLoad_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLibraryLoad_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJDBCInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJDBCInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_11_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_11_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleInput_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileOutputDelimited_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleInput_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_8_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_8_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_10_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_10_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlRow_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSetGlobalVar_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tFixedFlowInput_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDie_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tDie_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_9_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tJava_9_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tMSSqlRow_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlRow_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlRow_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlRow_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tFixedFlowInput_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_14_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_14_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tHashInput_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFlowToIterate_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFixedFlowInput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlOutput_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
					tHashInput_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_12_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_12_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tWarn_13_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tWarn_13_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tOracleClose_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tOracleClose_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMSSqlClose_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
				status = "failure";
				
					tMSSqlClose_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputProperties_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError1", 0, "error");
						}
					
					errorCode = null;
					tWarn_1Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError2", 0, "error");
						}
					
					errorCode = null;
					tWarn_3Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tOracleConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError3", 0, "error");
						}
					
					errorCode = null;
					tWarn_2Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError5", 0, "error");
						}
					
					errorCode = null;
					tWarn_5Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError4", 0, "error");
						}
					
					errorCode = null;
					tWarn_4Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError6", 0, "error");
						}
					
					errorCode = null;
					tWarn_6Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tFixedFlowInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError7", 0, "error");
						}
					
					errorCode = null;
					tWarn_7Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError8", 0, "error");
						}
					
					errorCode = null;
					tWarn_8Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tJava_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError9", 0, "error");
						}
					
					errorCode = null;
					tWarn_9Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError16", 0, "error");
						}
					
					errorCode = null;
					tWarn_15Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tOracleSP_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_15_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError18", 0, "error");
						}
					
					errorCode = null;
					tWarn_16Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tHashInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError11", 0, "error");
						}
					
					errorCode = null;
					tWarn_11Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tOracleSP_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_16_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tOracleInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_7_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLibraryLoad_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJDBCInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_11_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tOracleInput_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_8_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_10_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlRow_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLogCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tOracleRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDie_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_9_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlRow_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError13", 0, "error");
						}
					
					errorCode = null;
					tWarn_13Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tMSSqlRow_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlRow_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFixedFlowInput_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError14", 0, "error");
						}
					
					errorCode = null;
					tWarn_14Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_14_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tHashInput_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "ERROR", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

				try {
					
						if(this.execStat){
							runStat.updateStatOnConnection("OnSubjobError12", 0, "error");
						}
					
					errorCode = null;
					tWarn_12Process(globalMap);
					if (!"failure".equals(status)) {
						status = "end";
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			public void tWarn_12_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tOracleClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tWarn_13_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tOracleClose_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tMSSqlClose_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}







			


public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		
    	class BytesLimit65535_tPrejob_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tPrejob_1().limitLog4jByte();

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tFileInputProperties_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public static class row6Struct implements routines.system.IPersistableRow<row6Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row6Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row5Struct implements routines.system.IPersistableRow<row5Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputProperties_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputProperties_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row5Struct row5 = new row5Struct();
row6Struct row6 = new row6Struct();





	
	/**
	 * [tSetGlobalVar_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_2", false);
		start_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row6" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_2 = new StringBuilder();
            log4jParamters_tSetGlobalVar_2.append("Parameters:");
                    log4jParamters_tSetGlobalVar_2.append("VARIABLES" + " = " + "[{VALUE="+("row6.value")+", KEY="+("row6.key")+"}]");
                log4jParamters_tSetGlobalVar_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + (log4jParamters_tSetGlobalVar_2) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_2().limitLog4jByte();

 



/**
 * [tSetGlobalVar_2 begin ] stop
 */



	
	/**
	 * [tJavaRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_1", false);
		start_Hash.put("tJavaRow_1", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_1 = 0;
		
    	class BytesLimit65535_tJavaRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_1().limitLog4jByte();

int nb_line_tJavaRow_1 = 0;

 



/**
 * [tJavaRow_1 begin ] stop
 */



	
	/**
	 * [tFileInputProperties_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputProperties_1", false);
		start_Hash.put("tFileInputProperties_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputProperties_1";

	
		int tos_count_tFileInputProperties_1 = 0;
		
    	class BytesLimit65535_tFileInputProperties_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFileInputProperties_1().limitLog4jByte();

	java.io.File file_tFileInputProperties_1 = new java.io.File(context.prop_file_path);
	int nb_line_tFileInputProperties_1 = 0;				log.debug("tFileInputProperties_1 - Retrieving records from the datasource.");
			
	java.util.Properties properties_tFileInputProperties_1 = new java.util.Properties();
	java.io.FileInputStream fis_tFileInputProperties_1=new java.io.FileInputStream(file_tFileInputProperties_1);
   	try{
		properties_tFileInputProperties_1.load(fis_tFileInputProperties_1);
		java.util.Enumeration enumeration_tFileInputProperties_1 = properties_tFileInputProperties_1.propertyNames();
		while (enumeration_tFileInputProperties_1.hasMoreElements()) {
			nb_line_tFileInputProperties_1++;
				log.debug("tFileInputProperties_1 - Retrieving the record " + (nb_line_tFileInputProperties_1) + ".");
			
			row5.key = (String)enumeration_tFileInputProperties_1.nextElement();
			row5.value = (String)properties_tFileInputProperties_1.getProperty(row5.key);

 



/**
 * [tFileInputProperties_1 begin ] stop
 */
	
	/**
	 * [tFileInputProperties_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

 


	tos_count_tFileInputProperties_1++;

/**
 * [tFileInputProperties_1 main ] stop
 */

	
	/**
	 * [tJavaRow_1 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

			//row5
			//row5


			
				if(execStat){
					runStat.updateStatOnConnection("row5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row5 - " + (row5==null? "": row5.toLogString()));
    			}
    		

    row6.key = row5.key; 
if (row5.key.toLowerCase ().contains("password")) { 
	routines.TalendEncrypt enc = new routines.TalendEncrypt();
	row6.value = enc.decryptText(row5.value, enc.getPrivate(context.keyfile_path));
} else { 
  row6.value = row5.value; 
}
    nb_line_tJavaRow_1++;   

 


	tos_count_tJavaRow_1++;

/**
 * [tJavaRow_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			//row6
			//row6


			
				if(execStat){
					runStat.updateStatOnConnection("row6"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row6 - " + (row6==null? "": row6.toLogString()));
    			}
    		

globalMap.put(row6.key, row6.value);

 


	tos_count_tSetGlobalVar_2++;

/**
 * [tSetGlobalVar_2 main ] stop
 */






	
	/**
	 * [tFileInputProperties_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

		}
	}finally{
		if(fis_tFileInputProperties_1!=null){
			fis_tFileInputProperties_1.close();
		}
	}
globalMap.put("tFileInputProperties_1_NB_LINE", nb_line_tFileInputProperties_1);
				log.debug("tFileInputProperties_1 - Retrieved records count: "+ nb_line_tFileInputProperties_1 + " .");
			
 

ok_Hash.put("tFileInputProperties_1", true);
end_Hash.put("tFileInputProperties_1", System.currentTimeMillis());




/**
 * [tFileInputProperties_1 end ] stop
 */

	
	/**
	 * [tJavaRow_1 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

globalMap.put("tJavaRow_1_NB_LINE",nb_line_tJavaRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row5"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_1", true);
end_Hash.put("tJavaRow_1", System.currentTimeMillis());




/**
 * [tJavaRow_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row6"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_2 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_2", true);
end_Hash.put("tSetGlobalVar_2", System.currentTimeMillis());




/**
 * [tSetGlobalVar_2 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFileInputProperties_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tMSSqlConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputProperties_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputProperties_1";

	

 



/**
 * [tFileInputProperties_1 finally ] stop
 */

	
	/**
	 * [tJavaRow_1 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_1";

	

 



/**
 * [tJavaRow_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_2 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_2";

	

 



/**
 * [tSetGlobalVar_2 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputProperties_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tMSSqlConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlConnection_1", false);
		start_Hash.put("tMSSqlConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlConnection_1";

	
		int tos_count_tMSSqlConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlConnection_1 = new StringBuilder();
            log4jParamters_tMSSqlConnection_1.append("Parameters:");
                    log4jParamters_tMSSqlConnection_1.append("DRIVER" + " = " + "JTDS");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("HOST" + " = " + "((String)globalMap.get(\"AUDIT_HOSTNAME\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PORT" + " = " + "((String)globalMap.get(\"AUDIT_PORT\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SCHEMA_DB" + " = " + "((String)globalMap.get(\"AUDIT_SCHEMA\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("DBNAME" + " = " + "((String)globalMap.get(\"AUDIT_DATABASE\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("USER" + " = " + "((String)globalMap.get(\"AUDIT_USERNAME\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(((String)globalMap.get("AUDIT_PASSWORD")))).substring(0, 4) + "...");     
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("PROPERTIES" + " = " + "((String)globalMap.get(\"AUDIT_ADDITIONAL_PARAMETERS\"))");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                    log4jParamters_tMSSqlConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                log4jParamters_tMSSqlConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + (log4jParamters_tMSSqlConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlConnection_1().limitLog4jByte();
	

	
			String url_tMSSqlConnection_1 = "jdbc:jtds:sqlserver://" + ((String)globalMap.get("AUDIT_HOSTNAME")) ;
		String port_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_PORT"));
		String dbname_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_DATABASE")) ;
    	if (!"".equals(port_tMSSqlConnection_1)) {
    		url_tMSSqlConnection_1 += ":" + ((String)globalMap.get("AUDIT_PORT"));
    	}
    	if (!"".equals(dbname_tMSSqlConnection_1)) {
    		
				url_tMSSqlConnection_1 += "//" + ((String)globalMap.get("AUDIT_DATABASE")); 
    	}
		url_tMSSqlConnection_1 += ";appName=" + projectName + ";" + ((String)globalMap.get("AUDIT_ADDITIONAL_PARAMETERS"));  

	String dbUser_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_USERNAME"));
	
	
		
	final String decryptedPassword_tMSSqlConnection_1 = ((String)globalMap.get("AUDIT_PASSWORD")); 
		String dbPwd_tMSSqlConnection_1 = decryptedPassword_tMSSqlConnection_1;
	

	java.sql.Connection conn_tMSSqlConnection_1 = null;
	
		
			String driverClass_tMSSqlConnection_1 = "net.sourceforge.jtds.jdbc.Driver";
			java.lang.Class.forName(driverClass_tMSSqlConnection_1);
		
	    		log.debug("tMSSqlConnection_1 - Driver ClassName: "+driverClass_tMSSqlConnection_1+".");
			
	    		log.debug("tMSSqlConnection_1 - Connection attempt to '" + url_tMSSqlConnection_1 + "' with the username '" + dbUser_tMSSqlConnection_1 + "'.");
			
		conn_tMSSqlConnection_1 = java.sql.DriverManager.getConnection(url_tMSSqlConnection_1,dbUser_tMSSqlConnection_1,dbPwd_tMSSqlConnection_1);
	    		log.debug("tMSSqlConnection_1 - Connection to '" + url_tMSSqlConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tMSSqlConnection_1", conn_tMSSqlConnection_1);
	if (null != conn_tMSSqlConnection_1) {
		
			log.debug("tMSSqlConnection_1 - Connection is set auto commit to 'true'.");
			conn_tMSSqlConnection_1.setAutoCommit(true);
	}

	globalMap.put("dbschema_tMSSqlConnection_1", ((String)globalMap.get("AUDIT_SCHEMA")));

	globalMap.put("db_tMSSqlConnection_1",  ((String)globalMap.get("AUDIT_DATABASE")));

	globalMap.put("conn_tMSSqlConnection_1",conn_tMSSqlConnection_1);
	
	globalMap.put("shareIdentitySetting_tMSSqlConnection_1",  false);

 



/**
 * [tMSSqlConnection_1 begin ] stop
 */
	
	/**
	 * [tMSSqlConnection_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 


	tos_count_tMSSqlConnection_1++;

/**
 * [tMSSqlConnection_1 main ] stop
 */
	
	/**
	 * [tMSSqlConnection_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlConnection_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlConnection_1", true);
end_Hash.put("tMSSqlConnection_1", System.currentTimeMillis());




/**
 * [tMSSqlConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tMSSqlConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tMSSqlInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlConnection_1";

	

 



/**
 * [tMSSqlConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_1", false);
		start_Hash.put("tWarn_1", System.currentTimeMillis());
		
	
	currentComponent="tWarn_1";

	
		int tos_count_tWarn_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_1 = new StringBuilder();
            log4jParamters_tWarn_1.append("Parameters:");
                    log4jParamters_tWarn_1.append("MESSAGE" + " = " + "\"200|Audit connection failed\"");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("CODE" + " = " + "999");
                log4jParamters_tWarn_1.append(" | ");
                    log4jParamters_tWarn_1.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + (log4jParamters_tWarn_1) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_1().limitLog4jByte();

 



/**
 * [tWarn_1 begin ] stop
 */
	
	/**
	 * [tWarn_1 main ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_1", "", Thread.currentThread().getId() + "", "ERROR","","200|Audit connection failed","", "");
            log.error("tWarn_1 - "  + ("Message: ")  + ("200|Audit connection failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_1", 5, "200|Audit connection failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_1_WARN_MESSAGES", "200|Audit connection failed"); 
globalMap.put("tWarn_1_WARN_PRIORITY", 5);
globalMap.put("tWarn_1_WARN_CODE", 999);


 


	tos_count_tWarn_1++;

/**
 * [tWarn_1 main ] stop
 */
	
	/**
	 * [tWarn_1 end ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_1 - "  + ("Done.") );

ok_Hash.put("tWarn_1", true);
end_Hash.put("tWarn_1", System.currentTimeMillis());




/**
 * [tWarn_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_1 finally ] start
	 */

	

	
	
	currentComponent="tWarn_1";

	

 



/**
 * [tWarn_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_1_SUBPROCESS_STATE", 1);
	}
	


public static class row8Struct implements routines.system.IPersistableRow<row8Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row8Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row7Struct implements routines.system.IPersistableRow<row7Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row7Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row7Struct row7 = new row7Struct();
row8Struct row8 = new row8Struct();





	
	/**
	 * [tSetGlobalVar_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_3", false);
		start_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row8" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_3 = new StringBuilder();
            log4jParamters_tSetGlobalVar_3.append("Parameters:");
                    log4jParamters_tSetGlobalVar_3.append("VARIABLES" + " = " + "[{VALUE="+("row8.value")+", KEY="+("row8.key")+"}]");
                log4jParamters_tSetGlobalVar_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + (log4jParamters_tSetGlobalVar_3) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_3().limitLog4jByte();

 



/**
 * [tSetGlobalVar_3 begin ] stop
 */



	
	/**
	 * [tJavaRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaRow_2", false);
		start_Hash.put("tJavaRow_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row7" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tJavaRow_2 = 0;
		
    	class BytesLimit65535_tJavaRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaRow_2().limitLog4jByte();

int nb_line_tJavaRow_2 = 0;

 



/**
 * [tJavaRow_2 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_3", false);
		start_Hash.put("tMSSqlInput_3", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_3";

	
		int tos_count_tMSSqlInput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_3 = new StringBuilder();
            log4jParamters_tMSSqlInput_3.append("Parameters:");
                    log4jParamters_tMSSqlInput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("QUERY" + " = " + "\"  SELECT CONTEXT_KEY, CONTEXT_VALUE FROM (  SELECT UPPER(CONTEXT_KEY) AS CONTEXT_KEY  	, CONTEXT_VALUE  	, RANK () OVER(PARTITION BY CONTEXT_KEY ORDER BY PRIORITY) AS RNK  FROM DBO.T_TALEND_CONTEXT_LOAD CT  INNER JOIN (SELECT DISTINCT CONTEXT_ID, 2 AS PRIORITY  						FROM DBO.T_SRC_SYS_DCT_TBL  						WHERE SRC_SYS_ID = '\" + context.src_sys_id + \"'  							AND SUB_SYS_ID = '\" + context.sub_sys_id + \"'  						UNION  						SELECT DISTINCT CONTEXT_ID, 1 AS PRIORITY  						FROM DBO.T_LOAD_CTL_DTL  						WHERE SRC_SYS_ID = '\" + context.src_sys_id + \"'  							AND SUB_SYS_ID = '\" + context.sub_sys_id + \"'  							AND OBJECT_ID = '\" + context.object_id + \"') T  	ON CT.CONTEXT_ID = T.CONTEXT_ID) X  WHERE RNK = 1  \"");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_3.append(" | ");
                    log4jParamters_tMSSqlInput_3.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("key")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("value")+"}]");
                log4jParamters_tMSSqlInput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + (log4jParamters_tMSSqlInput_3) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_3().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_3 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_3 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_3  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_3, talendToDBArray_tMSSqlInput_3); 
		    int nb_line_tMSSqlInput_3 = 0;
		    java.sql.Connection conn_tMSSqlInput_3 = null;
		        conn_tMSSqlInput_3 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_3 != null) {
					if(conn_tMSSqlInput_3.getMetaData() != null) {
						
						log.debug("tMSSqlInput_3 - Uses an existing connection with username '" + conn_tMSSqlInput_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_3.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_3 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_3 = conn_tMSSqlInput_3.createStatement();

		    String dbquery_tMSSqlInput_3 = "\nSELECT CONTEXT_KEY, CONTEXT_VALUE FROM (\nSELECT UPPER(CONTEXT_KEY) AS CONTEXT_KEY\n	, CONTEXT_VALUE\n	, RANK () OVER(PARTITION BY CONTEXT_KEY ORDER BY PRIORITY) AS RNK\nFROM DBO.T_TALEND_CONTEXT_LOAD CT\nINNER JOIN (SELECT DISTINCT CONTEXT_ID, 2 AS PRIORITY\n						FROM DBO.T_SRC_SYS_DCT_TBL\n						WHERE SRC_SYS_ID = '" + context.src_sys_id + "'\n							AND SUB_SYS_ID = '" + context.sub_sys_id + "'\n						UNION\n						SELECT DISTINCT CONTEXT_ID, 1 AS PRIORITY\n						FROM DBO.T_LOAD_CTL_DTL\n						WHERE SRC_SYS_ID = '" + context.src_sys_id + "'\n							AND SUB_SYS_ID = '" + context.sub_sys_id + "'\n							AND OBJECT_ID = '" + context.object_id + "') T\n	ON CT.CONTEXT_ID = T.CONTEXT_ID) X\nWHERE RNK = 1\n";
			
                log.debug("tMSSqlInput_3 - Executing the query: '"+dbquery_tMSSqlInput_3+"'.");
			

                       globalMap.put("tMSSqlInput_3_QUERY",dbquery_tMSSqlInput_3);

		    java.sql.ResultSet rs_tMSSqlInput_3 = null;
		try{
		    rs_tMSSqlInput_3 = stmt_tMSSqlInput_3.executeQuery(dbquery_tMSSqlInput_3);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_3 = rs_tMSSqlInput_3.getMetaData();
		    int colQtyInRs_tMSSqlInput_3 = rsmd_tMSSqlInput_3.getColumnCount();

		    String tmpContent_tMSSqlInput_3 = null;
		    
		    
		    	log.debug("tMSSqlInput_3 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_3.next()) {
		        nb_line_tMSSqlInput_3++;
		        
							if(colQtyInRs_tMSSqlInput_3 < 1) {
								row7.key = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3.getString(1);
            if(tmpContent_tMSSqlInput_3 != null) {
            	if (talendToDBList_tMSSqlInput_3 .contains(rsmd_tMSSqlInput_3.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row7.key = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_3);
            	} else {
                	row7.key = tmpContent_tMSSqlInput_3;
                }
            } else {
                row7.key = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_3 < 2) {
								row7.value = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_3 = rs_tMSSqlInput_3.getString(2);
            if(tmpContent_tMSSqlInput_3 != null) {
            	if (talendToDBList_tMSSqlInput_3 .contains(rsmd_tMSSqlInput_3.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row7.value = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_3);
            	} else {
                	row7.value = tmpContent_tMSSqlInput_3;
                }
            } else {
                row7.value = null;
            }
		                    }
					
						log.debug("tMSSqlInput_3 - Retrieving the record " + nb_line_tMSSqlInput_3 + ".");
					





 



/**
 * [tMSSqlInput_3 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_3 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

 


	tos_count_tMSSqlInput_3++;

/**
 * [tMSSqlInput_3 main ] stop
 */

	
	/**
	 * [tJavaRow_2 main ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

			//row7
			//row7


			
				if(execStat){
					runStat.updateStatOnConnection("row7"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row7 - " + (row7==null? "": row7.toLogString()));
    			}
    		

    row8.key = row7.key; 
if (row7.key.toLowerCase ().contains("password")) { 
	routines.TalendEncrypt enc = new routines.TalendEncrypt();
	row8.value = enc.decryptText(row7.value, enc.getPrivate(context.keyfile_path));
} else { 
  row8.value = row7.value; 
}
    nb_line_tJavaRow_2++;   

 


	tos_count_tJavaRow_2++;

/**
 * [tJavaRow_2 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			//row8
			//row8


			
				if(execStat){
					runStat.updateStatOnConnection("row8"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row8 - " + (row8==null? "": row8.toLogString()));
    			}
    		

globalMap.put(row8.key, row8.value);

 


	tos_count_tSetGlobalVar_3++;

/**
 * [tSetGlobalVar_3 main ] stop
 */






	
	/**
	 * [tMSSqlInput_3 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

	}
}finally{
	stmt_tMSSqlInput_3.close();

}
globalMap.put("tMSSqlInput_3_NB_LINE",nb_line_tMSSqlInput_3);
	    		log.debug("tMSSqlInput_3 - Retrieved records count: "+nb_line_tMSSqlInput_3 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_3 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_3", true);
end_Hash.put("tMSSqlInput_3", System.currentTimeMillis());

   			if (!("CUSTOM_JDBC".equals((String)globalMap.get("OBJECT_TYPE"))) && !("CUSTOM_VERSION_12_7".equals((String)globalMap.get("OBJECT_TYPE")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If15", 0, "true");
					}
				
    			tOracleConnection_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If15", 0, "false");
					}   	 
   				}



/**
 * [tMSSqlInput_3 end ] stop
 */

	
	/**
	 * [tJavaRow_2 end ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

globalMap.put("tJavaRow_2_NB_LINE",nb_line_tJavaRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row7"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tJavaRow_2", true);
end_Hash.put("tJavaRow_2", System.currentTimeMillis());




/**
 * [tJavaRow_2 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row8"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_3 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_3", true);
end_Hash.put("tSetGlobalVar_3", System.currentTimeMillis());




/**
 * [tSetGlobalVar_3 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_3 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_3";

	

 



/**
 * [tMSSqlInput_3 finally ] stop
 */

	
	/**
	 * [tJavaRow_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaRow_2";

	

 



/**
 * [tJavaRow_2 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_3 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_3";

	

 



/**
 * [tSetGlobalVar_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_3", false);
		start_Hash.put("tWarn_3", System.currentTimeMillis());
		
	
	currentComponent="tWarn_3";

	
		int tos_count_tWarn_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_3 = new StringBuilder();
            log4jParamters_tWarn_3.append("Parameters:");
                    log4jParamters_tWarn_3.append("MESSAGE" + " = " + "\"201|Load context variables failed\"");
                log4jParamters_tWarn_3.append(" | ");
                    log4jParamters_tWarn_3.append("CODE" + " = " + "999");
                log4jParamters_tWarn_3.append(" | ");
                    log4jParamters_tWarn_3.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + (log4jParamters_tWarn_3) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_3().limitLog4jByte();

 



/**
 * [tWarn_3 begin ] stop
 */
	
	/**
	 * [tWarn_3 main ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_3", "", Thread.currentThread().getId() + "", "ERROR","","201|Load context variables failed","", "");
            log.error("tWarn_3 - "  + ("Message: ")  + ("201|Load context variables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_3", 5, "201|Load context variables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_3_WARN_MESSAGES", "201|Load context variables failed"); 
globalMap.put("tWarn_3_WARN_PRIORITY", 5);
globalMap.put("tWarn_3_WARN_CODE", 999);


 


	tos_count_tWarn_3++;

/**
 * [tWarn_3 main ] stop
 */
	
	/**
	 * [tWarn_3 end ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_3 - "  + ("Done.") );

ok_Hash.put("tWarn_3", true);
end_Hash.put("tWarn_3", System.currentTimeMillis());




/**
 * [tWarn_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_3 finally ] start
	 */

	

	
	
	currentComponent="tWarn_3";

	

 



/**
 * [tWarn_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_3_SUBPROCESS_STATE", 1);
	}
	

public void tOracleConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tOracleConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleConnection_1", false);
		start_Hash.put("tOracleConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tOracleConnection_1";

	
		int tos_count_tOracleConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tOracleConnection_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tOracleConnection_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tOracleConnection_1 = new StringBuilder();
            log4jParamters_tOracleConnection_1.append("Parameters:");
                    log4jParamters_tOracleConnection_1.append("CONNECTION_TYPE" + " = " + "ORACLE_SERVICE_NAME");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("DB_VERSION" + " = " + "ORACLE_11-6");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("USE_TNS_FILE" + " = " + "false");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("HOST" + " = " + "((String)globalMap.get(\"SOURCE_HOSTNAME\"))");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("PORT" + " = " + "((String)globalMap.get(\"SOURCE_PORT\"))");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("DBNAME" + " = " + "((String)globalMap.get(\"SOURCE_DATABASE\"))");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("SCHEMA_DB" + " = " + "((String)globalMap.get(\"SOURCE_SCHEMA\"))");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("USER" + " = " + "((String)globalMap.get(\"SOURCE_USERNAME\"))");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(((String)globalMap.get("SOURCE_PASSWORD")))).substring(0, 4) + "...");     
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("PROPERTIES" + " = " + "((String)globalMap.get(\"SOURCE_ADDITIONAL_PARAMETERS\"))");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tOracleConnection_1.append(" | ");
                    log4jParamters_tOracleConnection_1.append("AUTO_COMMIT" + " = " + "true");
                log4jParamters_tOracleConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tOracleConnection_1 - "  + (log4jParamters_tOracleConnection_1) );
    		}
    	}
    	
        new BytesLimit65535_tOracleConnection_1().limitLog4jByte();
	

	
        String url_tOracleConnection_1 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + ((String)globalMap.get("SOURCE_HOSTNAME")) + ")(port=" + ((String)globalMap.get("SOURCE_PORT")) + "))(connect_data=(service_name=" + ((String)globalMap.get("SOURCE_DATABASE")) + ")))";
    	globalMap.put("connectionType_" + "tOracleConnection_1", "ORACLE_SERVICE_NAME");

	String dbUser_tOracleConnection_1 = ((String)globalMap.get("SOURCE_USERNAME"));
	
	
		
	final String decryptedPassword_tOracleConnection_1 = ((String)globalMap.get("SOURCE_PASSWORD")); 
		String dbPwd_tOracleConnection_1 = decryptedPassword_tOracleConnection_1;
	

	java.sql.Connection conn_tOracleConnection_1 = null;
	
		
			String driverClass_tOracleConnection_1 = "oracle.jdbc.OracleDriver";
			java.lang.Class.forName(driverClass_tOracleConnection_1);
		
	    		log.debug("tOracleConnection_1 - Driver ClassName: "+driverClass_tOracleConnection_1+".");
			
	    		log.debug("tOracleConnection_1 - Connection attempt to '" + url_tOracleConnection_1 + "' with the username '" + dbUser_tOracleConnection_1 + "'.");
			
			java.util.Properties atnParamsPrope_tOracleConnection_1 = new java.util.Properties();
			atnParamsPrope_tOracleConnection_1.put("user",dbUser_tOracleConnection_1);
			atnParamsPrope_tOracleConnection_1.put("password",dbPwd_tOracleConnection_1);
			if(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS")) != null && !"\"\"".equals(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS"))) && !"".equals(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS")))){
                atnParamsPrope_tOracleConnection_1.load(new java.io.ByteArrayInputStream(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS")).replace("&", "\n").getBytes()));
            }
			conn_tOracleConnection_1 = java.sql.DriverManager.getConnection(url_tOracleConnection_1, atnParamsPrope_tOracleConnection_1);
	    		log.debug("tOracleConnection_1 - Connection to '" + url_tOracleConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tOracleConnection_1", conn_tOracleConnection_1);
	if (null != conn_tOracleConnection_1) {
		
			log.debug("tOracleConnection_1 - Connection is set auto commit to 'true'.");
			conn_tOracleConnection_1.setAutoCommit(true);
	}
        globalMap.put("host_" + "tOracleConnection_1",((String)globalMap.get("SOURCE_HOSTNAME")));
        globalMap.put("port_" + "tOracleConnection_1",((String)globalMap.get("SOURCE_PORT")));
        globalMap.put("dbname_" + "tOracleConnection_1",((String)globalMap.get("SOURCE_DATABASE")));

	globalMap.put("conn_" + "tOracleConnection_1",conn_tOracleConnection_1);
	globalMap.put("dbschema_" + "tOracleConnection_1", ((String)globalMap.get("SOURCE_SCHEMA")));
	globalMap.put("username_" + "tOracleConnection_1",((String)globalMap.get("SOURCE_USERNAME")));
	globalMap.put("password_" + "tOracleConnection_1",dbPwd_tOracleConnection_1);

 



/**
 * [tOracleConnection_1 begin ] stop
 */
	
	/**
	 * [tOracleConnection_1 main ] start
	 */

	

	
	
	currentComponent="tOracleConnection_1";

	

 


	tos_count_tOracleConnection_1++;

/**
 * [tOracleConnection_1 main ] stop
 */
	
	/**
	 * [tOracleConnection_1 end ] start
	 */

	

	
	
	currentComponent="tOracleConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tOracleConnection_1 - "  + ("Done.") );

ok_Hash.put("tOracleConnection_1", true);
end_Hash.put("tOracleConnection_1", System.currentTimeMillis());




/**
 * [tOracleConnection_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tOracleConnection_1";

	

 



/**
 * [tOracleConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_2", false);
		start_Hash.put("tWarn_2", System.currentTimeMillis());
		
	
	currentComponent="tWarn_2";

	
		int tos_count_tWarn_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_2 = new StringBuilder();
            log4jParamters_tWarn_2.append("Parameters:");
                    log4jParamters_tWarn_2.append("MESSAGE" + " = " + "\"202|Source connection failed\"");
                log4jParamters_tWarn_2.append(" | ");
                    log4jParamters_tWarn_2.append("CODE" + " = " + "999");
                log4jParamters_tWarn_2.append(" | ");
                    log4jParamters_tWarn_2.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + (log4jParamters_tWarn_2) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_2().limitLog4jByte();

 



/**
 * [tWarn_2 begin ] stop
 */
	
	/**
	 * [tWarn_2 main ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_2", "", Thread.currentThread().getId() + "", "ERROR","","202|Source connection failed","", "");
            log.error("tWarn_2 - "  + ("Message: ")  + ("202|Source connection failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_2", 5, "202|Source connection failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_2_WARN_MESSAGES", "202|Source connection failed"); 
globalMap.put("tWarn_2_WARN_PRIORITY", 5);
globalMap.put("tWarn_2_WARN_CODE", 999);


 


	tos_count_tWarn_2++;

/**
 * [tWarn_2 main ] stop
 */
	
	/**
	 * [tWarn_2 end ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_2 - "  + ("Done.") );

ok_Hash.put("tWarn_2", true);
end_Hash.put("tWarn_2", System.currentTimeMillis());




/**
 * [tWarn_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_2 finally ] start
	 */

	

	
	
	currentComponent="tWarn_2";

	

 



/**
 * [tWarn_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_2_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
    	class BytesLimit65535_tJava_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_1().limitLog4jByte();


globalMap.put("SRC_SYS_ID", context.src_sys_id);
globalMap.put("SUB_SYS_ID", context.sub_sys_id);
globalMap.put("OBJECT_ID", context.object_id);
globalMap.put("OBJECT_NM", context.object_nm);

if ("SP_MULTI_OBJECT_OTHER".equals((String)globalMap.get("OBJECT_TYPE"))) {
	globalMap.put("NO_PROCESS", "Y");
}
 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());

   			if (!("F".equals((String)globalMap.get("LOAD_STATUS"))) && Relational.ISNULL(globalMap.get("NO_PROCESS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				
    			tJava_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
    	class BytesLimit65535_tJava_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_2().limitLog4jByte();


globalMap.put("JOB_FQ_NAME", jobName + (Relational.ISNULL(globalMap.get("JOB_NAME_QUALIFIER")) ? "" : "_" + ((String)globalMap.get("JOB_NAME_QUALIFIER"))));

globalMap.put("BATCH_ID", context.batch_id);

// ******************* Get start time & job instance id ******************
globalMap.put("JOB_STARTTIME", TalendDate.getCurrentDate());
globalMap.put("JOB_STARTTIME_STRING", TalendDate.formatDate("yyyyMMddhhmmssSSS",((Date)globalMap.get("JOB_STARTTIME"))));

// ********************* Set job final Job Instance ID  **********************
globalMap.put("JOB_INSTANCE_ID", rccl_common_routine.getJobRunInstanceID()); // generate a new InstanceID

// ********************* Set job root directory ********************** 
globalMap.put("JOB_ROOT_DIR", ((String)globalMap.get("ENV_TALEND_ROOT_DIR")) + "/job-exec/" + projectName.toLowerCase() + "/" + ((String)globalMap.get("JOB_FQ_NAME")) + "/" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "_" + ((String)globalMap.get("JOB_INSTANCE_ID")));

// ********************* Set TAC Project execution directory ********************** 
globalMap.put("JOB_PROJECT_DIR", ((String)globalMap.get("ENV_TALEND_ROOT_DIR")) + "/job-exec/" + projectName.toLowerCase());

// ************* Get user executing job **********************
globalMap.put("JOB_USER", System.getProperty("user.name"));

// ************* Get execution server name **********************
globalMap.put("JOB_EXEC_SERVER_NAME_LONG", rccl_common_routine.getServerName("long"));
globalMap.put("JOB_EXEC_SERVER_NAME_SHORT", rccl_common_routine.getServerName("short"));

//*************** Set Audit Context Variable ***************
globalMap.put("RUN_ID", ((String)globalMap.get("JOB_INSTANCE_ID")) + "_" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "_" + ((String)globalMap.get("SRC_SYS_ID")) + "_" + ((String)globalMap.get("OBJECT_NM")));
 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk10", 0, "ok");
				}
				tMSSqlRow_4Process(globalMap);



/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tMSSqlInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_5", false);
		start_Hash.put("tWarn_5", System.currentTimeMillis());
		
	
	currentComponent="tWarn_5";

	
		int tos_count_tWarn_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_5 = new StringBuilder();
            log4jParamters_tWarn_5.append("Parameters:");
                    log4jParamters_tWarn_5.append("MESSAGE" + " = " + "\"203|Setting up init variables failed\"");
                log4jParamters_tWarn_5.append(" | ");
                    log4jParamters_tWarn_5.append("CODE" + " = " + "999");
                log4jParamters_tWarn_5.append(" | ");
                    log4jParamters_tWarn_5.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + (log4jParamters_tWarn_5) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_5().limitLog4jByte();

 



/**
 * [tWarn_5 begin ] stop
 */
	
	/**
	 * [tWarn_5 main ] start
	 */

	

	
	
	currentComponent="tWarn_5";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_5", "", Thread.currentThread().getId() + "", "ERROR","","203|Setting up init variables failed","", "");
            log.error("tWarn_5 - "  + ("Message: ")  + ("203|Setting up init variables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_5", 5, "203|Setting up init variables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_5_WARN_MESSAGES", "203|Setting up init variables failed"); 
globalMap.put("tWarn_5_WARN_PRIORITY", 5);
globalMap.put("tWarn_5_WARN_CODE", 999);


 


	tos_count_tWarn_5++;

/**
 * [tWarn_5 main ] stop
 */
	
	/**
	 * [tWarn_5 end ] start
	 */

	

	
	
	currentComponent="tWarn_5";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_5 - "  + ("Done.") );

ok_Hash.put("tWarn_5", true);
end_Hash.put("tWarn_5", System.currentTimeMillis());




/**
 * [tWarn_5 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_5 finally ] start
	 */

	

	
	
	currentComponent="tWarn_5";

	

 



/**
 * [tWarn_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_5_SUBPROCESS_STATE", 1);
	}
	


public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String SRC_SYS_ID;

				public String getSRC_SYS_ID () {
					return this.SRC_SYS_ID;
				}
				
			    public String SUB_SYS_ID;

				public String getSUB_SYS_ID () {
					return this.SUB_SYS_ID;
				}
				
			    public String SRC_SYS_NM;

				public String getSRC_SYS_NM () {
					return this.SRC_SYS_NM;
				}
				
			    public String SUB_SYS_NM;

				public String getSUB_SYS_NM () {
					return this.SUB_SYS_NM;
				}
				
			    public String OBJECT_ID;

				public String getOBJECT_ID () {
					return this.OBJECT_ID;
				}
				
			    public String OBJECT_NM;

				public String getOBJECT_NM () {
					return this.OBJECT_NM;
				}
				
			    public String OBJECT_SCHEMA;

				public String getOBJECT_SCHEMA () {
					return this.OBJECT_SCHEMA;
				}
				
			    public String PRMRY_K;

				public String getPRMRY_K () {
					return this.PRMRY_K;
				}
				
			    public String TMSTMP_K;

				public String getTMSTMP_K () {
					return this.TMSTMP_K;
				}
				
			    public java.util.Date LAST_RUN_DTTM;

				public java.util.Date getLAST_RUN_DTTM () {
					return this.LAST_RUN_DTTM;
				}
				
			    public java.util.Date NEXT_RUN_DTTM;

				public java.util.Date getNEXT_RUN_DTTM () {
					return this.NEXT_RUN_DTTM;
				}
				
			    public String CDC_COL_NM;

				public String getCDC_COL_NM () {
					return this.CDC_COL_NM;
				}
				
			    public String IS_ACTIVE;

				public String getIS_ACTIVE () {
					return this.IS_ACTIVE;
				}
				
			    public String FREQUENCY;

				public String getFREQUENCY () {
					return this.FREQUENCY;
				}
				
			    public String INIT_LD;

				public String getINIT_LD () {
					return this.INIT_LD;
				}
				
			    public String CHR_ENCODE;

				public String getCHR_ENCODE () {
					return this.CHR_ENCODE;
				}
				
			    public String CUST_QUERY;

				public String getCUST_QUERY () {
					return this.CUST_QUERY;
				}
				
			    public String IS_CLNSD;

				public String getIS_CLNSD () {
					return this.IS_CLNSD;
				}
				
			    public String OBJECT_LIST;

				public String getOBJECT_LIST () {
					return this.OBJECT_LIST;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.SRC_SYS_ID = readString(dis);
					
					this.SUB_SYS_ID = readString(dis);
					
					this.SRC_SYS_NM = readString(dis);
					
					this.SUB_SYS_NM = readString(dis);
					
					this.OBJECT_ID = readString(dis);
					
					this.OBJECT_NM = readString(dis);
					
					this.OBJECT_SCHEMA = readString(dis);
					
					this.PRMRY_K = readString(dis);
					
					this.TMSTMP_K = readString(dis);
					
					this.LAST_RUN_DTTM = readDate(dis);
					
					this.NEXT_RUN_DTTM = readDate(dis);
					
					this.CDC_COL_NM = readString(dis);
					
					this.IS_ACTIVE = readString(dis);
					
					this.FREQUENCY = readString(dis);
					
					this.INIT_LD = readString(dis);
					
					this.CHR_ENCODE = readString(dis);
					
					this.CUST_QUERY = readString(dis);
					
					this.IS_CLNSD = readString(dis);
					
					this.OBJECT_LIST = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.SRC_SYS_ID,dos);
					
					// String
				
						writeString(this.SUB_SYS_ID,dos);
					
					// String
				
						writeString(this.SRC_SYS_NM,dos);
					
					// String
				
						writeString(this.SUB_SYS_NM,dos);
					
					// String
				
						writeString(this.OBJECT_ID,dos);
					
					// String
				
						writeString(this.OBJECT_NM,dos);
					
					// String
				
						writeString(this.OBJECT_SCHEMA,dos);
					
					// String
				
						writeString(this.PRMRY_K,dos);
					
					// String
				
						writeString(this.TMSTMP_K,dos);
					
					// java.util.Date
				
						writeDate(this.LAST_RUN_DTTM,dos);
					
					// java.util.Date
				
						writeDate(this.NEXT_RUN_DTTM,dos);
					
					// String
				
						writeString(this.CDC_COL_NM,dos);
					
					// String
				
						writeString(this.IS_ACTIVE,dos);
					
					// String
				
						writeString(this.FREQUENCY,dos);
					
					// String
				
						writeString(this.INIT_LD,dos);
					
					// String
				
						writeString(this.CHR_ENCODE,dos);
					
					// String
				
						writeString(this.CUST_QUERY,dos);
					
					// String
				
						writeString(this.IS_CLNSD,dos);
					
					// String
				
						writeString(this.OBJECT_LIST,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("SRC_SYS_ID="+SRC_SYS_ID);
		sb.append(",SUB_SYS_ID="+SUB_SYS_ID);
		sb.append(",SRC_SYS_NM="+SRC_SYS_NM);
		sb.append(",SUB_SYS_NM="+SUB_SYS_NM);
		sb.append(",OBJECT_ID="+OBJECT_ID);
		sb.append(",OBJECT_NM="+OBJECT_NM);
		sb.append(",OBJECT_SCHEMA="+OBJECT_SCHEMA);
		sb.append(",PRMRY_K="+PRMRY_K);
		sb.append(",TMSTMP_K="+TMSTMP_K);
		sb.append(",LAST_RUN_DTTM="+String.valueOf(LAST_RUN_DTTM));
		sb.append(",NEXT_RUN_DTTM="+String.valueOf(NEXT_RUN_DTTM));
		sb.append(",CDC_COL_NM="+CDC_COL_NM);
		sb.append(",IS_ACTIVE="+IS_ACTIVE);
		sb.append(",FREQUENCY="+FREQUENCY);
		sb.append(",INIT_LD="+INIT_LD);
		sb.append(",CHR_ENCODE="+CHR_ENCODE);
		sb.append(",CUST_QUERY="+CUST_QUERY);
		sb.append(",IS_CLNSD="+IS_CLNSD);
		sb.append(",OBJECT_LIST="+OBJECT_LIST);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(SRC_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SRC_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(SUB_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SUB_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(SRC_SYS_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SRC_SYS_NM);
            			}
            		
        			sb.append("|");
        		
        				if(SUB_SYS_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SUB_SYS_NM);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_ID);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_NM);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_SCHEMA == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_SCHEMA);
            			}
            		
        			sb.append("|");
        		
        				if(PRMRY_K == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PRMRY_K);
            			}
            		
        			sb.append("|");
        		
        				if(TMSTMP_K == null){
        					sb.append("<null>");
        				}else{
            				sb.append(TMSTMP_K);
            			}
            		
        			sb.append("|");
        		
        				if(LAST_RUN_DTTM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(LAST_RUN_DTTM);
            			}
            		
        			sb.append("|");
        		
        				if(NEXT_RUN_DTTM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(NEXT_RUN_DTTM);
            			}
            		
        			sb.append("|");
        		
        				if(CDC_COL_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CDC_COL_NM);
            			}
            		
        			sb.append("|");
        		
        				if(IS_ACTIVE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IS_ACTIVE);
            			}
            		
        			sb.append("|");
        		
        				if(FREQUENCY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FREQUENCY);
            			}
            		
        			sb.append("|");
        		
        				if(INIT_LD == null){
        					sb.append("<null>");
        				}else{
            				sb.append(INIT_LD);
            			}
            		
        			sb.append("|");
        		
        				if(CHR_ENCODE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CHR_ENCODE);
            			}
            		
        			sb.append("|");
        		
        				if(CUST_QUERY == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CUST_QUERY);
            			}
            		
        			sb.append("|");
        		
        				if(IS_CLNSD == null){
        					sb.append("<null>");
        				}else{
            				sb.append(IS_CLNSD);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_LIST == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_LIST);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tMSSqlInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row1Struct row1 = new row1Struct();




	
	/**
	 * [tSetGlobalVar_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_1", false);
		start_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSetGlobalVar_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_1 = new StringBuilder();
            log4jParamters_tSetGlobalVar_1.append("Parameters:");
                    log4jParamters_tSetGlobalVar_1.append("VARIABLES" + " = " + "[{VALUE="+("row1.SRC_SYS_ID")+", KEY="+("\"SRC_SYS_ID\"")+"}, {VALUE="+("row1.SUB_SYS_ID")+", KEY="+("\"SUB_SYS_ID\"")+"}, {VALUE="+("row1.OBJECT_ID")+", KEY="+("\"OBJECT_ID\"")+"}, {VALUE="+("row1.OBJECT_NM")+", KEY="+("\"OBJECT_NM\"")+"}, {VALUE="+("row1.PRMRY_K")+", KEY="+("\"PRMRY_K\"")+"}, {VALUE="+("row1.TMSTMP_K")+", KEY="+("\"TMSTMP_K\"")+"}, {VALUE="+("row1.LAST_RUN_DTTM")+", KEY="+("\"LAST_RUN_DTTM\"")+"}, {VALUE="+("row1.NEXT_RUN_DTTM")+", KEY="+("\"NEXT_RUN_DTTM\"")+"}, {VALUE="+("row1.CDC_COL_NM")+", KEY="+("\"CDC_COL_NM\"")+"}, {VALUE="+("row1.IS_ACTIVE")+", KEY="+("\"IS_ACTIVE\"")+"}, {VALUE="+("row1.FREQUENCY")+", KEY="+("\"FREQUENCY\"")+"}, {VALUE="+("row1.INIT_LD")+", KEY="+("\"INIT_LD\"")+"}, {VALUE="+("row1.CHR_ENCODE")+", KEY="+("\"CHR_ENCODE\"")+"}, {VALUE="+("row1.CUST_QUERY")+", KEY="+("\"CUST_QUERY\"")+"}, {VALUE="+("row1.OBJECT_SCHEMA")+", KEY="+("\"OBJECT_SCHEMA\"")+"}, {VALUE="+("row1.SRC_SYS_NM")+", KEY="+("\"SRC_SYS_NM\"")+"}, {VALUE="+("row1.IS_CLNSD")+", KEY="+("\"IS_CLNSD\"")+"}, {VALUE="+("row1.OBJECT_LIST")+", KEY="+("\"OBJECT_LIST\"")+"}, {VALUE="+("row1.SUB_SYS_NM")+", KEY="+("\"SUB_SYS_NM\"")+"}]");
                log4jParamters_tSetGlobalVar_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + (log4jParamters_tSetGlobalVar_1) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_1().limitLog4jByte();

 



/**
 * [tSetGlobalVar_1 begin ] stop
 */



	
	/**
	 * [tMSSqlInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlInput_1", false);
		start_Hash.put("tMSSqlInput_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlInput_1";

	
		int tos_count_tMSSqlInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlInput_1 = new StringBuilder();
            log4jParamters_tMSSqlInput_1.append("Parameters:");
                    log4jParamters_tMSSqlInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("QUERY" + " = " + "\"  SELECT IT.SRC_SYS_ID  	, SR.SUB_SYS_ID  	, SR.SRC_SYS_DESC  \" + (\"NA\".equals(context.object_position) ?  \"  	, CASE WHEN SR.SUB_SYS_DESC = SR.SRC_SYS_DESC THEN NULL ELSE SR.SUB_SYS_DESC END AS SUB_SYS_NM  \"   :  \"  	, NULL AS SUB_SYS_NM  \") +  \"  	, IT.OBJECT_ID  	, IT.OBJECT_NM  	, LC.OBJECT_SCHEMA  	, OB.PRMRY_K  	, OB.TMSTMP_K  	, CD.LAST_RUN_DTTM  	, CD.NEXT_RUN_DTTM  	, CD.CDC_COL_NM  	, CD.IS_ACTIVE  	, CD.FREQUENCY  	, IT.INIT_LD  	, IT.CHR_ENCODE  	, LC.CUST_QUERY  	, LC.IS_CLNSD  	, LC.OBJECT_LIST  FROM DBO.T_INIT_LOAD_DTL IT  	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR  		ON IT.SRC_SYS_ID = SR.SRC_SYS_ID  			AND IT.SUB_SYS_ID = SR.SUB_SYS_ID  	LEFT JOIN DBO.T_CDC_AUX_DTL CD  		ON IT.SRC_SYS_ID = CD.SRC_SYS_ID  			AND SR.SUB_SYS_ID = CD.SUB_SYS_ID  			AND IT.OBJECT_ID = CD.OBJECT_ID  	LEFT JOIN DBO.T_OBJCT_KEY_DTL OB  		ON OB.SRC_SYS_ID = IT.SRC_SYS_ID  			AND OB.SUB_SYS_ID = SR.SUB_SYS_ID  			AND OB.OBJECT_ID = IT.OBJECT_ID  	LEFT JOIN DBO.T_LOAD_CTL_DTL LC  		ON IT.SRC_SYS_ID = LC.SRC_SYS_ID  			AND SR.SUB_SYS_ID = LC.SUB_SYS_ID  			AND IT.OBJECT_ID = LC.OBJECT_ID  WHERE IT.SRC_SYS_ID = '\" + context.src_sys_id + \"'  	AND SR.SUB_SYS_ID = '\" + context.sub_sys_id + \"'  	AND IT.OBJECT_ID = '\" + context.object_id + \"'  \"");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TRIM_ALL_COLUMN" + " = " + "false");
                log4jParamters_tMSSqlInput_1.append(" | ");
                    log4jParamters_tMSSqlInput_1.append("TRIM_COLUMN" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("SRC_SYS_ID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SUB_SYS_ID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SRC_SYS_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("SUB_SYS_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OBJECT_ID")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OBJECT_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OBJECT_SCHEMA")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("PRMRY_K")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("TMSTMP_K")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("LAST_RUN_DTTM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("NEXT_RUN_DTTM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CDC_COL_NM")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IS_ACTIVE")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("FREQUENCY")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("INIT_LD")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CHR_ENCODE")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("CUST_QUERY")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("IS_CLNSD")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("OBJECT_LIST")+"}]");
                log4jParamters_tMSSqlInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + (log4jParamters_tMSSqlInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlInput_1().limitLog4jByte();
	
    
	
			org.talend.designer.components.util.mssql.MSSqlGenerateTimestampUtil mssqlGTU_tMSSqlInput_1 = org.talend.designer.components.util.mssql.MSSqlUtilFactory.getMSSqlGenerateTimestampUtil();
			
			java.util.List<String> talendToDBList_tMSSqlInput_1 = new java.util.ArrayList();
			String[] talendToDBArray_tMSSqlInput_1  = new String[]{"FLOAT","NUMERIC","NUMERIC IDENTITY","DECIMAL","DECIMAL IDENTITY","REAL"}; 
			java.util.Collections.addAll(talendToDBList_tMSSqlInput_1, talendToDBArray_tMSSqlInput_1); 
		    int nb_line_tMSSqlInput_1 = 0;
		    java.sql.Connection conn_tMSSqlInput_1 = null;
		        conn_tMSSqlInput_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
				
				if(conn_tMSSqlInput_1 != null) {
					if(conn_tMSSqlInput_1.getMetaData() != null) {
						
						log.debug("tMSSqlInput_1 - Uses an existing connection with username '" + conn_tMSSqlInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
			String dbschema_tMSSqlInput_1 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
		    
			java.sql.Statement stmt_tMSSqlInput_1 = conn_tMSSqlInput_1.createStatement();

		    String dbquery_tMSSqlInput_1 = "\nSELECT IT.SRC_SYS_ID\n	, SR.SUB_SYS_ID\n	, SR.SRC_SYS_DESC\n" + ("NA".equals(context.object_position) ?
"\n	, CASE WHEN SR.SUB_SYS_DESC = SR.SRC_SYS_DESC THEN NULL ELSE SR.SUB_SYS_DESC END AS SUB_SYS_NM\n" 
:
"\n	, NULL AS SUB_SYS_NM\n") +
"\n	, IT.OBJECT_ID\n	, IT.OBJECT_NM\n	, LC.OBJECT_SCHEMA\n	, OB.PRMRY_K\n	, OB.TMSTMP_K\n	, CD.LAST_RUN_DTTM\n	, CD.NEXT_RUN_DTTM\n	, CD.CDC_COL_NM\n	, CD.IS_ACTIVE\n	, CD.FREQUENCY\n	, IT.INIT_LD\n	, IT.CHR_ENCODE\n	, LC.CUST_QUERY\n	, LC.IS_CLNSD\n	, LC.OBJECT_LIST\nFROM DBO.T_INIT_LOAD_DTL IT\n	INNER JOIN DBO.T_SRC_SYS_DCT_TBL SR\n		ON IT.SRC_SYS_ID = SR.SRC_SYS_ID\n			AND IT.SUB_SYS_ID = SR.SUB_SYS_ID\n	LEFT JOIN DBO.T_CDC_AUX_DTL CD\n		ON IT.SRC_SYS_ID = CD.SRC_SYS_ID\n			AND SR.SUB_SYS_ID = CD.SUB_SYS_ID\n			AND IT.OBJECT_ID = CD.OBJECT_ID\n	LEFT JOIN DBO.T_OBJCT_KEY_DTL OB\n		ON OB.SRC_SYS_ID = IT.SRC_SYS_ID\n			AND OB.SUB_SYS_ID = SR.SUB_SYS_ID\n			AND OB.OBJECT_ID = IT.OBJECT_ID\n	LEFT JOIN DBO.T_LOAD_CTL_DTL LC\n		ON IT.SRC_SYS_ID = LC.SRC_SYS_ID\n			AND SR.SUB_SYS_ID = LC.SUB_SYS_ID\n			AND IT.OBJECT_ID = LC.OBJECT_ID\nWHERE IT.SRC_SYS_ID = '" + context.src_sys_id + "'\n	AND SR.SUB_SYS_ID = '" + context.sub_sys_id + "'\n	AND IT.OBJECT_ID = '" + context.object_id + "'\n";
			
                log.debug("tMSSqlInput_1 - Executing the query: '"+dbquery_tMSSqlInput_1+"'.");
			

                       globalMap.put("tMSSqlInput_1_QUERY",dbquery_tMSSqlInput_1);

		    java.sql.ResultSet rs_tMSSqlInput_1 = null;
		try{
		    rs_tMSSqlInput_1 = stmt_tMSSqlInput_1.executeQuery(dbquery_tMSSqlInput_1);
		    java.sql.ResultSetMetaData rsmd_tMSSqlInput_1 = rs_tMSSqlInput_1.getMetaData();
		    int colQtyInRs_tMSSqlInput_1 = rsmd_tMSSqlInput_1.getColumnCount();

		    String tmpContent_tMSSqlInput_1 = null;
		    
		    
		    	log.debug("tMSSqlInput_1 - Retrieving records from the database.");
		    
		    while (rs_tMSSqlInput_1.next()) {
		        nb_line_tMSSqlInput_1++;
		        
							if(colQtyInRs_tMSSqlInput_1 < 1) {
								row1.SRC_SYS_ID = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(1);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(1).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SRC_SYS_ID = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SRC_SYS_ID = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SRC_SYS_ID = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 2) {
								row1.SUB_SYS_ID = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(2);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(2).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SUB_SYS_ID = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SUB_SYS_ID = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SUB_SYS_ID = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 3) {
								row1.SRC_SYS_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(3);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(3).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SRC_SYS_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SRC_SYS_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SRC_SYS_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 4) {
								row1.SUB_SYS_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(4);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(4).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.SUB_SYS_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.SUB_SYS_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.SUB_SYS_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 5) {
								row1.OBJECT_ID = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(5);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(5).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OBJECT_ID = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.OBJECT_ID = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.OBJECT_ID = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 6) {
								row1.OBJECT_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(6);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(6).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OBJECT_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.OBJECT_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.OBJECT_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 7) {
								row1.OBJECT_SCHEMA = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(7);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(7).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OBJECT_SCHEMA = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.OBJECT_SCHEMA = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.OBJECT_SCHEMA = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 8) {
								row1.PRMRY_K = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(8);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(8).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.PRMRY_K = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.PRMRY_K = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.PRMRY_K = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 9) {
								row1.TMSTMP_K = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(9);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(9).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.TMSTMP_K = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.TMSTMP_K = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.TMSTMP_K = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 10) {
								row1.LAST_RUN_DTTM = null;
							} else {
										
			row1.LAST_RUN_DTTM = mssqlGTU_tMSSqlInput_1.getDate(rsmd_tMSSqlInput_1, rs_tMSSqlInput_1, 10);
			
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 11) {
								row1.NEXT_RUN_DTTM = null;
							} else {
										
			row1.NEXT_RUN_DTTM = mssqlGTU_tMSSqlInput_1.getDate(rsmd_tMSSqlInput_1, rs_tMSSqlInput_1, 11);
			
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 12) {
								row1.CDC_COL_NM = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(12);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(12).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.CDC_COL_NM = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.CDC_COL_NM = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.CDC_COL_NM = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 13) {
								row1.IS_ACTIVE = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(13);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(13).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.IS_ACTIVE = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.IS_ACTIVE = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.IS_ACTIVE = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 14) {
								row1.FREQUENCY = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(14);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(14).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.FREQUENCY = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.FREQUENCY = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.FREQUENCY = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 15) {
								row1.INIT_LD = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(15);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(15).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.INIT_LD = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.INIT_LD = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.INIT_LD = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 16) {
								row1.CHR_ENCODE = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(16);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(16).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.CHR_ENCODE = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.CHR_ENCODE = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.CHR_ENCODE = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 17) {
								row1.CUST_QUERY = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(17);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(17).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.CUST_QUERY = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.CUST_QUERY = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.CUST_QUERY = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 18) {
								row1.IS_CLNSD = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(18);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(18).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.IS_CLNSD = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.IS_CLNSD = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.IS_CLNSD = null;
            }
		                    }
							if(colQtyInRs_tMSSqlInput_1 < 19) {
								row1.OBJECT_LIST = null;
							} else {
	                         		
           		tmpContent_tMSSqlInput_1 = rs_tMSSqlInput_1.getString(19);
            if(tmpContent_tMSSqlInput_1 != null) {
            	if (talendToDBList_tMSSqlInput_1 .contains(rsmd_tMSSqlInput_1.getColumnTypeName(19).toUpperCase(java.util.Locale.ENGLISH))) {
            		row1.OBJECT_LIST = FormatterUtils.formatUnwithE(tmpContent_tMSSqlInput_1);
            	} else {
                	row1.OBJECT_LIST = tmpContent_tMSSqlInput_1;
                }
            } else {
                row1.OBJECT_LIST = null;
            }
		                    }
					
						log.debug("tMSSqlInput_1 - Retrieving the record " + nb_line_tMSSqlInput_1 + ".");
					





 



/**
 * [tMSSqlInput_1 begin ] stop
 */
	
	/**
	 * [tMSSqlInput_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

 


	tos_count_tMSSqlInput_1++;

/**
 * [tMSSqlInput_1 main ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			//row1
			//row1


			
				if(execStat){
					runStat.updateStatOnConnection("row1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row1 - " + (row1==null? "": row1.toLogString()));
    			}
    		

globalMap.put("SRC_SYS_ID", row1.SRC_SYS_ID);
globalMap.put("SUB_SYS_ID", row1.SUB_SYS_ID);
globalMap.put("OBJECT_ID", row1.OBJECT_ID);
globalMap.put("OBJECT_NM", row1.OBJECT_NM);
globalMap.put("PRMRY_K", row1.PRMRY_K);
globalMap.put("TMSTMP_K", row1.TMSTMP_K);
globalMap.put("LAST_RUN_DTTM", row1.LAST_RUN_DTTM);
globalMap.put("NEXT_RUN_DTTM", row1.NEXT_RUN_DTTM);
globalMap.put("CDC_COL_NM", row1.CDC_COL_NM);
globalMap.put("IS_ACTIVE", row1.IS_ACTIVE);
globalMap.put("FREQUENCY", row1.FREQUENCY);
globalMap.put("INIT_LD", row1.INIT_LD);
globalMap.put("CHR_ENCODE", row1.CHR_ENCODE);
globalMap.put("CUST_QUERY", row1.CUST_QUERY);
globalMap.put("OBJECT_SCHEMA", row1.OBJECT_SCHEMA);
globalMap.put("SRC_SYS_NM", row1.SRC_SYS_NM);
globalMap.put("IS_CLNSD", row1.IS_CLNSD);
globalMap.put("OBJECT_LIST", row1.OBJECT_LIST);
globalMap.put("SUB_SYS_NM", row1.SUB_SYS_NM);

 


	tos_count_tSetGlobalVar_1++;

/**
 * [tSetGlobalVar_1 main ] stop
 */



	
	/**
	 * [tMSSqlInput_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

	}
}finally{
	stmt_tMSSqlInput_1.close();

}
globalMap.put("tMSSqlInput_1_NB_LINE",nb_line_tMSSqlInput_1);
	    		log.debug("tMSSqlInput_1 - Retrieved records count: "+nb_line_tMSSqlInput_1 + " .");
			

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlInput_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlInput_1", true);
end_Hash.put("tMSSqlInput_1", System.currentTimeMillis());




/**
 * [tMSSqlInput_1 end ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_1 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_1", true);
end_Hash.put("tSetGlobalVar_1", System.currentTimeMillis());




/**
 * [tSetGlobalVar_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tMSSqlInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tFixedFlowInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlInput_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlInput_1";

	

 



/**
 * [tMSSqlInput_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_1 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_1";

	

 



/**
 * [tSetGlobalVar_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_4", false);
		start_Hash.put("tWarn_4", System.currentTimeMillis());
		
	
	currentComponent="tWarn_4";

	
		int tos_count_tWarn_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_4 = new StringBuilder();
            log4jParamters_tWarn_4.append("Parameters:");
                    log4jParamters_tWarn_4.append("MESSAGE" + " = " + "\"204|Loading object variables failed\"");
                log4jParamters_tWarn_4.append(" | ");
                    log4jParamters_tWarn_4.append("CODE" + " = " + "999");
                log4jParamters_tWarn_4.append(" | ");
                    log4jParamters_tWarn_4.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + (log4jParamters_tWarn_4) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_4().limitLog4jByte();

 



/**
 * [tWarn_4 begin ] stop
 */
	
	/**
	 * [tWarn_4 main ] start
	 */

	

	
	
	currentComponent="tWarn_4";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_4", "", Thread.currentThread().getId() + "", "ERROR","","204|Loading object variables failed","", "");
            log.error("tWarn_4 - "  + ("Message: ")  + ("204|Loading object variables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_4", 5, "204|Loading object variables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_4_WARN_MESSAGES", "204|Loading object variables failed"); 
globalMap.put("tWarn_4_WARN_PRIORITY", 5);
globalMap.put("tWarn_4_WARN_CODE", 999);


 


	tos_count_tWarn_4++;

/**
 * [tWarn_4 main ] stop
 */
	
	/**
	 * [tWarn_4 end ] start
	 */

	

	
	
	currentComponent="tWarn_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_4 - "  + ("Done.") );

ok_Hash.put("tWarn_4", true);
end_Hash.put("tWarn_4", System.currentTimeMillis());




/**
 * [tWarn_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_4 finally ] start
	 */

	

	
	
	currentComponent="tWarn_4";

	

 



/**
 * [tWarn_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_4_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String batch_id;

				public String getBatch_id () {
					return this.batch_id;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String Jb_instnce_id;

				public String getJb_instnce_id () {
					return this.Jb_instnce_id;
				}
				
			    public String frequency;

				public String getFrequency () {
					return this.frequency;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_set_id;

				public String getObject_set_id () {
					return this.object_set_id;
				}
				
			    public String Info_dtl;

				public String getInfo_dtl () {
					return this.Info_dtl;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String JB_task_nm;

				public String getJB_task_nm () {
					return this.JB_task_nm;
				}
				
			    public String stg_id;

				public String getStg_id () {
					return this.stg_id;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.batch_id = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.Jb_instnce_id = readString(dis);
					
					this.frequency = readString(dis);
					
					this.object_id = readString(dis);
					
					this.object_set_id = readString(dis);
					
					this.Info_dtl = readString(dis);
					
					this.status = readString(dis);
					
					this.JB_task_nm = readString(dis);
					
					this.stg_id = readString(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_by = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.updt_dttm = readDate(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_nm = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.batch_id,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.Jb_instnce_id,dos);
					
					// String
				
						writeString(this.frequency,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_set_id,dos);
					
					// String
				
						writeString(this.Info_dtl,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.JB_task_nm,dos);
					
					// String
				
						writeString(this.stg_id,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("batch_id="+batch_id);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",run_id="+run_id);
		sb.append(",Jb_instnce_id="+Jb_instnce_id);
		sb.append(",frequency="+frequency);
		sb.append(",object_id="+object_id);
		sb.append(",object_set_id="+object_set_id);
		sb.append(",Info_dtl="+Info_dtl);
		sb.append(",status="+status);
		sb.append(",JB_task_nm="+JB_task_nm);
		sb.append(",stg_id="+stg_id);
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_by="+updt_by);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_nm="+object_nm);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(batch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(batch_id);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(Jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(frequency == null){
        					sb.append("<null>");
        				}else{
            				sb.append(frequency);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_set_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_set_id);
            			}
            		
        			sb.append("|");
        		
        				if(Info_dtl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Info_dtl);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(JB_task_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JB_task_nm);
            			}
            		
        			sb.append("|");
        		
        				if(stg_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stg_id);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tMSSqlOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_1", false);
		start_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_1 = new StringBuilder();
            log4jParamters_tMSSqlOutput_1.append("Parameters:");
                    log4jParamters_tMSSqlOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("TABLE" + " = " + "\"t_ingtn_trckng_dtl\"");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                    log4jParamters_tMSSqlOutput_1.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + (log4jParamters_tMSSqlOutput_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_1().limitLog4jByte();



int nb_line_tMSSqlOutput_1 = 0;
int nb_line_update_tMSSqlOutput_1 = 0;
int nb_line_inserted_tMSSqlOutput_1 = 0;
int nb_line_deleted_tMSSqlOutput_1 = 0;
int nb_line_rejected_tMSSqlOutput_1 = 0;

int deletedCount_tMSSqlOutput_1=0;
int updatedCount_tMSSqlOutput_1=0;
int insertedCount_tMSSqlOutput_1=0;
int rejectedCount_tMSSqlOutput_1=0;
String dbschema_tMSSqlOutput_1 = null;
String tableName_tMSSqlOutput_1 = null;
boolean whetherReject_tMSSqlOutput_1 = false;

java.util.Calendar calendar_tMSSqlOutput_1 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_1 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_1;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_1 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_1 = null;
String dbUser_tMSSqlOutput_1 = null;
	dbschema_tMSSqlOutput_1 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_1.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_1.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_1.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_1 == null || dbschema_tMSSqlOutput_1.trim().length() == 0) {
    tableName_tMSSqlOutput_1 = "t_ingtn_trckng_dtl";
} else {
    tableName_tMSSqlOutput_1 = dbschema_tMSSqlOutput_1 + "].[" + "t_ingtn_trckng_dtl";
}
	int count_tMSSqlOutput_1=0;

        String insert_tMSSqlOutput_1 = "INSERT INTO [" + tableName_tMSSqlOutput_1 + "] ([batch_id],[src_sys_id],[run_id],[Jb_instnce_id],[frequency],[object_id],[object_set_id],[Info_dtl],[status],[JB_task_nm],[stg_id],[crtd_by],[updt_by],[crtd_dttm],[updt_dttm],[sub_sys_id],[object_nm]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_1 = conn_tMSSqlOutput_1.prepareStatement(insert_tMSSqlOutput_1);

 	boolean isShareIdentity_tMSSqlOutput_1 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_1 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_1", false);
		start_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_1";

	
		int tos_count_tFixedFlowInput_1 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_1().limitLog4jByte();

	    for (int i_tFixedFlowInput_1 = 0 ; i_tFixedFlowInput_1 < (Relational.ISNULL(globalMap.get("OBJECT_TYPE")) ? 1 : ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? 3 : 1)) ; i_tFixedFlowInput_1++) {
	                	            	
    	            		row2.batch_id = ((String)globalMap.get("BATCH_ID"));
    	            	        	            	
    	            		row2.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row2.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row2.Jb_instnce_id = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row2.frequency = ((String)globalMap.get("FREQUENCY"));
    	            	        	            	
    	            		row2.object_id = (Relational.ISNULL(globalMap.get("OBJECT_TYPE")) ? ((String)globalMap.get("OBJECT_ID")) : ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? ((String)globalMap.get("MULTI_OBJECT_ID_" + Numeric.sequence("SEQ_OBJECT_ID_1", 1, 1))) : ((String)globalMap.get("OBJECT_ID"))));
    	            	        	            	
    	            		row2.object_set_id = ((String)globalMap.get("OBJECT_SET_ID"));
    	            	        	            	
    	            		row2.Info_dtl = ((String)globalMap.get("INFO_DTL"));
    	            	        	            	
    	            		row2.status = "P";
    	            	        	            	
    	            		row2.JB_task_nm = ((String)globalMap.get("JOB_FQ_NAME"));
    	            	        	            	
    	            		row2.stg_id = Relational.ISNULL(globalMap.get("STG_ID")) ? "1" : ((String)globalMap.get("STG_ID"));
    	            	        	            	
    	            		row2.crtd_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row2.updt_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row2.crtd_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row2.updt_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row2.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row2.object_nm = (Relational.ISNULL(globalMap.get("OBJECT_TYPE")) ? ((String)globalMap.get("OBJECT_NM")) : ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? ((String)globalMap.get("MULTI_OBJECT_NM_" + Numeric.sequence("SEQ_OBJECT_NM_1", 1, 1))) : ((String)globalMap.get("OBJECT_NM"))));
    	            	
 



/**
 * [tFixedFlowInput_1 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_1 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 


	tos_count_tFixedFlowInput_1++;

/**
 * [tFixedFlowInput_1 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_1";

	

			//row2
			//row2


			
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_1 = false;
                    if(row2.batch_id == null) {
pstmt_tMSSqlOutput_1.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(1, row2.batch_id);
}

                    if(row2.src_sys_id == null) {
pstmt_tMSSqlOutput_1.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(2, row2.src_sys_id);
}

                    if(row2.run_id == null) {
pstmt_tMSSqlOutput_1.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(3, row2.run_id);
}

                    if(row2.Jb_instnce_id == null) {
pstmt_tMSSqlOutput_1.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(4, row2.Jb_instnce_id);
}

                    if(row2.frequency == null) {
pstmt_tMSSqlOutput_1.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(5, row2.frequency);
}

                    if(row2.object_id == null) {
pstmt_tMSSqlOutput_1.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(6, row2.object_id);
}

                    if(row2.object_set_id == null) {
pstmt_tMSSqlOutput_1.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(7, row2.object_set_id);
}

                    if(row2.Info_dtl == null) {
pstmt_tMSSqlOutput_1.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(8, row2.Info_dtl);
}

                    if(row2.status == null) {
pstmt_tMSSqlOutput_1.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(9, row2.status);
}

                    if(row2.JB_task_nm == null) {
pstmt_tMSSqlOutput_1.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(10, row2.JB_task_nm);
}

                    if(row2.stg_id == null) {
pstmt_tMSSqlOutput_1.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(11, row2.stg_id);
}

                    if(row2.crtd_by == null) {
pstmt_tMSSqlOutput_1.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(12, row2.crtd_by);
}

                    if(row2.updt_by == null) {
pstmt_tMSSqlOutput_1.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(13, row2.updt_by);
}

                    if(row2.crtd_dttm != null) {
pstmt_tMSSqlOutput_1.setTimestamp(14, new java.sql.Timestamp(row2.crtd_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_1.setNull(14, java.sql.Types.DATE);
}

                    if(row2.updt_dttm != null) {
pstmt_tMSSqlOutput_1.setTimestamp(15, new java.sql.Timestamp(row2.updt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_1.setNull(15, java.sql.Types.DATE);
}

                    if(row2.sub_sys_id == null) {
pstmt_tMSSqlOutput_1.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(16, row2.sub_sys_id);
}

                    if(row2.object_nm == null) {
pstmt_tMSSqlOutput_1.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_1.setString(17, row2.object_nm);
}


            try {
                nb_line_tMSSqlOutput_1++;
                insertedCount_tMSSqlOutput_1 = insertedCount_tMSSqlOutput_1 + pstmt_tMSSqlOutput_1.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_1)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_1 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_1{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_1) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_1: pstmt_tMSSqlOutput_1.executeBatch()) {
							if(countEach_tMSSqlOutput_1 == -2 || countEach_tMSSqlOutput_1 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_1;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_1) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_1: pstmt_tMSSqlOutput_1.executeBatch()) {
							if(countEach_tMSSqlOutput_1 == -2 || countEach_tMSSqlOutput_1 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_1;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_1++;

/**
 * [tMSSqlOutput_1 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_1 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

        }
        globalMap.put("tFixedFlowInput_1_NB_LINE", (Relational.ISNULL(globalMap.get("OBJECT_TYPE")) ? 1 : ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? 3 : 1)));        

 

ok_Hash.put("tFixedFlowInput_1", true);
end_Hash.put("tFixedFlowInput_1", System.currentTimeMillis());




/**
 * [tFixedFlowInput_1 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_1";

	



        if(pstmt_tMSSqlOutput_1 != null) {
			
				pstmt_tMSSqlOutput_1.close();
			
        }


	nb_line_deleted_tMSSqlOutput_1=nb_line_deleted_tMSSqlOutput_1+ deletedCount_tMSSqlOutput_1;
	nb_line_update_tMSSqlOutput_1=nb_line_update_tMSSqlOutput_1 + updatedCount_tMSSqlOutput_1;
	nb_line_inserted_tMSSqlOutput_1=nb_line_inserted_tMSSqlOutput_1 + insertedCount_tMSSqlOutput_1;
	nb_line_rejected_tMSSqlOutput_1=nb_line_rejected_tMSSqlOutput_1 + rejectedCount_tMSSqlOutput_1;
	
        globalMap.put("tMSSqlOutput_1_NB_LINE",nb_line_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_1);
        globalMap.put("tMSSqlOutput_1_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_1);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_1)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_1", true);
end_Hash.put("tMSSqlOutput_1", System.currentTimeMillis());




/**
 * [tMSSqlOutput_1 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tFixedFlowInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_1 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_1";

	

 



/**
 * [tFixedFlowInput_1 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_1";

	



	

 



/**
 * [tMSSqlOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public java.util.Date MOMENT;

				public java.util.Date getMOMENT () {
					return this.MOMENT;
				}
				
			    public String PID;

				public String getPID () {
					return this.PID;
				}
				
			    public String FATHER_PID;

				public String getFATHER_PID () {
					return this.FATHER_PID;
				}
				
			    public String ROOT_PID;

				public String getROOT_PID () {
					return this.ROOT_PID;
				}
				
			    public Long SYSTEM_PID;

				public Long getSYSTEM_PID () {
					return this.SYSTEM_PID;
				}
				
			    public String PROJECT;

				public String getPROJECT () {
					return this.PROJECT;
				}
				
			    public String JOB;

				public String getJOB () {
					return this.JOB;
				}
				
			    public String JOB_REPOSITORY_ID;

				public String getJOB_REPOSITORY_ID () {
					return this.JOB_REPOSITORY_ID;
				}
				
			    public String JOB_VERSION;

				public String getJOB_VERSION () {
					return this.JOB_VERSION;
				}
				
			    public String CONTEXT;

				public String getCONTEXT () {
					return this.CONTEXT;
				}
				
			    public String ORIGIN;

				public String getORIGIN () {
					return this.ORIGIN;
				}
				
			    public String MESSAGE_TYPE;

				public String getMESSAGE_TYPE () {
					return this.MESSAGE_TYPE;
				}
				
			    public String MESSAGE;

				public String getMESSAGE () {
					return this.MESSAGE;
				}
				
			    public Long DURATION;

				public Long getDURATION () {
					return this.DURATION;
				}
				
			    public String SRC_SYS_ID;

				public String getSRC_SYS_ID () {
					return this.SRC_SYS_ID;
				}
				
			    public String SUB_SYS_ID;

				public String getSUB_SYS_ID () {
					return this.SUB_SYS_ID;
				}
				
			    public String OBJECT_NM;

				public String getOBJECT_NM () {
					return this.OBJECT_NM;
				}
				
			    public String RUN_ID;

				public String getRUN_ID () {
					return this.RUN_ID;
				}
				
			    public String JB_INSTNCE_ID;

				public String getJB_INSTNCE_ID () {
					return this.JB_INSTNCE_ID;
				}
				
			    public String OBJECT_ID;

				public String getOBJECT_ID () {
					return this.OBJECT_ID;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.MOMENT = readDate(dis);
					
					this.PID = readString(dis);
					
					this.FATHER_PID = readString(dis);
					
					this.ROOT_PID = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.SYSTEM_PID = null;
           				} else {
           			    	this.SYSTEM_PID = dis.readLong();
           				}
					
					this.PROJECT = readString(dis);
					
					this.JOB = readString(dis);
					
					this.JOB_REPOSITORY_ID = readString(dis);
					
					this.JOB_VERSION = readString(dis);
					
					this.CONTEXT = readString(dis);
					
					this.ORIGIN = readString(dis);
					
					this.MESSAGE_TYPE = readString(dis);
					
					this.MESSAGE = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.DURATION = null;
           				} else {
           			    	this.DURATION = dis.readLong();
           				}
					
					this.SRC_SYS_ID = readString(dis);
					
					this.SUB_SYS_ID = readString(dis);
					
					this.OBJECT_NM = readString(dis);
					
					this.RUN_ID = readString(dis);
					
					this.JB_INSTNCE_ID = readString(dis);
					
					this.OBJECT_ID = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.MOMENT,dos);
					
					// String
				
						writeString(this.PID,dos);
					
					// String
				
						writeString(this.FATHER_PID,dos);
					
					// String
				
						writeString(this.ROOT_PID,dos);
					
					// Long
				
						if(this.SYSTEM_PID == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.SYSTEM_PID);
		            	}
					
					// String
				
						writeString(this.PROJECT,dos);
					
					// String
				
						writeString(this.JOB,dos);
					
					// String
				
						writeString(this.JOB_REPOSITORY_ID,dos);
					
					// String
				
						writeString(this.JOB_VERSION,dos);
					
					// String
				
						writeString(this.CONTEXT,dos);
					
					// String
				
						writeString(this.ORIGIN,dos);
					
					// String
				
						writeString(this.MESSAGE_TYPE,dos);
					
					// String
				
						writeString(this.MESSAGE,dos);
					
					// Long
				
						if(this.DURATION == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.DURATION);
		            	}
					
					// String
				
						writeString(this.SRC_SYS_ID,dos);
					
					// String
				
						writeString(this.SUB_SYS_ID,dos);
					
					// String
				
						writeString(this.OBJECT_NM,dos);
					
					// String
				
						writeString(this.RUN_ID,dos);
					
					// String
				
						writeString(this.JB_INSTNCE_ID,dos);
					
					// String
				
						writeString(this.OBJECT_ID,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("MOMENT="+String.valueOf(MOMENT));
		sb.append(",PID="+PID);
		sb.append(",FATHER_PID="+FATHER_PID);
		sb.append(",ROOT_PID="+ROOT_PID);
		sb.append(",SYSTEM_PID="+String.valueOf(SYSTEM_PID));
		sb.append(",PROJECT="+PROJECT);
		sb.append(",JOB="+JOB);
		sb.append(",JOB_REPOSITORY_ID="+JOB_REPOSITORY_ID);
		sb.append(",JOB_VERSION="+JOB_VERSION);
		sb.append(",CONTEXT="+CONTEXT);
		sb.append(",ORIGIN="+ORIGIN);
		sb.append(",MESSAGE_TYPE="+MESSAGE_TYPE);
		sb.append(",MESSAGE="+MESSAGE);
		sb.append(",DURATION="+String.valueOf(DURATION));
		sb.append(",SRC_SYS_ID="+SRC_SYS_ID);
		sb.append(",SUB_SYS_ID="+SUB_SYS_ID);
		sb.append(",OBJECT_NM="+OBJECT_NM);
		sb.append(",RUN_ID="+RUN_ID);
		sb.append(",JB_INSTNCE_ID="+JB_INSTNCE_ID);
		sb.append(",OBJECT_ID="+OBJECT_ID);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(MOMENT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MOMENT);
            			}
            		
        			sb.append("|");
        		
        				if(PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PID);
            			}
            		
        			sb.append("|");
        		
        				if(FATHER_PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(FATHER_PID);
            			}
            		
        			sb.append("|");
        		
        				if(ROOT_PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ROOT_PID);
            			}
            		
        			sb.append("|");
        		
        				if(SYSTEM_PID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SYSTEM_PID);
            			}
            		
        			sb.append("|");
        		
        				if(PROJECT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(PROJECT);
            			}
            		
        			sb.append("|");
        		
        				if(JOB == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_REPOSITORY_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_REPOSITORY_ID);
            			}
            		
        			sb.append("|");
        		
        				if(JOB_VERSION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JOB_VERSION);
            			}
            		
        			sb.append("|");
        		
        				if(CONTEXT == null){
        					sb.append("<null>");
        				}else{
            				sb.append(CONTEXT);
            			}
            		
        			sb.append("|");
        		
        				if(ORIGIN == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ORIGIN);
            			}
            		
        			sb.append("|");
        		
        				if(MESSAGE_TYPE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MESSAGE_TYPE);
            			}
            		
        			sb.append("|");
        		
        				if(MESSAGE == null){
        					sb.append("<null>");
        				}else{
            				sb.append(MESSAGE);
            			}
            		
        			sb.append("|");
        		
        				if(DURATION == null){
        					sb.append("<null>");
        				}else{
            				sb.append(DURATION);
            			}
            		
        			sb.append("|");
        		
        				if(SRC_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SRC_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(SUB_SYS_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(SUB_SYS_ID);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_NM == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_NM);
            			}
            		
        			sb.append("|");
        		
        				if(RUN_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(RUN_ID);
            			}
            		
        			sb.append("|");
        		
        				if(JB_INSTNCE_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(JB_INSTNCE_ID);
            			}
            		
        			sb.append("|");
        		
        				if(OBJECT_ID == null){
        					sb.append("<null>");
        				}else{
            				sb.append(OBJECT_ID);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tMSSqlOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_2", false);
		start_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_2 = new StringBuilder();
            log4jParamters_tMSSqlOutput_2.append("Parameters:");
                    log4jParamters_tMSSqlOutput_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("TABLE" + " = " + "\"statcatcher\"");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                    log4jParamters_tMSSqlOutput_2.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + (log4jParamters_tMSSqlOutput_2) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_2().limitLog4jByte();



int nb_line_tMSSqlOutput_2 = 0;
int nb_line_update_tMSSqlOutput_2 = 0;
int nb_line_inserted_tMSSqlOutput_2 = 0;
int nb_line_deleted_tMSSqlOutput_2 = 0;
int nb_line_rejected_tMSSqlOutput_2 = 0;

int deletedCount_tMSSqlOutput_2=0;
int updatedCount_tMSSqlOutput_2=0;
int insertedCount_tMSSqlOutput_2=0;
int rejectedCount_tMSSqlOutput_2=0;
String dbschema_tMSSqlOutput_2 = null;
String tableName_tMSSqlOutput_2 = null;
boolean whetherReject_tMSSqlOutput_2 = false;

java.util.Calendar calendar_tMSSqlOutput_2 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_2 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_2;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_2 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_2 = null;
String dbUser_tMSSqlOutput_2 = null;
	dbschema_tMSSqlOutput_2 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_2 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_2.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_2.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_2.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_2 == null || dbschema_tMSSqlOutput_2.trim().length() == 0) {
    tableName_tMSSqlOutput_2 = "statcatcher";
} else {
    tableName_tMSSqlOutput_2 = dbschema_tMSSqlOutput_2 + "].[" + "statcatcher";
}
	int count_tMSSqlOutput_2=0;

        String insert_tMSSqlOutput_2 = "INSERT INTO [" + tableName_tMSSqlOutput_2 + "] ([MOMENT],[PID],[FATHER_PID],[ROOT_PID],[SYSTEM_PID],[PROJECT],[JOB],[JOB_REPOSITORY_ID],[JOB_VERSION],[CONTEXT],[ORIGIN],[MESSAGE_TYPE],[MESSAGE],[DURATION],[SRC_SYS_ID],[SUB_SYS_ID],[OBJECT_NM],[RUN_ID],[JB_INSTNCE_ID],[OBJECT_ID]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_2 = conn_tMSSqlOutput_2.prepareStatement(insert_tMSSqlOutput_2);

 	boolean isShareIdentity_tMSSqlOutput_2 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_2 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_2", false);
		start_Hash.put("tFixedFlowInput_2", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_2";

	
		int tos_count_tFixedFlowInput_2 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_2().limitLog4jByte();

	    for (int i_tFixedFlowInput_2 = 0 ; i_tFixedFlowInput_2 < 1 ; i_tFixedFlowInput_2++) {
	                	            	
    	            		row3.MOMENT = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row3.PID = pid;
    	            	        	            	
    	            		row3.FATHER_PID = context.root_pid;
    	            	        	            	
    	            		row3.ROOT_PID = context.root_pid;
    	            	        	            	
    	            		row3.SYSTEM_PID = null;
    	            	        	            	
    	            		row3.PROJECT = projectName;
    	            	        	            	
    	            		row3.JOB = jobName;
    	            	        	            	
    	            		row3.JOB_REPOSITORY_ID = null;
    	            	        	            	
    	            		row3.JOB_VERSION = jobVersion;
    	            	        	            	
    	            		row3.CONTEXT = contextStr ;
    	            	        	            	
    	            		row3.ORIGIN = null;
    	            	        	            	
    	            		row3.MESSAGE_TYPE = "begin";
    	            	        	            	
    	            		row3.MESSAGE = (!Relational.ISNULL((String)globalMap.get("LOAD_STATUS")) && "F".equals((String)globalMap.get("LOAD_STATUS")))?"failure":(!Relational.ISNULL((String)globalMap.get("LOAD_STATUS")) && "C".equals((String)globalMap.get("LOAD_STATUS")))?"success":null;
    	            	        	            	
    	            		row3.DURATION = (!Relational.ISNULL((String)globalMap.get("LOAD_STATUS")) && ("C".equals((String)globalMap.get("LOAD_STATUS"))||"F".equals((String)globalMap.get("LOAD_STATUS"))))?TalendDate.diffDate(TalendDate.getCurrentDate(),((Date)globalMap.get("JOB_STARTTIME")),"SSS"):null;
    	            	        	            	
    	            		row3.SRC_SYS_ID = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row3.SUB_SYS_ID = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row3.OBJECT_NM = ((String)globalMap.get("OBJECT_NM"));
    	            	        	            	
    	            		row3.RUN_ID = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row3.JB_INSTNCE_ID = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row3.OBJECT_ID = ((String)globalMap.get("OBJECT_ID"));
    	            	
 



/**
 * [tFixedFlowInput_2 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_2 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";

	

 


	tos_count_tFixedFlowInput_2++;

/**
 * [tFixedFlowInput_2 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_2 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_2";

	

			//row3
			//row3


			
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_2 = false;
                    if(row3.MOMENT != null) {
pstmt_tMSSqlOutput_2.setTimestamp(1, new java.sql.Timestamp(row3.MOMENT.getTime()));
} else {
pstmt_tMSSqlOutput_2.setNull(1, java.sql.Types.DATE);
}

                    if(row3.PID == null) {
pstmt_tMSSqlOutput_2.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(2, row3.PID);
}

                    if(row3.FATHER_PID == null) {
pstmt_tMSSqlOutput_2.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(3, row3.FATHER_PID);
}

                    if(row3.ROOT_PID == null) {
pstmt_tMSSqlOutput_2.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(4, row3.ROOT_PID);
}

                    if(row3.SYSTEM_PID == null) {
pstmt_tMSSqlOutput_2.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_2.setLong(5, row3.SYSTEM_PID);
}

                    if(row3.PROJECT == null) {
pstmt_tMSSqlOutput_2.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(6, row3.PROJECT);
}

                    if(row3.JOB == null) {
pstmt_tMSSqlOutput_2.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(7, row3.JOB);
}

                    if(row3.JOB_REPOSITORY_ID == null) {
pstmt_tMSSqlOutput_2.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(8, row3.JOB_REPOSITORY_ID);
}

                    if(row3.JOB_VERSION == null) {
pstmt_tMSSqlOutput_2.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(9, row3.JOB_VERSION);
}

                    if(row3.CONTEXT == null) {
pstmt_tMSSqlOutput_2.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(10, row3.CONTEXT);
}

                    if(row3.ORIGIN == null) {
pstmt_tMSSqlOutput_2.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(11, row3.ORIGIN);
}

                    if(row3.MESSAGE_TYPE == null) {
pstmt_tMSSqlOutput_2.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(12, row3.MESSAGE_TYPE);
}

                    if(row3.MESSAGE == null) {
pstmt_tMSSqlOutput_2.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(13, row3.MESSAGE);
}

                    if(row3.DURATION == null) {
pstmt_tMSSqlOutput_2.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_2.setLong(14, row3.DURATION);
}

                    if(row3.SRC_SYS_ID == null) {
pstmt_tMSSqlOutput_2.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(15, row3.SRC_SYS_ID);
}

                    if(row3.SUB_SYS_ID == null) {
pstmt_tMSSqlOutput_2.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(16, row3.SUB_SYS_ID);
}

                    if(row3.OBJECT_NM == null) {
pstmt_tMSSqlOutput_2.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(17, row3.OBJECT_NM);
}

                    if(row3.RUN_ID == null) {
pstmt_tMSSqlOutput_2.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(18, row3.RUN_ID);
}

                    if(row3.JB_INSTNCE_ID == null) {
pstmt_tMSSqlOutput_2.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(19, row3.JB_INSTNCE_ID);
}

                    if(row3.OBJECT_ID == null) {
pstmt_tMSSqlOutput_2.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_2.setString(20, row3.OBJECT_ID);
}


            try {
                nb_line_tMSSqlOutput_2++;
                insertedCount_tMSSqlOutput_2 = insertedCount_tMSSqlOutput_2 + pstmt_tMSSqlOutput_2.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_2)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_2 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_2{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_2) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_2: pstmt_tMSSqlOutput_2.executeBatch()) {
							if(countEach_tMSSqlOutput_2 == -2 || countEach_tMSSqlOutput_2 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_2;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_2) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_2: pstmt_tMSSqlOutput_2.executeBatch()) {
							if(countEach_tMSSqlOutput_2 == -2 || countEach_tMSSqlOutput_2 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_2;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_2++;

/**
 * [tMSSqlOutput_2 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_2 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";

	

        }
        globalMap.put("tFixedFlowInput_2_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_2", true);
end_Hash.put("tFixedFlowInput_2", System.currentTimeMillis());




/**
 * [tFixedFlowInput_2 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_2 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_2";

	



        if(pstmt_tMSSqlOutput_2 != null) {
			
				pstmt_tMSSqlOutput_2.close();
			
        }


	nb_line_deleted_tMSSqlOutput_2=nb_line_deleted_tMSSqlOutput_2+ deletedCount_tMSSqlOutput_2;
	nb_line_update_tMSSqlOutput_2=nb_line_update_tMSSqlOutput_2 + updatedCount_tMSSqlOutput_2;
	nb_line_inserted_tMSSqlOutput_2=nb_line_inserted_tMSSqlOutput_2 + insertedCount_tMSSqlOutput_2;
	nb_line_rejected_tMSSqlOutput_2=nb_line_rejected_tMSSqlOutput_2 + rejectedCount_tMSSqlOutput_2;
	
        globalMap.put("tMSSqlOutput_2_NB_LINE",nb_line_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_2);
        globalMap.put("tMSSqlOutput_2_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_2);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_2)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row3"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_2 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_2", true);
end_Hash.put("tMSSqlOutput_2", System.currentTimeMillis());




/**
 * [tMSSqlOutput_2 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tJava_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_2 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_2";

	

 



/**
 * [tFixedFlowInput_2 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_2";

	



	

 



/**
 * [tMSSqlOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_7", false);
		start_Hash.put("tWarn_7", System.currentTimeMillis());
		
	
	currentComponent="tWarn_7";

	
		int tos_count_tWarn_7 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_7{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_7 = new StringBuilder();
            log4jParamters_tWarn_7.append("Parameters:");
                    log4jParamters_tWarn_7.append("MESSAGE" + " = " + "\"206|Insert into stats table failed\"");
                log4jParamters_tWarn_7.append(" | ");
                    log4jParamters_tWarn_7.append("CODE" + " = " + "999");
                log4jParamters_tWarn_7.append(" | ");
                    log4jParamters_tWarn_7.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_7.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + (log4jParamters_tWarn_7) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_7().limitLog4jByte();

 



/**
 * [tWarn_7 begin ] stop
 */
	
	/**
	 * [tWarn_7 main ] start
	 */

	

	
	
	currentComponent="tWarn_7";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_7", "", Thread.currentThread().getId() + "", "ERROR","","206|Insert into stats table failed","", "");
            log.error("tWarn_7 - "  + ("Message: ")  + ("206|Insert into stats table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_7", 5, "206|Insert into stats table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_7_WARN_MESSAGES", "206|Insert into stats table failed"); 
globalMap.put("tWarn_7_WARN_PRIORITY", 5);
globalMap.put("tWarn_7_WARN_CODE", 999);


 


	tos_count_tWarn_7++;

/**
 * [tWarn_7 main ] stop
 */
	
	/**
	 * [tWarn_7 end ] start
	 */

	

	
	
	currentComponent="tWarn_7";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_7 - "  + ("Done.") );

ok_Hash.put("tWarn_7", true);
end_Hash.put("tWarn_7", System.currentTimeMillis());




/**
 * [tWarn_7 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_7 finally ] start
	 */

	

	
	
	currentComponent="tWarn_7";

	

 



/**
 * [tWarn_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_7_SUBPROCESS_STATE", 1);
	}
	

public void tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";

	
		int tos_count_tJava_3 = 0;
		
    	class BytesLimit65535_tJava_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_3().limitLog4jByte();


String dynamicQuery = "";

//***************** for dynamic query *********************//
String lst_run_dttm = (Relational.ISNULL(globalMap.get("LAST_RUN_DTTM")) ? null : TalendDate.formatDate("yyyyMMddHHmmssSSS", ((Date)globalMap.get("LAST_RUN_DTTM"))));

globalMap.put("NEXT_RUN_DTTM", TalendDate.addDate(TalendDate.getCurrentDate(), -3, "mm"));

String nxt_run_dttm = (Relational.ISNULL(globalMap.get("NEXT_RUN_DTTM")) ? null : TalendDate.formatDate("yyyyMMddHHmmssSSS", ((Date)globalMap.get("NEXT_RUN_DTTM"))));

if (!Relational.ISNULL(globalMap.get("CUST_QUERY")) && !"".equals(((String)globalMap.get("CUST_QUERY"))) && !"[]".equals(((String)globalMap.get("CUST_QUERY"))) && !Relational.ISNULL(globalMap.get("IS_ACTIVE")) && "Y".equals(((String)globalMap.get("IS_ACTIVE")))) {

	dynamicQuery= ((String)globalMap.get("CUST_QUERY")) + " where  " + ((String)globalMap.get("CDC_COL_NM")) + " > to_timestamp('" + lst_run_dttm + "', 'YYYYMMDDHH24MISSFF3') and " + ((String)globalMap.get("CDC_COL_NM")) + "<= to_timestamp('" + nxt_run_dttm + "', 'YYYYMMDDHH24MISSFF3')" ;

} else if (!Relational.ISNULL(globalMap.get("CUST_QUERY")) && !"".equals(((String)globalMap.get("CUST_QUERY"))) && !"[]".equals(((String)globalMap.get("CUST_QUERY"))) && !Relational.ISNULL(globalMap.get("IS_ACTIVE")) && "N".equals(((String)globalMap.get("IS_ACTIVE")))) {
	
	dynamicQuery = ((String)globalMap.get("CUST_QUERY"));
	globalMap.put("IS_ACTIVE", "N");
	
} else if ((Relational.ISNULL(globalMap.get("CUST_QUERY")) || "".equals(((String)globalMap.get("CUST_QUERY"))) || "[]".equals(((String)globalMap.get("CUST_QUERY")))) && (!Relational.ISNULL(globalMap.get("IS_ACTIVE")) && "Y".equals(((String)globalMap.get("IS_ACTIVE")))) ) {     

	dynamicQuery = "select * from " + ((String)globalMap.get("OBJECT_SCHEMA")) + "." + ((String)globalMap.get("OBJECT_NM")) + " where  " + ((String)globalMap.get("CDC_COL_NM")) + " > to_timestamp('" + lst_run_dttm + "', 'YYYYMMDDHH24MISSFF3') and " + ((String)globalMap.get("CDC_COL_NM")) + "<= to_timestamp('" + nxt_run_dttm + "', 'YYYYMMDDHH24MISSFF3')" ;

} else {
 
	dynamicQuery = "select * from " + ((String)globalMap.get("OBJECT_SCHEMA")) + "." + ((String)globalMap.get("OBJECT_NM"));
	globalMap.put("IS_ACTIVE", "N");
	
}

globalMap.put("DYNAMIC_QUERY", dynamicQuery);

globalMap.put("FILE_EXTENSION", (Relational.ISNULL("FILE_EXTENSION") ? ".csv" : ((String)globalMap.get("FILE_EXTENSION"))));

globalMap.put("FILE_NAME", ((String)globalMap.get("OBJECT_NM")) + "_" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "." + ((String)globalMap.get("FILE_EXTENSION")));

if (!Relational.ISNULL(globalMap.get("ADLS_LANDING_PATH")) && ((String)globalMap.get("ADLS_LANDING_PATH")).trim().length() > 0) {

	String [] pathFolders = ((String)globalMap.get("ADLS_LANDING_PATH")).trim().split("/");
	String adlsPath = "";

	for (int i=0;i<pathFolders.length;i++) {

		if ("".equals(pathFolders[i])) {
			//do nothing
		} else if ("SOURCE_SYSTEM_NAME".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + (Relational.ISNULL(globalMap.get("SRC_SYS_NM")) ? "" : ((String)globalMap.get("SRC_SYS_NM")));
		} else if ("SUB_SYSTEM_NAME".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + (Relational.ISNULL(globalMap.get("SUB_SYS_NM")) ? "" : ((String)globalMap.get("SUB_SYS_NM")));
		} else if ("OBJECT_NAME".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + (Relational.ISNULL(globalMap.get("OBJECT_NM")) ? "" : ((String)globalMap.get("OBJECT_NM")));
		} else if ("YYYY".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + TalendDate.formatDate("yyyy", TalendDate.getCurrentDate());
		} else if ("MM".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + TalendDate.formatDate("MM", TalendDate.getCurrentDate());
		} else if ("DD".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + TalendDate.formatDate("dd", TalendDate.getCurrentDate());
		} else {
			adlsPath += "/" + pathFolders[i];
		}
	}
	
	globalMap.put("ADLS_FILE_PATH", adlsPath);

} else {

	if ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE"))) {
		globalMap.put("ADLS_FILE_PATH", ((String)globalMap.get("OUT_FILE_LOCTN")) + "/" + ((String)globalMap.get("SRC_SYS_NM")) + (Relational.ISNULL((String)globalMap.get("SUB_SYS_NM")) ? "" : "_" + ((String)globalMap.get("SUB_SYS_NM"))));
	} else {
		globalMap.put("ADLS_FILE_PATH", ((String)globalMap.get("OUT_FILE_LOCTN")) + "/" + ((String)globalMap.get("SRC_SYS_NM")) + (Relational.ISNULL((String)globalMap.get("SUB_SYS_NM")) ? "" : "_" + ((String)globalMap.get("SUB_SYS_NM"))) + "/" + ((String)globalMap.get("OBJECT_NM")) + "/" + TalendDate.formatDate("yyyy/MM/dd", TalendDate.getCurrentDate()));
	}
	
}

if (!Relational.ISNULL(globalMap.get("ADLS_STAGING_PATH")) && ((String)globalMap.get("ADLS_STAGING_PATH")).trim().length() > 0) {

	String [] pathFolders = ((String)globalMap.get("ADLS_STAGING_PATH")).trim().split("/");
	String adlsPath = "";

	for (int i=0;i<pathFolders.length;i++) {

		if ("".equals(pathFolders[i])) {
			//do nothing
		} else if ("SOURCE_SYSTEM_NAME".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + (Relational.ISNULL(globalMap.get("SRC_SYS_NM")) ? "" : ((String)globalMap.get("SRC_SYS_NM")));
		} else if ("SUB_SYSTEM_NAME".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + (Relational.ISNULL(globalMap.get("SUB_SYS_NM")) ? "" : ((String)globalMap.get("SUB_SYS_NM")));
		} else if ("OBJECT_NAME".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + (Relational.ISNULL(globalMap.get("OBJECT_NM")) ? "" : ((String)globalMap.get("OBJECT_NM")));
		} else if ("YYYY".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + TalendDate.formatDate("yyyy", TalendDate.getCurrentDate());
		} else if ("MM".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + TalendDate.formatDate("MM", TalendDate.getCurrentDate());
		} else if ("DD".equalsIgnoreCase(pathFolders[i])) {
			adlsPath += "/" + TalendDate.formatDate("dd", TalendDate.getCurrentDate());
		} else {
			adlsPath += "/" + pathFolders[i];
		}
	}
	
	globalMap.put("ADLS_MERGE_PATH", adlsPath);

} else {

	if ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE"))) {
		globalMap.put("ADLS_MERGE_PATH", ((String)globalMap.get("MRGD_FILE_LOCTN")) + "/" + ((String)globalMap.get("SRC_SYS_NM")) + (Relational.ISNULL((String)globalMap.get("SUB_SYS_NM")) ? "" : "/" + ((String)globalMap.get("SUB_SYS_NM"))));
	} else {
		globalMap.put("ADLS_MERGE_PATH", ((String)globalMap.get("MRGD_FILE_LOCTN")) + "/" + ((String)globalMap.get("SRC_SYS_NM")) + (Relational.ISNULL((String)globalMap.get("SUB_SYS_NM")) ? "" : "/" + ((String)globalMap.get("SUB_SYS_NM"))) + "/" + ((String)globalMap.get("OBJECT_NM")));
	}

}

globalMap.put("LOCAL_DIRECTORY", ((String)globalMap.get("TALEND_FILE_PATH")) + "/" + ((String)globalMap.get("SRC_SYS_NM")) + (Relational.ISNULL((String)globalMap.get("SUB_SYS_NM")) ? "" : "/" + ((String)globalMap.get("SUB_SYS_NM"))) + "/" + context.root_pid + "/" + ((String)globalMap.get("OBJECT_NM")));

new java.io.File(((String)globalMap.get("LOCAL_DIRECTORY")) + "/Outbound").mkdirs();

globalMap.put("JDBC_URL", ("PROD".equals(contextStr) ? "jdbc:oracle:thin:@" + ((String)globalMap.get("SOURCE_HOSTNAME")) + ":" + ((String)globalMap.get("SOURCE_PORT")) + "/" + ((String)globalMap.get("SOURCE_DATABASE")) + "" : "jdbc:oracle:thin:@" + ((String)globalMap.get("SOURCE_HOSTNAME")) + ":" + ((String)globalMap.get("SOURCE_PORT")) + ":" + ((String)globalMap.get("SOURCE_DATABASE")) + ""));
 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk14", 0, "ok");
				}
				tFixedFlowInput_10Process(globalMap);



/**
 * [tJava_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk7", 0, "ok");
								} 
							
							tJava_8Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}
	

public void tJava_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_8", false);
		start_Hash.put("tJava_8", System.currentTimeMillis());
		
	
	currentComponent="tJava_8";

	
		int tos_count_tJava_8 = 0;
		
    	class BytesLimit65535_tJava_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_8().limitLog4jByte();


globalMap.put("INPROGRESS_COUNT", 2);
 



/**
 * [tJava_8 begin ] stop
 */
	
	/**
	 * [tJava_8 main ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 


	tos_count_tJava_8++;

/**
 * [tJava_8 main ] stop
 */
	
	/**
	 * [tJava_8 end ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 

ok_Hash.put("tJava_8", true);
end_Hash.put("tJava_8", System.currentTimeMillis());

   			if (Relational.ISNULL(globalMap.get("OBJECT_TYPE"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "true");
					}
				
    			tOracleInput_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If11", 0, "false");
					}   	 
   				}
   			if ("CUSTOM_JDBC".equals((String)globalMap.get("OBJECT_TYPE"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If16", 0, "true");
					}
				
    			tLibraryLoad_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If16", 0, "false");
					}   	 
   				}
   			if ("CUSTOM_VERSION_12_7".equals((String)globalMap.get("OBJECT_TYPE"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If19", 0, "true");
					}
				
    			tOracleInput_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If19", 0, "false");
					}   	 
   				}



/**
 * [tJava_8 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_8:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tJava_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_8 finally ] start
	 */

	

	
	
	currentComponent="tJava_8";

	

 



/**
 * [tJava_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_8_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_9", false);
		start_Hash.put("tWarn_9", System.currentTimeMillis());
		
	
	currentComponent="tWarn_9";

	
		int tos_count_tWarn_9 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_9{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_9 = new StringBuilder();
            log4jParamters_tWarn_9.append("Parameters:");
                    log4jParamters_tWarn_9.append("MESSAGE" + " = " + "\"208|Source extraction failed\"");
                log4jParamters_tWarn_9.append(" | ");
                    log4jParamters_tWarn_9.append("CODE" + " = " + "999");
                log4jParamters_tWarn_9.append(" | ");
                    log4jParamters_tWarn_9.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_9.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + (log4jParamters_tWarn_9) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_9().limitLog4jByte();

 



/**
 * [tWarn_9 begin ] stop
 */
	
	/**
	 * [tWarn_9 main ] start
	 */

	

	
	
	currentComponent="tWarn_9";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_9", "", Thread.currentThread().getId() + "", "ERROR","","208|Source extraction failed","", "");
            log.error("tWarn_9 - "  + ("Message: ")  + ("208|Source extraction failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_9", 5, "208|Source extraction failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_9_WARN_MESSAGES", "208|Source extraction failed"); 
globalMap.put("tWarn_9_WARN_PRIORITY", 5);
globalMap.put("tWarn_9_WARN_CODE", 999);


 


	tos_count_tWarn_9++;

/**
 * [tWarn_9 main ] stop
 */
	
	/**
	 * [tWarn_9 end ] start
	 */

	

	
	
	currentComponent="tWarn_9";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_9 - "  + ("Done.") );

ok_Hash.put("tWarn_9", true);
end_Hash.put("tWarn_9", System.currentTimeMillis());




/**
 * [tWarn_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_9 finally ] start
	 */

	

	
	
	currentComponent="tWarn_9";

	

 



/**
 * [tWarn_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_9_SUBPROCESS_STATE", 1);
	}
	

public void tJava_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";

	
		int tos_count_tJava_5 = 0;
		
    	class BytesLimit65535_tJava_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_5().limitLog4jByte();



 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());

   			if ("SP_SINGLE".equals((String)globalMap.get("OBJECT_TYPE"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "true");
					}
				
    			tOracleSP_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If6", 0, "false");
					}   	 
   				}



/**
 * [tJava_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk21", 0, "ok");
								} 
							
							tJava_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_5_SUBPROCESS_STATE", 1);
	}
	


public static class out2Struct implements routines.system.IPersistableRow<out2Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				
			    public String etl_crtd_by;

				public String getEtl_crtd_by () {
					return this.etl_crtd_by;
				}
				
			    public java.util.Date etl_crtd_dt;

				public java.util.Date getEtl_crtd_dt () {
					return this.etl_crtd_dt;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
					this.etl_crtd_by = readString(dis);
					
					this.etl_crtd_dt = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
					// String
				
						writeString(this.etl_crtd_by,dos);
					
					// java.util.Date
				
						writeDate(this.etl_crtd_dt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
		sb.append(",etl_crtd_by="+etl_crtd_by);
		sb.append(",etl_crtd_dt="+String.valueOf(etl_crtd_dt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_dt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_dt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row21Struct implements routines.system.IPersistableRow<row21Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic data_row;

				public routines.system.Dynamic getData_row () {
					return this.data_row;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.data_row = (routines.system.Dynamic) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.data_row);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("data_row="+String.valueOf(data_row));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(data_row == null){
        					sb.append("<null>");
        				}else{
            				sb.append(data_row);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row21Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row20Struct implements routines.system.IPersistableRow<row20Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public Object out_ref_cursor;

				public Object getOut_ref_cursor () {
					return this.out_ref_cursor;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.out_ref_cursor = (Object) dis.readObject();
					
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Object
				
       			    	dos.writeObject(this.out_ref_cursor);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("out_ref_cursor="+String.valueOf(out_ref_cursor));
		sb.append(",object_id="+object_id);
		sb.append(",object_nm="+object_nm);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(out_ref_cursor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_ref_cursor);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row20Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row19Struct implements routines.system.IPersistableRow<row19Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public Object out_ref_cursor;

				public Object getOut_ref_cursor () {
					return this.out_ref_cursor;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.out_ref_cursor = (Object) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Object
				
       			    	dos.writeObject(this.out_ref_cursor);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("out_ref_cursor="+String.valueOf(out_ref_cursor));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(out_ref_cursor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_ref_cursor);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row19Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tOracleSP_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleSP_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row19Struct row19 = new row19Struct();
row20Struct row20 = new row20Struct();
row21Struct row21 = new row21Struct();
out2Struct out2 = new out2Struct();





	
	/**
	 * [tFlowToIterate_5 begin ] start
	 */

				
			int NB_ITERATE_tJavaFlex_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_5", false);
		start_Hash.put("tFlowToIterate_5", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row20" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_5 = new StringBuilder();
            log4jParamters_tFlowToIterate_5.append("Parameters:");
                    log4jParamters_tFlowToIterate_5.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + (log4jParamters_tFlowToIterate_5) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_5().limitLog4jByte();

int nb_line_tFlowToIterate_5 = 0;
int counter_tFlowToIterate_5 = 0;

 



/**
 * [tFlowToIterate_5 begin ] stop
 */



	
	/**
	 * [tSplitRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSplitRow_2", false);
		start_Hash.put("tSplitRow_2", System.currentTimeMillis());
		
	
	currentComponent="tSplitRow_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row19" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSplitRow_2 = 0;
		
    	class BytesLimit65535_tSplitRow_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tSplitRow_2().limitLog4jByte();
int nb_line_tSplitRow_2 = 0;
 



/**
 * [tSplitRow_2 begin ] stop
 */



	
	/**
	 * [tOracleSP_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleSP_3", false);
		start_Hash.put("tOracleSP_3", System.currentTimeMillis());
		
	
	currentComponent="tOracleSP_3";

	
		int tos_count_tOracleSP_3 = 0;
		
    	class BytesLimit65535_tOracleSP_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tOracleSP_3().limitLog4jByte();

	java.sql.Connection connection_tOracleSP_3 = null;
	connection_tOracleSP_3 = (java.sql.Connection) globalMap.get("conn_tOracleConnection_1");
	

java.sql.CallableStatement statement_tOracleSP_3 = connection_tOracleSP_3.prepareCall("{call " + ((String)globalMap.get("OBJECT_LIST")) + "(?)}");

java.sql.Timestamp tmpDate_tOracleSP_3;
String tmpString_tOracleSP_3;

 



/**
 * [tOracleSP_3 begin ] stop
 */
	
	/**
	 * [tOracleSP_3 main ] start
	 */

	

	
	
	currentComponent="tOracleSP_3";

	

				statement_tOracleSP_3.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
		statement_tOracleSP_3.execute();
		
								row19.out_ref_cursor = statement_tOracleSP_3.getObject(1);

 


	tos_count_tOracleSP_3++;

/**
 * [tOracleSP_3 main ] stop
 */

	
	/**
	 * [tSplitRow_2 main ] start
	 */

	

	
	
	currentComponent="tSplitRow_2";

	

			//row19
			//row19


			
				if(execStat){
					runStat.updateStatOnConnection("row19"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row19 - " + (row19==null? "": row19.toLogString()));
    			}
    		
  java.util.List<row20Struct> rows_tSplitRow_2 = new java.util.ArrayList<row20Struct>(1);
  row20Struct rowTmp_tSplitRow_2 = null;

  // cache output rows for the loop
    rowTmp_tSplitRow_2 = new row20Struct();

      rowTmp_tSplitRow_2.out_ref_cursor = row19.out_ref_cursor;
      rowTmp_tSplitRow_2.object_id = context.object_id;
      rowTmp_tSplitRow_2.object_nm = context.object_nm;
    rows_tSplitRow_2.add(rowTmp_tSplitRow_2);
    nb_line_tSplitRow_2++;

  for (row20Struct row_tSplitRow_2 : rows_tSplitRow_2) {// C_01
    row20 = row_tSplitRow_2; 
 


	tos_count_tSplitRow_2++;

/**
 * [tSplitRow_2 main ] stop
 */
// Start of branch "row20"
if(row20 != null) { 



	
	/**
	 * [tFlowToIterate_5 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";

	

			//row20
			//row20


			
				if(execStat){
					runStat.updateStatOnConnection("row20"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row20 - " + (row20==null? "": row20.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row20.out_ref_cursor, value=")  + (row20.out_ref_cursor)  + (".") );            
            globalMap.put("row20.out_ref_cursor", row20.out_ref_cursor);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row20.object_id, value=")  + (row20.object_id)  + (".") );            
            globalMap.put("row20.object_id", row20.object_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_5 - "  + ("Set global var, key=row20.object_nm, value=")  + (row20.object_nm)  + (".") );            
            globalMap.put("row20.object_nm", row20.object_nm);
    	
 
	   nb_line_tFlowToIterate_5++;  
       counter_tFlowToIterate_5++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_5)  + (".") );
       globalMap.put("tFlowToIterate_5_CURRENT_ITERATION", counter_tFlowToIterate_5);
 


	tos_count_tFlowToIterate_5++;

/**
 * [tFlowToIterate_5 main ] stop
 */
	NB_ITERATE_tJavaFlex_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("out2", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row15", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row21", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate6", 1, "exec" + NB_ITERATE_tJavaFlex_3);
					//Thread.sleep(1000);
				}				
			



	
	/**
	 * [tFileOutputDelimited_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_2", false);
		start_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out2" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimited_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileOutputDelimited_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileOutputDelimited_2 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_2.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_2.append("USESTREAM" + " = " + "true");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("STREAMNAME" + " = " + "new java.io.FileOutputStream(((String)globalMap.get(\"LOCAL_DIRECTORY\")) + (\"NA\".equals(context.object_position) ? \"/Outbound/\" : \"/\") + ((String)globalMap.get(\"FILE_NAME\")), false)");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("OS_LINE_SEPARATOR_AS_ROW_SEPARATOR" + " = " + "true");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("CSVROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("FIELDSEPARATOR" + " = " + "((String)globalMap.get(\"FIELD_SEPARATOR\"))");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("CSV_OPTION" + " = " + "true");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ESCAPE_CHAR" + " = " + "((String)globalMap.get(\"ESCAPE_CHAR\"))");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("TEXT_ENCLOSURE" + " = " + "((String)globalMap.get(\"TEXT_ENCLOSURE\"))");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                    log4jParamters_tFileOutputDelimited_2.append("ENCODING" + " = " + "(Relational.ISNULL(globalMap.get(\"CHR_ENCODE\")) || \"\".equals((String)globalMap.get(\"CHR_ENCODE\"))) ? \"UTF-8\" : ((String)globalMap.get(\"CHR_ENCODE\"))");
                log4jParamters_tFileOutputDelimited_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_2 - "  + (log4jParamters_tFileOutputDelimited_2) );
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimited_2().limitLog4jByte();

String fileName_tFileOutputDelimited_2 = "";
        int dynamic_column_count_tFileOutputDelimited_2 = 1;
                boolean isFirstCheckDyn_tFileOutputDelimited_2= true;
                String[] headColutFileOutputDelimited_2 = null;
            class CSVBasicSet_tFileOutputDelimited_2{
                private char field_Delim;
                private char row_Delim;
                private char escape;
                private char textEnclosure;
                private boolean useCRLFRecordDelimiter;

                public boolean isUseCRLFRecordDelimiter() {
                    return useCRLFRecordDelimiter;
                }

                public void setFieldSeparator(String fieldSep) throws IllegalArgumentException{
                    char field_Delim_tFileOutputDelimited_2[] = null;

                    //support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'.
                    if (fieldSep.length() > 0 ){
                        field_Delim_tFileOutputDelimited_2 = fieldSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Field Separator must be assigned a char.");
                    }
                    this.field_Delim = field_Delim_tFileOutputDelimited_2[0];
                }

                public char getFieldDelim(){
                    if(this.field_Delim==0){
                        setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
                    }
                    return this.field_Delim;
                }

                public void setRowSeparator(String rowSep){
                    if("\r\n".equals(rowSep)) {
                        useCRLFRecordDelimiter = true;
                        return;
                    }
                    char row_DelimtFileOutputDelimited_2[] = null;

                    //support passing value (property: Row Separator) by 'context.rs' or 'globalMap.get("rs")'.
                    if (rowSep.length() > 0 ){
                        row_DelimtFileOutputDelimited_2 = rowSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Row Separator must be assigned a char.");
                    }
                    this.row_Delim = row_DelimtFileOutputDelimited_2[0];
                }

                public char getRowDelim(){
                    if(this.row_Delim==0){
                        setRowSeparator("\n");
                    }
                    return this.row_Delim;
                }

                public void setEscapeAndTextEnclosure(String strEscape, String strTextEnclosure) throws IllegalArgumentException{
                    if(strEscape.length() <= 0 ){
                        throw new IllegalArgumentException("Escape Char must be assigned a char.");
                    }

                    if ("".equals(strTextEnclosure)) strTextEnclosure = "\0";
                    char textEnclosure_tFileOutputDelimited_2[] = null;

                    if(strTextEnclosure.length() > 0 ){
                        textEnclosure_tFileOutputDelimited_2 = strTextEnclosure.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Text Enclosure must be assigned a char.");
                    }

                    this.textEnclosure = textEnclosure_tFileOutputDelimited_2[0];

                    if(("\\").equals(strEscape)){
                        this.escape = '\\';
                    }else if(strEscape.equals(strTextEnclosure)){
                        this.escape = this.textEnclosure;
                    } else {
                        //the default escape mode is double escape
                        this.escape = this.textEnclosure;
                    }


                }

                public char getEscapeChar(){
                    return (char)this.escape;
                }

                public char getTextEnclosure(){
                    return this.textEnclosure;
                }
            }

            int nb_line_tFileOutputDelimited_2 = 0;
            int splitedFileNo_tFileOutputDelimited_2 =0;
            int currentRow_tFileOutputDelimited_2 = 0;


            CSVBasicSet_tFileOutputDelimited_2 csvSettings_tFileOutputDelimited_2 = new CSVBasicSet_tFileOutputDelimited_2();
            csvSettings_tFileOutputDelimited_2.setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
            csvSettings_tFileOutputDelimited_2.setRowSeparator("\n");
            csvSettings_tFileOutputDelimited_2.setEscapeAndTextEnclosure(((String)globalMap.get("ESCAPE_CHAR")),((String)globalMap.get("TEXT_ENCLOSURE")));
                        java.io.OutputStreamWriter outWriter_tFileOutputDelimited_2 = null;
                        java.io.BufferedWriter bufferWriter_tFileOutputDelimited_2 = null;
                        com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_2 = null;
                        outWriter_tFileOutputDelimited_2 = new java.io.OutputStreamWriter(new java.io.FileOutputStream(((String)globalMap.get("LOCAL_DIRECTORY")) + ("NA".equals(context.object_position) ? "/Outbound/" : "/") + ((String)globalMap.get("FILE_NAME")), false), (Relational.ISNULL(globalMap.get("CHR_ENCODE")) || "".equals((String)globalMap.get("CHR_ENCODE"))) ? "UTF-8" : ((String)globalMap.get("CHR_ENCODE")));
                        bufferWriter_tFileOutputDelimited_2 = new java.io.BufferedWriter(outWriter_tFileOutputDelimited_2);
                        CsvWritertFileOutputDelimited_2 = new com.talend.csv.CSVWriter(bufferWriter_tFileOutputDelimited_2);
                        CsvWritertFileOutputDelimited_2.setSeparator(csvSettings_tFileOutputDelimited_2.getFieldDelim());
                    if(!csvSettings_tFileOutputDelimited_2.isUseCRLFRecordDelimiter() && csvSettings_tFileOutputDelimited_2.getRowDelim()!='\r' && csvSettings_tFileOutputDelimited_2.getRowDelim()!='\n') {
                        CsvWritertFileOutputDelimited_2.setLineEnd(""+csvSettings_tFileOutputDelimited_2.getRowDelim());
                    }



    resourceMap.put("CsvWriter_tFileOutputDelimited_2", CsvWritertFileOutputDelimited_2);
            resourceMap.put("bufferWriter_tFileOutputDelimited_2", bufferWriter_tFileOutputDelimited_2);
            resourceMap.put("outWriter_tFileOutputDelimited_2", outWriter_tFileOutputDelimited_2);
resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);

 



/**
 * [tFileOutputDelimited_2 begin ] stop
 */



	
	/**
	 * [tMap_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_3", false);
		start_Hash.put("tMap_3", System.currentTimeMillis());
		
	
	currentComponent="tMap_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row21" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_3 = new StringBuilder();
            log4jParamters_tMap_3.append("Parameters:");
                    log4jParamters_tMap_3.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_3.append(" | ");
                    log4jParamters_tMap_3.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_3.append(" | ");
                    log4jParamters_tMap_3.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_3.append(" | ");
                    log4jParamters_tMap_3.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + (log4jParamters_tMap_3) );
    		}
    	}
    	
        new BytesLimit65535_tMap_3().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row21_tMap_3 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_3__Struct  {
}
Var__tMap_3__Struct Var__tMap_3 = new Var__tMap_3__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out2_tMap_3 = 0;
				
out2Struct out2_tmp = new out2Struct();
// ###############################

        
        



        









 



/**
 * [tMap_3 begin ] stop
 */



	
	/**
	 * [tJavaFlex_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaFlex_3", false);
		start_Hash.put("tJavaFlex_3", System.currentTimeMillis());
		
	
	currentComponent="tJavaFlex_3";

	
		int tos_count_tJavaFlex_3 = 0;
		
    	class BytesLimit65535_tJavaFlex_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaFlex_3().limitLog4jByte();


int nb_line_inputSP = 0;

if (!Relational.ISNULL(globalMap.get("row20.out_ref_cursor"))) {

java.sql.ResultSet rs_inputSP = (java.sql.ResultSet)globalMap.get("row20.out_ref_cursor");

try {

	java.sql.ResultSetMetaData rsmd_inputSP = rs_inputSP.getMetaData();
	int colQtyInRs_inputSP = rsmd_inputSP.getColumnCount();

	routines.system.Dynamic dcg_inputSP = new routines.system.Dynamic();
	dcg_inputSP.setDbmsId("oracle_id");
	List<String> listSchema_inputSP = new java.util.ArrayList<String>();

	int fixedColumnCount_inputSP = 0;

	for (int i = 1; i <= rsmd_inputSP.getColumnCount() - 0; i++) {
		if (!(listSchema_inputSP.contains(rsmd_inputSP.getColumnLabel(i).toUpperCase()))) {
		
			routines.system.DynamicMetadata dcm_inputSP = new routines.system.DynamicMetadata();
			dcm_inputSP.setName(rsmd_inputSP.getColumnLabel(i));
			dcm_inputSP.setDbName(rsmd_inputSP.getColumnName(i));
			dcm_inputSP.setType(routines.system.Dynamic.getTalendTypeFromDBType("oracle_id", rsmd_inputSP.getColumnTypeName(i).toUpperCase(), rsmd_inputSP.getPrecision(i), rsmd_inputSP.getScale(i)));
			dcm_inputSP.setDbType(rsmd_inputSP.getColumnTypeName(i));
			dcm_inputSP.setDbTypeId(rsmd_inputSP.getColumnType(i));
			dcm_inputSP.setFormat("yyyy-MM-dd HH:mm:ss.SSS");
			
			if ("LONG".equals(rsmd_inputSP.getColumnTypeName(i).toUpperCase())) {
			
				String length = MetadataTalendType.getDefaultDBTypes("oracle_id", "LONG", MetadataTalendType.DEFAULT_LENGTH);
				if (length != null && !("".equals(length))) {
					dcm_inputSP.setLength(Integer.parseInt(length));
				} else {
					dcm_inputSP.setLength(rsmd_inputSP.getPrecision(i));
				}
			} else {
				dcm_inputSP.setLength(rsmd_inputSP.getPrecision(i));
			}
			dcm_inputSP.setPrecision(rsmd_inputSP.getScale(i));
			dcm_inputSP.setNullable(rsmd_inputSP.isNullable(i) == 0 ? false : true);
			dcm_inputSP.setKey(false);
			dcm_inputSP.setSourceType(DynamicMetadata.sourceTypes.database);
			dcm_inputSP.setColumnPosition(i);
			dcg_inputSP.metadatas.add(dcm_inputSP);
		}
	}
	
	String tmpContent_inputSP = null;
	int column_index_inputSP = 1;

	while (rs_inputSP.next()) {


 



/**
 * [tJavaFlex_3 begin ] stop
 */
	
	/**
	 * [tJavaFlex_3 main ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	



nb_line_inputSP++;

column_index_inputSP = 1;

if (colQtyInRs_inputSP < column_index_inputSP) {
	row21.data_row = null;
} else {
	row21.data_row = dcg_inputSP;
	routines.system.DynamicUtils.readColumnsFromDatabase(row21.data_row, rs_inputSP, fixedColumnCount_inputSP, false);
}


 


	tos_count_tJavaFlex_3++;

/**
 * [tJavaFlex_3 main ] stop
 */

	
	/**
	 * [tMap_3 main ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

			//row21
			//row21


			
				if(execStat){
					runStat.updateStatOnConnection("row21"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row21 - " + (row21==null? "": row21.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_3 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_3 = false;
		  boolean mainRowRejected_tMap_3 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_3__Struct Var = Var__tMap_3;// ###############################
        // ###############################
        // # Output tables

out2 = null;


// # Output table : 'out2'
count_out2_tMap_3++;

out2_tmp.datarow = "Y".equals((String)globalMap.get("IS_CLNSD")) ? routines.DataCleanser.replaceNewLinesAndReturns(row21.data_row) : row21.data_row ;
out2_tmp.etl_crtd_by = ((String)globalMap.get("DB_USER"));
out2_tmp.etl_crtd_dt = TalendDate.getCurrentDate();
out2 = out2_tmp;
log.debug("tMap_3 - Outputting the record " + count_out2_tMap_3 + " of the output table 'out2'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_3 = false;










 


	tos_count_tMap_3++;

/**
 * [tMap_3 main ] stop
 */
// Start of branch "out2"
if(out2 != null) { 



	
	/**
	 * [tFileOutputDelimited_2 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	

			//out2
			//out2


			
				if(execStat){
					runStat.updateStatOnConnection("out2"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out2 - " + (out2==null? "": out2.toLogString()));
    			}
    		


                dynamic_column_count_tFileOutputDelimited_2 = 1;
                        if(isFirstCheckDyn_tFileOutputDelimited_2 ){
                            headColutFileOutputDelimited_2 = new String[3-1+out2.datarow.getColumnCount()];
                                    dynamic_column_count_tFileOutputDelimited_2 = out2.datarow.getColumnCount();
                             for(int mi=0;mi<dynamic_column_count_tFileOutputDelimited_2;mi++){
                                headColutFileOutputDelimited_2[0+mi]=out2.datarow.getColumnMetadata(mi).getName();
                             }
                            headColutFileOutputDelimited_2[0+dynamic_column_count_tFileOutputDelimited_2]="etl_crtd_by";
                            headColutFileOutputDelimited_2[1+dynamic_column_count_tFileOutputDelimited_2]="etl_crtd_dt";
                            CsvWritertFileOutputDelimited_2.writeNext(headColutFileOutputDelimited_2);
                            CsvWritertFileOutputDelimited_2.flush();
                        }
                        if(isFirstCheckDyn_tFileOutputDelimited_2){
                            CsvWritertFileOutputDelimited_2.setEscapeChar(csvSettings_tFileOutputDelimited_2.getEscapeChar());
                            CsvWritertFileOutputDelimited_2.setQuoteChar(csvSettings_tFileOutputDelimited_2.getTextEnclosure());
                            CsvWritertFileOutputDelimited_2.setQuoteStatus(com.talend.csv.CSVWriter.QuoteStatus.FORCE);
                            isFirstCheckDyn_tFileOutputDelimited_2 = false;
                        }
                        String[] rowtFileOutputDelimited_2=new String[3+out2.datarow.getColumnCount()-1];
                        dynamic_column_count_tFileOutputDelimited_2 =1;
                                dynamic_column_count_tFileOutputDelimited_2 = out2.datarow.getColumnCount();
                            if (out2.datarow != null) {
                                routines.system.DynamicUtils.writeValuesToStringArrayEnhance(out2.datarow, rowtFileOutputDelimited_2, 0,
                                           null
                                );
                            }
                            rowtFileOutputDelimited_2[0+dynamic_column_count_tFileOutputDelimited_2]=out2.etl_crtd_by == null ? null : out2.etl_crtd_by;
                            rowtFileOutputDelimited_2[1+dynamic_column_count_tFileOutputDelimited_2]=out2.etl_crtd_dt == null ? null : FormatterUtils.format_Date(out2.etl_crtd_dt, "yyyy-MM-dd HH:mm:ss.SSS");
                nb_line_tFileOutputDelimited_2++;
                resourceMap.put("nb_line_tFileOutputDelimited_2", nb_line_tFileOutputDelimited_2);
                                       CsvWritertFileOutputDelimited_2.writeNext(rowtFileOutputDelimited_2);
                            log.debug("tFileOutputDelimited_2 - Writing the record " + nb_line_tFileOutputDelimited_2 + ".");




 


	tos_count_tFileOutputDelimited_2++;

/**
 * [tFileOutputDelimited_2 main ] stop
 */

} // End of branch "out2"







	
	/**
	 * [tJavaFlex_3 end ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	


	}
} finally {

	globalMap.put("CURRENT_RESULTSET_RECORD_COUNT", nb_line_inputSP);

}
}

 

ok_Hash.put("tJavaFlex_3", true);
end_Hash.put("tJavaFlex_3", System.currentTimeMillis());




/**
 * [tJavaFlex_3 end ] stop
 */

	
	/**
	 * [tMap_3 end ] start
	 */

	

	
	
	currentComponent="tMap_3";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_3 - Written records count in the table 'out2': " + count_out2_tMap_3 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row21"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_3 - "  + ("Done.") );

ok_Hash.put("tMap_3", true);
end_Hash.put("tMap_3", System.currentTimeMillis());




/**
 * [tMap_3 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_2 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	



		
			
		
				
						if(CsvWritertFileOutputDelimited_2!=null) {
							CsvWritertFileOutputDelimited_2.flush();
						}
						if(bufferWriter_tFileOutputDelimited_2!=null) {
							bufferWriter_tFileOutputDelimited_2.flush();
						}
						if(outWriter_tFileOutputDelimited_2!=null) {
							outWriter_tFileOutputDelimited_2.flush();
						}
						CsvWritertFileOutputDelimited_2 = null;
					
		    	globalMap.put("tFileOutputDelimited_2_NB_LINE",nb_line_tFileOutputDelimited_2);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_2", true);
	
				log.debug("tFileOutputDelimited_2 - Written records count: " + nb_line_tFileOutputDelimited_2 + " .");
			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out2"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_2 - "  + ("Done.") );

ok_Hash.put("tFileOutputDelimited_2", true);
end_Hash.put("tFileOutputDelimited_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk12", 0, "ok");
				}
				tFixedFlowInput_8Process(globalMap);



/**
 * [tFileOutputDelimited_2 end ] stop
 */






						if(execStat){
							runStat.updateStatOnConnection("iterate6", 2, "exec" + NB_ITERATE_tJavaFlex_3);
						}				
					





} // End of branch "row20"



	
		} // C_01
	



	
	/**
	 * [tOracleSP_3 end ] start
	 */

	

	
	
	currentComponent="tOracleSP_3";

	


	statement_tOracleSP_3.close();

 

ok_Hash.put("tOracleSP_3", true);
end_Hash.put("tOracleSP_3", System.currentTimeMillis());




/**
 * [tOracleSP_3 end ] stop
 */

	
	/**
	 * [tSplitRow_2 end ] start
	 */

	

	
	
	currentComponent="tSplitRow_2";

	
globalMap.put("tSplitRow_2_NB_LINE", nb_line_tSplitRow_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row19"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tSplitRow_2", true);
end_Hash.put("tSplitRow_2", System.currentTimeMillis());




/**
 * [tSplitRow_2 end ] stop
 */

	
	/**
	 * [tFlowToIterate_5 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";

	

globalMap.put("tFlowToIterate_5_NB_LINE",nb_line_tFlowToIterate_5);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row20"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_5 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_5", true);
end_Hash.put("tFlowToIterate_5", System.currentTimeMillis());




/**
 * [tFlowToIterate_5 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleSP_3 finally ] start
	 */

	

	
	
	currentComponent="tOracleSP_3";

	

 



/**
 * [tOracleSP_3 finally ] stop
 */

	
	/**
	 * [tSplitRow_2 finally ] start
	 */

	

	
	
	currentComponent="tSplitRow_2";

	

 



/**
 * [tSplitRow_2 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_5 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_5";

	

 



/**
 * [tFlowToIterate_5 finally ] stop
 */

	
	/**
	 * [tJavaFlex_3 finally ] start
	 */

	

	
	
	currentComponent="tJavaFlex_3";

	

 



/**
 * [tJavaFlex_3 finally ] stop
 */

	
	/**
	 * [tMap_3 finally ] start
	 */

	

	
	
	currentComponent="tMap_3";

	

 



/**
 * [tMap_3 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_2 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_2";

	


		if(resourceMap.get("finish_tFileOutputDelimited_2") == null){ 
			
				
			
					com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_2 = (com.talend.csv.CSVWriter)resourceMap.get("CsvWriter_tFileOutputDelimited_2");
					
							if(CsvWritertFileOutputDelimited_2!=null) {
								CsvWritertFileOutputDelimited_2.flush();
							}
							java.io.BufferedWriter bufferWriter_tFileOutputDelimited_2 = (java.io.BufferedWriter)resourceMap.get("bufferWriter_tFileOutputDelimited_2");
							if(bufferWriter_tFileOutputDelimited_2!=null) {
								bufferWriter_tFileOutputDelimited_2.flush();
							}
							java.io.OutputStreamWriter outWriter_tFileOutputDelimited_2 = (java.io.OutputStreamWriter)resourceMap.get("outWriter_tFileOutputDelimited_2");
							if(outWriter_tFileOutputDelimited_2!=null) {
								outWriter_tFileOutputDelimited_2.flush();
							}
							CsvWritertFileOutputDelimited_2 = null;
						
			
		}
	

 



/**
 * [tFileOutputDelimited_2 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleSP_3_SUBPROCESS_STATE", 1);
	}
	


public static class row15Struct implements routines.system.IPersistableRow<row15Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row15Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row15Struct row15 = new row15Struct();




	
	/**
	 * [tHashOutput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_2", false);
		start_Hash.put("tHashOutput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row15" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_2 = 0;
		
    	class BytesLimit65535_tHashOutput_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_2().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashOutput_2 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_2.getKeyMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" +pid + "_tHashOutput_2", "tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid + "_tHashOutput_4");
        int nb_line_tHashOutput_2 = 0;
 



/**
 * [tHashOutput_2 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_8", false);
		start_Hash.put("tFixedFlowInput_8", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_8";

	
		int tos_count_tFixedFlowInput_8 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_8{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_8().limitLog4jByte();

	    for (int i_tFixedFlowInput_8 = 0 ; i_tFixedFlowInput_8 < 1 ; i_tFixedFlowInput_8++) {
	                	            	
    	            		row15.object_id = context.object_id;
    	            	        	            	
    	            		row15.object_nm = context.object_nm;
    	            	        	            	
    	            		row15.source_count = ((Integer)globalMap.get("CURRENT_RESULTSET_RECORD_COUNT"));
    	            	        	            	
    	            		row15.target_count = ((Integer)globalMap.get("tFileOutputDelimited_2_NB_LINE"));
    	            	        	            	
    	            		row15.file_name = ((String)globalMap.get("FILE_NAME"));
    	            	        	            	
    	            		row15.cdc_start_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("LAST_RUN_DTTM"))) ? ((Date)globalMap.get("LAST_RUN_DTTM")) : null;
    	            	        	            	
    	            		row15.cdc_end_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("NEXT_RUN_DTTM"))) ? ((Date)globalMap.get("NEXT_RUN_DTTM")) : null;
    	            	
 



/**
 * [tFixedFlowInput_8 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_8 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_8";

	

 


	tos_count_tFixedFlowInput_8++;

/**
 * [tFixedFlowInput_8 main ] stop
 */

	
	/**
	 * [tHashOutput_2 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	

			//row15
			//row15


			
				if(execStat){
					runStat.updateStatOnConnection("row15"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row15 - " + (row15==null? "": row15.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_2 == null){
			tHashFile_tHashOutput_2 = mf_tHashOutput_2.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
			mf_tHashOutput_2.getResourceMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_2", tHashFile_tHashOutput_2);
		}
		row22Struct oneRow_tHashOutput_2 = new row22Struct();
			oneRow_tHashOutput_2.object_id = row15.object_id;
			oneRow_tHashOutput_2.object_nm = row15.object_nm;
			oneRow_tHashOutput_2.source_count = row15.source_count;
			oneRow_tHashOutput_2.target_count = row15.target_count;
			oneRow_tHashOutput_2.file_name = row15.file_name;
			oneRow_tHashOutput_2.cdc_start_dttm = row15.cdc_start_dttm;
			oneRow_tHashOutput_2.cdc_end_dttm = row15.cdc_end_dttm;
        tHashFile_tHashOutput_2.put(oneRow_tHashOutput_2);
        nb_line_tHashOutput_2 ++;	
 


	tos_count_tHashOutput_2++;

/**
 * [tHashOutput_2 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_8 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_8";

	

        }
        globalMap.put("tFixedFlowInput_8_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_8", true);
end_Hash.put("tFixedFlowInput_8", System.currentTimeMillis());




/**
 * [tFixedFlowInput_8 end ] stop
 */

	
	/**
	 * [tHashOutput_2 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	
globalMap.put("tHashOutput_2_NB_LINE", nb_line_tHashOutput_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row15"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_2", true);
end_Hash.put("tHashOutput_2", System.currentTimeMillis());




/**
 * [tHashOutput_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_8 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_8";

	

 



/**
 * [tFixedFlowInput_8 finally ] stop
 */

	
	/**
	 * [tHashOutput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_2";

	

 



/**
 * [tHashOutput_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_8_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_15Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_15_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_15 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_15", false);
		start_Hash.put("tWarn_15", System.currentTimeMillis());
		
	
	currentComponent="tWarn_15";

	
		int tos_count_tWarn_15 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_15 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_15{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_15 = new StringBuilder();
            log4jParamters_tWarn_15.append("Parameters:");
                    log4jParamters_tWarn_15.append("MESSAGE" + " = " + "\"209|Single SP extraction failed\"");
                log4jParamters_tWarn_15.append(" | ");
                    log4jParamters_tWarn_15.append("CODE" + " = " + "999");
                log4jParamters_tWarn_15.append(" | ");
                    log4jParamters_tWarn_15.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_15.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_15 - "  + (log4jParamters_tWarn_15) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_15().limitLog4jByte();

 



/**
 * [tWarn_15 begin ] stop
 */
	
	/**
	 * [tWarn_15 main ] start
	 */

	

	
	
	currentComponent="tWarn_15";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_15", "", Thread.currentThread().getId() + "", "ERROR","","209|Single SP extraction failed","", "");
            log.error("tWarn_15 - "  + ("Message: ")  + ("209|Single SP extraction failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_15 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_15", 5, "209|Single SP extraction failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_15_WARN_MESSAGES", "209|Single SP extraction failed"); 
globalMap.put("tWarn_15_WARN_PRIORITY", 5);
globalMap.put("tWarn_15_WARN_CODE", 999);


 


	tos_count_tWarn_15++;

/**
 * [tWarn_15 main ] stop
 */
	
	/**
	 * [tWarn_15 end ] start
	 */

	

	
	
	currentComponent="tWarn_15";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_15 - "  + ("Done.") );

ok_Hash.put("tWarn_15", true);
end_Hash.put("tWarn_15", System.currentTimeMillis());




/**
 * [tWarn_15 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_15 finally ] start
	 */

	

	
	
	currentComponent="tWarn_15";

	

 



/**
 * [tWarn_15 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_15_SUBPROCESS_STATE", 1);
	}
	

public void tJava_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_6", false);
		start_Hash.put("tJava_6", System.currentTimeMillis());
		
	
	currentComponent="tJava_6";

	
		int tos_count_tJava_6 = 0;
		
    	class BytesLimit65535_tJava_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_6().limitLog4jByte();



 



/**
 * [tJava_6 begin ] stop
 */
	
	/**
	 * [tJava_6 main ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 


	tos_count_tJava_6++;

/**
 * [tJava_6 main ] stop
 */
	
	/**
	 * [tJava_6 end ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 

ok_Hash.put("tJava_6", true);
end_Hash.put("tJava_6", System.currentTimeMillis());

   			if ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "true");
					}
				
    			tOracleSP_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If7", 0, "false");
					}   	 
   				}



/**
 * [tJava_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk20", 0, "ok");
								} 
							
							tHashInput_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_6 finally ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_6_SUBPROCESS_STATE", 1);
	}
	


public static class row23Struct implements routines.system.IPersistableRow<row23Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row23Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row25Struct implements routines.system.IPersistableRow<row25Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row25Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tHashInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row25Struct row25 = new row25Struct();
row23Struct row23 = new row23Struct();





	
	/**
	 * [tFlowToIterate_4 begin ] start
	 */

				
			int NB_ITERATE_tSystem_1 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_4", false);
		start_Hash.put("tFlowToIterate_4", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row23" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_4 = new StringBuilder();
            log4jParamters_tFlowToIterate_4.append("Parameters:");
                    log4jParamters_tFlowToIterate_4.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + (log4jParamters_tFlowToIterate_4) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_4().limitLog4jByte();

int nb_line_tFlowToIterate_4 = 0;
int counter_tFlowToIterate_4 = 0;

 



/**
 * [tFlowToIterate_4 begin ] stop
 */



	
	/**
	 * [tFilterRow_29 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_29", false);
		start_Hash.put("tFilterRow_29", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_29";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row25" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFilterRow_29 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_29 - "  + ("Start to work.") );
    	class BytesLimit65535_tFilterRow_29{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFilterRow_29 = new StringBuilder();
            log4jParamters_tFilterRow_29.append("Parameters:");
                    log4jParamters_tFilterRow_29.append("LOGICAL_OP" + " = " + "&&");
                log4jParamters_tFilterRow_29.append(" | ");
                    log4jParamters_tFilterRow_29.append("CONDITIONS" + " = " + "[{OPERATOR="+(">")+", RVALUE="+("0")+", INPUT_COLUMN="+("target_count")+", FUNCTION="+("")+"}]");
                log4jParamters_tFilterRow_29.append(" | ");
                    log4jParamters_tFilterRow_29.append("USE_ADVANCED" + " = " + "false");
                log4jParamters_tFilterRow_29.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_29 - "  + (log4jParamters_tFilterRow_29) );
    		}
    	}
    	
        new BytesLimit65535_tFilterRow_29().limitLog4jByte();
    int nb_line_tFilterRow_29 = 0;
    int nb_line_ok_tFilterRow_29 = 0;
    int nb_line_reject_tFilterRow_29 = 0;

    class Operator_tFilterRow_29 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_29(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_29 begin ] stop
 */



	
	/**
	 * [tHashInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_2", false);
		start_Hash.put("tHashInput_2", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_2";

	
		int tos_count_tHashInput_2 = 0;
		
    	class BytesLimit65535_tHashInput_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashInput_2().limitLog4jByte();


int nb_line_tHashInput_2 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_2=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashInput_2 = mf_tHashInput_2.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
if(tHashFile_tHashInput_2==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row22Struct> iterator_tHashInput_2 = tHashFile_tHashInput_2.iterator();
while (iterator_tHashInput_2.hasNext()) {
    row22Struct next_tHashInput_2 = iterator_tHashInput_2.next();

	row25.object_id = next_tHashInput_2.object_id;
	row25.object_nm = next_tHashInput_2.object_nm;
	row25.source_count = next_tHashInput_2.source_count;
	row25.target_count = next_tHashInput_2.target_count;
	row25.file_name = next_tHashInput_2.file_name;
	row25.cdc_start_dttm = next_tHashInput_2.cdc_start_dttm;
	row25.cdc_end_dttm = next_tHashInput_2.cdc_end_dttm;
 



/**
 * [tHashInput_2 begin ] stop
 */
	
	/**
	 * [tHashInput_2 main ] start
	 */

	

	
	
	currentComponent="tHashInput_2";

	

 


	tos_count_tHashInput_2++;

/**
 * [tHashInput_2 main ] stop
 */

	
	/**
	 * [tFilterRow_29 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_29";

	

			//row25
			//row25


			
				if(execStat){
					runStat.updateStatOnConnection("row25"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row25 - " + (row25==null? "": row25.toLogString()));
    			}
    		

          row23 = null;
    Operator_tFilterRow_29 ope_tFilterRow_29 = new Operator_tFilterRow_29("&&");
            ope_tFilterRow_29.matches((row25.target_count == null? false : row25.target_count.compareTo(ParserUtils.parseTo_Integer(String.valueOf(0))) > 0)
                           , "target_count.compareTo(0) > 0 failed");
		 	
    
    if (ope_tFilterRow_29.getMatchFlag()) {
              if(row23 == null){ 
                row23 = new row23Struct();
              }
               row23.object_id = row25.object_id;
               row23.object_nm = row25.object_nm;
               row23.source_count = row25.source_count;
               row23.target_count = row25.target_count;
               row23.file_name = row25.file_name;
               row23.cdc_start_dttm = row25.cdc_start_dttm;
               row23.cdc_end_dttm = row25.cdc_end_dttm;
					log.debug("tFilterRow_29 - Process the record " + (nb_line_tFilterRow_29+1) + ".");
					    
      nb_line_ok_tFilterRow_29++;
    } else {
      nb_line_reject_tFilterRow_29++;
    }

nb_line_tFilterRow_29++;

 


	tos_count_tFilterRow_29++;

/**
 * [tFilterRow_29 main ] stop
 */
// Start of branch "row23"
if(row23 != null) { 



	
	/**
	 * [tFlowToIterate_4 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

			//row23
			//row23


			
				if(execStat){
					runStat.updateStatOnConnection("row23"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row23 - " + (row23==null? "": row23.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row23.object_id, value=")  + (row23.object_id)  + (".") );            
            globalMap.put("row23.object_id", row23.object_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row23.object_nm, value=")  + (row23.object_nm)  + (".") );            
            globalMap.put("row23.object_nm", row23.object_nm);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row23.source_count, value=")  + (row23.source_count)  + (".") );            
            globalMap.put("row23.source_count", row23.source_count);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row23.target_count, value=")  + (row23.target_count)  + (".") );            
            globalMap.put("row23.target_count", row23.target_count);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row23.file_name, value=")  + (row23.file_name)  + (".") );            
            globalMap.put("row23.file_name", row23.file_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row23.cdc_start_dttm, value=")  + (row23.cdc_start_dttm)  + (".") );            
            globalMap.put("row23.cdc_start_dttm", row23.cdc_start_dttm);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_4 - "  + ("Set global var, key=row23.cdc_end_dttm, value=")  + (row23.cdc_end_dttm)  + (".") );            
            globalMap.put("row23.cdc_end_dttm", row23.cdc_end_dttm);
    	
 
	   nb_line_tFlowToIterate_4++;  
       counter_tFlowToIterate_4++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_4)  + (".") );
       globalMap.put("tFlowToIterate_4_CURRENT_ITERATION", counter_tFlowToIterate_4);
 


	tos_count_tFlowToIterate_4++;

/**
 * [tFlowToIterate_4 main ] stop
 */
	NB_ITERATE_tSystem_1++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("If4", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If3", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate2", 1, "exec" + NB_ITERATE_tSystem_1);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tSystem_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSystem_1", false);
		start_Hash.put("tSystem_1", System.currentTimeMillis());
		
	
	currentComponent="tSystem_1";

	
		int tos_count_tSystem_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tSystem_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSystem_1 = new StringBuilder();
            log4jParamters_tSystem_1.append("Parameters:");
                    log4jParamters_tSystem_1.append("ROOTDIR" + " = " + "false");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("USE_SINGLE_COMMAND" + " = " + "false");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("USE_ARRAY_COMMAND" + " = " + "true");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("ARRAY_COMMAND" + " = " + "[{VALUE="+("\"/bin/bash\"")+"}, {VALUE="+("\"-c\"")+"}, {VALUE="+("\"sh \" + ((String)globalMap.get(\"TALEND_OPER_PATH\")) + \"/\" + (\"Y\".equals((String)globalMap.get(\"COPY_TO_STAGING\")) ? ((String)globalMap.get(\"LANDING_STAGING_SCRIPT\")) : ((String)globalMap.get(\"LANDING_SCRIPT\"))) + \" \" + ((String)globalMap.get(\"row23.file_name\")) + \" \" + ((String)globalMap.get(\"LOCAL_DIRECTORY\")) + \"/Outbound \" + ((String)globalMap.get(\"ADLS_FILE_PATH\")) + (\"SP_MULTI_UCM_CONTACT\".equals((String)globalMap.get(\"OBJECT_TYPE\")) ? \"/\" + ((String)globalMap.get(\"row23.object_nm\")) + \"/\" + TalendDate.formatDate(\"yyyy/MM/dd\", TalendDate.getCurrentDate()) : \"\") + (\"Y\".equals((String)globalMap.get(\"COPY_TO_STAGING\")) ? \" \" + ((String)globalMap.get(\"ADLS_MERGE_PATH\")) + (\"SP_MULTI_UCM_CONTACT\".equals((String)globalMap.get(\"OBJECT_TYPE\")) ? \"/\" + ((String)globalMap.get(\"row23.object_nm\")) : \"\") : \"\")")+"}]");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("OUTPUT" + " = " + "OUTPUT_TO_CONSOLE");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("ERROROUTPUT" + " = " + "OUTPUT_TO_CONSOLE");
                log4jParamters_tSystem_1.append(" | ");
                    log4jParamters_tSystem_1.append("PARAMS" + " = " + "[]");
                log4jParamters_tSystem_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + (log4jParamters_tSystem_1) );
    		}
    	}
    	
        new BytesLimit65535_tSystem_1().limitLog4jByte();

		
			String commandArrayForLog_tSystem_1 ="";
		
		String[] command_tSystem_1 = new String[3];
		
			command_tSystem_1[0] = "/bin/bash";
			
				if(("/bin/bash").contains(" "))
					commandArrayForLog_tSystem_1+="\"" + "/bin/bash" + "\" ";
				else
					commandArrayForLog_tSystem_1+="/bin/bash" + " ";
			
			command_tSystem_1[1] = "-c";
			
				if(("-c").contains(" "))
					commandArrayForLog_tSystem_1+="\"" + "-c" + "\" ";
				else
					commandArrayForLog_tSystem_1+="-c" + " ";
			
			command_tSystem_1[2] = "sh " + ((String)globalMap.get("TALEND_OPER_PATH")) + "/" + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? ((String)globalMap.get("LANDING_STAGING_SCRIPT")) : ((String)globalMap.get("LANDING_SCRIPT"))) + " " + ((String)globalMap.get("row23.file_name")) + " " + ((String)globalMap.get("LOCAL_DIRECTORY")) + "/Outbound " + ((String)globalMap.get("ADLS_FILE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) + "/" + TalendDate.formatDate("yyyy/MM/dd", TalendDate.getCurrentDate()) : "") + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? " " + ((String)globalMap.get("ADLS_MERGE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) : "") : "");
			
				if(("sh " + ((String)globalMap.get("TALEND_OPER_PATH")) + "/" + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? ((String)globalMap.get("LANDING_STAGING_SCRIPT")) : ((String)globalMap.get("LANDING_SCRIPT"))) + " " + ((String)globalMap.get("row23.file_name")) + " " + ((String)globalMap.get("LOCAL_DIRECTORY")) + "/Outbound " + ((String)globalMap.get("ADLS_FILE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) + "/" + TalendDate.formatDate("yyyy/MM/dd", TalendDate.getCurrentDate()) : "") + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? " " + ((String)globalMap.get("ADLS_MERGE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) : "") : "")).contains(" "))
					commandArrayForLog_tSystem_1+="\"" + "sh " + ((String)globalMap.get("TALEND_OPER_PATH")) + "/" + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? ((String)globalMap.get("LANDING_STAGING_SCRIPT")) : ((String)globalMap.get("LANDING_SCRIPT"))) + " " + ((String)globalMap.get("row23.file_name")) + " " + ((String)globalMap.get("LOCAL_DIRECTORY")) + "/Outbound " + ((String)globalMap.get("ADLS_FILE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) + "/" + TalendDate.formatDate("yyyy/MM/dd", TalendDate.getCurrentDate()) : "") + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? " " + ((String)globalMap.get("ADLS_MERGE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) : "") : "") + "\" ";
				else
					commandArrayForLog_tSystem_1+="sh " + ((String)globalMap.get("TALEND_OPER_PATH")) + "/" + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? ((String)globalMap.get("LANDING_STAGING_SCRIPT")) : ((String)globalMap.get("LANDING_SCRIPT"))) + " " + ((String)globalMap.get("row23.file_name")) + " " + ((String)globalMap.get("LOCAL_DIRECTORY")) + "/Outbound " + ((String)globalMap.get("ADLS_FILE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) + "/" + TalendDate.formatDate("yyyy/MM/dd", TalendDate.getCurrentDate()) : "") + ("Y".equals((String)globalMap.get("COPY_TO_STAGING")) ? " " + ((String)globalMap.get("ADLS_MERGE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row23.object_nm")) : "") : "") + " ";
			
Runtime runtime_tSystem_1 = Runtime.getRuntime();

String[] env_tSystem_1= null;
java.util.Map<String,String> envMap_tSystem_1= System.getenv();
java.util.Map<String,String> envMapClone_tSystem_1= new java.util.HashMap();
envMapClone_tSystem_1.putAll(envMap_tSystem_1);

	log.info("tSystem_1 - Setting the parameters.");
final Process ps_tSystem_1 = runtime_tSystem_1.exec(command_tSystem_1 ,env_tSystem_1);

globalMap.remove("tSystem_1_OUTPUT");
globalMap.remove("tSystem_1_ERROROUTPUT");

Thread normal_tSystem_1 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_1.getInputStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
					
						log.debug("tSystem_1 - Sending the standard output to the console.");
					
					System.out.println(line);
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_1 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
	log.info("tSystem_1 - Executing the command.");
	log.info("tSystem_1 - Command to execute: '" + commandArrayForLog_tSystem_1  + "'.");
normal_tSystem_1.start();
	log.info("tSystem_1 - The command has been executed successfully.");

Thread error_tSystem_1 = new Thread() {
	public void run() {
		try {
			java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(ps_tSystem_1.getErrorStream()));
			String line = "";
			try {
				while((line = reader.readLine()) != null) {
					
						log.debug("tSystem_1 - Sending the error output to the console.");
					
					System.err.println(line);
				}
			} finally {
				reader.close();
			}
		} catch(java.io.IOException ioe) {
			
				log.error("tSystem_1 - "  + ioe.getMessage());
			
			ioe.printStackTrace();
		}
	}
};
error_tSystem_1.start();
if(ps_tSystem_1.getOutputStream()!=null){
    ps_tSystem_1.getOutputStream().close();
}
ps_tSystem_1.waitFor();
normal_tSystem_1.join(10000);
error_tSystem_1.join(10000);


 



/**
 * [tSystem_1 begin ] stop
 */
	
	/**
	 * [tSystem_1 main ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	


 


	tos_count_tSystem_1++;

/**
 * [tSystem_1 main ] stop
 */
	
	/**
	 * [tSystem_1 end ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	

globalMap.put("tSystem_1_EXIT_VALUE", ps_tSystem_1.exitValue());

 
                if(log.isDebugEnabled())
            log.debug("tSystem_1 - "  + ("Done.") );

ok_Hash.put("tSystem_1", true);
end_Hash.put("tSystem_1", System.currentTimeMillis());

   			if (!(((Integer)globalMap.get("tSystem_1_EXIT_VALUE")) == 0)) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "true");
					}
				
    			tWarn_10Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If3", 0, "false");
					}   	 
   				}
   			if (((Integer)globalMap.get("tSystem_1_EXIT_VALUE")) == 0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "true");
					}
				
    			tJava_4Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If4", 0, "false");
					}   	 
   				}



/**
 * [tSystem_1 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate2", 2, "exec" + NB_ITERATE_tSystem_1);
						}				
					





} // End of branch "row23"







	
	/**
	 * [tHashInput_2 end ] start
	 */

	

	
	
	currentComponent="tHashInput_2";

	
    

		
			nb_line_tHashInput_2++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
	


	globalMap.put("tHashInput_2_NB_LINE", nb_line_tHashInput_2);       

 

ok_Hash.put("tHashInput_2", true);
end_Hash.put("tHashInput_2", System.currentTimeMillis());




/**
 * [tHashInput_2 end ] stop
 */

	
	/**
	 * [tFilterRow_29 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_29";

	
    globalMap.put("tFilterRow_29_NB_LINE", nb_line_tFilterRow_29);
    globalMap.put("tFilterRow_29_NB_LINE_OK", nb_line_ok_tFilterRow_29);
    globalMap.put("tFilterRow_29_NB_LINE_REJECT", nb_line_reject_tFilterRow_29);
    
    	log.info("tFilterRow_29 - Processed records count:" + nb_line_tFilterRow_29 + ". Matched records count:" + nb_line_ok_tFilterRow_29 + ". Rejected records count:" + nb_line_reject_tFilterRow_29 + ".");

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row25"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_29 - "  + ("Done.") );

ok_Hash.put("tFilterRow_29", true);
end_Hash.put("tFilterRow_29", System.currentTimeMillis());




/**
 * [tFilterRow_29 end ] stop
 */

	
	/**
	 * [tFlowToIterate_4 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

globalMap.put("tFlowToIterate_4_NB_LINE",nb_line_tFlowToIterate_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row23"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_4 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_4", true);
end_Hash.put("tFlowToIterate_4", System.currentTimeMillis());




/**
 * [tFlowToIterate_4 end ] stop
 */






				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tHashInput_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk22", 0, "ok");
								} 
							
							tJava_7Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tHashInput_2 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_2";

	

 



/**
 * [tHashInput_2 finally ] stop
 */

	
	/**
	 * [tFilterRow_29 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_29";

	

 



/**
 * [tFilterRow_29 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_4 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_4";

	

 



/**
 * [tFlowToIterate_4 finally ] stop
 */

	
	/**
	 * [tSystem_1 finally ] start
	 */

	

	
	
	currentComponent="tSystem_1";

	

 



/**
 * [tSystem_1 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_2_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_10", false);
		start_Hash.put("tWarn_10", System.currentTimeMillis());
		
	
	currentComponent="tWarn_10";

	
		int tos_count_tWarn_10 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_10{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_10 = new StringBuilder();
            log4jParamters_tWarn_10.append("Parameters:");
                    log4jParamters_tWarn_10.append("MESSAGE" + " = " + "\"211|File upload to ADLS failed\"");
                log4jParamters_tWarn_10.append(" | ");
                    log4jParamters_tWarn_10.append("CODE" + " = " + "999");
                log4jParamters_tWarn_10.append(" | ");
                    log4jParamters_tWarn_10.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_10.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + (log4jParamters_tWarn_10) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_10().limitLog4jByte();

 



/**
 * [tWarn_10 begin ] stop
 */
	
	/**
	 * [tWarn_10 main ] start
	 */

	

	
	
	currentComponent="tWarn_10";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_10", "", Thread.currentThread().getId() + "", "ERROR","","211|File upload to ADLS failed","", "");
            log.error("tWarn_10 - "  + ("Message: ")  + ("211|File upload to ADLS failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_10", 5, "211|File upload to ADLS failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_10_WARN_MESSAGES", "211|File upload to ADLS failed"); 
globalMap.put("tWarn_10_WARN_PRIORITY", 5);
globalMap.put("tWarn_10_WARN_CODE", 999);


 


	tos_count_tWarn_10++;

/**
 * [tWarn_10 main ] stop
 */
	
	/**
	 * [tWarn_10 end ] start
	 */

	

	
	
	currentComponent="tWarn_10";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_10 - "  + ("Done.") );

ok_Hash.put("tWarn_10", true);
end_Hash.put("tWarn_10", System.currentTimeMillis());




/**
 * [tWarn_10 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_10 finally ] start
	 */

	

	
	
	currentComponent="tWarn_10";

	

 



/**
 * [tWarn_10 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_10_SUBPROCESS_STATE", 1);
	}
	

public void tJava_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_4", false);
		start_Hash.put("tJava_4", System.currentTimeMillis());
		
	
	currentComponent="tJava_4";

	
		int tos_count_tJava_4 = 0;
		
    	class BytesLimit65535_tJava_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_4().limitLog4jByte();


/* -------- set details of t_load_status_dtl -------*/
globalMap.put("LOAD_STATUS", "C");

if("Y".equals((String)globalMap.get("COPY_TO_STAGING"))) {

	globalMap.put("INGTN_TYP", "F");
	globalMap.put("IS_MERGED", "C");

} else if("Y".equals((String)globalMap.get("IS_ACTIVE"))) {

	globalMap.put("INGTN_TYP", "D");
	globalMap.put("IS_MERGED", "N");

} else {

	globalMap.put("INGTN_TYP", "F");
	globalMap.put("IS_MERGED", "NR");

}
 



/**
 * [tJava_4 begin ] stop
 */
	
	/**
	 * [tJava_4 main ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 


	tos_count_tJava_4++;

/**
 * [tJava_4 main ] stop
 */
	
	/**
	 * [tJava_4 end ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 

ok_Hash.put("tJava_4", true);
end_Hash.put("tJava_4", System.currentTimeMillis());




/**
 * [tJava_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_4 finally ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_7", false);
		start_Hash.put("tJava_7", System.currentTimeMillis());
		
	
	currentComponent="tJava_7";

	
		int tos_count_tJava_7 = 0;
		
    	class BytesLimit65535_tJava_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_7().limitLog4jByte();


if(globalMap.containsKey("conn_tMSSqlConnection_1"))
{
		tMSSqlConnection_1Process(globalMap);
}

 



/**
 * [tJava_7 begin ] stop
 */
	
	/**
	 * [tJava_7 main ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 


	tos_count_tJava_7++;

/**
 * [tJava_7 main ] stop
 */
	
	/**
	 * [tJava_7 end ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 

ok_Hash.put("tJava_7", true);
end_Hash.put("tJava_7", System.currentTimeMillis());




/**
 * [tJava_7 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_7:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk24", 0, "ok");
								} 
							
							tHashInput_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_7 finally ] start
	 */

	

	
	
	currentComponent="tJava_7";

	

 



/**
 * [tJava_7 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_7_SUBPROCESS_STATE", 1);
	}
	


public static class file_trcking_dtlStruct implements routines.system.IPersistableRow<file_trcking_dtlStruct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String mrg_jb_instnce_id;

				public String getMrg_jb_instnce_id () {
					return this.mrg_jb_instnce_id;
				}
				
			    public String file_nm;

				public String getFile_nm () {
					return this.file_nm;
				}
				
			    public String adls_file_loctn;

				public String getAdls_file_loctn () {
					return this.adls_file_loctn;
				}
				
			    public String ingtn_typ;

				public String getIngtn_typ () {
					return this.ingtn_typ;
				}
				
			    public String is_merged;

				public String getIs_merged () {
					return this.is_merged;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public String mrgd_file_loctn;

				public String getMrgd_file_loctn () {
					return this.mrgd_file_loctn;
				}
				
			    public String out_file_loctn;

				public String getOut_file_loctn () {
					return this.out_file_loctn;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.mrg_jb_instnce_id = readString(dis);
					
					this.file_nm = readString(dis);
					
					this.adls_file_loctn = readString(dis);
					
					this.ingtn_typ = readString(dis);
					
					this.is_merged = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_dttm = readDate(dis);
					
					this.updt_by = readString(dis);
					
					this.mrgd_file_loctn = readString(dis);
					
					this.out_file_loctn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.mrg_jb_instnce_id,dos);
					
					// String
				
						writeString(this.file_nm,dos);
					
					// String
				
						writeString(this.adls_file_loctn,dos);
					
					// String
				
						writeString(this.ingtn_typ,dos);
					
					// String
				
						writeString(this.is_merged,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// String
				
						writeString(this.mrgd_file_loctn,dos);
					
					// String
				
						writeString(this.out_file_loctn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",run_id="+run_id);
		sb.append(",mrg_jb_instnce_id="+mrg_jb_instnce_id);
		sb.append(",file_nm="+file_nm);
		sb.append(",adls_file_loctn="+adls_file_loctn);
		sb.append(",ingtn_typ="+ingtn_typ);
		sb.append(",is_merged="+is_merged);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
		sb.append(",updt_by="+updt_by);
		sb.append(",mrgd_file_loctn="+mrgd_file_loctn);
		sb.append(",out_file_loctn="+out_file_loctn);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(mrg_jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mrg_jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(file_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_nm);
            			}
            		
        			sb.append("|");
        		
        				if(adls_file_loctn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(adls_file_loctn);
            			}
            		
        			sb.append("|");
        		
        				if(ingtn_typ == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ingtn_typ);
            			}
            		
        			sb.append("|");
        		
        				if(is_merged == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_merged);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(mrgd_file_loctn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mrgd_file_loctn);
            			}
            		
        			sb.append("|");
        		
        				if(out_file_loctn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_file_loctn);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(file_trcking_dtlStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row9Struct implements routines.system.IPersistableRow<row9Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String mrg_jb_instnce_id;

				public String getMrg_jb_instnce_id () {
					return this.mrg_jb_instnce_id;
				}
				
			    public String file_nm;

				public String getFile_nm () {
					return this.file_nm;
				}
				
			    public String adls_file_loctn;

				public String getAdls_file_loctn () {
					return this.adls_file_loctn;
				}
				
			    public String ingtn_type;

				public String getIngtn_type () {
					return this.ingtn_type;
				}
				
			    public String is_merged;

				public String getIs_merged () {
					return this.is_merged;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public String mrgd_file_loctn;

				public String getMrgd_file_loctn () {
					return this.mrgd_file_loctn;
				}
				
			    public String out_file_loctn;

				public String getOut_file_loctn () {
					return this.out_file_loctn;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.mrg_jb_instnce_id = readString(dis);
					
					this.file_nm = readString(dis);
					
					this.adls_file_loctn = readString(dis);
					
					this.ingtn_type = readString(dis);
					
					this.is_merged = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_dttm = readDate(dis);
					
					this.updt_by = readString(dis);
					
					this.mrgd_file_loctn = readString(dis);
					
					this.out_file_loctn = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.mrg_jb_instnce_id,dos);
					
					// String
				
						writeString(this.file_nm,dos);
					
					// String
				
						writeString(this.adls_file_loctn,dos);
					
					// String
				
						writeString(this.ingtn_type,dos);
					
					// String
				
						writeString(this.is_merged,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// String
				
						writeString(this.mrgd_file_loctn,dos);
					
					// String
				
						writeString(this.out_file_loctn,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",run_id="+run_id);
		sb.append(",mrg_jb_instnce_id="+mrg_jb_instnce_id);
		sb.append(",file_nm="+file_nm);
		sb.append(",adls_file_loctn="+adls_file_loctn);
		sb.append(",ingtn_type="+ingtn_type);
		sb.append(",is_merged="+is_merged);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
		sb.append(",updt_by="+updt_by);
		sb.append(",mrgd_file_loctn="+mrgd_file_loctn);
		sb.append(",out_file_loctn="+out_file_loctn);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(mrg_jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mrg_jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(file_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_nm);
            			}
            		
        			sb.append("|");
        		
        				if(adls_file_loctn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(adls_file_loctn);
            			}
            		
        			sb.append("|");
        		
        				if(ingtn_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ingtn_type);
            			}
            		
        			sb.append("|");
        		
        				if(is_merged == null){
        					sb.append("<null>");
        				}else{
            				sb.append(is_merged);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(mrgd_file_loctn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(mrgd_file_loctn);
            			}
            		
        			sb.append("|");
        		
        				if(out_file_loctn == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_file_loctn);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row9Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row24Struct implements routines.system.IPersistableRow<row24Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row24Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row26Struct implements routines.system.IPersistableRow<row26Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row26Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tHashInput_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row26Struct row26 = new row26Struct();
row24Struct row24 = new row24Struct();
row9Struct row9 = new row9Struct();
file_trcking_dtlStruct file_trcking_dtl = new file_trcking_dtlStruct();





	
	/**
	 * [tFlowToIterate_6 begin ] start
	 */

				
			int NB_ITERATE_tFixedFlowInput_3 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_6", false);
		start_Hash.put("tFlowToIterate_6", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row24" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_6 = new StringBuilder();
            log4jParamters_tFlowToIterate_6.append("Parameters:");
                    log4jParamters_tFlowToIterate_6.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + (log4jParamters_tFlowToIterate_6) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_6().limitLog4jByte();

int nb_line_tFlowToIterate_6 = 0;
int counter_tFlowToIterate_6 = 0;

 



/**
 * [tFlowToIterate_6 begin ] stop
 */



	
	/**
	 * [tFilterRow_31 begin ] start
	 */

	

	
		
		ok_Hash.put("tFilterRow_31", false);
		start_Hash.put("tFilterRow_31", System.currentTimeMillis());
		
	
	currentComponent="tFilterRow_31";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row26" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFilterRow_31 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFilterRow_31 - "  + ("Start to work.") );
    	class BytesLimit65535_tFilterRow_31{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFilterRow_31 = new StringBuilder();
            log4jParamters_tFilterRow_31.append("Parameters:");
                    log4jParamters_tFilterRow_31.append("LOGICAL_OP" + " = " + "&&");
                log4jParamters_tFilterRow_31.append(" | ");
                    log4jParamters_tFilterRow_31.append("CONDITIONS" + " = " + "[{OPERATOR="+(">")+", RVALUE="+("0")+", INPUT_COLUMN="+("target_count")+", FUNCTION="+("")+"}]");
                log4jParamters_tFilterRow_31.append(" | ");
                    log4jParamters_tFilterRow_31.append("USE_ADVANCED" + " = " + "false");
                log4jParamters_tFilterRow_31.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFilterRow_31 - "  + (log4jParamters_tFilterRow_31) );
    		}
    	}
    	
        new BytesLimit65535_tFilterRow_31().limitLog4jByte();
    int nb_line_tFilterRow_31 = 0;
    int nb_line_ok_tFilterRow_31 = 0;
    int nb_line_reject_tFilterRow_31 = 0;

    class Operator_tFilterRow_31 {
      private String sErrorMsg = "";
      private boolean bMatchFlag = true;
      private String sUnionFlag = "&&";

      public Operator_tFilterRow_31(String unionFlag){
        sUnionFlag = unionFlag;
        bMatchFlag =  "||".equals(unionFlag) ? false : true;
      }

      public String getErrorMsg() {
        if (sErrorMsg != null && sErrorMsg.length() > 1)
          return sErrorMsg.substring(1);
        else 
          return null;
      }

      public boolean getMatchFlag() {
        return bMatchFlag;
      }

      public void matches(boolean partMatched, String reason) {
        // no need to care about the next judgement
        if ("||".equals(sUnionFlag) && bMatchFlag){
          return;
        }

        if (!partMatched) {
          sErrorMsg += "|" + reason;
        }

        if ("||".equals(sUnionFlag))
          bMatchFlag = bMatchFlag || partMatched;
        else
          bMatchFlag = bMatchFlag && partMatched;
      }
    }

 



/**
 * [tFilterRow_31 begin ] stop
 */



	
	/**
	 * [tHashInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_3", false);
		start_Hash.put("tHashInput_3", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_3";

	
		int tos_count_tHashInput_3 = 0;
		
    	class BytesLimit65535_tHashInput_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashInput_3().limitLog4jByte();


int nb_line_tHashInput_3 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_3=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashInput_3 = mf_tHashInput_3.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
if(tHashFile_tHashInput_3==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row22Struct> iterator_tHashInput_3 = tHashFile_tHashInput_3.iterator();
while (iterator_tHashInput_3.hasNext()) {
    row22Struct next_tHashInput_3 = iterator_tHashInput_3.next();

	row26.object_id = next_tHashInput_3.object_id;
	row26.object_nm = next_tHashInput_3.object_nm;
	row26.source_count = next_tHashInput_3.source_count;
	row26.target_count = next_tHashInput_3.target_count;
	row26.file_name = next_tHashInput_3.file_name;
	row26.cdc_start_dttm = next_tHashInput_3.cdc_start_dttm;
	row26.cdc_end_dttm = next_tHashInput_3.cdc_end_dttm;
 



/**
 * [tHashInput_3 begin ] stop
 */
	
	/**
	 * [tHashInput_3 main ] start
	 */

	

	
	
	currentComponent="tHashInput_3";

	

 


	tos_count_tHashInput_3++;

/**
 * [tHashInput_3 main ] stop
 */

	
	/**
	 * [tFilterRow_31 main ] start
	 */

	

	
	
	currentComponent="tFilterRow_31";

	

			//row26
			//row26


			
				if(execStat){
					runStat.updateStatOnConnection("row26"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row26 - " + (row26==null? "": row26.toLogString()));
    			}
    		

          row24 = null;
    Operator_tFilterRow_31 ope_tFilterRow_31 = new Operator_tFilterRow_31("&&");
            ope_tFilterRow_31.matches((row26.target_count == null? false : row26.target_count.compareTo(ParserUtils.parseTo_Integer(String.valueOf(0))) > 0)
                           , "target_count.compareTo(0) > 0 failed");
		 	
    
    if (ope_tFilterRow_31.getMatchFlag()) {
              if(row24 == null){ 
                row24 = new row24Struct();
              }
               row24.object_id = row26.object_id;
               row24.object_nm = row26.object_nm;
               row24.source_count = row26.source_count;
               row24.target_count = row26.target_count;
               row24.file_name = row26.file_name;
               row24.cdc_start_dttm = row26.cdc_start_dttm;
               row24.cdc_end_dttm = row26.cdc_end_dttm;
					log.debug("tFilterRow_31 - Process the record " + (nb_line_tFilterRow_31+1) + ".");
					    
      nb_line_ok_tFilterRow_31++;
    } else {
      nb_line_reject_tFilterRow_31++;
    }

nb_line_tFilterRow_31++;

 


	tos_count_tFilterRow_31++;

/**
 * [tFilterRow_31 main ] stop
 */
// Start of branch "row24"
if(row24 != null) { 



	
	/**
	 * [tFlowToIterate_6 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_6";

	

			//row24
			//row24


			
				if(execStat){
					runStat.updateStatOnConnection("row24"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row24 - " + (row24==null? "": row24.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row24.object_id, value=")  + (row24.object_id)  + (".") );            
            globalMap.put("row24.object_id", row24.object_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row24.object_nm, value=")  + (row24.object_nm)  + (".") );            
            globalMap.put("row24.object_nm", row24.object_nm);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row24.source_count, value=")  + (row24.source_count)  + (".") );            
            globalMap.put("row24.source_count", row24.source_count);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row24.target_count, value=")  + (row24.target_count)  + (".") );            
            globalMap.put("row24.target_count", row24.target_count);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row24.file_name, value=")  + (row24.file_name)  + (".") );            
            globalMap.put("row24.file_name", row24.file_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row24.cdc_start_dttm, value=")  + (row24.cdc_start_dttm)  + (".") );            
            globalMap.put("row24.cdc_start_dttm", row24.cdc_start_dttm);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_6 - "  + ("Set global var, key=row24.cdc_end_dttm, value=")  + (row24.cdc_end_dttm)  + (".") );            
            globalMap.put("row24.cdc_end_dttm", row24.cdc_end_dttm);
    	
 
	   nb_line_tFlowToIterate_6++;  
       counter_tFlowToIterate_6++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_6)  + (".") );
       globalMap.put("tFlowToIterate_6_CURRENT_ITERATION", counter_tFlowToIterate_6);
 


	tos_count_tFlowToIterate_6++;

/**
 * [tFlowToIterate_6 main ] stop
 */
	NB_ITERATE_tFixedFlowInput_3++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row9", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("file_trcking_dtl", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate7", 1, "exec" + NB_ITERATE_tFixedFlowInput_3);
					//Thread.sleep(1000);
				}				
			



	
	/**
	 * [tMSSqlOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_3", false);
		start_Hash.put("tMSSqlOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("file_trcking_dtl" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_3 = new StringBuilder();
            log4jParamters_tMSSqlOutput_3.append("Parameters:");
                    log4jParamters_tMSSqlOutput_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("TABLE" + " = " + "\"t_file_trckr_dtl\"");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                    log4jParamters_tMSSqlOutput_3.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + (log4jParamters_tMSSqlOutput_3) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_3().limitLog4jByte();



int nb_line_tMSSqlOutput_3 = 0;
int nb_line_update_tMSSqlOutput_3 = 0;
int nb_line_inserted_tMSSqlOutput_3 = 0;
int nb_line_deleted_tMSSqlOutput_3 = 0;
int nb_line_rejected_tMSSqlOutput_3 = 0;

int deletedCount_tMSSqlOutput_3=0;
int updatedCount_tMSSqlOutput_3=0;
int insertedCount_tMSSqlOutput_3=0;
int rejectedCount_tMSSqlOutput_3=0;
String dbschema_tMSSqlOutput_3 = null;
String tableName_tMSSqlOutput_3 = null;
boolean whetherReject_tMSSqlOutput_3 = false;

java.util.Calendar calendar_tMSSqlOutput_3 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_3 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_3;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_3 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_3 = null;
String dbUser_tMSSqlOutput_3 = null;
	dbschema_tMSSqlOutput_3 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_3 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_3.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_3.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_3.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_3 == null || dbschema_tMSSqlOutput_3.trim().length() == 0) {
    tableName_tMSSqlOutput_3 = "t_file_trckr_dtl";
} else {
    tableName_tMSSqlOutput_3 = dbschema_tMSSqlOutput_3 + "].[" + "t_file_trckr_dtl";
}
	int count_tMSSqlOutput_3=0;

        String insert_tMSSqlOutput_3 = "INSERT INTO [" + tableName_tMSSqlOutput_3 + "] ([src_sys_id],[sub_sys_id],[object_id],[run_id],[mrg_jb_instnce_id],[file_nm],[adls_file_loctn],[ingtn_typ],[is_merged],[crtd_dttm],[crtd_by],[updt_dttm],[updt_by],[mrgd_file_loctn],[out_file_loctn]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_3 = conn_tMSSqlOutput_3.prepareStatement(insert_tMSSqlOutput_3);

 	boolean isShareIdentity_tMSSqlOutput_3 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_3 begin ] stop
 */



	
	/**
	 * [tMap_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_2", false);
		start_Hash.put("tMap_2", System.currentTimeMillis());
		
	
	currentComponent="tMap_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row9" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_2 = new StringBuilder();
            log4jParamters_tMap_2.append("Parameters:");
                    log4jParamters_tMap_2.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_2.append(" | ");
                    log4jParamters_tMap_2.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + (log4jParamters_tMap_2) );
    		}
    	}
    	
        new BytesLimit65535_tMap_2().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row9_tMap_2 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_2__Struct  {
}
Var__tMap_2__Struct Var__tMap_2 = new Var__tMap_2__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_file_trcking_dtl_tMap_2 = 0;
				
file_trcking_dtlStruct file_trcking_dtl_tmp = new file_trcking_dtlStruct();
// ###############################

        
        



        









 



/**
 * [tMap_2 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_3", false);
		start_Hash.put("tFixedFlowInput_3", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_3";

	
		int tos_count_tFixedFlowInput_3 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_3().limitLog4jByte();

	    for (int i_tFixedFlowInput_3 = 0 ; i_tFixedFlowInput_3 < 1 ; i_tFixedFlowInput_3++) {
	                	            	
    	            		row9.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row9.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row9.object_id = ((String)globalMap.get("row24.object_id"));
    	            	        	            	
    	            		row9.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row9.mrg_jb_instnce_id = null;        	            	
    	            	        	            	
    	            		row9.file_nm = ((String)globalMap.get("row24.file_name"));
    	            	        	            	
    	            		row9.adls_file_loctn = ((String)globalMap.get("ADLS_FILE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row24.object_nm")) + "/" + TalendDate.formatDate("yyyy/MM/dd", TalendDate.getCurrentDate()) : "") + "/" + ((String)globalMap.get("row24.file_name"));
    	            	        	            	
    	            		row9.ingtn_type = ((String)globalMap.get("INGTN_TYP"));
    	            	        	            	
    	            		row9.is_merged = ((String)globalMap.get("IS_MERGED"));
    	            	        	            	
    	            		row9.crtd_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row9.crtd_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row9.updt_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row9.updt_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row9.mrgd_file_loctn = ((String)globalMap.get("ADLS_MERGE_PATH")) + ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE")) ? "/" + ((String)globalMap.get("row24.object_nm")) : "");
    	            	        	            	
    	            		row9.out_file_loctn = ((String)globalMap.get("OUT_FILE_LOCTN")) + "/" + ((String)globalMap.get("SRC_SYS_NM")) + (Relational.ISNULL((String)globalMap.get("SUB_SYS_NM")) ? "" : "_" + ((String)globalMap.get("SUB_SYS_NM"))) + "/" + ((String)globalMap.get("row24.object_nm")) + "_TEMP";
    	            	
 



/**
 * [tFixedFlowInput_3 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_3 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

 


	tos_count_tFixedFlowInput_3++;

/**
 * [tFixedFlowInput_3 main ] stop
 */

	
	/**
	 * [tMap_2 main ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

			//row9
			//row9


			
				if(execStat){
					runStat.updateStatOnConnection("row9"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row9 - " + (row9==null? "": row9.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_2 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_2 = false;
		  boolean mainRowRejected_tMap_2 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_2__Struct Var = Var__tMap_2;// ###############################
        // ###############################
        // # Output tables

file_trcking_dtl = null;


// # Output table : 'file_trcking_dtl'
count_file_trcking_dtl_tMap_2++;

file_trcking_dtl_tmp.src_sys_id = row9.src_sys_id ;
file_trcking_dtl_tmp.sub_sys_id = row9.sub_sys_id ;
file_trcking_dtl_tmp.object_id = row9.object_id ;
file_trcking_dtl_tmp.run_id = row9.run_id ;
file_trcking_dtl_tmp.mrg_jb_instnce_id = row9.mrg_jb_instnce_id ;
file_trcking_dtl_tmp.file_nm = row9.file_nm ;
file_trcking_dtl_tmp.adls_file_loctn = row9.adls_file_loctn ;
file_trcking_dtl_tmp.ingtn_typ = row9.ingtn_type;
file_trcking_dtl_tmp.is_merged = row9.is_merged ;
file_trcking_dtl_tmp.crtd_dttm = row9.crtd_dttm ;
file_trcking_dtl_tmp.crtd_by = row9.crtd_by ;
file_trcking_dtl_tmp.updt_dttm = row9.updt_dttm ;
file_trcking_dtl_tmp.updt_by = row9.updt_by ;
file_trcking_dtl_tmp.mrgd_file_loctn = row9.mrgd_file_loctn.replaceAll(" ","") ;
file_trcking_dtl_tmp.out_file_loctn = row9.out_file_loctn.replaceAll(" ","") ;
file_trcking_dtl = file_trcking_dtl_tmp;
log.debug("tMap_2 - Outputting the record " + count_file_trcking_dtl_tMap_2 + " of the output table 'file_trcking_dtl'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_2 = false;










 


	tos_count_tMap_2++;

/**
 * [tMap_2 main ] stop
 */
// Start of branch "file_trcking_dtl"
if(file_trcking_dtl != null) { 



	
	/**
	 * [tMSSqlOutput_3 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_3";

	

			//file_trcking_dtl
			//file_trcking_dtl


			
				if(execStat){
					runStat.updateStatOnConnection("file_trcking_dtl"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("file_trcking_dtl - " + (file_trcking_dtl==null? "": file_trcking_dtl.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_3 = false;
                    if(file_trcking_dtl.src_sys_id == null) {
pstmt_tMSSqlOutput_3.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(1, file_trcking_dtl.src_sys_id);
}

                    if(file_trcking_dtl.sub_sys_id == null) {
pstmt_tMSSqlOutput_3.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(2, file_trcking_dtl.sub_sys_id);
}

                    if(file_trcking_dtl.object_id == null) {
pstmt_tMSSqlOutput_3.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(3, file_trcking_dtl.object_id);
}

                    if(file_trcking_dtl.run_id == null) {
pstmt_tMSSqlOutput_3.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(4, file_trcking_dtl.run_id);
}

                    if(file_trcking_dtl.mrg_jb_instnce_id == null) {
pstmt_tMSSqlOutput_3.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(5, file_trcking_dtl.mrg_jb_instnce_id);
}

                    if(file_trcking_dtl.file_nm == null) {
pstmt_tMSSqlOutput_3.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(6, file_trcking_dtl.file_nm);
}

                    if(file_trcking_dtl.adls_file_loctn == null) {
pstmt_tMSSqlOutput_3.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(7, file_trcking_dtl.adls_file_loctn);
}

                    if(file_trcking_dtl.ingtn_typ == null) {
pstmt_tMSSqlOutput_3.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(8, file_trcking_dtl.ingtn_typ);
}

                    if(file_trcking_dtl.is_merged == null) {
pstmt_tMSSqlOutput_3.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(9, file_trcking_dtl.is_merged);
}

                    if(file_trcking_dtl.crtd_dttm != null) {
pstmt_tMSSqlOutput_3.setTimestamp(10, new java.sql.Timestamp(file_trcking_dtl.crtd_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_3.setNull(10, java.sql.Types.DATE);
}

                    if(file_trcking_dtl.crtd_by == null) {
pstmt_tMSSqlOutput_3.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(11, file_trcking_dtl.crtd_by);
}

                    if(file_trcking_dtl.updt_dttm != null) {
pstmt_tMSSqlOutput_3.setTimestamp(12, new java.sql.Timestamp(file_trcking_dtl.updt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_3.setNull(12, java.sql.Types.DATE);
}

                    if(file_trcking_dtl.updt_by == null) {
pstmt_tMSSqlOutput_3.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(13, file_trcking_dtl.updt_by);
}

                    if(file_trcking_dtl.mrgd_file_loctn == null) {
pstmt_tMSSqlOutput_3.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(14, file_trcking_dtl.mrgd_file_loctn);
}

                    if(file_trcking_dtl.out_file_loctn == null) {
pstmt_tMSSqlOutput_3.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_3.setString(15, file_trcking_dtl.out_file_loctn);
}


            try {
                nb_line_tMSSqlOutput_3++;
                insertedCount_tMSSqlOutput_3 = insertedCount_tMSSqlOutput_3 + pstmt_tMSSqlOutput_3.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_3)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_3 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_3{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_3) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_3: pstmt_tMSSqlOutput_3.executeBatch()) {
							if(countEach_tMSSqlOutput_3 == -2 || countEach_tMSSqlOutput_3 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_3;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_3) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_3: pstmt_tMSSqlOutput_3.executeBatch()) {
							if(countEach_tMSSqlOutput_3 == -2 || countEach_tMSSqlOutput_3 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_3;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_3++;

/**
 * [tMSSqlOutput_3 main ] stop
 */

} // End of branch "file_trcking_dtl"







	
	/**
	 * [tFixedFlowInput_3 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

        }
        globalMap.put("tFixedFlowInput_3_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_3", true);
end_Hash.put("tFixedFlowInput_3", System.currentTimeMillis());




/**
 * [tFixedFlowInput_3 end ] stop
 */

	
	/**
	 * [tMap_2 end ] start
	 */

	

	
	
	currentComponent="tMap_2";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_2 - Written records count in the table 'file_trcking_dtl': " + count_file_trcking_dtl_tMap_2 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row9"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_2 - "  + ("Done.") );

ok_Hash.put("tMap_2", true);
end_Hash.put("tMap_2", System.currentTimeMillis());




/**
 * [tMap_2 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_3 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_3";

	



        if(pstmt_tMSSqlOutput_3 != null) {
			
				pstmt_tMSSqlOutput_3.close();
			
        }


	nb_line_deleted_tMSSqlOutput_3=nb_line_deleted_tMSSqlOutput_3+ deletedCount_tMSSqlOutput_3;
	nb_line_update_tMSSqlOutput_3=nb_line_update_tMSSqlOutput_3 + updatedCount_tMSSqlOutput_3;
	nb_line_inserted_tMSSqlOutput_3=nb_line_inserted_tMSSqlOutput_3 + insertedCount_tMSSqlOutput_3;
	nb_line_rejected_tMSSqlOutput_3=nb_line_rejected_tMSSqlOutput_3 + rejectedCount_tMSSqlOutput_3;
	
        globalMap.put("tMSSqlOutput_3_NB_LINE",nb_line_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_3);
        globalMap.put("tMSSqlOutput_3_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_3);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_3)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("file_trcking_dtl"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_3 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_3", true);
end_Hash.put("tMSSqlOutput_3", System.currentTimeMillis());




/**
 * [tMSSqlOutput_3 end ] stop
 */






						if(execStat){
							runStat.updateStatOnConnection("iterate7", 2, "exec" + NB_ITERATE_tFixedFlowInput_3);
						}				
					





} // End of branch "row24"







	
	/**
	 * [tHashInput_3 end ] start
	 */

	

	
	
	currentComponent="tHashInput_3";

	
    

		
			nb_line_tHashInput_3++;
		}	
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
	


	globalMap.put("tHashInput_3_NB_LINE", nb_line_tHashInput_3);       

 

ok_Hash.put("tHashInput_3", true);
end_Hash.put("tHashInput_3", System.currentTimeMillis());




/**
 * [tHashInput_3 end ] stop
 */

	
	/**
	 * [tFilterRow_31 end ] start
	 */

	

	
	
	currentComponent="tFilterRow_31";

	
    globalMap.put("tFilterRow_31_NB_LINE", nb_line_tFilterRow_31);
    globalMap.put("tFilterRow_31_NB_LINE_OK", nb_line_ok_tFilterRow_31);
    globalMap.put("tFilterRow_31_NB_LINE_REJECT", nb_line_reject_tFilterRow_31);
    
    	log.info("tFilterRow_31 - Processed records count:" + nb_line_tFilterRow_31 + ". Matched records count:" + nb_line_ok_tFilterRow_31 + ". Rejected records count:" + nb_line_reject_tFilterRow_31 + ".");

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row26"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFilterRow_31 - "  + ("Done.") );

ok_Hash.put("tFilterRow_31", true);
end_Hash.put("tFilterRow_31", System.currentTimeMillis());




/**
 * [tFilterRow_31 end ] stop
 */

	
	/**
	 * [tFlowToIterate_6 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_6";

	

globalMap.put("tFlowToIterate_6_NB_LINE",nb_line_tFlowToIterate_6);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row24"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_6 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_6", true);
end_Hash.put("tFlowToIterate_6", System.currentTimeMillis());




/**
 * [tFlowToIterate_6 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tHashInput_3 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_3";

	

 



/**
 * [tHashInput_3 finally ] stop
 */

	
	/**
	 * [tFilterRow_31 finally ] start
	 */

	

	
	
	currentComponent="tFilterRow_31";

	

 



/**
 * [tFilterRow_31 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_6 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_6";

	

 



/**
 * [tFlowToIterate_6 finally ] stop
 */

	
	/**
	 * [tFixedFlowInput_3 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_3";

	

 



/**
 * [tFixedFlowInput_3 finally ] stop
 */

	
	/**
	 * [tMap_2 finally ] start
	 */

	

	
	
	currentComponent="tMap_2";

	

 



/**
 * [tMap_2 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_3";

	



	

 



/**
 * [tMSSqlOutput_3 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_3_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_11", false);
		start_Hash.put("tWarn_11", System.currentTimeMillis());
		
	
	currentComponent="tWarn_11";

	
		int tos_count_tWarn_11 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_11{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_11 = new StringBuilder();
            log4jParamters_tWarn_11.append("Parameters:");
                    log4jParamters_tWarn_11.append("MESSAGE" + " = " + "\"212|Insert into File Tracker table failed\"");
                log4jParamters_tWarn_11.append(" | ");
                    log4jParamters_tWarn_11.append("CODE" + " = " + "999");
                log4jParamters_tWarn_11.append(" | ");
                    log4jParamters_tWarn_11.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_11.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + (log4jParamters_tWarn_11) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_11().limitLog4jByte();

 



/**
 * [tWarn_11 begin ] stop
 */
	
	/**
	 * [tWarn_11 main ] start
	 */

	

	
	
	currentComponent="tWarn_11";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_11", "", Thread.currentThread().getId() + "", "ERROR","","212|Insert into File Tracker table failed","", "");
            log.error("tWarn_11 - "  + ("Message: ")  + ("212|Insert into File Tracker table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_11", 5, "212|Insert into File Tracker table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_11_WARN_MESSAGES", "212|Insert into File Tracker table failed"); 
globalMap.put("tWarn_11_WARN_PRIORITY", 5);
globalMap.put("tWarn_11_WARN_CODE", 999);


 


	tos_count_tWarn_11++;

/**
 * [tWarn_11 main ] stop
 */
	
	/**
	 * [tWarn_11 end ] start
	 */

	

	
	
	currentComponent="tWarn_11";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_11 - "  + ("Done.") );

ok_Hash.put("tWarn_11", true);
end_Hash.put("tWarn_11", System.currentTimeMillis());




/**
 * [tWarn_11 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_11 finally ] start
	 */

	

	
	
	currentComponent="tWarn_11";

	

 



/**
 * [tWarn_11 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_11_SUBPROCESS_STATE", 1);
	}
	


public static class out3Struct implements routines.system.IPersistableRow<out3Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				
			    public String etl_crtd_by;

				public String getEtl_crtd_by () {
					return this.etl_crtd_by;
				}
				
			    public java.util.Date etl_crtd_dt;

				public java.util.Date getEtl_crtd_dt () {
					return this.etl_crtd_dt;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
					this.etl_crtd_by = readString(dis);
					
					this.etl_crtd_dt = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
					// String
				
						writeString(this.etl_crtd_by,dos);
					
					// java.util.Date
				
						writeDate(this.etl_crtd_dt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
		sb.append(",etl_crtd_by="+etl_crtd_by);
		sb.append(",etl_crtd_dt="+String.valueOf(etl_crtd_dt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_dt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_dt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class sp_multi_outStruct implements routines.system.IPersistableRow<sp_multi_outStruct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic data_row;

				public routines.system.Dynamic getData_row () {
					return this.data_row;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.data_row = (routines.system.Dynamic) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.data_row);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("data_row="+String.valueOf(data_row));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(data_row == null){
        					sb.append("<null>");
        				}else{
            				sb.append(data_row);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(sp_multi_outStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class sp_multi_inStruct implements routines.system.IPersistableRow<sp_multi_inStruct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public Object out_ref_cursor;

				public Object getOut_ref_cursor () {
					return this.out_ref_cursor;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.out_ref_cursor = (Object) dis.readObject();
					
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Object
				
       			    	dos.writeObject(this.out_ref_cursor);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("out_ref_cursor="+String.valueOf(out_ref_cursor));
		sb.append(",object_id="+object_id);
		sb.append(",object_nm="+object_nm);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(out_ref_cursor == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_ref_cursor);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(sp_multi_inStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row17Struct implements routines.system.IPersistableRow<row17Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public Object out_ref_cursor_sdh_con;

				public Object getOut_ref_cursor_sdh_con () {
					return this.out_ref_cursor_sdh_con;
				}
				
			    public Object out_ref_cursor_sdh_child;

				public Object getOut_ref_cursor_sdh_child () {
					return this.out_ref_cursor_sdh_child;
				}
				
			    public Object out_ref_cursor_sdh_addr;

				public Object getOut_ref_cursor_sdh_addr () {
					return this.out_ref_cursor_sdh_addr;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.out_ref_cursor_sdh_con = (Object) dis.readObject();
					
						this.out_ref_cursor_sdh_child = (Object) dis.readObject();
					
						this.out_ref_cursor_sdh_addr = (Object) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Object
				
       			    	dos.writeObject(this.out_ref_cursor_sdh_con);
					
					// Object
				
       			    	dos.writeObject(this.out_ref_cursor_sdh_child);
					
					// Object
				
       			    	dos.writeObject(this.out_ref_cursor_sdh_addr);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("out_ref_cursor_sdh_con="+String.valueOf(out_ref_cursor_sdh_con));
		sb.append(",out_ref_cursor_sdh_child="+String.valueOf(out_ref_cursor_sdh_child));
		sb.append(",out_ref_cursor_sdh_addr="+String.valueOf(out_ref_cursor_sdh_addr));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(out_ref_cursor_sdh_con == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_ref_cursor_sdh_con);
            			}
            		
        			sb.append("|");
        		
        				if(out_ref_cursor_sdh_child == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_ref_cursor_sdh_child);
            			}
            		
        			sb.append("|");
        		
        				if(out_ref_cursor_sdh_addr == null){
        					sb.append("<null>");
        				}else{
            				sb.append(out_ref_cursor_sdh_addr);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row17Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tOracleSP_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleSP_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row17Struct row17 = new row17Struct();
sp_multi_inStruct sp_multi_in = new sp_multi_inStruct();
sp_multi_outStruct sp_multi_out = new sp_multi_outStruct();
out3Struct out3 = new out3Struct();





	
	/**
	 * [tFlowToIterate_2 begin ] start
	 */

				
			int NB_ITERATE_tJavaFlex_2 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_2", false);
		start_Hash.put("tFlowToIterate_2", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_2";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("sp_multi_in" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_2 = new StringBuilder();
            log4jParamters_tFlowToIterate_2.append("Parameters:");
                    log4jParamters_tFlowToIterate_2.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + (log4jParamters_tFlowToIterate_2) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_2().limitLog4jByte();

int nb_line_tFlowToIterate_2 = 0;
int counter_tFlowToIterate_2 = 0;

 



/**
 * [tFlowToIterate_2 begin ] stop
 */



	
	/**
	 * [tSplitRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSplitRow_1", false);
		start_Hash.put("tSplitRow_1", System.currentTimeMillis());
		
	
	currentComponent="tSplitRow_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row17" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tSplitRow_1 = 0;
		
    	class BytesLimit65535_tSplitRow_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tSplitRow_1().limitLog4jByte();
int nb_line_tSplitRow_1 = 0;
 



/**
 * [tSplitRow_1 begin ] stop
 */



	
	/**
	 * [tOracleSP_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleSP_2", false);
		start_Hash.put("tOracleSP_2", System.currentTimeMillis());
		
	
	currentComponent="tOracleSP_2";

	
		int tos_count_tOracleSP_2 = 0;
		
    	class BytesLimit65535_tOracleSP_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tOracleSP_2().limitLog4jByte();

	java.sql.Connection connection_tOracleSP_2 = null;
	connection_tOracleSP_2 = (java.sql.Connection) globalMap.get("conn_tOracleConnection_1");
	

java.sql.CallableStatement statement_tOracleSP_2 = connection_tOracleSP_2.prepareCall("{call " + ((String)globalMap.get("OBJECT_LIST")) + "(?,?,?)}");

java.sql.Timestamp tmpDate_tOracleSP_2;
String tmpString_tOracleSP_2;

 



/**
 * [tOracleSP_2 begin ] stop
 */
	
	/**
	 * [tOracleSP_2 main ] start
	 */

	

	
	
	currentComponent="tOracleSP_2";

	

				statement_tOracleSP_2.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
				statement_tOracleSP_2.registerOutParameter(2, oracle.jdbc.OracleTypes.CURSOR);
				statement_tOracleSP_2.registerOutParameter(3, oracle.jdbc.OracleTypes.CURSOR);
		statement_tOracleSP_2.execute();
		
								row17.out_ref_cursor_sdh_con = statement_tOracleSP_2.getObject(1);
								row17.out_ref_cursor_sdh_child = statement_tOracleSP_2.getObject(2);
								row17.out_ref_cursor_sdh_addr = statement_tOracleSP_2.getObject(3);

 


	tos_count_tOracleSP_2++;

/**
 * [tOracleSP_2 main ] stop
 */

	
	/**
	 * [tSplitRow_1 main ] start
	 */

	

	
	
	currentComponent="tSplitRow_1";

	

			//row17
			//row17


			
				if(execStat){
					runStat.updateStatOnConnection("row17"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row17 - " + (row17==null? "": row17.toLogString()));
    			}
    		
  java.util.List<sp_multi_inStruct> rows_tSplitRow_1 = new java.util.ArrayList<sp_multi_inStruct>(3);
  sp_multi_inStruct rowTmp_tSplitRow_1 = null;

  // cache output rows for the loop
    rowTmp_tSplitRow_1 = new sp_multi_inStruct();

      rowTmp_tSplitRow_1.out_ref_cursor = row17.out_ref_cursor_sdh_con;
      rowTmp_tSplitRow_1.object_id = ((String)globalMap.get("MULTI_OBJECT_ID_1"));
      rowTmp_tSplitRow_1.object_nm = ((String)globalMap.get("MULTI_OBJECT_NM_1"));
    rows_tSplitRow_1.add(rowTmp_tSplitRow_1);
    nb_line_tSplitRow_1++;
    rowTmp_tSplitRow_1 = new sp_multi_inStruct();

      rowTmp_tSplitRow_1.out_ref_cursor = row17.out_ref_cursor_sdh_child;
      rowTmp_tSplitRow_1.object_id = ((String)globalMap.get("MULTI_OBJECT_ID_2"));
      rowTmp_tSplitRow_1.object_nm = ((String)globalMap.get("MULTI_OBJECT_NM_2"));
    rows_tSplitRow_1.add(rowTmp_tSplitRow_1);
    nb_line_tSplitRow_1++;
    rowTmp_tSplitRow_1 = new sp_multi_inStruct();

      rowTmp_tSplitRow_1.out_ref_cursor = row17.out_ref_cursor_sdh_addr;
      rowTmp_tSplitRow_1.object_id = ((String)globalMap.get("MULTI_OBJECT_ID_3"));
      rowTmp_tSplitRow_1.object_nm = ((String)globalMap.get("MULTI_OBJECT_NM_3"));
    rows_tSplitRow_1.add(rowTmp_tSplitRow_1);
    nb_line_tSplitRow_1++;

  for (sp_multi_inStruct row_tSplitRow_1 : rows_tSplitRow_1) {// C_01
    sp_multi_in = row_tSplitRow_1; 
 


	tos_count_tSplitRow_1++;

/**
 * [tSplitRow_1 main ] stop
 */
// Start of branch "sp_multi_in"
if(sp_multi_in != null) { 



	
	/**
	 * [tFlowToIterate_2 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

			//sp_multi_in
			//sp_multi_in


			
				if(execStat){
					runStat.updateStatOnConnection("sp_multi_in"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("sp_multi_in - " + (sp_multi_in==null? "": sp_multi_in.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=sp_multi_in.out_ref_cursor, value=")  + (sp_multi_in.out_ref_cursor)  + (".") );            
            globalMap.put("sp_multi_in.out_ref_cursor", sp_multi_in.out_ref_cursor);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=sp_multi_in.object_id, value=")  + (sp_multi_in.object_id)  + (".") );            
            globalMap.put("sp_multi_in.object_id", sp_multi_in.object_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_2 - "  + ("Set global var, key=sp_multi_in.object_nm, value=")  + (sp_multi_in.object_nm)  + (".") );            
            globalMap.put("sp_multi_in.object_nm", sp_multi_in.object_nm);
    	
 
	   nb_line_tFlowToIterate_2++;  
       counter_tFlowToIterate_2++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_2)  + (".") );
       globalMap.put("tFlowToIterate_2_CURRENT_ITERATION", counter_tFlowToIterate_2);
 


	tos_count_tFlowToIterate_2++;

/**
 * [tFlowToIterate_2 main ] stop
 */
	NB_ITERATE_tJavaFlex_2++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("OnComponentOk13", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("sp_multi_out", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("out3", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row16", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate4", 1, "exec" + NB_ITERATE_tJavaFlex_2);
					//Thread.sleep(1000);
				}				
			



	
	/**
	 * [tFileOutputDelimited_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_4", false);
		start_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out3" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimited_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileOutputDelimited_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileOutputDelimited_4 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_4.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_4.append("USESTREAM" + " = " + "true");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("STREAMNAME" + " = " + "new java.io.FileOutputStream(((String)globalMap.get(\"LOCAL_DIRECTORY\")) + \"/Outbound/\" + ((String)globalMap.get(\"sp_multi_in.object_nm\")) + \"_\" + ((String)globalMap.get(\"JOB_STARTTIME_STRING\")) + \".\" + ((String)globalMap.get(\"FILE_EXTENSION\")), false)");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("OS_LINE_SEPARATOR_AS_ROW_SEPARATOR" + " = " + "true");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("CSVROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("FIELDSEPARATOR" + " = " + "((String)globalMap.get(\"FIELD_SEPARATOR\"))");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("CSV_OPTION" + " = " + "true");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ESCAPE_CHAR" + " = " + "((String)globalMap.get(\"ESCAPE_CHAR\"))");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("TEXT_ENCLOSURE" + " = " + "((String)globalMap.get(\"TEXT_ENCLOSURE\"))");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                    log4jParamters_tFileOutputDelimited_4.append("ENCODING" + " = " + "(Relational.ISNULL(globalMap.get(\"CHR_ENCODE\")) || \"\".equals((String)globalMap.get(\"CHR_ENCODE\"))) ? \"UTF-8\" : ((String)globalMap.get(\"CHR_ENCODE\"))");
                log4jParamters_tFileOutputDelimited_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_4 - "  + (log4jParamters_tFileOutputDelimited_4) );
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimited_4().limitLog4jByte();

String fileName_tFileOutputDelimited_4 = "";
        int dynamic_column_count_tFileOutputDelimited_4 = 1;
                boolean isFirstCheckDyn_tFileOutputDelimited_4= true;
                String[] headColutFileOutputDelimited_4 = null;
            class CSVBasicSet_tFileOutputDelimited_4{
                private char field_Delim;
                private char row_Delim;
                private char escape;
                private char textEnclosure;
                private boolean useCRLFRecordDelimiter;

                public boolean isUseCRLFRecordDelimiter() {
                    return useCRLFRecordDelimiter;
                }

                public void setFieldSeparator(String fieldSep) throws IllegalArgumentException{
                    char field_Delim_tFileOutputDelimited_4[] = null;

                    //support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'.
                    if (fieldSep.length() > 0 ){
                        field_Delim_tFileOutputDelimited_4 = fieldSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Field Separator must be assigned a char.");
                    }
                    this.field_Delim = field_Delim_tFileOutputDelimited_4[0];
                }

                public char getFieldDelim(){
                    if(this.field_Delim==0){
                        setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
                    }
                    return this.field_Delim;
                }

                public void setRowSeparator(String rowSep){
                    if("\r\n".equals(rowSep)) {
                        useCRLFRecordDelimiter = true;
                        return;
                    }
                    char row_DelimtFileOutputDelimited_4[] = null;

                    //support passing value (property: Row Separator) by 'context.rs' or 'globalMap.get("rs")'.
                    if (rowSep.length() > 0 ){
                        row_DelimtFileOutputDelimited_4 = rowSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Row Separator must be assigned a char.");
                    }
                    this.row_Delim = row_DelimtFileOutputDelimited_4[0];
                }

                public char getRowDelim(){
                    if(this.row_Delim==0){
                        setRowSeparator("\n");
                    }
                    return this.row_Delim;
                }

                public void setEscapeAndTextEnclosure(String strEscape, String strTextEnclosure) throws IllegalArgumentException{
                    if(strEscape.length() <= 0 ){
                        throw new IllegalArgumentException("Escape Char must be assigned a char.");
                    }

                    if ("".equals(strTextEnclosure)) strTextEnclosure = "\0";
                    char textEnclosure_tFileOutputDelimited_4[] = null;

                    if(strTextEnclosure.length() > 0 ){
                        textEnclosure_tFileOutputDelimited_4 = strTextEnclosure.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Text Enclosure must be assigned a char.");
                    }

                    this.textEnclosure = textEnclosure_tFileOutputDelimited_4[0];

                    if(("\\").equals(strEscape)){
                        this.escape = '\\';
                    }else if(strEscape.equals(strTextEnclosure)){
                        this.escape = this.textEnclosure;
                    } else {
                        //the default escape mode is double escape
                        this.escape = this.textEnclosure;
                    }


                }

                public char getEscapeChar(){
                    return (char)this.escape;
                }

                public char getTextEnclosure(){
                    return this.textEnclosure;
                }
            }

            int nb_line_tFileOutputDelimited_4 = 0;
            int splitedFileNo_tFileOutputDelimited_4 =0;
            int currentRow_tFileOutputDelimited_4 = 0;


            CSVBasicSet_tFileOutputDelimited_4 csvSettings_tFileOutputDelimited_4 = new CSVBasicSet_tFileOutputDelimited_4();
            csvSettings_tFileOutputDelimited_4.setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
            csvSettings_tFileOutputDelimited_4.setRowSeparator("\n");
            csvSettings_tFileOutputDelimited_4.setEscapeAndTextEnclosure(((String)globalMap.get("ESCAPE_CHAR")),((String)globalMap.get("TEXT_ENCLOSURE")));
                        java.io.OutputStreamWriter outWriter_tFileOutputDelimited_4 = null;
                        java.io.BufferedWriter bufferWriter_tFileOutputDelimited_4 = null;
                        com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_4 = null;
                        outWriter_tFileOutputDelimited_4 = new java.io.OutputStreamWriter(new java.io.FileOutputStream(((String)globalMap.get("LOCAL_DIRECTORY")) + "/Outbound/" + ((String)globalMap.get("sp_multi_in.object_nm")) + "_" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "." + ((String)globalMap.get("FILE_EXTENSION")), false), (Relational.ISNULL(globalMap.get("CHR_ENCODE")) || "".equals((String)globalMap.get("CHR_ENCODE"))) ? "UTF-8" : ((String)globalMap.get("CHR_ENCODE")));
                        bufferWriter_tFileOutputDelimited_4 = new java.io.BufferedWriter(outWriter_tFileOutputDelimited_4);
                        CsvWritertFileOutputDelimited_4 = new com.talend.csv.CSVWriter(bufferWriter_tFileOutputDelimited_4);
                        CsvWritertFileOutputDelimited_4.setSeparator(csvSettings_tFileOutputDelimited_4.getFieldDelim());
                    if(!csvSettings_tFileOutputDelimited_4.isUseCRLFRecordDelimiter() && csvSettings_tFileOutputDelimited_4.getRowDelim()!='\r' && csvSettings_tFileOutputDelimited_4.getRowDelim()!='\n') {
                        CsvWritertFileOutputDelimited_4.setLineEnd(""+csvSettings_tFileOutputDelimited_4.getRowDelim());
                    }



    resourceMap.put("CsvWriter_tFileOutputDelimited_4", CsvWritertFileOutputDelimited_4);
            resourceMap.put("bufferWriter_tFileOutputDelimited_4", bufferWriter_tFileOutputDelimited_4);
            resourceMap.put("outWriter_tFileOutputDelimited_4", outWriter_tFileOutputDelimited_4);
resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);

 



/**
 * [tFileOutputDelimited_4 begin ] stop
 */



	
	/**
	 * [tMap_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_4", false);
		start_Hash.put("tMap_4", System.currentTimeMillis());
		
	
	currentComponent="tMap_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("sp_multi_out" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_4 = new StringBuilder();
            log4jParamters_tMap_4.append("Parameters:");
                    log4jParamters_tMap_4.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_4.append(" | ");
                    log4jParamters_tMap_4.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_4.append(" | ");
                    log4jParamters_tMap_4.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_4.append(" | ");
                    log4jParamters_tMap_4.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + (log4jParamters_tMap_4) );
    		}
    	}
    	
        new BytesLimit65535_tMap_4().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_sp_multi_out_tMap_4 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_4__Struct  {
}
Var__tMap_4__Struct Var__tMap_4 = new Var__tMap_4__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out3_tMap_4 = 0;
				
out3Struct out3_tmp = new out3Struct();
// ###############################

        
        



        









 



/**
 * [tMap_4 begin ] stop
 */



	
	/**
	 * [tJavaFlex_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJavaFlex_2", false);
		start_Hash.put("tJavaFlex_2", System.currentTimeMillis());
		
	
	currentComponent="tJavaFlex_2";

	
		int tos_count_tJavaFlex_2 = 0;
		
    	class BytesLimit65535_tJavaFlex_2{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJavaFlex_2().limitLog4jByte();


int nb_line_inputSP = 0;

java.sql.ResultSet rs_inputSP = (java.sql.ResultSet)globalMap.get("sp_multi_in.out_ref_cursor");

try {

	java.sql.ResultSetMetaData rsmd_inputSP = rs_inputSP.getMetaData();
	int colQtyInRs_inputSP = rsmd_inputSP.getColumnCount();

	routines.system.Dynamic dcg_inputSP = new routines.system.Dynamic();
	dcg_inputSP.setDbmsId("oracle_id");
	List<String> listSchema_inputSP = new java.util.ArrayList<String>();

	int fixedColumnCount_inputSP = 0;

	for (int i = 1; i <= rsmd_inputSP.getColumnCount() - 0; i++) {
		if (!(listSchema_inputSP.contains(rsmd_inputSP.getColumnLabel(i).toUpperCase()))) {
		
			routines.system.DynamicMetadata dcm_inputSP = new routines.system.DynamicMetadata();
			dcm_inputSP.setName(rsmd_inputSP.getColumnLabel(i));
			dcm_inputSP.setDbName(rsmd_inputSP.getColumnName(i));
			dcm_inputSP.setType(routines.system.Dynamic.getTalendTypeFromDBType("oracle_id", rsmd_inputSP.getColumnTypeName(i).toUpperCase(), rsmd_inputSP.getPrecision(i), rsmd_inputSP.getScale(i)));
			dcm_inputSP.setDbType(rsmd_inputSP.getColumnTypeName(i));
			dcm_inputSP.setDbTypeId(rsmd_inputSP.getColumnType(i));
			dcm_inputSP.setFormat("yyyy-MM-dd HH:mm:ss.SSS");
			
			if ("LONG".equals(rsmd_inputSP.getColumnTypeName(i).toUpperCase())) {
			
				String length = MetadataTalendType.getDefaultDBTypes("oracle_id", "LONG", MetadataTalendType.DEFAULT_LENGTH);
				if (length != null && !("".equals(length))) {
					dcm_inputSP.setLength(Integer.parseInt(length));
				} else {
					dcm_inputSP.setLength(rsmd_inputSP.getPrecision(i));
				}
			} else {
				dcm_inputSP.setLength(rsmd_inputSP.getPrecision(i));
			}
			dcm_inputSP.setPrecision(rsmd_inputSP.getScale(i));
			dcm_inputSP.setNullable(rsmd_inputSP.isNullable(i) == 0 ? false : true);
			dcm_inputSP.setKey(false);
			dcm_inputSP.setSourceType(DynamicMetadata.sourceTypes.database);
			dcm_inputSP.setColumnPosition(i);
			dcg_inputSP.metadatas.add(dcm_inputSP);
		}
	}
	
	String tmpContent_inputSP = null;
	int column_index_inputSP = 1;

	while (rs_inputSP.next()) {


 



/**
 * [tJavaFlex_2 begin ] stop
 */
	
	/**
	 * [tJavaFlex_2 main ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	



nb_line_inputSP++;

column_index_inputSP = 1;

if (colQtyInRs_inputSP < column_index_inputSP) {
	sp_multi_out.data_row = null;
} else {
	sp_multi_out.data_row = dcg_inputSP;
	routines.system.DynamicUtils.readColumnsFromDatabase(sp_multi_out.data_row, rs_inputSP, fixedColumnCount_inputSP, false);
}


 


	tos_count_tJavaFlex_2++;

/**
 * [tJavaFlex_2 main ] stop
 */

	
	/**
	 * [tMap_4 main ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

			//sp_multi_out
			//sp_multi_out


			
				if(execStat){
					runStat.updateStatOnConnection("sp_multi_out"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("sp_multi_out - " + (sp_multi_out==null? "": sp_multi_out.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_4 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_4 = false;
		  boolean mainRowRejected_tMap_4 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_4__Struct Var = Var__tMap_4;// ###############################
        // ###############################
        // # Output tables

out3 = null;


// # Output table : 'out3'
count_out3_tMap_4++;

out3_tmp.datarow = "Y".equals((String)globalMap.get("IS_CLNSD")) ? routines.DataCleanser.replaceNewLinesAndReturns(sp_multi_out.data_row) : sp_multi_out.data_row ;
out3_tmp.etl_crtd_by = ((String)globalMap.get("DB_USER"));
out3_tmp.etl_crtd_dt = TalendDate.getCurrentDate();
out3 = out3_tmp;
log.debug("tMap_4 - Outputting the record " + count_out3_tMap_4 + " of the output table 'out3'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_4 = false;










 


	tos_count_tMap_4++;

/**
 * [tMap_4 main ] stop
 */
// Start of branch "out3"
if(out3 != null) { 



	
	/**
	 * [tFileOutputDelimited_4 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	

			//out3
			//out3


			
				if(execStat){
					runStat.updateStatOnConnection("out3"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out3 - " + (out3==null? "": out3.toLogString()));
    			}
    		


                dynamic_column_count_tFileOutputDelimited_4 = 1;
                        if(isFirstCheckDyn_tFileOutputDelimited_4 ){
                            headColutFileOutputDelimited_4 = new String[3-1+out3.datarow.getColumnCount()];
                                    dynamic_column_count_tFileOutputDelimited_4 = out3.datarow.getColumnCount();
                             for(int mi=0;mi<dynamic_column_count_tFileOutputDelimited_4;mi++){
                                headColutFileOutputDelimited_4[0+mi]=out3.datarow.getColumnMetadata(mi).getName();
                             }
                            headColutFileOutputDelimited_4[0+dynamic_column_count_tFileOutputDelimited_4]="etl_crtd_by";
                            headColutFileOutputDelimited_4[1+dynamic_column_count_tFileOutputDelimited_4]="etl_crtd_dt";
                            CsvWritertFileOutputDelimited_4.writeNext(headColutFileOutputDelimited_4);
                            CsvWritertFileOutputDelimited_4.flush();
                        }
                        if(isFirstCheckDyn_tFileOutputDelimited_4){
                            CsvWritertFileOutputDelimited_4.setEscapeChar(csvSettings_tFileOutputDelimited_4.getEscapeChar());
                            CsvWritertFileOutputDelimited_4.setQuoteChar(csvSettings_tFileOutputDelimited_4.getTextEnclosure());
                            CsvWritertFileOutputDelimited_4.setQuoteStatus(com.talend.csv.CSVWriter.QuoteStatus.FORCE);
                            isFirstCheckDyn_tFileOutputDelimited_4 = false;
                        }
                        String[] rowtFileOutputDelimited_4=new String[3+out3.datarow.getColumnCount()-1];
                        dynamic_column_count_tFileOutputDelimited_4 =1;
                                dynamic_column_count_tFileOutputDelimited_4 = out3.datarow.getColumnCount();
                            if (out3.datarow != null) {
                                routines.system.DynamicUtils.writeValuesToStringArrayEnhance(out3.datarow, rowtFileOutputDelimited_4, 0,
                                           null
                                );
                            }
                            rowtFileOutputDelimited_4[0+dynamic_column_count_tFileOutputDelimited_4]=out3.etl_crtd_by == null ? null : out3.etl_crtd_by;
                            rowtFileOutputDelimited_4[1+dynamic_column_count_tFileOutputDelimited_4]=out3.etl_crtd_dt == null ? null : FormatterUtils.format_Date(out3.etl_crtd_dt, "yyyy-MM-dd HH:mm:ss.SSS");
                nb_line_tFileOutputDelimited_4++;
                resourceMap.put("nb_line_tFileOutputDelimited_4", nb_line_tFileOutputDelimited_4);
                                       CsvWritertFileOutputDelimited_4.writeNext(rowtFileOutputDelimited_4);
                            log.debug("tFileOutputDelimited_4 - Writing the record " + nb_line_tFileOutputDelimited_4 + ".");




 


	tos_count_tFileOutputDelimited_4++;

/**
 * [tFileOutputDelimited_4 main ] stop
 */

} // End of branch "out3"







	
	/**
	 * [tJavaFlex_2 end ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	


	}
} finally {

	globalMap.put("CURRENT_RESULTSET_RECORD_COUNT", nb_line_inputSP);

}

 

ok_Hash.put("tJavaFlex_2", true);
end_Hash.put("tJavaFlex_2", System.currentTimeMillis());




/**
 * [tJavaFlex_2 end ] stop
 */

	
	/**
	 * [tMap_4 end ] start
	 */

	

	
	
	currentComponent="tMap_4";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_4 - Written records count in the table 'out3': " + count_out3_tMap_4 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("sp_multi_out"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_4 - "  + ("Done.") );

ok_Hash.put("tMap_4", true);
end_Hash.put("tMap_4", System.currentTimeMillis());




/**
 * [tMap_4 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	



		
			
		
				
						if(CsvWritertFileOutputDelimited_4!=null) {
							CsvWritertFileOutputDelimited_4.flush();
						}
						if(bufferWriter_tFileOutputDelimited_4!=null) {
							bufferWriter_tFileOutputDelimited_4.flush();
						}
						if(outWriter_tFileOutputDelimited_4!=null) {
							outWriter_tFileOutputDelimited_4.flush();
						}
						CsvWritertFileOutputDelimited_4 = null;
					
		    	globalMap.put("tFileOutputDelimited_4_NB_LINE",nb_line_tFileOutputDelimited_4);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_4", true);
	
				log.debug("tFileOutputDelimited_4 - Written records count: " + nb_line_tFileOutputDelimited_4 + " .");
			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out3"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_4 - "  + ("Done.") );

ok_Hash.put("tFileOutputDelimited_4", true);
end_Hash.put("tFileOutputDelimited_4", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk13", 0, "ok");
				}
				tFixedFlowInput_9Process(globalMap);



/**
 * [tFileOutputDelimited_4 end ] stop
 */






						if(execStat){
							runStat.updateStatOnConnection("iterate4", 2, "exec" + NB_ITERATE_tJavaFlex_2);
						}				
					





} // End of branch "sp_multi_in"



	
		} // C_01
	



	
	/**
	 * [tOracleSP_2 end ] start
	 */

	

	
	
	currentComponent="tOracleSP_2";

	


	statement_tOracleSP_2.close();

 

ok_Hash.put("tOracleSP_2", true);
end_Hash.put("tOracleSP_2", System.currentTimeMillis());




/**
 * [tOracleSP_2 end ] stop
 */

	
	/**
	 * [tSplitRow_1 end ] start
	 */

	

	
	
	currentComponent="tSplitRow_1";

	
globalMap.put("tSplitRow_1_NB_LINE", nb_line_tSplitRow_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row17"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tSplitRow_1", true);
end_Hash.put("tSplitRow_1", System.currentTimeMillis());




/**
 * [tSplitRow_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_2 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

globalMap.put("tFlowToIterate_2_NB_LINE",nb_line_tFlowToIterate_2);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("sp_multi_in"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_2 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_2", true);
end_Hash.put("tFlowToIterate_2", System.currentTimeMillis());




/**
 * [tFlowToIterate_2 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleSP_2 finally ] start
	 */

	

	
	
	currentComponent="tOracleSP_2";

	

 



/**
 * [tOracleSP_2 finally ] stop
 */

	
	/**
	 * [tSplitRow_1 finally ] start
	 */

	

	
	
	currentComponent="tSplitRow_1";

	

 



/**
 * [tSplitRow_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_2 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_2";

	

 



/**
 * [tFlowToIterate_2 finally ] stop
 */

	
	/**
	 * [tJavaFlex_2 finally ] start
	 */

	

	
	
	currentComponent="tJavaFlex_2";

	

 



/**
 * [tJavaFlex_2 finally ] stop
 */

	
	/**
	 * [tMap_4 finally ] start
	 */

	

	
	
	currentComponent="tMap_4";

	

 



/**
 * [tMap_4 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_4 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_4";

	


		if(resourceMap.get("finish_tFileOutputDelimited_4") == null){ 
			
				
			
					com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_4 = (com.talend.csv.CSVWriter)resourceMap.get("CsvWriter_tFileOutputDelimited_4");
					
							if(CsvWritertFileOutputDelimited_4!=null) {
								CsvWritertFileOutputDelimited_4.flush();
							}
							java.io.BufferedWriter bufferWriter_tFileOutputDelimited_4 = (java.io.BufferedWriter)resourceMap.get("bufferWriter_tFileOutputDelimited_4");
							if(bufferWriter_tFileOutputDelimited_4!=null) {
								bufferWriter_tFileOutputDelimited_4.flush();
							}
							java.io.OutputStreamWriter outWriter_tFileOutputDelimited_4 = (java.io.OutputStreamWriter)resourceMap.get("outWriter_tFileOutputDelimited_4");
							if(outWriter_tFileOutputDelimited_4!=null) {
								outWriter_tFileOutputDelimited_4.flush();
							}
							CsvWritertFileOutputDelimited_4 = null;
						
			
		}
	

 



/**
 * [tFileOutputDelimited_4 finally ] stop
 */















				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleSP_2_SUBPROCESS_STATE", 1);
	}
	


public static class row16Struct implements routines.system.IPersistableRow<row16Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row16Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row16Struct row16 = new row16Struct();




	
	/**
	 * [tHashOutput_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_3", false);
		start_Hash.put("tHashOutput_3", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row16" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_3 = 0;
		
    	class BytesLimit65535_tHashOutput_3{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_3().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_3=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashOutput_3 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_3.getKeyMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" +pid + "_tHashOutput_3", "tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid + "_tHashOutput_4");
        int nb_line_tHashOutput_3 = 0;
 



/**
 * [tHashOutput_3 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_9", false);
		start_Hash.put("tFixedFlowInput_9", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_9";

	
		int tos_count_tFixedFlowInput_9 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_9{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_9().limitLog4jByte();

	    for (int i_tFixedFlowInput_9 = 0 ; i_tFixedFlowInput_9 < 1 ; i_tFixedFlowInput_9++) {
	                	            	
    	            		row16.object_id = ((String)globalMap.get("sp_multi_in.object_id"));
    	            	        	            	
    	            		row16.object_nm = ((String)globalMap.get("sp_multi_in.object_nm"));
    	            	        	            	
    	            		row16.source_count = ((Integer)globalMap.get("CURRENT_RESULTSET_RECORD_COUNT"));
    	            	        	            	
    	            		row16.target_count = ((Integer)globalMap.get("tFileOutputDelimited_4_NB_LINE"));
    	            	        	            	
    	            		row16.file_name = ((String)globalMap.get("sp_multi_in.object_nm")) + "_" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "." + ((String)globalMap.get("FILE_EXTENSION"));
    	            	        	            	
    	            		row16.cdc_start_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("LAST_RUN_DTTM"))) ? ((Date)globalMap.get("LAST_RUN_DTTM")) : null;
    	            	        	            	
    	            		row16.cdc_end_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("NEXT_RUN_DTTM"))) ? ((Date)globalMap.get("NEXT_RUN_DTTM")) : null;
    	            	
 



/**
 * [tFixedFlowInput_9 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_9 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_9";

	

 


	tos_count_tFixedFlowInput_9++;

/**
 * [tFixedFlowInput_9 main ] stop
 */

	
	/**
	 * [tHashOutput_3 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";

	

			//row16
			//row16


			
				if(execStat){
					runStat.updateStatOnConnection("row16"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row16 - " + (row16==null? "": row16.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_3 == null){
			tHashFile_tHashOutput_3 = mf_tHashOutput_3.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
			mf_tHashOutput_3.getResourceMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_3", tHashFile_tHashOutput_3);
		}
		row22Struct oneRow_tHashOutput_3 = new row22Struct();
			oneRow_tHashOutput_3.object_id = row16.object_id;
			oneRow_tHashOutput_3.object_nm = row16.object_nm;
			oneRow_tHashOutput_3.source_count = row16.source_count;
			oneRow_tHashOutput_3.target_count = row16.target_count;
			oneRow_tHashOutput_3.file_name = row16.file_name;
			oneRow_tHashOutput_3.cdc_start_dttm = row16.cdc_start_dttm;
			oneRow_tHashOutput_3.cdc_end_dttm = row16.cdc_end_dttm;
        tHashFile_tHashOutput_3.put(oneRow_tHashOutput_3);
        nb_line_tHashOutput_3 ++;	
 


	tos_count_tHashOutput_3++;

/**
 * [tHashOutput_3 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_9 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_9";

	

        }
        globalMap.put("tFixedFlowInput_9_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_9", true);
end_Hash.put("tFixedFlowInput_9", System.currentTimeMillis());




/**
 * [tFixedFlowInput_9 end ] stop
 */

	
	/**
	 * [tHashOutput_3 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";

	
globalMap.put("tHashOutput_3_NB_LINE", nb_line_tHashOutput_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row16"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_3", true);
end_Hash.put("tHashOutput_3", System.currentTimeMillis());




/**
 * [tHashOutput_3 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_9 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_9";

	

 



/**
 * [tFixedFlowInput_9 finally ] stop
 */

	
	/**
	 * [tHashOutput_3 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_3";

	

 



/**
 * [tHashOutput_3 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_9_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_16Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_16_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_16 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_16", false);
		start_Hash.put("tWarn_16", System.currentTimeMillis());
		
	
	currentComponent="tWarn_16";

	
		int tos_count_tWarn_16 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_16 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_16{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_16 = new StringBuilder();
            log4jParamters_tWarn_16.append("Parameters:");
                    log4jParamters_tWarn_16.append("MESSAGE" + " = " + "\"210|Multi SP Extraction Failed\"");
                log4jParamters_tWarn_16.append(" | ");
                    log4jParamters_tWarn_16.append("CODE" + " = " + "999");
                log4jParamters_tWarn_16.append(" | ");
                    log4jParamters_tWarn_16.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_16.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_16 - "  + (log4jParamters_tWarn_16) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_16().limitLog4jByte();

 



/**
 * [tWarn_16 begin ] stop
 */
	
	/**
	 * [tWarn_16 main ] start
	 */

	

	
	
	currentComponent="tWarn_16";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_16", "", Thread.currentThread().getId() + "", "ERROR","","210|Multi SP Extraction Failed","", "");
            log.error("tWarn_16 - "  + ("Message: ")  + ("210|Multi SP Extraction Failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_16 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_16", 5, "210|Multi SP Extraction Failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_16_WARN_MESSAGES", "210|Multi SP Extraction Failed"); 
globalMap.put("tWarn_16_WARN_PRIORITY", 5);
globalMap.put("tWarn_16_WARN_CODE", 999);


 


	tos_count_tWarn_16++;

/**
 * [tWarn_16 main ] stop
 */
	
	/**
	 * [tWarn_16 end ] start
	 */

	

	
	
	currentComponent="tWarn_16";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_16 - "  + ("Done.") );

ok_Hash.put("tWarn_16", true);
end_Hash.put("tWarn_16", System.currentTimeMillis());




/**
 * [tWarn_16 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_16 finally ] start
	 */

	

	
	
	currentComponent="tWarn_16";

	

 



/**
 * [tWarn_16 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_16_SUBPROCESS_STATE", 1);
	}
	


public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				
			    public String etl_crtd_by;

				public String getEtl_crtd_by () {
					return this.etl_crtd_by;
				}
				
			    public java.util.Date etl_crtd_dt;

				public java.util.Date getEtl_crtd_dt () {
					return this.etl_crtd_dt;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
					this.etl_crtd_by = readString(dis);
					
					this.etl_crtd_dt = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
					// String
				
						writeString(this.etl_crtd_by,dos);
					
					// java.util.Date
				
						writeDate(this.etl_crtd_dt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
		sb.append(",etl_crtd_by="+etl_crtd_by);
		sb.append(",etl_crtd_dt="+String.valueOf(etl_crtd_dt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_dt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_dt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out1Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row4Struct implements routines.system.IPersistableRow<row4Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tOracleInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row4Struct row4 = new row4Struct();
out1Struct out1 = new out1Struct();





	
	/**
	 * [tFileOutputDelimited_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_1", false);
		start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out1" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimited_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileOutputDelimited_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileOutputDelimited_1 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_1.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_1.append("USESTREAM" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("STREAMNAME" + " = " + "new java.io.FileOutputStream(((String)globalMap.get(\"LOCAL_DIRECTORY\")) + (\"NA\".equals(context.object_position) ? \"/Outbound/\" : \"/\") + ((String)globalMap.get(\"FILE_NAME\")), false)");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("OS_LINE_SEPARATOR_AS_ROW_SEPARATOR" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("CSVROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FIELDSEPARATOR" + " = " + "((String)globalMap.get(\"FIELD_SEPARATOR\"))");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("CSV_OPTION" + " = " + "true");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ESCAPE_CHAR" + " = " + "((String)globalMap.get(\"ESCAPE_CHAR\"))");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("TEXT_ENCLOSURE" + " = " + "((String)globalMap.get(\"TEXT_ENCLOSURE\"))");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                    log4jParamters_tFileOutputDelimited_1.append("ENCODING" + " = " + "(Relational.ISNULL(globalMap.get(\"CHR_ENCODE\")) || \"\".equals((String)globalMap.get(\"CHR_ENCODE\"))) ? \"UTF-8\" : ((String)globalMap.get(\"CHR_ENCODE\"))");
                log4jParamters_tFileOutputDelimited_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + (log4jParamters_tFileOutputDelimited_1) );
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimited_1().limitLog4jByte();

String fileName_tFileOutputDelimited_1 = "";
        int dynamic_column_count_tFileOutputDelimited_1 = 1;
                boolean isFirstCheckDyn_tFileOutputDelimited_1= true;
                String[] headColutFileOutputDelimited_1 = null;
            class CSVBasicSet_tFileOutputDelimited_1{
                private char field_Delim;
                private char row_Delim;
                private char escape;
                private char textEnclosure;
                private boolean useCRLFRecordDelimiter;

                public boolean isUseCRLFRecordDelimiter() {
                    return useCRLFRecordDelimiter;
                }

                public void setFieldSeparator(String fieldSep) throws IllegalArgumentException{
                    char field_Delim_tFileOutputDelimited_1[] = null;

                    //support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'.
                    if (fieldSep.length() > 0 ){
                        field_Delim_tFileOutputDelimited_1 = fieldSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Field Separator must be assigned a char.");
                    }
                    this.field_Delim = field_Delim_tFileOutputDelimited_1[0];
                }

                public char getFieldDelim(){
                    if(this.field_Delim==0){
                        setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
                    }
                    return this.field_Delim;
                }

                public void setRowSeparator(String rowSep){
                    if("\r\n".equals(rowSep)) {
                        useCRLFRecordDelimiter = true;
                        return;
                    }
                    char row_DelimtFileOutputDelimited_1[] = null;

                    //support passing value (property: Row Separator) by 'context.rs' or 'globalMap.get("rs")'.
                    if (rowSep.length() > 0 ){
                        row_DelimtFileOutputDelimited_1 = rowSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Row Separator must be assigned a char.");
                    }
                    this.row_Delim = row_DelimtFileOutputDelimited_1[0];
                }

                public char getRowDelim(){
                    if(this.row_Delim==0){
                        setRowSeparator("\n");
                    }
                    return this.row_Delim;
                }

                public void setEscapeAndTextEnclosure(String strEscape, String strTextEnclosure) throws IllegalArgumentException{
                    if(strEscape.length() <= 0 ){
                        throw new IllegalArgumentException("Escape Char must be assigned a char.");
                    }

                    if ("".equals(strTextEnclosure)) strTextEnclosure = "\0";
                    char textEnclosure_tFileOutputDelimited_1[] = null;

                    if(strTextEnclosure.length() > 0 ){
                        textEnclosure_tFileOutputDelimited_1 = strTextEnclosure.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Text Enclosure must be assigned a char.");
                    }

                    this.textEnclosure = textEnclosure_tFileOutputDelimited_1[0];

                    if(("\\").equals(strEscape)){
                        this.escape = '\\';
                    }else if(strEscape.equals(strTextEnclosure)){
                        this.escape = this.textEnclosure;
                    } else {
                        //the default escape mode is double escape
                        this.escape = this.textEnclosure;
                    }


                }

                public char getEscapeChar(){
                    return (char)this.escape;
                }

                public char getTextEnclosure(){
                    return this.textEnclosure;
                }
            }

            int nb_line_tFileOutputDelimited_1 = 0;
            int splitedFileNo_tFileOutputDelimited_1 =0;
            int currentRow_tFileOutputDelimited_1 = 0;


            CSVBasicSet_tFileOutputDelimited_1 csvSettings_tFileOutputDelimited_1 = new CSVBasicSet_tFileOutputDelimited_1();
            csvSettings_tFileOutputDelimited_1.setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
            csvSettings_tFileOutputDelimited_1.setRowSeparator("\n");
            csvSettings_tFileOutputDelimited_1.setEscapeAndTextEnclosure(((String)globalMap.get("ESCAPE_CHAR")),((String)globalMap.get("TEXT_ENCLOSURE")));
                        java.io.OutputStreamWriter outWriter_tFileOutputDelimited_1 = null;
                        java.io.BufferedWriter bufferWriter_tFileOutputDelimited_1 = null;
                        com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_1 = null;
                        outWriter_tFileOutputDelimited_1 = new java.io.OutputStreamWriter(new java.io.FileOutputStream(((String)globalMap.get("LOCAL_DIRECTORY")) + ("NA".equals(context.object_position) ? "/Outbound/" : "/") + ((String)globalMap.get("FILE_NAME")), false), (Relational.ISNULL(globalMap.get("CHR_ENCODE")) || "".equals((String)globalMap.get("CHR_ENCODE"))) ? "UTF-8" : ((String)globalMap.get("CHR_ENCODE")));
                        bufferWriter_tFileOutputDelimited_1 = new java.io.BufferedWriter(outWriter_tFileOutputDelimited_1);
                        CsvWritertFileOutputDelimited_1 = new com.talend.csv.CSVWriter(bufferWriter_tFileOutputDelimited_1);
                        CsvWritertFileOutputDelimited_1.setSeparator(csvSettings_tFileOutputDelimited_1.getFieldDelim());
                    if(!csvSettings_tFileOutputDelimited_1.isUseCRLFRecordDelimiter() && csvSettings_tFileOutputDelimited_1.getRowDelim()!='\r' && csvSettings_tFileOutputDelimited_1.getRowDelim()!='\n') {
                        CsvWritertFileOutputDelimited_1.setLineEnd(""+csvSettings_tFileOutputDelimited_1.getRowDelim());
                    }



    resourceMap.put("CsvWriter_tFileOutputDelimited_1", CsvWritertFileOutputDelimited_1);
            resourceMap.put("bufferWriter_tFileOutputDelimited_1", bufferWriter_tFileOutputDelimited_1);
            resourceMap.put("outWriter_tFileOutputDelimited_1", outWriter_tFileOutputDelimited_1);
resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

 



/**
 * [tFileOutputDelimited_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_1 = new StringBuilder();
            log4jParamters_tMap_1.append("Parameters:");
                    log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_1.append(" | ");
                    log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
    		}
    	}
    	
        new BytesLimit65535_tMap_1().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row4_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out1_tMap_1 = 0;
				
out1Struct out1_tmp = new out1Struct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tOracleInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleInput_1", false);
		start_Hash.put("tOracleInput_1", System.currentTimeMillis());
		
	
	currentComponent="tOracleInput_1";

	
		int tos_count_tOracleInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tOracleInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tOracleInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tOracleInput_1 = new StringBuilder();
            log4jParamters_tOracleInput_1.append("Parameters:");
                    log4jParamters_tOracleInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("CONNECTION" + " = " + "tOracleConnection_1");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("QUERY" + " = " + "((String)globalMap.get(\"DYNAMIC_QUERY\"))");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("IS_CONVERT_XMLTYPE" + " = " + "false");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("USE_CURSOR" + " = " + "true");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("CURSOR_SIZE" + " = " + "Relational.ISNULL(globalMap.get(\"CURSOR_SIZE\")) ? 10000 : Integer.parseInt(((String)globalMap.get(\"CURSOR_SIZE\")))");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("TRIM_ALL_COLUMN" + " = " + "true");
                log4jParamters_tOracleInput_1.append(" | ");
                    log4jParamters_tOracleInput_1.append("NO_NULL_VALUES" + " = " + "true");
                log4jParamters_tOracleInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tOracleInput_1 - "  + (log4jParamters_tOracleInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tOracleInput_1().limitLog4jByte();
	


	
		    int nb_line_tOracleInput_1 = 0;
		    java.sql.Connection conn_tOracleInput_1 = null;
		        conn_tOracleInput_1 = (java.sql.Connection)globalMap.get("conn_tOracleConnection_1");
				
				if(conn_tOracleInput_1 != null) {
					if(conn_tOracleInput_1.getMetaData() != null) {
						
						log.debug("tOracleInput_1 - Uses an existing connection with username '" + conn_tOracleInput_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tOracleInput_1.getMetaData().getURL() + ".");
						
					}
				}
			
				if(((oracle.jdbc.OracleConnection)conn_tOracleInput_1).getSessionTimeZone() == null){
					java.sql.Statement stmtGetTZ_tOracleInput_1 = conn_tOracleInput_1.createStatement();
					java.sql.ResultSet rsGetTZ_tOracleInput_1 = stmtGetTZ_tOracleInput_1.executeQuery("select sessiontimezone from dual");
					String sessionTimezone_tOracleInput_1 = java.util.TimeZone.getDefault().getID();
					while (rsGetTZ_tOracleInput_1.next()) {
						sessionTimezone_tOracleInput_1 = rsGetTZ_tOracleInput_1.getString(1);
					}
					((oracle.jdbc.OracleConnection)conn_tOracleInput_1).setSessionTimeZone(sessionTimezone_tOracleInput_1);
				}
			
		    
			java.sql.Statement stmt_tOracleInput_1 = conn_tOracleInput_1.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
																					java.sql.ResultSet.CONCUR_READ_ONLY);
			
                stmt_tOracleInput_1.setFetchSize(Relational.ISNULL(globalMap.get("CURSOR_SIZE")) ? 10000 : Integer.parseInt(((String)globalMap.get("CURSOR_SIZE"))));


		    String dbquery_tOracleInput_1 = ((String)globalMap.get("DYNAMIC_QUERY"));
			
                log.debug("tOracleInput_1 - Executing the query: '"+dbquery_tOracleInput_1+"'.");
			

                       globalMap.put("tOracleInput_1_QUERY",dbquery_tOracleInput_1);

		    java.sql.ResultSet rs_tOracleInput_1 = null;
		try{
		    rs_tOracleInput_1 = stmt_tOracleInput_1.executeQuery(dbquery_tOracleInput_1);
		    java.sql.ResultSetMetaData rsmd_tOracleInput_1 = rs_tOracleInput_1.getMetaData();
		    int colQtyInRs_tOracleInput_1 = rsmd_tOracleInput_1.getColumnCount();

		    routines.system.Dynamic dcg_tOracleInput_1 =  new routines.system.Dynamic();
		    dcg_tOracleInput_1.setDbmsId("oracle_id");
		    List<String> listSchema_tOracleInput_1=new java.util.ArrayList<String>();
		    

			int fixedColumnCount_tOracleInput_1 = 0;

            for (int i = 1; i <= rsmd_tOracleInput_1.getColumnCount()-0; i++) {
                if (!(listSchema_tOracleInput_1.contains(rsmd_tOracleInput_1.getColumnLabel(i).toUpperCase()) )) {
                	routines.system.DynamicMetadata dcm_tOracleInput_1=new routines.system.DynamicMetadata();
                	dcm_tOracleInput_1.setName(rsmd_tOracleInput_1.getColumnLabel(i));
                	dcm_tOracleInput_1.setDbName(rsmd_tOracleInput_1.getColumnName(i));
                	dcm_tOracleInput_1.setType(routines.system.Dynamic.getTalendTypeFromDBType("oracle_id", rsmd_tOracleInput_1.getColumnTypeName(i).toUpperCase(), rsmd_tOracleInput_1.getPrecision(i), rsmd_tOracleInput_1.getScale(i)));
                	dcm_tOracleInput_1.setDbType(rsmd_tOracleInput_1.getColumnTypeName(i));
                	dcm_tOracleInput_1.setDbTypeId(rsmd_tOracleInput_1.getColumnType(i));
                	dcm_tOracleInput_1.setFormat("yyyy-MM-dd HH:mm:ss.SSS");
			if("LONG".equals(rsmd_tOracleInput_1.getColumnTypeName(i).toUpperCase())) {
				String length = MetadataTalendType.getDefaultDBTypes("oracle_id", "LONG", MetadataTalendType.DEFAULT_LENGTH);
				if(length!=null && !("".equals(length))) {
					dcm_tOracleInput_1.setLength(Integer.parseInt(length));
				} else {
					dcm_tOracleInput_1.setLength(rsmd_tOracleInput_1.getPrecision(i));
				}
			} else {
				dcm_tOracleInput_1.setLength(rsmd_tOracleInput_1.getPrecision(i));
			}
                	dcm_tOracleInput_1.setPrecision(rsmd_tOracleInput_1.getScale(i));
                	dcm_tOracleInput_1.setNullable(rsmd_tOracleInput_1.isNullable(i) == 0 ? false : true);
                	dcm_tOracleInput_1.setKey(false);
                	dcm_tOracleInput_1.setSourceType(DynamicMetadata.sourceTypes.database);
                	dcm_tOracleInput_1.setColumnPosition(i);
                	dcg_tOracleInput_1.metadatas.add(dcm_tOracleInput_1);
                }
            }
		    String tmpContent_tOracleInput_1 = null;
		    
		    	int column_index_tOracleInput_1 =1;
		    
		    
		    	log.debug("tOracleInput_1 - Retrieving records from the database.");
		    
		    while (rs_tOracleInput_1.next()) {
		        nb_line_tOracleInput_1++;
		        
									column_index_tOracleInput_1 = 1;
								
							
							if(colQtyInRs_tOracleInput_1 < column_index_tOracleInput_1) {
								row4.datarow = null;
							} else {
                                  row4.datarow=dcg_tOracleInput_1;
                                		 routines.system.DynamicUtils.readColumnsFromDatabase(row4.datarow, rs_tOracleInput_1, fixedColumnCount_tOracleInput_1,true);
		                    }
					
						log.debug("tOracleInput_1 - Retrieving the record " + nb_line_tOracleInput_1 + ".");
					




 



/**
 * [tOracleInput_1 begin ] stop
 */
	
	/**
	 * [tOracleInput_1 main ] start
	 */

	

	
	
	currentComponent="tOracleInput_1";

	

 


	tos_count_tOracleInput_1++;

/**
 * [tOracleInput_1 main ] stop
 */

	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

			//row4
			//row4


			
				if(execStat){
					runStat.updateStatOnConnection("row4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row4 - " + (row4==null? "": row4.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

out1 = null;


// # Output table : 'out1'
count_out1_tMap_1++;

out1_tmp.datarow = "Y".equals((String)globalMap.get("IS_CLNSD")) ? routines.DataCleanser.replaceNewLinesAndReturns(row4.datarow) : row4.datarow ;
out1_tmp.etl_crtd_by = ((String)globalMap.get("DB_USER"));
out1_tmp.etl_crtd_dt = TalendDate.getCurrentDate();
out1 = out1_tmp;
log.debug("tMap_1 - Outputting the record " + count_out1_tMap_1 + " of the output table 'out1'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
// Start of branch "out1"
if(out1 != null) { 



	
	/**
	 * [tFileOutputDelimited_1 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	

			//out1
			//out1


			
				if(execStat){
					runStat.updateStatOnConnection("out1"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out1 - " + (out1==null? "": out1.toLogString()));
    			}
    		


                dynamic_column_count_tFileOutputDelimited_1 = 1;
                        if(isFirstCheckDyn_tFileOutputDelimited_1 ){
                            headColutFileOutputDelimited_1 = new String[3-1+out1.datarow.getColumnCount()];
                                    dynamic_column_count_tFileOutputDelimited_1 = out1.datarow.getColumnCount();
                             for(int mi=0;mi<dynamic_column_count_tFileOutputDelimited_1;mi++){
                                headColutFileOutputDelimited_1[0+mi]=out1.datarow.getColumnMetadata(mi).getName();
                             }
                            headColutFileOutputDelimited_1[0+dynamic_column_count_tFileOutputDelimited_1]="etl_crtd_by";
                            headColutFileOutputDelimited_1[1+dynamic_column_count_tFileOutputDelimited_1]="etl_crtd_dt";
                            CsvWritertFileOutputDelimited_1.writeNext(headColutFileOutputDelimited_1);
                            CsvWritertFileOutputDelimited_1.flush();
                        }
                        if(isFirstCheckDyn_tFileOutputDelimited_1){
                            CsvWritertFileOutputDelimited_1.setEscapeChar(csvSettings_tFileOutputDelimited_1.getEscapeChar());
                            CsvWritertFileOutputDelimited_1.setQuoteChar(csvSettings_tFileOutputDelimited_1.getTextEnclosure());
                            CsvWritertFileOutputDelimited_1.setQuoteStatus(com.talend.csv.CSVWriter.QuoteStatus.FORCE);
                            isFirstCheckDyn_tFileOutputDelimited_1 = false;
                        }
                        String[] rowtFileOutputDelimited_1=new String[3+out1.datarow.getColumnCount()-1];
                        dynamic_column_count_tFileOutputDelimited_1 =1;
                                dynamic_column_count_tFileOutputDelimited_1 = out1.datarow.getColumnCount();
                            if (out1.datarow != null) {
                                routines.system.DynamicUtils.writeValuesToStringArrayEnhance(out1.datarow, rowtFileOutputDelimited_1, 0,
                                           null
                                );
                            }
                            rowtFileOutputDelimited_1[0+dynamic_column_count_tFileOutputDelimited_1]=out1.etl_crtd_by == null ? null : out1.etl_crtd_by;
                            rowtFileOutputDelimited_1[1+dynamic_column_count_tFileOutputDelimited_1]=out1.etl_crtd_dt == null ? null : FormatterUtils.format_Date(out1.etl_crtd_dt, "yyyy-MM-dd HH:mm:ss.SSS");
                nb_line_tFileOutputDelimited_1++;
                resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);
                                       CsvWritertFileOutputDelimited_1.writeNext(rowtFileOutputDelimited_1);
                            log.debug("tFileOutputDelimited_1 - Writing the record " + nb_line_tFileOutputDelimited_1 + ".");




 


	tos_count_tFileOutputDelimited_1++;

/**
 * [tFileOutputDelimited_1 main ] stop
 */

} // End of branch "out1"







	
	/**
	 * [tOracleInput_1 end ] start
	 */

	

	
	
	currentComponent="tOracleInput_1";

	

}
}finally{
stmt_tOracleInput_1.close();

}

globalMap.put("tOracleInput_1_NB_LINE",nb_line_tOracleInput_1);
	    		log.debug("tOracleInput_1 - Retrieved records count: "+nb_line_tOracleInput_1 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tOracleInput_1 - "  + ("Done.") );

ok_Hash.put("tOracleInput_1", true);
end_Hash.put("tOracleInput_1", System.currentTimeMillis());




/**
 * [tOracleInput_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'out1': " + count_out1_tMap_1 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row4"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	



		
			
		
				
						if(CsvWritertFileOutputDelimited_1!=null) {
							CsvWritertFileOutputDelimited_1.flush();
						}
						if(bufferWriter_tFileOutputDelimited_1!=null) {
							bufferWriter_tFileOutputDelimited_1.flush();
						}
						if(outWriter_tFileOutputDelimited_1!=null) {
							outWriter_tFileOutputDelimited_1.flush();
						}
						CsvWritertFileOutputDelimited_1 = null;
					
		    	globalMap.put("tFileOutputDelimited_1_NB_LINE",nb_line_tFileOutputDelimited_1);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_1", true);
	
				log.debug("tFileOutputDelimited_1 - Written records count: " + nb_line_tFileOutputDelimited_1 + " .");
			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out1"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_1 - "  + ("Done.") );

ok_Hash.put("tFileOutputDelimited_1", true);
end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk11", 0, "ok");
				}
				tFixedFlowInput_7Process(globalMap);



/**
 * [tFileOutputDelimited_1 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleInput_1 finally ] start
	 */

	

	
	
	currentComponent="tOracleInput_1";

	

 



/**
 * [tOracleInput_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_1 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_1";

	


		if(resourceMap.get("finish_tFileOutputDelimited_1") == null){ 
			
				
			
					com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_1 = (com.talend.csv.CSVWriter)resourceMap.get("CsvWriter_tFileOutputDelimited_1");
					
							if(CsvWritertFileOutputDelimited_1!=null) {
								CsvWritertFileOutputDelimited_1.flush();
							}
							java.io.BufferedWriter bufferWriter_tFileOutputDelimited_1 = (java.io.BufferedWriter)resourceMap.get("bufferWriter_tFileOutputDelimited_1");
							if(bufferWriter_tFileOutputDelimited_1!=null) {
								bufferWriter_tFileOutputDelimited_1.flush();
							}
							java.io.OutputStreamWriter outWriter_tFileOutputDelimited_1 = (java.io.OutputStreamWriter)resourceMap.get("outWriter_tFileOutputDelimited_1");
							if(outWriter_tFileOutputDelimited_1!=null) {
								outWriter_tFileOutputDelimited_1.flush();
							}
							CsvWritertFileOutputDelimited_1 = null;
						
			
		}
	

 



/**
 * [tFileOutputDelimited_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row14Struct implements routines.system.IPersistableRow<row14Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row14Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_7Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_7_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row14Struct row14 = new row14Struct();




	
	/**
	 * [tHashOutput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_1", false);
		start_Hash.put("tHashOutput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row14" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_1 = 0;
		
    	class BytesLimit65535_tHashOutput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_1().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashOutput_1 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_1.getKeyMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" +pid + "_tHashOutput_1", "tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid + "_tHashOutput_4");
        int nb_line_tHashOutput_1 = 0;
 



/**
 * [tHashOutput_1 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_7 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_7", false);
		start_Hash.put("tFixedFlowInput_7", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_7";

	
		int tos_count_tFixedFlowInput_7 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_7{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_7().limitLog4jByte();

	    for (int i_tFixedFlowInput_7 = 0 ; i_tFixedFlowInput_7 < 1 ; i_tFixedFlowInput_7++) {
	                	            	
    	            		row14.object_id = context.object_id;
    	            	        	            	
    	            		row14.object_nm = context.object_nm;
    	            	        	            	
    	            		row14.source_count = ((Integer)globalMap.get("tOracleInput_1_NB_LINE"));
    	            	        	            	
    	            		row14.target_count = ((Integer)globalMap.get("tFileOutputDelimited_1_NB_LINE"));
    	            	        	            	
    	            		row14.file_name = ((String)globalMap.get("FILE_NAME"));
    	            	        	            	
    	            		row14.cdc_start_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("LAST_RUN_DTTM"))) ? ((Date)globalMap.get("LAST_RUN_DTTM")) : null;
    	            	        	            	
    	            		row14.cdc_end_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("NEXT_RUN_DTTM"))) ? ((Date)globalMap.get("NEXT_RUN_DTTM")) : null;
    	            	
 



/**
 * [tFixedFlowInput_7 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_7 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_7";

	

 


	tos_count_tFixedFlowInput_7++;

/**
 * [tFixedFlowInput_7 main ] stop
 */

	
	/**
	 * [tHashOutput_1 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	

			//row14
			//row14


			
				if(execStat){
					runStat.updateStatOnConnection("row14"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row14 - " + (row14==null? "": row14.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_1 == null){
			tHashFile_tHashOutput_1 = mf_tHashOutput_1.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
			mf_tHashOutput_1.getResourceMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_1", tHashFile_tHashOutput_1);
		}
		row22Struct oneRow_tHashOutput_1 = new row22Struct();
			oneRow_tHashOutput_1.object_id = row14.object_id;
			oneRow_tHashOutput_1.object_nm = row14.object_nm;
			oneRow_tHashOutput_1.source_count = row14.source_count;
			oneRow_tHashOutput_1.target_count = row14.target_count;
			oneRow_tHashOutput_1.file_name = row14.file_name;
			oneRow_tHashOutput_1.cdc_start_dttm = row14.cdc_start_dttm;
			oneRow_tHashOutput_1.cdc_end_dttm = row14.cdc_end_dttm;
        tHashFile_tHashOutput_1.put(oneRow_tHashOutput_1);
        nb_line_tHashOutput_1 ++;	
 


	tos_count_tHashOutput_1++;

/**
 * [tHashOutput_1 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_7 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_7";

	

        }
        globalMap.put("tFixedFlowInput_7_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_7", true);
end_Hash.put("tFixedFlowInput_7", System.currentTimeMillis());




/**
 * [tFixedFlowInput_7 end ] stop
 */

	
	/**
	 * [tHashOutput_1 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	
globalMap.put("tHashOutput_1_NB_LINE", nb_line_tHashOutput_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row14"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_1", true);
end_Hash.put("tHashOutput_1", System.currentTimeMillis());




/**
 * [tHashOutput_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_7 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_7";

	

 



/**
 * [tFixedFlowInput_7 finally ] stop
 */

	
	/**
	 * [tHashOutput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_1";

	

 



/**
 * [tHashOutput_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_7_SUBPROCESS_STATE", 1);
	}
	

public void tLibraryLoad_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLibraryLoad_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tLibraryLoad_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLibraryLoad_1", false);
		start_Hash.put("tLibraryLoad_1", System.currentTimeMillis());
		
	
	currentComponent="tLibraryLoad_1";

	
		int tos_count_tLibraryLoad_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLibraryLoad_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tLibraryLoad_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLibraryLoad_1 = new StringBuilder();
            log4jParamters_tLibraryLoad_1.append("Parameters:");
                    log4jParamters_tLibraryLoad_1.append("LIBRARY" + " = " + "\"ojdbc6.jar\"");
                log4jParamters_tLibraryLoad_1.append(" | ");
                    log4jParamters_tLibraryLoad_1.append("HOTLIBS" + " = " + "[]");
                log4jParamters_tLibraryLoad_1.append(" | ");
                    log4jParamters_tLibraryLoad_1.append("IMPORT" + " = " + "//import java.util.List;");
                log4jParamters_tLibraryLoad_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLibraryLoad_1 - "  + (log4jParamters_tLibraryLoad_1) );
    		}
    	}
    	
        new BytesLimit65535_tLibraryLoad_1().limitLog4jByte();



 



/**
 * [tLibraryLoad_1 begin ] stop
 */
	
	/**
	 * [tLibraryLoad_1 main ] start
	 */

	

	
	
	currentComponent="tLibraryLoad_1";

	

 


	tos_count_tLibraryLoad_1++;

/**
 * [tLibraryLoad_1 main ] stop
 */
	
	/**
	 * [tLibraryLoad_1 end ] start
	 */

	

	
	
	currentComponent="tLibraryLoad_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tLibraryLoad_1 - "  + ("Done.") );

ok_Hash.put("tLibraryLoad_1", true);
end_Hash.put("tLibraryLoad_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk17", 0, "ok");
				}
				tJDBCInput_1Process(globalMap);



/**
 * [tLibraryLoad_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLibraryLoad_1 finally ] start
	 */

	

	
	
	currentComponent="tLibraryLoad_1";

	

 



/**
 * [tLibraryLoad_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLibraryLoad_1_SUBPROCESS_STATE", 1);
	}
	


public static class out4Struct implements routines.system.IPersistableRow<out4Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				
			    public String etl_crtd_by;

				public String getEtl_crtd_by () {
					return this.etl_crtd_by;
				}
				
			    public java.util.Date etl_crtd_dt;

				public java.util.Date getEtl_crtd_dt () {
					return this.etl_crtd_dt;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
					this.etl_crtd_by = readString(dis);
					
					this.etl_crtd_dt = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
					// String
				
						writeString(this.etl_crtd_by,dos);
					
					// java.util.Date
				
						writeDate(this.etl_crtd_dt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
		sb.append(",etl_crtd_by="+etl_crtd_by);
		sb.append(",etl_crtd_dt="+String.valueOf(etl_crtd_dt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_dt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_dt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out4Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row27Struct implements routines.system.IPersistableRow<row27Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row27Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tJDBCInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJDBCInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row27Struct row27 = new row27Struct();
out4Struct out4 = new out4Struct();





	
	/**
	 * [tFileOutputDelimited_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_3", false);
		start_Hash.put("tFileOutputDelimited_3", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out4" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimited_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileOutputDelimited_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileOutputDelimited_3 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_3.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_3.append("USESTREAM" + " = " + "true");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("STREAMNAME" + " = " + "new java.io.FileOutputStream(((String)globalMap.get(\"LOCAL_DIRECTORY\")) + (\"NA\".equals(context.object_position) ? \"/Outbound/\" : \"/\") + ((String)globalMap.get(\"FILE_NAME\")), false)");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("OS_LINE_SEPARATOR_AS_ROW_SEPARATOR" + " = " + "true");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("CSVROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("FIELDSEPARATOR" + " = " + "((String)globalMap.get(\"FIELD_SEPARATOR\"))");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("CSV_OPTION" + " = " + "true");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ESCAPE_CHAR" + " = " + "((String)globalMap.get(\"ESCAPE_CHAR\"))");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("TEXT_ENCLOSURE" + " = " + "((String)globalMap.get(\"TEXT_ENCLOSURE\"))");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                    log4jParamters_tFileOutputDelimited_3.append("ENCODING" + " = " + "(Relational.ISNULL(globalMap.get(\"CHR_ENCODE\")) || \"\".equals((String)globalMap.get(\"CHR_ENCODE\"))) ? \"UTF-8\" : ((String)globalMap.get(\"CHR_ENCODE\"))");
                log4jParamters_tFileOutputDelimited_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_3 - "  + (log4jParamters_tFileOutputDelimited_3) );
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimited_3().limitLog4jByte();

String fileName_tFileOutputDelimited_3 = "";
        int dynamic_column_count_tFileOutputDelimited_3 = 1;
                boolean isFirstCheckDyn_tFileOutputDelimited_3= true;
                String[] headColutFileOutputDelimited_3 = null;
            class CSVBasicSet_tFileOutputDelimited_3{
                private char field_Delim;
                private char row_Delim;
                private char escape;
                private char textEnclosure;
                private boolean useCRLFRecordDelimiter;

                public boolean isUseCRLFRecordDelimiter() {
                    return useCRLFRecordDelimiter;
                }

                public void setFieldSeparator(String fieldSep) throws IllegalArgumentException{
                    char field_Delim_tFileOutputDelimited_3[] = null;

                    //support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'.
                    if (fieldSep.length() > 0 ){
                        field_Delim_tFileOutputDelimited_3 = fieldSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Field Separator must be assigned a char.");
                    }
                    this.field_Delim = field_Delim_tFileOutputDelimited_3[0];
                }

                public char getFieldDelim(){
                    if(this.field_Delim==0){
                        setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
                    }
                    return this.field_Delim;
                }

                public void setRowSeparator(String rowSep){
                    if("\r\n".equals(rowSep)) {
                        useCRLFRecordDelimiter = true;
                        return;
                    }
                    char row_DelimtFileOutputDelimited_3[] = null;

                    //support passing value (property: Row Separator) by 'context.rs' or 'globalMap.get("rs")'.
                    if (rowSep.length() > 0 ){
                        row_DelimtFileOutputDelimited_3 = rowSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Row Separator must be assigned a char.");
                    }
                    this.row_Delim = row_DelimtFileOutputDelimited_3[0];
                }

                public char getRowDelim(){
                    if(this.row_Delim==0){
                        setRowSeparator("\n");
                    }
                    return this.row_Delim;
                }

                public void setEscapeAndTextEnclosure(String strEscape, String strTextEnclosure) throws IllegalArgumentException{
                    if(strEscape.length() <= 0 ){
                        throw new IllegalArgumentException("Escape Char must be assigned a char.");
                    }

                    if ("".equals(strTextEnclosure)) strTextEnclosure = "\0";
                    char textEnclosure_tFileOutputDelimited_3[] = null;

                    if(strTextEnclosure.length() > 0 ){
                        textEnclosure_tFileOutputDelimited_3 = strTextEnclosure.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Text Enclosure must be assigned a char.");
                    }

                    this.textEnclosure = textEnclosure_tFileOutputDelimited_3[0];

                    if(("\\").equals(strEscape)){
                        this.escape = '\\';
                    }else if(strEscape.equals(strTextEnclosure)){
                        this.escape = this.textEnclosure;
                    } else {
                        //the default escape mode is double escape
                        this.escape = this.textEnclosure;
                    }


                }

                public char getEscapeChar(){
                    return (char)this.escape;
                }

                public char getTextEnclosure(){
                    return this.textEnclosure;
                }
            }

            int nb_line_tFileOutputDelimited_3 = 0;
            int splitedFileNo_tFileOutputDelimited_3 =0;
            int currentRow_tFileOutputDelimited_3 = 0;


            CSVBasicSet_tFileOutputDelimited_3 csvSettings_tFileOutputDelimited_3 = new CSVBasicSet_tFileOutputDelimited_3();
            csvSettings_tFileOutputDelimited_3.setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
            csvSettings_tFileOutputDelimited_3.setRowSeparator("\n");
            csvSettings_tFileOutputDelimited_3.setEscapeAndTextEnclosure(((String)globalMap.get("ESCAPE_CHAR")),((String)globalMap.get("TEXT_ENCLOSURE")));
                        java.io.OutputStreamWriter outWriter_tFileOutputDelimited_3 = null;
                        java.io.BufferedWriter bufferWriter_tFileOutputDelimited_3 = null;
                        com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_3 = null;
                        outWriter_tFileOutputDelimited_3 = new java.io.OutputStreamWriter(new java.io.FileOutputStream(((String)globalMap.get("LOCAL_DIRECTORY")) + ("NA".equals(context.object_position) ? "/Outbound/" : "/") + ((String)globalMap.get("FILE_NAME")), false), (Relational.ISNULL(globalMap.get("CHR_ENCODE")) || "".equals((String)globalMap.get("CHR_ENCODE"))) ? "UTF-8" : ((String)globalMap.get("CHR_ENCODE")));
                        bufferWriter_tFileOutputDelimited_3 = new java.io.BufferedWriter(outWriter_tFileOutputDelimited_3);
                        CsvWritertFileOutputDelimited_3 = new com.talend.csv.CSVWriter(bufferWriter_tFileOutputDelimited_3);
                        CsvWritertFileOutputDelimited_3.setSeparator(csvSettings_tFileOutputDelimited_3.getFieldDelim());
                    if(!csvSettings_tFileOutputDelimited_3.isUseCRLFRecordDelimiter() && csvSettings_tFileOutputDelimited_3.getRowDelim()!='\r' && csvSettings_tFileOutputDelimited_3.getRowDelim()!='\n') {
                        CsvWritertFileOutputDelimited_3.setLineEnd(""+csvSettings_tFileOutputDelimited_3.getRowDelim());
                    }



    resourceMap.put("CsvWriter_tFileOutputDelimited_3", CsvWritertFileOutputDelimited_3);
            resourceMap.put("bufferWriter_tFileOutputDelimited_3", bufferWriter_tFileOutputDelimited_3);
            resourceMap.put("outWriter_tFileOutputDelimited_3", outWriter_tFileOutputDelimited_3);
resourceMap.put("nb_line_tFileOutputDelimited_3", nb_line_tFileOutputDelimited_3);

 



/**
 * [tFileOutputDelimited_3 begin ] stop
 */



	
	/**
	 * [tMap_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_5", false);
		start_Hash.put("tMap_5", System.currentTimeMillis());
		
	
	currentComponent="tMap_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row27" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_5 = new StringBuilder();
            log4jParamters_tMap_5.append("Parameters:");
                    log4jParamters_tMap_5.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_5.append(" | ");
                    log4jParamters_tMap_5.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_5.append(" | ");
                    log4jParamters_tMap_5.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_5.append(" | ");
                    log4jParamters_tMap_5.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + (log4jParamters_tMap_5) );
    		}
    	}
    	
        new BytesLimit65535_tMap_5().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row27_tMap_5 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_5__Struct  {
}
Var__tMap_5__Struct Var__tMap_5 = new Var__tMap_5__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out4_tMap_5 = 0;
				
out4Struct out4_tmp = new out4Struct();
// ###############################

        
        



        









 



/**
 * [tMap_5 begin ] stop
 */



	
	/**
	 * [tJDBCInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJDBCInput_1", false);
		start_Hash.put("tJDBCInput_1", System.currentTimeMillis());
		
	
	currentComponent="tJDBCInput_1";

	
		int tos_count_tJDBCInput_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tJDBCInput_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tJDBCInput_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tJDBCInput_1 = new StringBuilder();
            log4jParamters_tJDBCInput_1.append("Parameters:");
                    log4jParamters_tJDBCInput_1.append("USE_EXISTING_CONNECTION" + " = " + "false");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("URL" + " = " + "((String)globalMap.get(\"JDBC_URL\"))");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("DRIVER_JAR" + " = " + "[{JAR_NAME="+("ojdbc6.jar")+"}]");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("DRIVER_CLASS" + " = " + "\"oracle.jdbc.driver.OracleDriver\"");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("USER" + " = " + "((String)globalMap.get(\"SOURCE_USERNAME\"))");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(((String)globalMap.get("SOURCE_PASSWORD")))).substring(0, 4) + "...");     
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("TABLE" + " = " + "\"\"");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("QUERY" + " = " + "((String)globalMap.get(\"DYNAMIC_QUERY\"))");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("USE_CURSOR" + " = " + "true");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("CURSOR_SIZE" + " = " + "Relational.ISNULL(globalMap.get(\"CURSOR_SIZE\")) ? 10000 : Integer.parseInt(((String)globalMap.get(\"CURSOR_SIZE\")))");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("TRIM_ALL_COLUMN" + " = " + "true");
                log4jParamters_tJDBCInput_1.append(" | ");
                    log4jParamters_tJDBCInput_1.append("ENABLE_MAPPING" + " = " + "false");
                log4jParamters_tJDBCInput_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tJDBCInput_1 - "  + (log4jParamters_tJDBCInput_1) );
    		}
    	}
    	
        new BytesLimit65535_tJDBCInput_1().limitLog4jByte();
	
    
	
		    int nb_line_tJDBCInput_1 = 0;
		    java.sql.Connection conn_tJDBCInput_1 = null;
					String driverClass_tJDBCInput_1 = "oracle.jdbc.driver.OracleDriver";
					java.lang.Class.forName(driverClass_tJDBCInput_1);
					
			String url_tJDBCInput_1 = ((String)globalMap.get("JDBC_URL"));
					String dbUser_tJDBCInput_1 = ((String)globalMap.get("SOURCE_USERNAME"));

					

					
	final String decryptedPassword_tJDBCInput_1 = ((String)globalMap.get("SOURCE_PASSWORD")); 

					String dbPwd_tJDBCInput_1 = decryptedPassword_tJDBCInput_1;

					
	    		log.debug("tJDBCInput_1 - Driver ClassName: "+driverClass_tJDBCInput_1+".");
			
	    		log.debug("tJDBCInput_1 - Connection attempt to '" + url_tJDBCInput_1 + "' with the username '" + dbUser_tJDBCInput_1 + "'.");
			
			conn_tJDBCInput_1 = java.sql.DriverManager.getConnection(url_tJDBCInput_1, dbUser_tJDBCInput_1, dbPwd_tJDBCInput_1);
			
	    		log.debug("tJDBCInput_1 - Connection to '" + url_tJDBCInput_1 + "' has succeeded.");
			
		    
			java.sql.Statement stmt_tJDBCInput_1 = conn_tJDBCInput_1.createStatement();
              stmt_tJDBCInput_1.setFetchSize(Relational.ISNULL(globalMap.get("CURSOR_SIZE")) ? 10000 : Integer.parseInt(((String)globalMap.get("CURSOR_SIZE"))));

		    String dbquery_tJDBCInput_1 = ((String)globalMap.get("DYNAMIC_QUERY"));
			
                log.debug("tJDBCInput_1 - Executing the query: '"+dbquery_tJDBCInput_1+"'.");
			

                       globalMap.put("tJDBCInput_1_QUERY",dbquery_tJDBCInput_1);

		    java.sql.ResultSet rs_tJDBCInput_1 = null;
		try{
		    rs_tJDBCInput_1 = stmt_tJDBCInput_1.executeQuery(dbquery_tJDBCInput_1);
		    java.sql.ResultSetMetaData rsmd_tJDBCInput_1 = rs_tJDBCInput_1.getMetaData();
		    int colQtyInRs_tJDBCInput_1 = rsmd_tJDBCInput_1.getColumnCount();

		    routines.system.Dynamic dcg_tJDBCInput_1 =  new routines.system.Dynamic();
		    dcg_tJDBCInput_1.setDbmsId("");
		    List<String> listSchema_tJDBCInput_1=new java.util.ArrayList<String>();
		    

			int fixedColumnCount_tJDBCInput_1 = 0;

            for (int i = 1; i <= rsmd_tJDBCInput_1.getColumnCount()-0; i++) {
                if (!(listSchema_tJDBCInput_1.contains(rsmd_tJDBCInput_1.getColumnLabel(i).toUpperCase()) )) {
                	routines.system.DynamicMetadata dcm_tJDBCInput_1=new routines.system.DynamicMetadata();
                	dcm_tJDBCInput_1.setName(rsmd_tJDBCInput_1.getColumnLabel(i));
                	dcm_tJDBCInput_1.setDbName(rsmd_tJDBCInput_1.getColumnName(i));
                	dcm_tJDBCInput_1.setType(routines.system.Dynamic.getTalendTypeFromDBType("", rsmd_tJDBCInput_1.getColumnTypeName(i).toUpperCase(), rsmd_tJDBCInput_1.getPrecision(i), rsmd_tJDBCInput_1.getScale(i)));
                	dcm_tJDBCInput_1.setDbType(rsmd_tJDBCInput_1.getColumnTypeName(i));
                	dcm_tJDBCInput_1.setDbTypeId(rsmd_tJDBCInput_1.getColumnType(i));
                	dcm_tJDBCInput_1.setFormat("yyyy-MM-dd HH:mm:ss.SSS");
			dcm_tJDBCInput_1.setLength(rsmd_tJDBCInput_1.getPrecision(i));
                	dcm_tJDBCInput_1.setPrecision(rsmd_tJDBCInput_1.getScale(i));
                	dcm_tJDBCInput_1.setNullable(rsmd_tJDBCInput_1.isNullable(i) == 0 ? false : true);
                	dcm_tJDBCInput_1.setKey(false);
                	dcm_tJDBCInput_1.setSourceType(DynamicMetadata.sourceTypes.database);
                	dcm_tJDBCInput_1.setColumnPosition(i);
                	dcg_tJDBCInput_1.metadatas.add(dcm_tJDBCInput_1);
                }
            }
		    String tmpContent_tJDBCInput_1 = null;
		    
		    	int column_index_tJDBCInput_1 =1;
		    
		    
		    	log.debug("tJDBCInput_1 - Retrieving records from the database.");
		    
		    while (rs_tJDBCInput_1.next()) {
		        nb_line_tJDBCInput_1++;
		        
									column_index_tJDBCInput_1 = 1;
								
							
							if(colQtyInRs_tJDBCInput_1 < column_index_tJDBCInput_1) {
								row27.datarow = null;
							} else {
                                  row27.datarow=dcg_tJDBCInput_1;
                                		 routines.system.DynamicUtils.readColumnsFromDatabase(row27.datarow, rs_tJDBCInput_1, fixedColumnCount_tJDBCInput_1,true);
		                    }
					
						log.debug("tJDBCInput_1 - Retrieving the record " + nb_line_tJDBCInput_1 + ".");
					



 



/**
 * [tJDBCInput_1 begin ] stop
 */
	
	/**
	 * [tJDBCInput_1 main ] start
	 */

	

	
	
	currentComponent="tJDBCInput_1";

	

 


	tos_count_tJDBCInput_1++;

/**
 * [tJDBCInput_1 main ] stop
 */

	
	/**
	 * [tMap_5 main ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

			//row27
			//row27


			
				if(execStat){
					runStat.updateStatOnConnection("row27"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row27 - " + (row27==null? "": row27.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_5 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_5 = false;
		  boolean mainRowRejected_tMap_5 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_5__Struct Var = Var__tMap_5;// ###############################
        // ###############################
        // # Output tables

out4 = null;


// # Output table : 'out4'
count_out4_tMap_5++;

out4_tmp.datarow = "Y".equals((String)globalMap.get("IS_CLNSD")) ? routines.DataCleanser.replaceNewLinesAndReturns(row27.datarow) : row27.datarow ;
out4_tmp.etl_crtd_by = ((String)globalMap.get("DB_USER"));
out4_tmp.etl_crtd_dt = TalendDate.getCurrentDate();
out4 = out4_tmp;
log.debug("tMap_5 - Outputting the record " + count_out4_tMap_5 + " of the output table 'out4'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_5 = false;










 


	tos_count_tMap_5++;

/**
 * [tMap_5 main ] stop
 */
// Start of branch "out4"
if(out4 != null) { 



	
	/**
	 * [tFileOutputDelimited_3 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_3";

	

			//out4
			//out4


			
				if(execStat){
					runStat.updateStatOnConnection("out4"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out4 - " + (out4==null? "": out4.toLogString()));
    			}
    		


                dynamic_column_count_tFileOutputDelimited_3 = 1;
                        if(isFirstCheckDyn_tFileOutputDelimited_3 ){
                            headColutFileOutputDelimited_3 = new String[3-1+out4.datarow.getColumnCount()];
                                    dynamic_column_count_tFileOutputDelimited_3 = out4.datarow.getColumnCount();
                             for(int mi=0;mi<dynamic_column_count_tFileOutputDelimited_3;mi++){
                                headColutFileOutputDelimited_3[0+mi]=out4.datarow.getColumnMetadata(mi).getName();
                             }
                            headColutFileOutputDelimited_3[0+dynamic_column_count_tFileOutputDelimited_3]="etl_crtd_by";
                            headColutFileOutputDelimited_3[1+dynamic_column_count_tFileOutputDelimited_3]="etl_crtd_dt";
                            CsvWritertFileOutputDelimited_3.writeNext(headColutFileOutputDelimited_3);
                            CsvWritertFileOutputDelimited_3.flush();
                        }
                        if(isFirstCheckDyn_tFileOutputDelimited_3){
                            CsvWritertFileOutputDelimited_3.setEscapeChar(csvSettings_tFileOutputDelimited_3.getEscapeChar());
                            CsvWritertFileOutputDelimited_3.setQuoteChar(csvSettings_tFileOutputDelimited_3.getTextEnclosure());
                            CsvWritertFileOutputDelimited_3.setQuoteStatus(com.talend.csv.CSVWriter.QuoteStatus.FORCE);
                            isFirstCheckDyn_tFileOutputDelimited_3 = false;
                        }
                        String[] rowtFileOutputDelimited_3=new String[3+out4.datarow.getColumnCount()-1];
                        dynamic_column_count_tFileOutputDelimited_3 =1;
                                dynamic_column_count_tFileOutputDelimited_3 = out4.datarow.getColumnCount();
                            if (out4.datarow != null) {
                                routines.system.DynamicUtils.writeValuesToStringArrayEnhance(out4.datarow, rowtFileOutputDelimited_3, 0,
                                           null
                                );
                            }
                            rowtFileOutputDelimited_3[0+dynamic_column_count_tFileOutputDelimited_3]=out4.etl_crtd_by == null ? null : out4.etl_crtd_by;
                            rowtFileOutputDelimited_3[1+dynamic_column_count_tFileOutputDelimited_3]=out4.etl_crtd_dt == null ? null : FormatterUtils.format_Date(out4.etl_crtd_dt, "yyyy-MM-dd HH:mm:ss.SSS");
                nb_line_tFileOutputDelimited_3++;
                resourceMap.put("nb_line_tFileOutputDelimited_3", nb_line_tFileOutputDelimited_3);
                                       CsvWritertFileOutputDelimited_3.writeNext(rowtFileOutputDelimited_3);
                            log.debug("tFileOutputDelimited_3 - Writing the record " + nb_line_tFileOutputDelimited_3 + ".");




 


	tos_count_tFileOutputDelimited_3++;

/**
 * [tFileOutputDelimited_3 main ] stop
 */

} // End of branch "out4"







	
	/**
	 * [tJDBCInput_1 end ] start
	 */

	

	
	
	currentComponent="tJDBCInput_1";

	

	}
}finally{
	if(rs_tJDBCInput_1 !=null){
		rs_tJDBCInput_1.close();
	}
	stmt_tJDBCInput_1.close();

if(conn_tJDBCInput_1 != null && !conn_tJDBCInput_1.isClosed()) {
	
	    		log.debug("tJDBCInput_1 - Closing the connection to the database.");
			
			conn_tJDBCInput_1.close();
			
	    		log.debug("tJDBCInput_1 - Connection to the database closed.");
			
}
}
globalMap.put("tJDBCInput_1_NB_LINE", nb_line_tJDBCInput_1);
	    		log.debug("tJDBCInput_1 - Retrieved records count: "+nb_line_tJDBCInput_1 + " .");
			



 
                if(log.isDebugEnabled())
            log.debug("tJDBCInput_1 - "  + ("Done.") );

ok_Hash.put("tJDBCInput_1", true);
end_Hash.put("tJDBCInput_1", System.currentTimeMillis());




/**
 * [tJDBCInput_1 end ] stop
 */

	
	/**
	 * [tMap_5 end ] start
	 */

	

	
	
	currentComponent="tMap_5";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_5 - Written records count in the table 'out4': " + count_out4_tMap_5 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row27"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_5 - "  + ("Done.") );

ok_Hash.put("tMap_5", true);
end_Hash.put("tMap_5", System.currentTimeMillis());




/**
 * [tMap_5 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_3 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_3";

	



		
			
		
				
						if(CsvWritertFileOutputDelimited_3!=null) {
							CsvWritertFileOutputDelimited_3.flush();
						}
						if(bufferWriter_tFileOutputDelimited_3!=null) {
							bufferWriter_tFileOutputDelimited_3.flush();
						}
						if(outWriter_tFileOutputDelimited_3!=null) {
							outWriter_tFileOutputDelimited_3.flush();
						}
						CsvWritertFileOutputDelimited_3 = null;
					
		    	globalMap.put("tFileOutputDelimited_3_NB_LINE",nb_line_tFileOutputDelimited_3);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_3", true);
	
				log.debug("tFileOutputDelimited_3 - Written records count: " + nb_line_tFileOutputDelimited_3 + " .");
			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out4"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_3 - "  + ("Done.") );

ok_Hash.put("tFileOutputDelimited_3", true);
end_Hash.put("tFileOutputDelimited_3", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk18", 0, "ok");
				}
				tFixedFlowInput_11Process(globalMap);



/**
 * [tFileOutputDelimited_3 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJDBCInput_1 finally ] start
	 */

	

	
	
	currentComponent="tJDBCInput_1";

	

 



/**
 * [tJDBCInput_1 finally ] stop
 */

	
	/**
	 * [tMap_5 finally ] start
	 */

	

	
	
	currentComponent="tMap_5";

	

 



/**
 * [tMap_5 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_3 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_3";

	


		if(resourceMap.get("finish_tFileOutputDelimited_3") == null){ 
			
				
			
					com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_3 = (com.talend.csv.CSVWriter)resourceMap.get("CsvWriter_tFileOutputDelimited_3");
					
							if(CsvWritertFileOutputDelimited_3!=null) {
								CsvWritertFileOutputDelimited_3.flush();
							}
							java.io.BufferedWriter bufferWriter_tFileOutputDelimited_3 = (java.io.BufferedWriter)resourceMap.get("bufferWriter_tFileOutputDelimited_3");
							if(bufferWriter_tFileOutputDelimited_3!=null) {
								bufferWriter_tFileOutputDelimited_3.flush();
							}
							java.io.OutputStreamWriter outWriter_tFileOutputDelimited_3 = (java.io.OutputStreamWriter)resourceMap.get("outWriter_tFileOutputDelimited_3");
							if(outWriter_tFileOutputDelimited_3!=null) {
								outWriter_tFileOutputDelimited_3.flush();
							}
							CsvWritertFileOutputDelimited_3 = null;
						
			
		}
	

 



/**
 * [tFileOutputDelimited_3 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJDBCInput_1_SUBPROCESS_STATE", 1);
	}
	


public static class row28Struct implements routines.system.IPersistableRow<row28Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row28Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_11Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_11_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row28Struct row28 = new row28Struct();




	
	/**
	 * [tHashOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_5", false);
		start_Hash.put("tHashOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row28" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_5 = 0;
		
    	class BytesLimit65535_tHashOutput_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_5().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_5=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashOutput_5 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_5.getKeyMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" +pid + "_tHashOutput_5", "tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid + "_tHashOutput_4");
        int nb_line_tHashOutput_5 = 0;
 



/**
 * [tHashOutput_5 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_11 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_11", false);
		start_Hash.put("tFixedFlowInput_11", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_11";

	
		int tos_count_tFixedFlowInput_11 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_11{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_11().limitLog4jByte();

	    for (int i_tFixedFlowInput_11 = 0 ; i_tFixedFlowInput_11 < 1 ; i_tFixedFlowInput_11++) {
	                	            	
    	            		row28.object_id = context.object_id;
    	            	        	            	
    	            		row28.object_nm = context.object_nm;
    	            	        	            	
    	            		row28.source_count = ((Integer)globalMap.get("tJDBCInput_1_NB_LINE"));
    	            	        	            	
    	            		row28.target_count = ((Integer)globalMap.get("tFileOutputDelimited_3_NB_LINE"));
    	            	        	            	
    	            		row28.file_name = ((String)globalMap.get("FILE_NAME"));
    	            	        	            	
    	            		row28.cdc_start_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("LAST_RUN_DTTM"))) ? ((Date)globalMap.get("LAST_RUN_DTTM")) : null;
    	            	        	            	
    	            		row28.cdc_end_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("NEXT_RUN_DTTM"))) ? ((Date)globalMap.get("NEXT_RUN_DTTM")) : null;
    	            	
 



/**
 * [tFixedFlowInput_11 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_11 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_11";

	

 


	tos_count_tFixedFlowInput_11++;

/**
 * [tFixedFlowInput_11 main ] stop
 */

	
	/**
	 * [tHashOutput_5 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_5";

	

			//row28
			//row28


			
				if(execStat){
					runStat.updateStatOnConnection("row28"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row28 - " + (row28==null? "": row28.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_5 == null){
			tHashFile_tHashOutput_5 = mf_tHashOutput_5.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
			mf_tHashOutput_5.getResourceMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_5", tHashFile_tHashOutput_5);
		}
		row22Struct oneRow_tHashOutput_5 = new row22Struct();
			oneRow_tHashOutput_5.object_id = row28.object_id;
			oneRow_tHashOutput_5.object_nm = row28.object_nm;
			oneRow_tHashOutput_5.source_count = row28.source_count;
			oneRow_tHashOutput_5.target_count = row28.target_count;
			oneRow_tHashOutput_5.file_name = row28.file_name;
			oneRow_tHashOutput_5.cdc_start_dttm = row28.cdc_start_dttm;
			oneRow_tHashOutput_5.cdc_end_dttm = row28.cdc_end_dttm;
        tHashFile_tHashOutput_5.put(oneRow_tHashOutput_5);
        nb_line_tHashOutput_5 ++;	
 


	tos_count_tHashOutput_5++;

/**
 * [tHashOutput_5 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_11 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_11";

	

        }
        globalMap.put("tFixedFlowInput_11_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_11", true);
end_Hash.put("tFixedFlowInput_11", System.currentTimeMillis());




/**
 * [tFixedFlowInput_11 end ] stop
 */

	
	/**
	 * [tHashOutput_5 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_5";

	
globalMap.put("tHashOutput_5_NB_LINE", nb_line_tHashOutput_5);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row28"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_5", true);
end_Hash.put("tHashOutput_5", System.currentTimeMillis());




/**
 * [tHashOutput_5 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_11 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_11";

	

 



/**
 * [tFixedFlowInput_11 finally ] stop
 */

	
	/**
	 * [tHashOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_5";

	

 



/**
 * [tHashOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_11_SUBPROCESS_STATE", 1);
	}
	


public static class out5Struct implements routines.system.IPersistableRow<out5Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				
			    public String etl_crtd_by;

				public String getEtl_crtd_by () {
					return this.etl_crtd_by;
				}
				
			    public java.util.Date etl_crtd_dt;

				public java.util.Date getEtl_crtd_dt () {
					return this.etl_crtd_dt;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
					this.etl_crtd_by = readString(dis);
					
					this.etl_crtd_dt = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
					// String
				
						writeString(this.etl_crtd_by,dos);
					
					// java.util.Date
				
						writeDate(this.etl_crtd_dt,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
		sb.append(",etl_crtd_by="+etl_crtd_by);
		sb.append(",etl_crtd_dt="+String.valueOf(etl_crtd_dt));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(etl_crtd_dt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(etl_crtd_dt);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(out5Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row29Struct implements routines.system.IPersistableRow<row29Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public routines.system.Dynamic datarow;

				public routines.system.Dynamic getDatarow () {
					return this.datarow;
				}
				



    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
						this.datarow = (routines.system.Dynamic) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// Dynamic
				
       			    	dos.writeObject(this.datarow);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("datarow="+String.valueOf(datarow));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(datarow == null){
        					sb.append("<null>");
        				}else{
            				sb.append(datarow);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row29Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tOracleInput_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleInput_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row29Struct row29 = new row29Struct();
out5Struct out5 = new out5Struct();





	
	/**
	 * [tFileOutputDelimited_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileOutputDelimited_5", false);
		start_Hash.put("tFileOutputDelimited_5", System.currentTimeMillis());
		
	
	currentComponent="tFileOutputDelimited_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("out5" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFileOutputDelimited_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tFileOutputDelimited_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFileOutputDelimited_5 = new StringBuilder();
            log4jParamters_tFileOutputDelimited_5.append("Parameters:");
                    log4jParamters_tFileOutputDelimited_5.append("USESTREAM" + " = " + "true");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("STREAMNAME" + " = " + "new java.io.FileOutputStream(((String)globalMap.get(\"LOCAL_DIRECTORY\")) + (\"NA\".equals(context.object_position) ? \"/Outbound/\" : \"/\") + ((String)globalMap.get(\"FILE_NAME\")), false)");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("OS_LINE_SEPARATOR_AS_ROW_SEPARATOR" + " = " + "true");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("CSVROWSEPARATOR" + " = " + "\"\\n\"");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("FIELDSEPARATOR" + " = " + "((String)globalMap.get(\"FIELD_SEPARATOR\"))");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("INCLUDEHEADER" + " = " + "true");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("COMPRESS" + " = " + "false");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("ADVANCED_SEPARATOR" + " = " + "false");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("CSV_OPTION" + " = " + "true");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("ESCAPE_CHAR" + " = " + "((String)globalMap.get(\"ESCAPE_CHAR\"))");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("TEXT_ENCLOSURE" + " = " + "((String)globalMap.get(\"TEXT_ENCLOSURE\"))");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("FLUSHONROW" + " = " + "false");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("ROW_MODE" + " = " + "false");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                    log4jParamters_tFileOutputDelimited_5.append("ENCODING" + " = " + "(Relational.ISNULL(globalMap.get(\"CHR_ENCODE\")) || \"\".equals((String)globalMap.get(\"CHR_ENCODE\"))) ? \"UTF-8\" : ((String)globalMap.get(\"CHR_ENCODE\"))");
                log4jParamters_tFileOutputDelimited_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_5 - "  + (log4jParamters_tFileOutputDelimited_5) );
    		}
    	}
    	
        new BytesLimit65535_tFileOutputDelimited_5().limitLog4jByte();

String fileName_tFileOutputDelimited_5 = "";
        int dynamic_column_count_tFileOutputDelimited_5 = 1;
                boolean isFirstCheckDyn_tFileOutputDelimited_5= true;
                String[] headColutFileOutputDelimited_5 = null;
            class CSVBasicSet_tFileOutputDelimited_5{
                private char field_Delim;
                private char row_Delim;
                private char escape;
                private char textEnclosure;
                private boolean useCRLFRecordDelimiter;

                public boolean isUseCRLFRecordDelimiter() {
                    return useCRLFRecordDelimiter;
                }

                public void setFieldSeparator(String fieldSep) throws IllegalArgumentException{
                    char field_Delim_tFileOutputDelimited_5[] = null;

                    //support passing value (property: Field Separator) by 'context.fs' or 'globalMap.get("fs")'.
                    if (fieldSep.length() > 0 ){
                        field_Delim_tFileOutputDelimited_5 = fieldSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Field Separator must be assigned a char.");
                    }
                    this.field_Delim = field_Delim_tFileOutputDelimited_5[0];
                }

                public char getFieldDelim(){
                    if(this.field_Delim==0){
                        setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
                    }
                    return this.field_Delim;
                }

                public void setRowSeparator(String rowSep){
                    if("\r\n".equals(rowSep)) {
                        useCRLFRecordDelimiter = true;
                        return;
                    }
                    char row_DelimtFileOutputDelimited_5[] = null;

                    //support passing value (property: Row Separator) by 'context.rs' or 'globalMap.get("rs")'.
                    if (rowSep.length() > 0 ){
                        row_DelimtFileOutputDelimited_5 = rowSep.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Row Separator must be assigned a char.");
                    }
                    this.row_Delim = row_DelimtFileOutputDelimited_5[0];
                }

                public char getRowDelim(){
                    if(this.row_Delim==0){
                        setRowSeparator("\n");
                    }
                    return this.row_Delim;
                }

                public void setEscapeAndTextEnclosure(String strEscape, String strTextEnclosure) throws IllegalArgumentException{
                    if(strEscape.length() <= 0 ){
                        throw new IllegalArgumentException("Escape Char must be assigned a char.");
                    }

                    if ("".equals(strTextEnclosure)) strTextEnclosure = "\0";
                    char textEnclosure_tFileOutputDelimited_5[] = null;

                    if(strTextEnclosure.length() > 0 ){
                        textEnclosure_tFileOutputDelimited_5 = strTextEnclosure.toCharArray();
                    }else {
                        throw new IllegalArgumentException("Text Enclosure must be assigned a char.");
                    }

                    this.textEnclosure = textEnclosure_tFileOutputDelimited_5[0];

                    if(("\\").equals(strEscape)){
                        this.escape = '\\';
                    }else if(strEscape.equals(strTextEnclosure)){
                        this.escape = this.textEnclosure;
                    } else {
                        //the default escape mode is double escape
                        this.escape = this.textEnclosure;
                    }


                }

                public char getEscapeChar(){
                    return (char)this.escape;
                }

                public char getTextEnclosure(){
                    return this.textEnclosure;
                }
            }

            int nb_line_tFileOutputDelimited_5 = 0;
            int splitedFileNo_tFileOutputDelimited_5 =0;
            int currentRow_tFileOutputDelimited_5 = 0;


            CSVBasicSet_tFileOutputDelimited_5 csvSettings_tFileOutputDelimited_5 = new CSVBasicSet_tFileOutputDelimited_5();
            csvSettings_tFileOutputDelimited_5.setFieldSeparator(((String)globalMap.get("FIELD_SEPARATOR")));
            csvSettings_tFileOutputDelimited_5.setRowSeparator("\n");
            csvSettings_tFileOutputDelimited_5.setEscapeAndTextEnclosure(((String)globalMap.get("ESCAPE_CHAR")),((String)globalMap.get("TEXT_ENCLOSURE")));
                        java.io.OutputStreamWriter outWriter_tFileOutputDelimited_5 = null;
                        java.io.BufferedWriter bufferWriter_tFileOutputDelimited_5 = null;
                        com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_5 = null;
                        outWriter_tFileOutputDelimited_5 = new java.io.OutputStreamWriter(new java.io.FileOutputStream(((String)globalMap.get("LOCAL_DIRECTORY")) + ("NA".equals(context.object_position) ? "/Outbound/" : "/") + ((String)globalMap.get("FILE_NAME")), false), (Relational.ISNULL(globalMap.get("CHR_ENCODE")) || "".equals((String)globalMap.get("CHR_ENCODE"))) ? "UTF-8" : ((String)globalMap.get("CHR_ENCODE")));
                        bufferWriter_tFileOutputDelimited_5 = new java.io.BufferedWriter(outWriter_tFileOutputDelimited_5);
                        CsvWritertFileOutputDelimited_5 = new com.talend.csv.CSVWriter(bufferWriter_tFileOutputDelimited_5);
                        CsvWritertFileOutputDelimited_5.setSeparator(csvSettings_tFileOutputDelimited_5.getFieldDelim());
                    if(!csvSettings_tFileOutputDelimited_5.isUseCRLFRecordDelimiter() && csvSettings_tFileOutputDelimited_5.getRowDelim()!='\r' && csvSettings_tFileOutputDelimited_5.getRowDelim()!='\n') {
                        CsvWritertFileOutputDelimited_5.setLineEnd(""+csvSettings_tFileOutputDelimited_5.getRowDelim());
                    }



    resourceMap.put("CsvWriter_tFileOutputDelimited_5", CsvWritertFileOutputDelimited_5);
            resourceMap.put("bufferWriter_tFileOutputDelimited_5", bufferWriter_tFileOutputDelimited_5);
            resourceMap.put("outWriter_tFileOutputDelimited_5", outWriter_tFileOutputDelimited_5);
resourceMap.put("nb_line_tFileOutputDelimited_5", nb_line_tFileOutputDelimited_5);

 



/**
 * [tFileOutputDelimited_5 begin ] stop
 */



	
	/**
	 * [tMap_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_6", false);
		start_Hash.put("tMap_6", System.currentTimeMillis());
		
	
	currentComponent="tMap_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row29" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMap_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tMap_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMap_6 = new StringBuilder();
            log4jParamters_tMap_6.append("Parameters:");
                    log4jParamters_tMap_6.append("LINK_STYLE" + " = " + "AUTO");
                log4jParamters_tMap_6.append(" | ");
                    log4jParamters_tMap_6.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                log4jParamters_tMap_6.append(" | ");
                    log4jParamters_tMap_6.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                log4jParamters_tMap_6.append(" | ");
                    log4jParamters_tMap_6.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                log4jParamters_tMap_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + (log4jParamters_tMap_6) );
    		}
    	}
    	
        new BytesLimit65535_tMap_6().limitLog4jByte();




// ###############################
// # Lookup's keys initialization
		int count_row29_tMap_6 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_6__Struct  {
}
Var__tMap_6__Struct Var__tMap_6 = new Var__tMap_6__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_out5_tMap_6 = 0;
				
out5Struct out5_tmp = new out5Struct();
// ###############################

        
        



        









 



/**
 * [tMap_6 begin ] stop
 */



	
	/**
	 * [tOracleInput_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleInput_2", false);
		start_Hash.put("tOracleInput_2", System.currentTimeMillis());
		
	
	currentComponent="tOracleInput_2";

	
		int tos_count_tOracleInput_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tOracleInput_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tOracleInput_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tOracleInput_2 = new StringBuilder();
            log4jParamters_tOracleInput_2.append("Parameters:");
                    log4jParamters_tOracleInput_2.append("USE_EXISTING_CONNECTION" + " = " + "false");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("CONNECTION_TYPE" + " = " + "ORACLE_SERVICE_NAME");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("DB_VERSION" + " = " + "ORACLE_12");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("HOST" + " = " + "((String)globalMap.get(\"SOURCE_HOSTNAME\"))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("PORT" + " = " + "((String)globalMap.get(\"SOURCE_PORT\"))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("DBNAME" + " = " + "((String)globalMap.get(\"SOURCE_DATABASE\"))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("SCHEMA_DB" + " = " + "((String)globalMap.get(\"SOURCE_SCHEMA\"))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("USER" + " = " + "((String)globalMap.get(\"SOURCE_USERNAME\"))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(((String)globalMap.get("SOURCE_PASSWORD")))).substring(0, 4) + "...");     
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("TABLE" + " = " + "\"\"");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("QUERY" + " = " + "((String)globalMap.get(\"DYNAMIC_QUERY\"))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("PROPERTIES" + " = " + "((String)globalMap.get(\"SOURCE_ADDITIONAL_PARAMETERS\"))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("IS_CONVERT_XMLTYPE" + " = " + "false");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("USE_CURSOR" + " = " + "true");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("CURSOR_SIZE" + " = " + "Relational.ISNULL(globalMap.get(\"CURSOR_SIZE\")) ? 10000 : Integer.parseInt(((String)globalMap.get(\"CURSOR_SIZE\")))");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("TRIM_ALL_COLUMN" + " = " + "true");
                log4jParamters_tOracleInput_2.append(" | ");
                    log4jParamters_tOracleInput_2.append("NO_NULL_VALUES" + " = " + "true");
                log4jParamters_tOracleInput_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tOracleInput_2 - "  + (log4jParamters_tOracleInput_2) );
    		}
    	}
    	
        new BytesLimit65535_tOracleInput_2().limitLog4jByte();
	


	
		    int nb_line_tOracleInput_2 = 0;
		    java.sql.Connection conn_tOracleInput_2 = null;
				String driverClass_tOracleInput_2 = "oracle.jdbc.OracleDriver";
				java.lang.Class.forName(driverClass_tOracleInput_2);
				
			String url_tOracleInput_2 = null;
				url_tOracleInput_2 = "jdbc:oracle:thin:@(description=(address=(protocol=tcp)(host=" + ((String)globalMap.get("SOURCE_HOSTNAME")) + ")(port=" + ((String)globalMap.get("SOURCE_PORT")) + "))(connect_data=(service_name=" + ((String)globalMap.get("SOURCE_DATABASE")) + ")))";

				String dbUser_tOracleInput_2 = ((String)globalMap.get("SOURCE_USERNAME"));

				

				
	final String decryptedPassword_tOracleInput_2 = ((String)globalMap.get("SOURCE_PASSWORD")); 

				String dbPwd_tOracleInput_2 = decryptedPassword_tOracleInput_2;

				
	    		log.debug("tOracleInput_2 - Driver ClassName: "+driverClass_tOracleInput_2+".");
			
	    		log.debug("tOracleInput_2 - Connection attempt to '" + url_tOracleInput_2 + "' with the username '" + dbUser_tOracleInput_2 + "'.");
			
					java.util.Properties atnParamsPrope_tOracleInput_2 = new java.util.Properties();
					atnParamsPrope_tOracleInput_2.put("user",dbUser_tOracleInput_2);
					atnParamsPrope_tOracleInput_2.put("password",dbPwd_tOracleInput_2);
                    if(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS")) != null && !"\"\"".equals(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS"))) && !"".equals(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS")))){
                        atnParamsPrope_tOracleInput_2.load(new java.io.ByteArrayInputStream(((String)globalMap.get("SOURCE_ADDITIONAL_PARAMETERS")).replace("&", "\n").getBytes()));
                    }
					conn_tOracleInput_2 = java.sql.DriverManager.getConnection(url_tOracleInput_2, atnParamsPrope_tOracleInput_2);
	    		log.debug("tOracleInput_2 - Connection to '" + url_tOracleInput_2 + "' has succeeded.");
			
				java.sql.Statement stmtGetTZ_tOracleInput_2 = conn_tOracleInput_2.createStatement();
				java.sql.ResultSet rsGetTZ_tOracleInput_2 = stmtGetTZ_tOracleInput_2.executeQuery("select sessiontimezone from dual");
				String sessionTimezone_tOracleInput_2 = java.util.TimeZone.getDefault().getID();
				while (rsGetTZ_tOracleInput_2.next()) {
					sessionTimezone_tOracleInput_2 = rsGetTZ_tOracleInput_2.getString(1);
				}
				((oracle.jdbc.OracleConnection)conn_tOracleInput_2).setSessionTimeZone(sessionTimezone_tOracleInput_2);
		    
			java.sql.Statement stmt_tOracleInput_2 = conn_tOracleInput_2.createStatement(java.sql.ResultSet.TYPE_FORWARD_ONLY,
																					java.sql.ResultSet.CONCUR_READ_ONLY);
			
                stmt_tOracleInput_2.setFetchSize(Relational.ISNULL(globalMap.get("CURSOR_SIZE")) ? 10000 : Integer.parseInt(((String)globalMap.get("CURSOR_SIZE"))));


		    String dbquery_tOracleInput_2 = ((String)globalMap.get("DYNAMIC_QUERY"));
			
                log.debug("tOracleInput_2 - Executing the query: '"+dbquery_tOracleInput_2+"'.");
			

                       globalMap.put("tOracleInput_2_QUERY",dbquery_tOracleInput_2);

		    java.sql.ResultSet rs_tOracleInput_2 = null;
		try{
		    rs_tOracleInput_2 = stmt_tOracleInput_2.executeQuery(dbquery_tOracleInput_2);
		    java.sql.ResultSetMetaData rsmd_tOracleInput_2 = rs_tOracleInput_2.getMetaData();
		    int colQtyInRs_tOracleInput_2 = rsmd_tOracleInput_2.getColumnCount();

		    routines.system.Dynamic dcg_tOracleInput_2 =  new routines.system.Dynamic();
		    dcg_tOracleInput_2.setDbmsId("oracle_id");
		    List<String> listSchema_tOracleInput_2=new java.util.ArrayList<String>();
		    

			int fixedColumnCount_tOracleInput_2 = 0;

            for (int i = 1; i <= rsmd_tOracleInput_2.getColumnCount()-0; i++) {
                if (!(listSchema_tOracleInput_2.contains(rsmd_tOracleInput_2.getColumnLabel(i).toUpperCase()) )) {
                	routines.system.DynamicMetadata dcm_tOracleInput_2=new routines.system.DynamicMetadata();
                	dcm_tOracleInput_2.setName(rsmd_tOracleInput_2.getColumnLabel(i));
                	dcm_tOracleInput_2.setDbName(rsmd_tOracleInput_2.getColumnName(i));
                	dcm_tOracleInput_2.setType(routines.system.Dynamic.getTalendTypeFromDBType("oracle_id", rsmd_tOracleInput_2.getColumnTypeName(i).toUpperCase(), rsmd_tOracleInput_2.getPrecision(i), rsmd_tOracleInput_2.getScale(i)));
                	dcm_tOracleInput_2.setDbType(rsmd_tOracleInput_2.getColumnTypeName(i));
                	dcm_tOracleInput_2.setDbTypeId(rsmd_tOracleInput_2.getColumnType(i));
                	dcm_tOracleInput_2.setFormat("yyyy-MM-dd HH:mm:ss.SSS");
			if("LONG".equals(rsmd_tOracleInput_2.getColumnTypeName(i).toUpperCase())) {
				String length = MetadataTalendType.getDefaultDBTypes("oracle_id", "LONG", MetadataTalendType.DEFAULT_LENGTH);
				if(length!=null && !("".equals(length))) {
					dcm_tOracleInput_2.setLength(Integer.parseInt(length));
				} else {
					dcm_tOracleInput_2.setLength(rsmd_tOracleInput_2.getPrecision(i));
				}
			} else {
				dcm_tOracleInput_2.setLength(rsmd_tOracleInput_2.getPrecision(i));
			}
                	dcm_tOracleInput_2.setPrecision(rsmd_tOracleInput_2.getScale(i));
                	dcm_tOracleInput_2.setNullable(rsmd_tOracleInput_2.isNullable(i) == 0 ? false : true);
                	dcm_tOracleInput_2.setKey(false);
                	dcm_tOracleInput_2.setSourceType(DynamicMetadata.sourceTypes.database);
                	dcm_tOracleInput_2.setColumnPosition(i);
                	dcg_tOracleInput_2.metadatas.add(dcm_tOracleInput_2);
                }
            }
		    String tmpContent_tOracleInput_2 = null;
		    
		    	int column_index_tOracleInput_2 =1;
		    
		    
		    	log.debug("tOracleInput_2 - Retrieving records from the database.");
		    
		    while (rs_tOracleInput_2.next()) {
		        nb_line_tOracleInput_2++;
		        
									column_index_tOracleInput_2 = 1;
								
							
							if(colQtyInRs_tOracleInput_2 < column_index_tOracleInput_2) {
								row29.datarow = null;
							} else {
                                  row29.datarow=dcg_tOracleInput_2;
                                		 routines.system.DynamicUtils.readColumnsFromDatabase(row29.datarow, rs_tOracleInput_2, fixedColumnCount_tOracleInput_2,true);
		                    }
					
						log.debug("tOracleInput_2 - Retrieving the record " + nb_line_tOracleInput_2 + ".");
					




 



/**
 * [tOracleInput_2 begin ] stop
 */
	
	/**
	 * [tOracleInput_2 main ] start
	 */

	

	
	
	currentComponent="tOracleInput_2";

	

 


	tos_count_tOracleInput_2++;

/**
 * [tOracleInput_2 main ] stop
 */

	
	/**
	 * [tMap_6 main ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

			//row29
			//row29


			
				if(execStat){
					runStat.updateStatOnConnection("row29"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row29 - " + (row29==null? "": row29.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_6 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_6 = false;
		  boolean mainRowRejected_tMap_6 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_6__Struct Var = Var__tMap_6;// ###############################
        // ###############################
        // # Output tables

out5 = null;


// # Output table : 'out5'
count_out5_tMap_6++;

out5_tmp.datarow = "Y".equals((String)globalMap.get("IS_CLNSD")) ? routines.DataCleanser.replaceNewLinesAndReturns(row29.datarow) : row29.datarow ;
out5_tmp.etl_crtd_by = ((String)globalMap.get("DB_USER"));
out5_tmp.etl_crtd_dt = TalendDate.getCurrentDate();
out5 = out5_tmp;
log.debug("tMap_6 - Outputting the record " + count_out5_tMap_6 + " of the output table 'out5'.");

// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_6 = false;










 


	tos_count_tMap_6++;

/**
 * [tMap_6 main ] stop
 */
// Start of branch "out5"
if(out5 != null) { 



	
	/**
	 * [tFileOutputDelimited_5 main ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	

			//out5
			//out5


			
				if(execStat){
					runStat.updateStatOnConnection("out5"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("out5 - " + (out5==null? "": out5.toLogString()));
    			}
    		


                dynamic_column_count_tFileOutputDelimited_5 = 1;
                        if(isFirstCheckDyn_tFileOutputDelimited_5 ){
                            headColutFileOutputDelimited_5 = new String[3-1+out5.datarow.getColumnCount()];
                                    dynamic_column_count_tFileOutputDelimited_5 = out5.datarow.getColumnCount();
                             for(int mi=0;mi<dynamic_column_count_tFileOutputDelimited_5;mi++){
                                headColutFileOutputDelimited_5[0+mi]=out5.datarow.getColumnMetadata(mi).getName();
                             }
                            headColutFileOutputDelimited_5[0+dynamic_column_count_tFileOutputDelimited_5]="etl_crtd_by";
                            headColutFileOutputDelimited_5[1+dynamic_column_count_tFileOutputDelimited_5]="etl_crtd_dt";
                            CsvWritertFileOutputDelimited_5.writeNext(headColutFileOutputDelimited_5);
                            CsvWritertFileOutputDelimited_5.flush();
                        }
                        if(isFirstCheckDyn_tFileOutputDelimited_5){
                            CsvWritertFileOutputDelimited_5.setEscapeChar(csvSettings_tFileOutputDelimited_5.getEscapeChar());
                            CsvWritertFileOutputDelimited_5.setQuoteChar(csvSettings_tFileOutputDelimited_5.getTextEnclosure());
                            CsvWritertFileOutputDelimited_5.setQuoteStatus(com.talend.csv.CSVWriter.QuoteStatus.FORCE);
                            isFirstCheckDyn_tFileOutputDelimited_5 = false;
                        }
                        String[] rowtFileOutputDelimited_5=new String[3+out5.datarow.getColumnCount()-1];
                        dynamic_column_count_tFileOutputDelimited_5 =1;
                                dynamic_column_count_tFileOutputDelimited_5 = out5.datarow.getColumnCount();
                            if (out5.datarow != null) {
                                routines.system.DynamicUtils.writeValuesToStringArrayEnhance(out5.datarow, rowtFileOutputDelimited_5, 0,
                                           null
                                );
                            }
                            rowtFileOutputDelimited_5[0+dynamic_column_count_tFileOutputDelimited_5]=out5.etl_crtd_by == null ? null : out5.etl_crtd_by;
                            rowtFileOutputDelimited_5[1+dynamic_column_count_tFileOutputDelimited_5]=out5.etl_crtd_dt == null ? null : FormatterUtils.format_Date(out5.etl_crtd_dt, "yyyy-MM-dd HH:mm:ss.SSS");
                nb_line_tFileOutputDelimited_5++;
                resourceMap.put("nb_line_tFileOutputDelimited_5", nb_line_tFileOutputDelimited_5);
                                       CsvWritertFileOutputDelimited_5.writeNext(rowtFileOutputDelimited_5);
                            log.debug("tFileOutputDelimited_5 - Writing the record " + nb_line_tFileOutputDelimited_5 + ".");




 


	tos_count_tFileOutputDelimited_5++;

/**
 * [tFileOutputDelimited_5 main ] stop
 */

} // End of branch "out5"







	
	/**
	 * [tOracleInput_2 end ] start
	 */

	

	
	
	currentComponent="tOracleInput_2";

	

}
}finally{
stmt_tOracleInput_2.close();

	if(conn_tOracleInput_2 != null && !conn_tOracleInput_2.isClosed()) {
	
	    		log.debug("tOracleInput_2 - Closing the connection to the database.");
			
			conn_tOracleInput_2.close();
			
	    		log.debug("tOracleInput_2 - Connection to the database closed.");
			
	}
	
}

globalMap.put("tOracleInput_2_NB_LINE",nb_line_tOracleInput_2);
	    		log.debug("tOracleInput_2 - Retrieved records count: "+nb_line_tOracleInput_2 + " .");
			
 
                if(log.isDebugEnabled())
            log.debug("tOracleInput_2 - "  + ("Done.") );

ok_Hash.put("tOracleInput_2", true);
end_Hash.put("tOracleInput_2", System.currentTimeMillis());




/**
 * [tOracleInput_2 end ] stop
 */

	
	/**
	 * [tMap_6 end ] start
	 */

	

	
	
	currentComponent="tMap_6";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_6 - Written records count in the table 'out5': " + count_out5_tMap_6 + ".");





			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row29"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_6 - "  + ("Done.") );

ok_Hash.put("tMap_6", true);
end_Hash.put("tMap_6", System.currentTimeMillis());




/**
 * [tMap_6 end ] stop
 */

	
	/**
	 * [tFileOutputDelimited_5 end ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	



		
			
		
				
						if(CsvWritertFileOutputDelimited_5!=null) {
							CsvWritertFileOutputDelimited_5.flush();
						}
						if(bufferWriter_tFileOutputDelimited_5!=null) {
							bufferWriter_tFileOutputDelimited_5.flush();
						}
						if(outWriter_tFileOutputDelimited_5!=null) {
							outWriter_tFileOutputDelimited_5.flush();
						}
						CsvWritertFileOutputDelimited_5 = null;
					
		    	globalMap.put("tFileOutputDelimited_5_NB_LINE",nb_line_tFileOutputDelimited_5);
			
		
		
		resourceMap.put("finish_tFileOutputDelimited_5", true);
	
				log.debug("tFileOutputDelimited_5 - Written records count: " + nb_line_tFileOutputDelimited_5 + " .");
			

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("out5"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFileOutputDelimited_5 - "  + ("Done.") );

ok_Hash.put("tFileOutputDelimited_5", true);
end_Hash.put("tFileOutputDelimited_5", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk20", 0, "ok");
				}
				tFixedFlowInput_12Process(globalMap);



/**
 * [tFileOutputDelimited_5 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleInput_2 finally ] start
	 */

	

	
	
	currentComponent="tOracleInput_2";

	

 



/**
 * [tOracleInput_2 finally ] stop
 */

	
	/**
	 * [tMap_6 finally ] start
	 */

	

	
	
	currentComponent="tMap_6";

	

 



/**
 * [tMap_6 finally ] stop
 */

	
	/**
	 * [tFileOutputDelimited_5 finally ] start
	 */

	

	
	
	currentComponent="tFileOutputDelimited_5";

	


		if(resourceMap.get("finish_tFileOutputDelimited_5") == null){ 
			
				
			
					com.talend.csv.CSVWriter CsvWritertFileOutputDelimited_5 = (com.talend.csv.CSVWriter)resourceMap.get("CsvWriter_tFileOutputDelimited_5");
					
							if(CsvWritertFileOutputDelimited_5!=null) {
								CsvWritertFileOutputDelimited_5.flush();
							}
							java.io.BufferedWriter bufferWriter_tFileOutputDelimited_5 = (java.io.BufferedWriter)resourceMap.get("bufferWriter_tFileOutputDelimited_5");
							if(bufferWriter_tFileOutputDelimited_5!=null) {
								bufferWriter_tFileOutputDelimited_5.flush();
							}
							java.io.OutputStreamWriter outWriter_tFileOutputDelimited_5 = (java.io.OutputStreamWriter)resourceMap.get("outWriter_tFileOutputDelimited_5");
							if(outWriter_tFileOutputDelimited_5!=null) {
								outWriter_tFileOutputDelimited_5.flush();
							}
							CsvWritertFileOutputDelimited_5 = null;
						
			
		}
	

 



/**
 * [tFileOutputDelimited_5 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleInput_2_SUBPROCESS_STATE", 1);
	}
	


public static class row30Struct implements routines.system.IPersistableRow<row30Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row30Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row30Struct row30 = new row30Struct();




	
	/**
	 * [tHashOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_6", false);
		start_Hash.put("tHashOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row30" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_6 = 0;
		
    	class BytesLimit65535_tHashOutput_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_6().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_6=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashOutput_6 = null; 
		//use this map to keep the present key and the previous key of AdvancedMemoryHashFile
		mf_tHashOutput_6.getKeyMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" +pid + "_tHashOutput_6", "tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid + "_tHashOutput_4");
        int nb_line_tHashOutput_6 = 0;
 



/**
 * [tHashOutput_6 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_12", false);
		start_Hash.put("tFixedFlowInput_12", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_12";

	
		int tos_count_tFixedFlowInput_12 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_12{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_12().limitLog4jByte();

	    for (int i_tFixedFlowInput_12 = 0 ; i_tFixedFlowInput_12 < 1 ; i_tFixedFlowInput_12++) {
	                	            	
    	            		row30.object_id = context.object_id;
    	            	        	            	
    	            		row30.object_nm = context.object_nm;
    	            	        	            	
    	            		row30.source_count = ((Integer)globalMap.get("tOracleInput_2_NB_LINE"));
    	            	        	            	
    	            		row30.target_count = ((Integer)globalMap.get("tFileOutputDelimited_5_NB_LINE"));
    	            	        	            	
    	            		row30.file_name = ((String)globalMap.get("FILE_NAME"));
    	            	        	            	
    	            		row30.cdc_start_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("LAST_RUN_DTTM"))) ? ((Date)globalMap.get("LAST_RUN_DTTM")) : null;
    	            	        	            	
    	            		row30.cdc_end_dttm = ("Y".equals((String)globalMap.get("IS_ACTIVE")) && !Relational.ISNULL(globalMap.get("NEXT_RUN_DTTM"))) ? ((Date)globalMap.get("NEXT_RUN_DTTM")) : null;
    	            	
 



/**
 * [tFixedFlowInput_12 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_12 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_12";

	

 


	tos_count_tFixedFlowInput_12++;

/**
 * [tFixedFlowInput_12 main ] stop
 */

	
	/**
	 * [tHashOutput_6 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_6";

	

			//row30
			//row30


			
				if(execStat){
					runStat.updateStatOnConnection("row30"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row30 - " + (row30==null? "": row30.toLogString()));
    			}
    		




		if(tHashFile_tHashOutput_6 == null){
			tHashFile_tHashOutput_6 = mf_tHashOutput_6.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
			mf_tHashOutput_6.getResourceMap().put("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_6", tHashFile_tHashOutput_6);
		}
		row22Struct oneRow_tHashOutput_6 = new row22Struct();
			oneRow_tHashOutput_6.object_id = row30.object_id;
			oneRow_tHashOutput_6.object_nm = row30.object_nm;
			oneRow_tHashOutput_6.source_count = row30.source_count;
			oneRow_tHashOutput_6.target_count = row30.target_count;
			oneRow_tHashOutput_6.file_name = row30.file_name;
			oneRow_tHashOutput_6.cdc_start_dttm = row30.cdc_start_dttm;
			oneRow_tHashOutput_6.cdc_end_dttm = row30.cdc_end_dttm;
        tHashFile_tHashOutput_6.put(oneRow_tHashOutput_6);
        nb_line_tHashOutput_6 ++;	
 


	tos_count_tHashOutput_6++;

/**
 * [tHashOutput_6 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_12 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_12";

	

        }
        globalMap.put("tFixedFlowInput_12_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_12", true);
end_Hash.put("tFixedFlowInput_12", System.currentTimeMillis());




/**
 * [tFixedFlowInput_12 end ] stop
 */

	
	/**
	 * [tHashOutput_6 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_6";

	
globalMap.put("tHashOutput_6_NB_LINE", nb_line_tHashOutput_6);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row30"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_6", true);
end_Hash.put("tHashOutput_6", System.currentTimeMillis());




/**
 * [tHashOutput_6 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_12 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_12";

	

 



/**
 * [tFixedFlowInput_12 finally ] stop
 */

	
	/**
	 * [tHashOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_6";

	

 



/**
 * [tHashOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_12_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_8Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_8_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_8 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_8", false);
		start_Hash.put("tWarn_8", System.currentTimeMillis());
		
	
	currentComponent="tWarn_8";

	
		int tos_count_tWarn_8 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_8{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_8 = new StringBuilder();
            log4jParamters_tWarn_8.append("Parameters:");
                    log4jParamters_tWarn_8.append("MESSAGE" + " = " + "\"207|Setting up dynamic query failed\"");
                log4jParamters_tWarn_8.append(" | ");
                    log4jParamters_tWarn_8.append("CODE" + " = " + "999");
                log4jParamters_tWarn_8.append(" | ");
                    log4jParamters_tWarn_8.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_8.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + (log4jParamters_tWarn_8) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_8().limitLog4jByte();

 



/**
 * [tWarn_8 begin ] stop
 */
	
	/**
	 * [tWarn_8 main ] start
	 */

	

	
	
	currentComponent="tWarn_8";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_8", "", Thread.currentThread().getId() + "", "ERROR","","207|Setting up dynamic query failed","", "");
            log.error("tWarn_8 - "  + ("Message: ")  + ("207|Setting up dynamic query failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_8", 5, "207|Setting up dynamic query failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_8_WARN_MESSAGES", "207|Setting up dynamic query failed"); 
globalMap.put("tWarn_8_WARN_PRIORITY", 5);
globalMap.put("tWarn_8_WARN_CODE", 999);


 


	tos_count_tWarn_8++;

/**
 * [tWarn_8 main ] stop
 */
	
	/**
	 * [tWarn_8 end ] start
	 */

	

	
	
	currentComponent="tWarn_8";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_8 - "  + ("Done.") );

ok_Hash.put("tWarn_8", true);
end_Hash.put("tWarn_8", System.currentTimeMillis());




/**
 * [tWarn_8 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_8 finally ] start
	 */

	

	
	
	currentComponent="tWarn_8";

	

 



/**
 * [tWarn_8 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_8_SUBPROCESS_STATE", 1);
	}
	


public static class row22Struct implements routines.system.IPersistableRow<row22Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row22Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_10Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_10_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row22Struct row22 = new row22Struct();




	
	/**
	 * [tHashOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashOutput_4", false);
		start_Hash.put("tHashOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tHashOutput_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row22" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tHashOutput_4 = 0;
		
    	class BytesLimit65535_tHashOutput_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashOutput_4().limitLog4jByte();



org.talend.designer.components.hashfile.common.MapHashFile mf_tHashOutput_4=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();    
		org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashOutput_4 = null;
		String hashKey_tHashOutput_4 = "tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid + "_tHashOutput_4";
			synchronized(org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.get(hashKey_tHashOutput_4)){
			    if(mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4) == null){
	      		    mf_tHashOutput_4.getResourceMap().put(hashKey_tHashOutput_4, new org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct>(org.talend.designer.components.hashfile.common.MATCHING_MODE.KEEP_ALL));
	      		    tHashFile_tHashOutput_4 = mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4);
			    }else{
			    	tHashFile_tHashOutput_4 = mf_tHashOutput_4.getResourceMap().get(hashKey_tHashOutput_4);
			    }
			}
        int nb_line_tHashOutput_4 = 0;
 



/**
 * [tHashOutput_4 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_10 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_10", false);
		start_Hash.put("tFixedFlowInput_10", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_10";

	
		int tos_count_tFixedFlowInput_10 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_10{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_10().limitLog4jByte();

	    for (int i_tFixedFlowInput_10 = 0 ; i_tFixedFlowInput_10 < 0 ; i_tFixedFlowInput_10++) {
	                	            	
    	            		row22.object_id = null;        	            	
    	            	        	            	
    	            		row22.object_nm = null;        	            	
    	            	        	            	
    	            		row22.source_count = null;        	            	
    	            	        	            	
    	            		row22.target_count = null;        	            	
    	            	        	            	
    	            		row22.file_name = null;        	            	
    	            	        	            	
    	            		row22.cdc_start_dttm = null;        	            	
    	            	        	            	
    	            		row22.cdc_end_dttm = null;        	            	
    	            	
 



/**
 * [tFixedFlowInput_10 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_10 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_10";

	

 


	tos_count_tFixedFlowInput_10++;

/**
 * [tFixedFlowInput_10 main ] stop
 */

	
	/**
	 * [tHashOutput_4 main ] start
	 */

	

	
	
	currentComponent="tHashOutput_4";

	

			//row22
			//row22


			
				if(execStat){
					runStat.updateStatOnConnection("row22"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row22 - " + (row22==null? "": row22.toLogString()));
    			}
    		



    
		row22Struct oneRow_tHashOutput_4 = new row22Struct();
				
					oneRow_tHashOutput_4.object_id = row22.object_id;
					oneRow_tHashOutput_4.object_nm = row22.object_nm;
					oneRow_tHashOutput_4.source_count = row22.source_count;
					oneRow_tHashOutput_4.target_count = row22.target_count;
					oneRow_tHashOutput_4.file_name = row22.file_name;
					oneRow_tHashOutput_4.cdc_start_dttm = row22.cdc_start_dttm;
					oneRow_tHashOutput_4.cdc_end_dttm = row22.cdc_end_dttm;
		
        tHashFile_tHashOutput_4.put(oneRow_tHashOutput_4);
        nb_line_tHashOutput_4 ++;
 


	tos_count_tHashOutput_4++;

/**
 * [tHashOutput_4 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_10 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_10";

	

        }
        globalMap.put("tFixedFlowInput_10_NB_LINE", 0);        

 

ok_Hash.put("tFixedFlowInput_10", true);
end_Hash.put("tFixedFlowInput_10", System.currentTimeMillis());




/**
 * [tFixedFlowInput_10 end ] stop
 */

	
	/**
	 * [tHashOutput_4 end ] start
	 */

	

	
	
	currentComponent="tHashOutput_4";

	
globalMap.put("tHashOutput_4_NB_LINE", nb_line_tHashOutput_4);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row22"+iterateId,2, 0); 
			 	}
			}
		
 

ok_Hash.put("tHashOutput_4", true);
end_Hash.put("tHashOutput_4", System.currentTimeMillis());




/**
 * [tHashOutput_4 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_10 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_10";

	

 



/**
 * [tFixedFlowInput_10 finally ] stop
 */

	
	/**
	 * [tHashOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tHashOutput_4";

	

 



/**
 * [tHashOutput_4 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_10_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_6", false);
		start_Hash.put("tWarn_6", System.currentTimeMillis());
		
	
	currentComponent="tWarn_6";

	
		int tos_count_tWarn_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_6 = new StringBuilder();
            log4jParamters_tWarn_6.append("Parameters:");
                    log4jParamters_tWarn_6.append("MESSAGE" + " = " + "\"205|Insert into ingestion tracking table failed\"");
                log4jParamters_tWarn_6.append(" | ");
                    log4jParamters_tWarn_6.append("CODE" + " = " + "999");
                log4jParamters_tWarn_6.append(" | ");
                    log4jParamters_tWarn_6.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + (log4jParamters_tWarn_6) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_6().limitLog4jByte();

 



/**
 * [tWarn_6 begin ] stop
 */
	
	/**
	 * [tWarn_6 main ] start
	 */

	

	
	
	currentComponent="tWarn_6";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_6", "", Thread.currentThread().getId() + "", "ERROR","","205|Insert into ingestion tracking table failed","", "");
            log.error("tWarn_6 - "  + ("Message: ")  + ("205|Insert into ingestion tracking table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_6", 5, "205|Insert into ingestion tracking table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_6_WARN_MESSAGES", "205|Insert into ingestion tracking table failed"); 
globalMap.put("tWarn_6_WARN_PRIORITY", 5);
globalMap.put("tWarn_6_WARN_CODE", 999);


 


	tos_count_tWarn_6++;

/**
 * [tWarn_6 main ] stop
 */
	
	/**
	 * [tWarn_6 end ] start
	 */

	

	
	
	currentComponent="tWarn_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_6 - "  + ("Done.") );

ok_Hash.put("tWarn_6", true);
end_Hash.put("tWarn_6", System.currentTimeMillis());




/**
 * [tWarn_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_6 finally ] start
	 */

	

	
	
	currentComponent="tWarn_6";

	

 



/**
 * [tWarn_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_6_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tMSSqlRow_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_4", false);
		start_Hash.put("tMSSqlRow_4", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_4";

	
		int tos_count_tMSSqlRow_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_4 = new StringBuilder();
            log4jParamters_tMSSqlRow_4.append("Parameters:");
                    log4jParamters_tMSSqlRow_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("QUERY" + " = " + "\"  UPDATE DBO.T_LOAD_CTL_DTL  SET STATUS = 'I'  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'  WHERE OBJECT_ID = '\" + ((String)globalMap.get(\"OBJECT_ID\")) + \"'  	AND SRC_SYS_ID ='\" + ((String)globalMap.get(\"SRC_SYS_ID\")) + \"'  	AND IS_ACTIVE = 'Y'  	AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"SUB_SYS_ID\")) + \"'  \"");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_4.append(" | ");
                    log4jParamters_tMSSqlRow_4.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_4 - "  + (log4jParamters_tMSSqlRow_4) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_4().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_4 = null;
	String query_tMSSqlRow_4 = "";
	boolean whetherReject_tMSSqlRow_4 = false;
				conn_tMSSqlRow_4 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_4 != null) {
					if(conn_tMSSqlRow_4.getMetaData() != null) {
						
						log.debug("tMSSqlRow_4 - Uses an existing connection with username '" + conn_tMSSqlRow_4.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_4.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_4 = conn_tMSSqlRow_4.createStatement();
	

 



/**
 * [tMSSqlRow_4 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_4 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_4";

	

	    		log.debug("tMSSqlRow_4 - Executing the query: '" + "  UPDATE DBO.T_LOAD_CTL_DTL  SET STATUS = 'I'  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'  WHERE OBJECT_ID = '" + ((String)globalMap.get("OBJECT_ID")) + "'  	AND SRC_SYS_ID ='" + ((String)globalMap.get("SRC_SYS_ID")) + "'  	AND IS_ACTIVE = 'Y'  	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'  " + "'.");
			
query_tMSSqlRow_4 = "\nUPDATE DBO.T_LOAD_CTL_DTL\nSET STATUS = 'I'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE OBJECT_ID = '" + ((String)globalMap.get("OBJECT_ID")) + "'\n	AND SRC_SYS_ID ='" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n	AND IS_ACTIVE = 'Y'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n";
whetherReject_tMSSqlRow_4 = false;
globalMap.put("tMSSqlRow_4_QUERY",query_tMSSqlRow_4);
try {
		stmt_tMSSqlRow_4.execute(query_tMSSqlRow_4);
		
	    		log.debug("tMSSqlRow_4 - Execute the query: '" + "\nUPDATE DBO.T_LOAD_CTL_DTL\nSET STATUS = 'I'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE OBJECT_ID = '" + ((String)globalMap.get("OBJECT_ID")) + "'\n	AND SRC_SYS_ID ='" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n	AND IS_ACTIVE = 'Y'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_4 = true;
		
			throw(e);
			
	}
	

 


	tos_count_tMSSqlRow_4++;

/**
 * [tMSSqlRow_4 main ] stop
 */
	
	/**
	 * [tMSSqlRow_4 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_4";

	

	
	stmt_tMSSqlRow_4.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_4 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_4", true);
end_Hash.put("tMSSqlRow_4", System.currentTimeMillis());




/**
 * [tMSSqlRow_4 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_4 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_4";

	

 



/**
 * [tMSSqlRow_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_4_SUBPROCESS_STATE", 1);
	}
	


public static class row13Struct implements routines.system.IPersistableRow<row13Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row13Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tLogCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row13Struct row13 = new row13Struct();




	
	/**
	 * [tFlowToIterate_1 begin ] start
	 */

				
			int NB_ITERATE_tSetGlobalVar_4 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_1", false);
		start_Hash.put("tFlowToIterate_1", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_1";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row13" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_1 = new StringBuilder();
            log4jParamters_tFlowToIterate_1.append("Parameters:");
                    log4jParamters_tFlowToIterate_1.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + (log4jParamters_tFlowToIterate_1) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_1().limitLog4jByte();

int nb_line_tFlowToIterate_1 = 0;
int counter_tFlowToIterate_1 = 0;

 



/**
 * [tFlowToIterate_1 begin ] stop
 */



	
	/**
	 * [tLogCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogCatcher_1", false);
		start_Hash.put("tLogCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tLogCatcher_1";

	
		int tos_count_tLogCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tLogCatcher_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tLogCatcher_1 = new StringBuilder();
            log4jParamters_tLogCatcher_1.append("Parameters:");
                    log4jParamters_tLogCatcher_1.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TDIE" + " = " + "false");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TWARN" + " = " + "true");
                log4jParamters_tLogCatcher_1.append(" | ");
                    log4jParamters_tLogCatcher_1.append("CATCH_TACTIONFAILURE" + " = " + "false");
                log4jParamters_tLogCatcher_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + (log4jParamters_tLogCatcher_1) );
    		}
    	}
    	
        new BytesLimit65535_tLogCatcher_1().limitLog4jByte();

	for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1.getMessages()) {
		row13.type = lcm.getType();
		row13.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row13.priority = lcm.getPriority();
		row13.message = lcm.getMessage();
		row13.code = lcm.getCode();
		
		row13.moment = java.util.Calendar.getInstance().getTime();
	
    	row13.pid = pid;
		row13.root_pid = rootPid;
		row13.father_pid = fatherPid;
	
    	row13.project = projectName;
    	row13.job = jobName;
    	row13.context = contextStr;
    		
 



/**
 * [tLogCatcher_1 begin ] stop
 */
	
	/**
	 * [tLogCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 


	tos_count_tLogCatcher_1++;

/**
 * [tLogCatcher_1 main ] stop
 */

	
	/**
	 * [tFlowToIterate_1 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

			//row13
			//row13


			
				if(execStat){
					runStat.updateStatOnConnection("row13"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row13 - " + (row13==null? "": row13.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.moment, value=")  + (row13.moment)  + (".") );            
            globalMap.put("row13.moment", row13.moment);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.pid, value=")  + (row13.pid)  + (".") );            
            globalMap.put("row13.pid", row13.pid);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.root_pid, value=")  + (row13.root_pid)  + (".") );            
            globalMap.put("row13.root_pid", row13.root_pid);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.father_pid, value=")  + (row13.father_pid)  + (".") );            
            globalMap.put("row13.father_pid", row13.father_pid);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.project, value=")  + (row13.project)  + (".") );            
            globalMap.put("row13.project", row13.project);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.job, value=")  + (row13.job)  + (".") );            
            globalMap.put("row13.job", row13.job);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.context, value=")  + (row13.context)  + (".") );            
            globalMap.put("row13.context", row13.context);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.priority, value=")  + (row13.priority)  + (".") );            
            globalMap.put("row13.priority", row13.priority);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.type, value=")  + (row13.type)  + (".") );            
            globalMap.put("row13.type", row13.type);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.origin, value=")  + (row13.origin)  + (".") );            
            globalMap.put("row13.origin", row13.origin);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.message, value=")  + (row13.message)  + (".") );            
            globalMap.put("row13.message", row13.message);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_1 - "  + ("Set global var, key=row13.code, value=")  + (row13.code)  + (".") );            
            globalMap.put("row13.code", row13.code);
    	
 
	   nb_line_tFlowToIterate_1++;  
       counter_tFlowToIterate_1++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_1)  + (".") );
       globalMap.put("tFlowToIterate_1_CURRENT_ITERATION", counter_tFlowToIterate_1);
 


	tos_count_tFlowToIterate_1++;

/**
 * [tFlowToIterate_1 main ] stop
 */
	NB_ITERATE_tSetGlobalVar_4++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("If21", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("row12", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("OnSubjobOk19", 3, 0);
					}           			
				
					if(execStat){				
	       				runStat.updateStatOnConnection("If20", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate1", 1, "exec" + NB_ITERATE_tSetGlobalVar_4);
					//Thread.sleep(1000);
				}				
			

	
	/**
	 * [tSetGlobalVar_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tSetGlobalVar_4", false);
		start_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());
		
	
	currentComponent="tSetGlobalVar_4";

	
		int tos_count_tSetGlobalVar_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tSetGlobalVar_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tSetGlobalVar_4 = new StringBuilder();
            log4jParamters_tSetGlobalVar_4.append("Parameters:");
                    log4jParamters_tSetGlobalVar_4.append("VARIABLES" + " = " + "[{VALUE="+("\"F\"")+", KEY="+("\"LOAD_STATUS\"")+"}]");
                log4jParamters_tSetGlobalVar_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + (log4jParamters_tSetGlobalVar_4) );
    		}
    	}
    	
        new BytesLimit65535_tSetGlobalVar_4().limitLog4jByte();

 



/**
 * [tSetGlobalVar_4 begin ] stop
 */
	
	/**
	 * [tSetGlobalVar_4 main ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

globalMap.put("LOAD_STATUS", "F");

 


	tos_count_tSetGlobalVar_4++;

/**
 * [tSetGlobalVar_4 main ] stop
 */
	
	/**
	 * [tSetGlobalVar_4 end ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tSetGlobalVar_4 - "  + ("Done.") );

ok_Hash.put("tSetGlobalVar_4", true);
end_Hash.put("tSetGlobalVar_4", System.currentTimeMillis());

   			if (!Relational.ISNULL(globalMap.get("RUN_ID"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If21", 0, "true");
					}
				
    			tFixedFlowInput_6Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If21", 0, "false");
					}   	 
   				}



/**
 * [tSetGlobalVar_4 end ] stop
 */
						if(execStat){
							runStat.updateStatOnConnection("iterate1", 2, "exec" + NB_ITERATE_tSetGlobalVar_4);
						}				
					







	
	/**
	 * [tLogCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	
	}
 
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Done.") );

ok_Hash.put("tLogCatcher_1", true);
end_Hash.put("tLogCatcher_1", System.currentTimeMillis());




/**
 * [tLogCatcher_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_1 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

globalMap.put("tFlowToIterate_1_NB_LINE",nb_line_tFlowToIterate_1);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row13"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_1 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_1", true);
end_Hash.put("tFlowToIterate_1", System.currentTimeMillis());




/**
 * [tFlowToIterate_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLogCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_1 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_1";

	

 



/**
 * [tFlowToIterate_1 finally ] stop
 */

	
	/**
	 * [tSetGlobalVar_4 finally ] start
	 */

	

	
	
	currentComponent="tSetGlobalVar_4";

	

 



/**
 * [tSetGlobalVar_4 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class row12Struct implements routines.system.IPersistableRow<row12Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String stg_id;

				public String getStg_id () {
					return this.stg_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public String batch_id;

				public String getBatch_id () {
					return this.batch_id;
				}
				
			    public String Jb_instnce_id;

				public String getJb_instnce_id () {
					return this.Jb_instnce_id;
				}
				
			    public String err_msg;

				public String getErr_msg () {
					return this.err_msg;
				}
				
			    public String info_dtl;

				public String getInfo_dtl () {
					return this.info_dtl;
				}
				
			    public java.util.Date run_dttm;

				public java.util.Date getRun_dttm () {
					return this.run_dttm;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.stg_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
					this.batch_id = readString(dis);
					
					this.Jb_instnce_id = readString(dis);
					
					this.err_msg = readString(dis);
					
					this.info_dtl = readString(dis);
					
					this.run_dttm = readDate(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_by = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.updt_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.stg_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// String
				
						writeString(this.batch_id,dos);
					
					// String
				
						writeString(this.Jb_instnce_id,dos);
					
					// String
				
						writeString(this.err_msg,dos);
					
					// String
				
						writeString(this.info_dtl,dos);
					
					// java.util.Date
				
						writeDate(this.run_dttm,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("stg_id="+stg_id);
		sb.append(",run_id="+run_id);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",batch_id="+batch_id);
		sb.append(",Jb_instnce_id="+Jb_instnce_id);
		sb.append(",err_msg="+err_msg);
		sb.append(",info_dtl="+info_dtl);
		sb.append(",run_dttm="+String.valueOf(run_dttm));
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_by="+updt_by);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(stg_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stg_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(batch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(batch_id);
            			}
            		
        			sb.append("|");
        		
        				if(Jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(err_msg == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_msg);
            			}
            		
        			sb.append("|");
        		
        				if(info_dtl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(info_dtl);
            			}
            		
        			sb.append("|");
        		
        				if(run_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row12Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row12Struct row12 = new row12Struct();




	
	/**
	 * [tMSSqlOutput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_6", false);
		start_Hash.put("tMSSqlOutput_6", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_6";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row12" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_6{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_6 = new StringBuilder();
            log4jParamters_tMSSqlOutput_6.append("Parameters:");
                    log4jParamters_tMSSqlOutput_6.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("TABLE" + " = " + "\"t_error_log_dtl\"");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                    log4jParamters_tMSSqlOutput_6.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + (log4jParamters_tMSSqlOutput_6) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_6().limitLog4jByte();



int nb_line_tMSSqlOutput_6 = 0;
int nb_line_update_tMSSqlOutput_6 = 0;
int nb_line_inserted_tMSSqlOutput_6 = 0;
int nb_line_deleted_tMSSqlOutput_6 = 0;
int nb_line_rejected_tMSSqlOutput_6 = 0;

int deletedCount_tMSSqlOutput_6=0;
int updatedCount_tMSSqlOutput_6=0;
int insertedCount_tMSSqlOutput_6=0;
int rejectedCount_tMSSqlOutput_6=0;
String dbschema_tMSSqlOutput_6 = null;
String tableName_tMSSqlOutput_6 = null;
boolean whetherReject_tMSSqlOutput_6 = false;

java.util.Calendar calendar_tMSSqlOutput_6 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_6 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_6 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_6 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_6;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_6 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_6 = null;
String dbUser_tMSSqlOutput_6 = null;
	dbschema_tMSSqlOutput_6 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_6 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_6.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_6.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_6.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_6 == null || dbschema_tMSSqlOutput_6.trim().length() == 0) {
    tableName_tMSSqlOutput_6 = "t_error_log_dtl";
} else {
    tableName_tMSSqlOutput_6 = dbschema_tMSSqlOutput_6 + "].[" + "t_error_log_dtl";
}
	int count_tMSSqlOutput_6=0;

        String insert_tMSSqlOutput_6 = "INSERT INTO [" + tableName_tMSSqlOutput_6 + "] ([stg_id],[run_id],[src_sys_id],[sub_sys_id],[object_id],[object_nm],[batch_id],[Jb_instnce_id],[err_msg],[info_dtl],[run_dttm],[crtd_by],[updt_by],[crtd_dttm],[updt_dttm]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_6 = conn_tMSSqlOutput_6.prepareStatement(insert_tMSSqlOutput_6);

 	boolean isShareIdentity_tMSSqlOutput_6 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_6 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_6", false);
		start_Hash.put("tFixedFlowInput_6", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_6";

	
		int tos_count_tFixedFlowInput_6 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_6{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_6().limitLog4jByte();

	    for (int i_tFixedFlowInput_6 = 0 ; i_tFixedFlowInput_6 < 1 ; i_tFixedFlowInput_6++) {
	                	            	
    	            		row12.stg_id = Relational.ISNULL(globalMap.get("STG_ID")) ? "1" : ((String)globalMap.get("STG_ID"));
    	            	        	            	
    	            		row12.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row12.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row12.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row12.object_id = ((String)globalMap.get("OBJECT_ID"));
    	            	        	            	
    	            		row12.object_nm = ((String)globalMap.get("OBJECT_NM"));
    	            	        	            	
    	            		row12.batch_id = ((String)globalMap.get("BATCH_ID"));
    	            	        	            	
    	            		row12.Jb_instnce_id = null;        	            	
    	            	        	            	
    	            		row12.err_msg = ((String)globalMap.get("row13.message"));
    	            	        	            	
    	            		row12.info_dtl = ((String)globalMap.get("INFO_DTL"));
    	            	        	            	
    	            		row12.run_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row12.crtd_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row12.updt_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row12.crtd_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row12.updt_dttm = TalendDate.getCurrentDate();
    	            	
 



/**
 * [tFixedFlowInput_6 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_6 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_6";

	

 


	tos_count_tFixedFlowInput_6++;

/**
 * [tFixedFlowInput_6 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_6 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_6";

	

			//row12
			//row12


			
				if(execStat){
					runStat.updateStatOnConnection("row12"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row12 - " + (row12==null? "": row12.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_6 = false;
                    if(row12.stg_id == null) {
pstmt_tMSSqlOutput_6.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(1, row12.stg_id);
}

                    if(row12.run_id == null) {
pstmt_tMSSqlOutput_6.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(2, row12.run_id);
}

                    if(row12.src_sys_id == null) {
pstmt_tMSSqlOutput_6.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(3, row12.src_sys_id);
}

                    if(row12.sub_sys_id == null) {
pstmt_tMSSqlOutput_6.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(4, row12.sub_sys_id);
}

                    if(row12.object_id == null) {
pstmt_tMSSqlOutput_6.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(5, row12.object_id);
}

                    if(row12.object_nm == null) {
pstmt_tMSSqlOutput_6.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(6, row12.object_nm);
}

                    if(row12.batch_id == null) {
pstmt_tMSSqlOutput_6.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(7, row12.batch_id);
}

                    if(row12.Jb_instnce_id == null) {
pstmt_tMSSqlOutput_6.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(8, row12.Jb_instnce_id);
}

                    if(row12.err_msg == null) {
pstmt_tMSSqlOutput_6.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(9, row12.err_msg);
}

                    if(row12.info_dtl == null) {
pstmt_tMSSqlOutput_6.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(10, row12.info_dtl);
}

                    if(row12.run_dttm != null) {
pstmt_tMSSqlOutput_6.setTimestamp(11, new java.sql.Timestamp(row12.run_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_6.setNull(11, java.sql.Types.DATE);
}

                    if(row12.crtd_by == null) {
pstmt_tMSSqlOutput_6.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(12, row12.crtd_by);
}

                    if(row12.updt_by == null) {
pstmt_tMSSqlOutput_6.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_6.setString(13, row12.updt_by);
}

                    if(row12.crtd_dttm != null) {
pstmt_tMSSqlOutput_6.setTimestamp(14, new java.sql.Timestamp(row12.crtd_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_6.setNull(14, java.sql.Types.DATE);
}

                    if(row12.updt_dttm != null) {
pstmt_tMSSqlOutput_6.setTimestamp(15, new java.sql.Timestamp(row12.updt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_6.setNull(15, java.sql.Types.DATE);
}


            try {
                nb_line_tMSSqlOutput_6++;
                insertedCount_tMSSqlOutput_6 = insertedCount_tMSSqlOutput_6 + pstmt_tMSSqlOutput_6.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_6)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_6 = true;
                    throw(e);
            }
            if(!whetherReject_tMSSqlOutput_6) {
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_6{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_6) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_6: pstmt_tMSSqlOutput_6.executeBatch()) {
							if(countEach_tMSSqlOutput_6 == -2 || countEach_tMSSqlOutput_6 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_6;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_6) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_6: pstmt_tMSSqlOutput_6.executeBatch()) {
							if(countEach_tMSSqlOutput_6 == -2 || countEach_tMSSqlOutput_6 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_6;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_6++;

/**
 * [tMSSqlOutput_6 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_6 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_6";

	

        }
        globalMap.put("tFixedFlowInput_6_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_6", true);
end_Hash.put("tFixedFlowInput_6", System.currentTimeMillis());




/**
 * [tFixedFlowInput_6 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_6 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_6";

	



        if(pstmt_tMSSqlOutput_6 != null) {
			
				pstmt_tMSSqlOutput_6.close();
			
        }


	nb_line_deleted_tMSSqlOutput_6=nb_line_deleted_tMSSqlOutput_6+ deletedCount_tMSSqlOutput_6;
	nb_line_update_tMSSqlOutput_6=nb_line_update_tMSSqlOutput_6 + updatedCount_tMSSqlOutput_6;
	nb_line_inserted_tMSSqlOutput_6=nb_line_inserted_tMSSqlOutput_6 + insertedCount_tMSSqlOutput_6;
	nb_line_rejected_tMSSqlOutput_6=nb_line_rejected_tMSSqlOutput_6 + rejectedCount_tMSSqlOutput_6;
	
        globalMap.put("tMSSqlOutput_6_NB_LINE",nb_line_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_6);
        globalMap.put("tMSSqlOutput_6_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_6);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_6)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row12"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_6 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_6", true);
end_Hash.put("tMSSqlOutput_6", System.currentTimeMillis());

   			if ((("SP_SINGLE".equals((String)globalMap.get("OBJECT_TYPE")) || "SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE"))) && (Numeric.sequence("SEQ_SP_TYPE_ERROR", 1, 1) == 1))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If20", 0, "true");
					}
				
    			tOracleRow_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If20", 0, "false");
					}   	 
   				}



/**
 * [tMSSqlOutput_6 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk19", 0, "ok");
								} 
							
							tDie_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_6 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_6";

	

 



/**
 * [tFixedFlowInput_6 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_6 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_6";

	



	

 



/**
 * [tMSSqlOutput_6 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_6_SUBPROCESS_STATE", 1);
	}
	

public void tOracleRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tOracleRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleRow_1", false);
		start_Hash.put("tOracleRow_1", System.currentTimeMillis());
		
	
	currentComponent="tOracleRow_1";

	
		int tos_count_tOracleRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tOracleRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tOracleRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tOracleRow_1 = new StringBuilder();
            log4jParamters_tOracleRow_1.append("Parameters:");
                    log4jParamters_tOracleRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tOracleRow_1.append(" | ");
                    log4jParamters_tOracleRow_1.append("CONNECTION" + " = " + "tOracleConnection_1");
                log4jParamters_tOracleRow_1.append(" | ");
                    log4jParamters_tOracleRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tOracleRow_1.append(" | ");
                    log4jParamters_tOracleRow_1.append("QUERY" + " = " + "\"  MERGE  INTO EIM_ADMIN.RUN_CTL_LAST_RUN_DTM_DL A  USING (SELECT TABLE_NAME, OLD_LAST_UPD, RANK () OVER(PARTITION BY TABLE_NAME ORDER BY START_DTM DESC) AS RNK  	   FROM EIM_ADMIN.STG_DL_EXTRACT_LOG  	   WHERE TABLE_NAME LIKE '%\" + ((String)globalMap.get(\"OBJECT_NM\")) + \"'  			AND START_DTM > TO_TIMESTAMP('\" + ((String)globalMap.get(\"JOB_STARTTIME_STRING\")) + \"', 'YYYYMMDDHH24MISSFF3')) B  ON (A.TABLE_NAME = B.TABLE_NAME AND B.RNK = 1)  WHEN MATCHED THEN UPDATE  	SET A.LAST_RUN_DTM = B.OLD_LAST_UPD  \"");
                log4jParamters_tOracleRow_1.append(" | ");
                    log4jParamters_tOracleRow_1.append("USE_NB_LINE" + " = " + "NONE");
                log4jParamters_tOracleRow_1.append(" | ");
                    log4jParamters_tOracleRow_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tOracleRow_1.append(" | ");
                    log4jParamters_tOracleRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tOracleRow_1.append(" | ");
                    log4jParamters_tOracleRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tOracleRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tOracleRow_1 - "  + (log4jParamters_tOracleRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tOracleRow_1().limitLog4jByte();

	java.sql.Connection conn_tOracleRow_1 = null;
	String query_tOracleRow_1 = "";
	boolean whetherReject_tOracleRow_1 = false;
				conn_tOracleRow_1 = (java.sql.Connection)globalMap.get("conn_tOracleConnection_1");
			
				if(conn_tOracleRow_1 != null) {
					if(conn_tOracleRow_1.getMetaData() != null) {
						
						log.debug("tOracleRow_1 - Uses an existing connection with username '" + conn_tOracleRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tOracleRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tOracleRow_1 = conn_tOracleRow_1.createStatement();
	

 



/**
 * [tOracleRow_1 begin ] stop
 */
	
	/**
	 * [tOracleRow_1 main ] start
	 */

	

	
	
	currentComponent="tOracleRow_1";

	

	    		log.debug("tOracleRow_1 - Executing the query: '" + "  MERGE  INTO EIM_ADMIN.RUN_CTL_LAST_RUN_DTM_DL A  USING (SELECT TABLE_NAME, OLD_LAST_UPD, RANK () OVER(PARTITION BY TABLE_NAME ORDER BY START_DTM DESC) AS RNK  	   FROM EIM_ADMIN.STG_DL_EXTRACT_LOG  	   WHERE TABLE_NAME LIKE '%" + ((String)globalMap.get("OBJECT_NM")) + "'  			AND START_DTM > TO_TIMESTAMP('" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "', 'YYYYMMDDHH24MISSFF3')) B  ON (A.TABLE_NAME = B.TABLE_NAME AND B.RNK = 1)  WHEN MATCHED THEN UPDATE  	SET A.LAST_RUN_DTM = B.OLD_LAST_UPD  " + "'.");
			
query_tOracleRow_1 = "\nMERGE\nINTO EIM_ADMIN.RUN_CTL_LAST_RUN_DTM_DL A\nUSING (SELECT TABLE_NAME, OLD_LAST_UPD, RANK () OVER(PARTITION BY TABLE_NAME ORDER BY START_DTM DESC) AS RNK\n	   FROM EIM_ADMIN.STG_DL_EXTRACT_LOG\n	   WHERE TABLE_NAME LIKE '%" + ((String)globalMap.get("OBJECT_NM")) + "'\n			AND START_DTM > TO_TIMESTAMP('" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "', 'YYYYMMDDHH24MISSFF3')) B\nON (A.TABLE_NAME = B.TABLE_NAME AND B.RNK = 1)\nWHEN MATCHED THEN UPDATE\n	SET A.LAST_RUN_DTM = B.OLD_LAST_UPD\n";
whetherReject_tOracleRow_1 = false;
globalMap.put("tOracleRow_1_QUERY",query_tOracleRow_1);
try {
		stmt_tOracleRow_1.execute(query_tOracleRow_1);
		
	    		log.info("tOracleRow_1 - Execute the query: '" + "\nMERGE\nINTO EIM_ADMIN.RUN_CTL_LAST_RUN_DTM_DL A\nUSING (SELECT TABLE_NAME, OLD_LAST_UPD, RANK () OVER(PARTITION BY TABLE_NAME ORDER BY START_DTM DESC) AS RNK\n	   FROM EIM_ADMIN.STG_DL_EXTRACT_LOG\n	   WHERE TABLE_NAME LIKE '%" + ((String)globalMap.get("OBJECT_NM")) + "'\n			AND START_DTM > TO_TIMESTAMP('" + ((String)globalMap.get("JOB_STARTTIME_STRING")) + "', 'YYYYMMDDHH24MISSFF3')) B\nON (A.TABLE_NAME = B.TABLE_NAME AND B.RNK = 1)\nWHEN MATCHED THEN UPDATE\n	SET A.LAST_RUN_DTM = B.OLD_LAST_UPD\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tOracleRow_1 = true;
		
			throw(e);
			
	}
	

 


	tos_count_tOracleRow_1++;

/**
 * [tOracleRow_1 main ] stop
 */
	
	/**
	 * [tOracleRow_1 end ] start
	 */

	

	
	
	currentComponent="tOracleRow_1";

	

	
	stmt_tOracleRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tOracleRow_1 - "  + ("Done.") );

ok_Hash.put("tOracleRow_1", true);
end_Hash.put("tOracleRow_1", System.currentTimeMillis());




/**
 * [tOracleRow_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleRow_1 finally ] start
	 */

	

	
	
	currentComponent="tOracleRow_1";

	

 



/**
 * [tOracleRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tDie_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDie_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tDie_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDie_1", false);
		start_Hash.put("tDie_1", System.currentTimeMillis());
		
	
	currentComponent="tDie_1";

	
		int tos_count_tDie_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tDie_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tDie_1 = new StringBuilder();
            log4jParamters_tDie_1.append("Parameters:");
                    log4jParamters_tDie_1.append("MESSAGE" + " = " + "\"the end is near\"");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("CODE" + " = " + "4");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("PRIORITY" + " = " + "5");
                log4jParamters_tDie_1.append(" | ");
                    log4jParamters_tDie_1.append("EXIT_JVM" + " = " + "false");
                log4jParamters_tDie_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + (log4jParamters_tDie_1) );
    		}
    	}
    	
        new BytesLimit65535_tDie_1().limitLog4jByte();

 



/**
 * [tDie_1 begin ] stop
 */
	
	/**
	 * [tDie_1 main ] start
	 */

	

	
	
	currentComponent="tDie_1";

	


	globalMap.put("tDie_1_DIE_PRIORITY", 5);
	System.err.println("the end is near");
	
		log.error("tDie_1 - The die message: "+"the end is near");
	
	globalMap.put("tDie_1_DIE_MESSAGE", "the end is near");
	globalMap.put("tDie_1_DIE_MESSAGES", "the end is near");
	currentComponent = "tDie_1";
	status = "failure";
        errorCode = new Integer(4);
        globalMap.put("tDie_1_DIE_CODE", errorCode);        
    
	if(true){	
	    throw new TDieException();
	}

 


	tos_count_tDie_1++;

/**
 * [tDie_1 main ] stop
 */
	
	/**
	 * [tDie_1 end ] start
	 */

	

	
	
	currentComponent="tDie_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tDie_1 - "  + ("Done.") );

ok_Hash.put("tDie_1", true);
end_Hash.put("tDie_1", System.currentTimeMillis());




/**
 * [tDie_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDie_1 finally ] start
	 */

	

	
	
	currentComponent="tDie_1";

	

 



/**
 * [tDie_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDie_1_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";

	
		int tos_count_tPostjob_1 = 0;
		
    	class BytesLimit65535_tPostjob_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tPostjob_1().limitLog4jByte();

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk7", 0, "ok");
				}
				tJava_9Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_9Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_9_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_9 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_9", false);
		start_Hash.put("tJava_9", System.currentTimeMillis());
		
	
	currentComponent="tJava_9";

	
		int tos_count_tJava_9 = 0;
		
    	class BytesLimit65535_tJava_9{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tJava_9().limitLog4jByte();


if ("SP_MULTI_UCM_CONTACT".equals((String)globalMap.get("OBJECT_TYPE"))) {
	globalMap.put("MULTI_OBJECT_IDS", (Relational.ISNULL(globalMap.get("MULTI_OBJECT_ID_1")) ? "" : "IN ('" + ((String)globalMap.get("MULTI_OBJECT_ID_1")) + "'") + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_ID_2")) ? "" : ", '" + ((String)globalMap.get("MULTI_OBJECT_ID_2")) + "'") + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_ID_3")) ? "" : ", '" + ((String)globalMap.get("MULTI_OBJECT_ID_3")) + "'") + ")");
}
 



/**
 * [tJava_9 begin ] stop
 */
	
	/**
	 * [tJava_9 main ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 


	tos_count_tJava_9++;

/**
 * [tJava_9 main ] stop
 */
	
	/**
	 * [tJava_9 end ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 

ok_Hash.put("tJava_9", true);
end_Hash.put("tJava_9", System.currentTimeMillis());

   			if (Relational.ISNULL(globalMap.get("NO_PROCESS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If13", 0, "true");
					}
				
    			tMSSqlRow_1Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If13", 0, "false");
					}   	 
   				}
   			if ("Y".equals((String)globalMap.get("NO_PROCESS"))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If14", 0, "true");
					}
				
    			tOracleClose_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If14", 0, "false");
					}   	 
   				}



/**
 * [tJava_9 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_9 finally ] start
	 */

	

	
	
	currentComponent="tJava_9";

	

 



/**
 * [tJava_9 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_9_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tMSSqlRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_1", false);
		start_Hash.put("tMSSqlRow_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_1";

	
		int tos_count_tMSSqlRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_1 = new StringBuilder();
            log4jParamters_tMSSqlRow_1.append("Parameters:");
                    log4jParamters_tMSSqlRow_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("QUERY" + " = " + "\"  UPDATE DBO.T_INGTN_TRCKNG_DTL  SET STATUS = '\" + (\"F\".equals((String)globalMap.get(\"LOAD_STATUS\")) ? \"F\" : \"C\") + \"'  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'  WHERE JB_INSTNCE_ID = '\" + ((String)globalMap.get(\"JOB_INSTANCE_ID\")) + \"'  \"");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                    log4jParamters_tMSSqlRow_1.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + (log4jParamters_tMSSqlRow_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_1().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_1 = null;
	String query_tMSSqlRow_1 = "";
	boolean whetherReject_tMSSqlRow_1 = false;
				conn_tMSSqlRow_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_1 != null) {
					if(conn_tMSSqlRow_1.getMetaData() != null) {
						
						log.debug("tMSSqlRow_1 - Uses an existing connection with username '" + conn_tMSSqlRow_1.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_1.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_1 = conn_tMSSqlRow_1.createStatement();
	

 



/**
 * [tMSSqlRow_1 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

	    		log.debug("tMSSqlRow_1 - Executing the query: '" + "  UPDATE DBO.T_INGTN_TRCKNG_DTL  SET STATUS = '" + ("F".equals((String)globalMap.get("LOAD_STATUS")) ? "F" : "C") + "'  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'  WHERE JB_INSTNCE_ID = '" + ((String)globalMap.get("JOB_INSTANCE_ID")) + "'  " + "'.");
			
query_tMSSqlRow_1 = "\nUPDATE DBO.T_INGTN_TRCKNG_DTL\nSET STATUS = '" + ("F".equals((String)globalMap.get("LOAD_STATUS")) ? "F" : "C") + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE JB_INSTNCE_ID = '" + ((String)globalMap.get("JOB_INSTANCE_ID")) + "'\n";
whetherReject_tMSSqlRow_1 = false;
globalMap.put("tMSSqlRow_1_QUERY",query_tMSSqlRow_1);
try {
		stmt_tMSSqlRow_1.execute(query_tMSSqlRow_1);
		
	    		log.debug("tMSSqlRow_1 - Execute the query: '" + "\nUPDATE DBO.T_INGTN_TRCKNG_DTL\nSET STATUS = '" + ("F".equals((String)globalMap.get("LOAD_STATUS")) ? "F" : "C") + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE JB_INSTNCE_ID = '" + ((String)globalMap.get("JOB_INSTANCE_ID")) + "'\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_1 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tMSSqlRow_1) {
		
	}
	

 


	tos_count_tMSSqlRow_1++;

/**
 * [tMSSqlRow_1 main ] stop
 */
	
	/**
	 * [tMSSqlRow_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

	
	stmt_tMSSqlRow_1.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_1", true);
end_Hash.put("tMSSqlRow_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk4", 0, "ok");
				}
				tMSSqlRow_2Process(globalMap);



/**
 * [tMSSqlRow_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tMSSqlRow_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk13", 0, "ok");
								} 
							
							tFixedFlowInput_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_1";

	

 



/**
 * [tMSSqlRow_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tMSSqlRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_2", false);
		start_Hash.put("tMSSqlRow_2", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_2";

	
		int tos_count_tMSSqlRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_2 = new StringBuilder();
            log4jParamters_tMSSqlRow_2.append("Parameters:");
                    log4jParamters_tMSSqlRow_2.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("QUERY" + " = " + "\"  UPDATE DBO.T_LOAD_CTL_DTL  SET STATUS = '\" + (\"F\".equals((String)globalMap.get(\"LOAD_STATUS\")) ? \"F\" : \"C\") + \"'  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'  WHERE OBJECT_ID \" + (Relational.ISNULL(globalMap.get(\"MULTI_OBJECT_IDS\")) ? \"= '\" + ((String)globalMap.get(\"OBJECT_ID\")) + \"'\" : ((String)globalMap.get(\"MULTI_OBJECT_IDS\"))) + \"  	AND SRC_SYS_ID ='\" + ((String)globalMap.get(\"SRC_SYS_ID\")) + \"'  	AND IS_ACTIVE = 'Y'  	AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"SUB_SYS_ID\")) + \"'  \"");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_2.append(" | ");
                    log4jParamters_tMSSqlRow_2.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_2 - "  + (log4jParamters_tMSSqlRow_2) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_2().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_2 = null;
	String query_tMSSqlRow_2 = "";
	boolean whetherReject_tMSSqlRow_2 = false;
				conn_tMSSqlRow_2 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_2 != null) {
					if(conn_tMSSqlRow_2.getMetaData() != null) {
						
						log.debug("tMSSqlRow_2 - Uses an existing connection with username '" + conn_tMSSqlRow_2.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_2.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_2 = conn_tMSSqlRow_2.createStatement();
	

 



/**
 * [tMSSqlRow_2 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_2 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_2";

	

	    		log.debug("tMSSqlRow_2 - Executing the query: '" + "  UPDATE DBO.T_LOAD_CTL_DTL  SET STATUS = '" + ("F".equals((String)globalMap.get("LOAD_STATUS")) ? "F" : "C") + "'  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'  WHERE OBJECT_ID " + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_IDS")) ? "= '" + ((String)globalMap.get("OBJECT_ID")) + "'" : ((String)globalMap.get("MULTI_OBJECT_IDS"))) + "  	AND SRC_SYS_ID ='" + ((String)globalMap.get("SRC_SYS_ID")) + "'  	AND IS_ACTIVE = 'Y'  	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'  " + "'.");
			
query_tMSSqlRow_2 = "\nUPDATE DBO.T_LOAD_CTL_DTL\nSET STATUS = '" + ("F".equals((String)globalMap.get("LOAD_STATUS")) ? "F" : "C") + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE OBJECT_ID " + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_IDS")) ? "= '" + ((String)globalMap.get("OBJECT_ID")) + "'" : ((String)globalMap.get("MULTI_OBJECT_IDS"))) + "\n	AND SRC_SYS_ID ='" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n	AND IS_ACTIVE = 'Y'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n";
whetherReject_tMSSqlRow_2 = false;
globalMap.put("tMSSqlRow_2_QUERY",query_tMSSqlRow_2);
try {
		stmt_tMSSqlRow_2.execute(query_tMSSqlRow_2);
		
	    		log.debug("tMSSqlRow_2 - Execute the query: '" + "\nUPDATE DBO.T_LOAD_CTL_DTL\nSET STATUS = '" + ("F".equals((String)globalMap.get("LOAD_STATUS")) ? "F" : "C") + "'\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE OBJECT_ID " + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_IDS")) ? "= '" + ((String)globalMap.get("OBJECT_ID")) + "'" : ((String)globalMap.get("MULTI_OBJECT_IDS"))) + "\n	AND SRC_SYS_ID ='" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n	AND IS_ACTIVE = 'Y'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_2 = true;
		
			throw(e);
			
	}
	
	if(!whetherReject_tMSSqlRow_2) {
		
	}
	

 


	tos_count_tMSSqlRow_2++;

/**
 * [tMSSqlRow_2 main ] stop
 */
	
	/**
	 * [tMSSqlRow_2 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_2";

	

	
	stmt_tMSSqlRow_2.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_2 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_2", true);
end_Hash.put("tMSSqlRow_2", System.currentTimeMillis());

   			if (("Y".equals((String)globalMap.get("IS_ACTIVE"))) && (!"F".equals((String)globalMap.get("LOAD_STATUS")))) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "true");
					}
				
    			tMSSqlRow_3Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If2", 0, "false");
					}   	 
   				}



/**
 * [tMSSqlRow_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_2 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_2";

	

 



/**
 * [tMSSqlRow_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_2_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlRow_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlRow_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tMSSqlRow_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlRow_3", false);
		start_Hash.put("tMSSqlRow_3", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlRow_3";

	
		int tos_count_tMSSqlRow_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlRow_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlRow_3 = new StringBuilder();
            log4jParamters_tMSSqlRow_3.append("Parameters:");
                    log4jParamters_tMSSqlRow_3.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("QUERYSTORE" + " = " + "\"\"");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("QUERY" + " = " + "\"  UPDATE DBO.T_CDC_AUX_DTL SET LAST_RUN_DTTM = CAST('\" + TalendDate.formatDate(\"yyyy-MM-dd HH:mm:ss.SSS\", (Date)globalMap.get(\"NEXT_RUN_DTTM\")) + \"' AS DATETIME2)  	, NEXT_RUN_DTTM = DATEADD(MINUTE, \" + ((String)globalMap.get(\"FREQUENCY\")) + \", CAST('\" + TalendDate.formatDate(\"yyyy-MM-dd HH:mm:ss.SSS\", (Date)globalMap.get(\"NEXT_RUN_DTTM\")) + \"' AS DATETIME2))  	, UPDT_DTTM = CAST('\" + TalendDate.getDate(\"yyyy-MM-dd HH:mm:ss.SSS\") + \"' AS DATETIME2)  	, UPDT_BY = '\" + ((String)globalMap.get(\"DB_USER\")) + \"'  WHERE OBJECT_ID \" + (Relational.ISNULL(globalMap.get(\"MULTI_OBJECT_IDS\")) ? \"= '\" + ((String)globalMap.get(\"OBJECT_ID\")) + \"'\" : ((String)globalMap.get(\"MULTI_OBJECT_IDS\"))) + \"  	AND SRC_SYS_ID = '\" + ((String)globalMap.get(\"SRC_SYS_ID\")) + \"'  	AND SUB_SYS_ID = '\" + ((String)globalMap.get(\"SUB_SYS_ID\")) + \"'  \"");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("PROPAGATE_RECORD_SET" + " = " + "false");
                log4jParamters_tMSSqlRow_3.append(" | ");
                    log4jParamters_tMSSqlRow_3.append("USE_PREPAREDSTATEMENT" + " = " + "false");
                log4jParamters_tMSSqlRow_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_3 - "  + (log4jParamters_tMSSqlRow_3) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlRow_3().limitLog4jByte();

	java.sql.Connection conn_tMSSqlRow_3 = null;
	String query_tMSSqlRow_3 = "";
	boolean whetherReject_tMSSqlRow_3 = false;
				conn_tMSSqlRow_3 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
			
				if(conn_tMSSqlRow_3 != null) {
					if(conn_tMSSqlRow_3.getMetaData() != null) {
						
						log.debug("tMSSqlRow_3 - Uses an existing connection with username '" + conn_tMSSqlRow_3.getMetaData().getUserName() + "'. Connection URL: " + conn_tMSSqlRow_3.getMetaData().getURL() + ".");
						
					}
				}
			
		java.sql.Statement stmt_tMSSqlRow_3 = conn_tMSSqlRow_3.createStatement();
	

 



/**
 * [tMSSqlRow_3 begin ] stop
 */
	
	/**
	 * [tMSSqlRow_3 main ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_3";

	

	    		log.debug("tMSSqlRow_3 - Executing the query: '" + "  UPDATE DBO.T_CDC_AUX_DTL SET LAST_RUN_DTTM = CAST('" + TalendDate.formatDate("yyyy-MM-dd HH:mm:ss.SSS", (Date)globalMap.get("NEXT_RUN_DTTM")) + "' AS DATETIME2)  	, NEXT_RUN_DTTM = DATEADD(MINUTE, " + ((String)globalMap.get("FREQUENCY")) + ", CAST('" + TalendDate.formatDate("yyyy-MM-dd HH:mm:ss.SSS", (Date)globalMap.get("NEXT_RUN_DTTM")) + "' AS DATETIME2))  	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)  	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'  WHERE OBJECT_ID " + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_IDS")) ? "= '" + ((String)globalMap.get("OBJECT_ID")) + "'" : ((String)globalMap.get("MULTI_OBJECT_IDS"))) + "  	AND SRC_SYS_ID = '" + ((String)globalMap.get("SRC_SYS_ID")) + "'  	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'  " + "'.");
			
query_tMSSqlRow_3 = "\nUPDATE DBO.T_CDC_AUX_DTL SET LAST_RUN_DTTM = CAST('" + TalendDate.formatDate("yyyy-MM-dd HH:mm:ss.SSS", (Date)globalMap.get("NEXT_RUN_DTTM")) + "' AS DATETIME2)\n	, NEXT_RUN_DTTM = DATEADD(MINUTE, " + ((String)globalMap.get("FREQUENCY")) + ", CAST('" + TalendDate.formatDate("yyyy-MM-dd HH:mm:ss.SSS", (Date)globalMap.get("NEXT_RUN_DTTM")) + "' AS DATETIME2))\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE OBJECT_ID " + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_IDS")) ? "= '" + ((String)globalMap.get("OBJECT_ID")) + "'" : ((String)globalMap.get("MULTI_OBJECT_IDS"))) + "\n	AND SRC_SYS_ID = '" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n";
whetherReject_tMSSqlRow_3 = false;
globalMap.put("tMSSqlRow_3_QUERY",query_tMSSqlRow_3);
try {
		stmt_tMSSqlRow_3.execute(query_tMSSqlRow_3);
		
	    		log.debug("tMSSqlRow_3 - Execute the query: '" + "\nUPDATE DBO.T_CDC_AUX_DTL SET LAST_RUN_DTTM = CAST('" + TalendDate.formatDate("yyyy-MM-dd HH:mm:ss.SSS", (Date)globalMap.get("NEXT_RUN_DTTM")) + "' AS DATETIME2)\n	, NEXT_RUN_DTTM = DATEADD(MINUTE, " + ((String)globalMap.get("FREQUENCY")) + ", CAST('" + TalendDate.formatDate("yyyy-MM-dd HH:mm:ss.SSS", (Date)globalMap.get("NEXT_RUN_DTTM")) + "' AS DATETIME2))\n	, UPDT_DTTM = CAST('" + TalendDate.getDate("yyyy-MM-dd HH:mm:ss.SSS") + "' AS DATETIME2)\n	, UPDT_BY = '" + ((String)globalMap.get("DB_USER")) + "'\nWHERE OBJECT_ID " + (Relational.ISNULL(globalMap.get("MULTI_OBJECT_IDS")) ? "= '" + ((String)globalMap.get("OBJECT_ID")) + "'" : ((String)globalMap.get("MULTI_OBJECT_IDS"))) + "\n	AND SRC_SYS_ID = '" + ((String)globalMap.get("SRC_SYS_ID")) + "'\n	AND SUB_SYS_ID = '" + ((String)globalMap.get("SUB_SYS_ID")) + "'\n" + "' has finished.");
			
	} catch (java.lang.Exception e) {
		whetherReject_tMSSqlRow_3 = true;
		
			throw(e);
			
	}
	

 


	tos_count_tMSSqlRow_3++;

/**
 * [tMSSqlRow_3 main ] stop
 */
	
	/**
	 * [tMSSqlRow_3 end ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_3";

	

	
	stmt_tMSSqlRow_3.close();	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlRow_3 - "  + ("Done.") );

ok_Hash.put("tMSSqlRow_3", true);
end_Hash.put("tMSSqlRow_3", System.currentTimeMillis());




/**
 * [tMSSqlRow_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlRow_3 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlRow_3";

	

 



/**
 * [tMSSqlRow_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlRow_3_SUBPROCESS_STATE", 1);
	}
	


public static class row11Struct implements routines.system.IPersistableRow<row11Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public Long system_pid;

				public Long getSystem_pid () {
					return this.system_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String job_repository_id;

				public String getJob_repository_id () {
					return this.job_repository_id;
				}
				
			    public String job_version;

				public String getJob_version () {
					return this.job_version;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message_type;

				public String getMessage_type () {
					return this.message_type;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Long duration;

				public Long getDuration () {
					return this.duration;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String Jb_instnce_id;

				public String getJb_instnce_id () {
					return this.Jb_instnce_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.root_pid = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.system_pid = null;
           				} else {
           			    	this.system_pid = dis.readLong();
           				}
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.job_repository_id = readString(dis);
					
					this.job_version = readString(dis);
					
					this.context = readString(dis);
					
					this.origin = readString(dis);
					
					this.message_type = readString(dis);
					
					this.message = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.duration = null;
           				} else {
           			    	this.duration = dis.readLong();
           				}
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.object_nm = readString(dis);
					
					this.run_id = readString(dis);
					
					this.Jb_instnce_id = readString(dis);
					
					this.object_id = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// Long
				
						if(this.system_pid == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.system_pid);
		            	}
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.job_repository_id,dos);
					
					// String
				
						writeString(this.job_version,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message_type,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Long
				
						if(this.duration == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.duration);
		            	}
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.Jb_instnce_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",system_pid="+String.valueOf(system_pid));
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",job_repository_id="+job_repository_id);
		sb.append(",job_version="+job_version);
		sb.append(",context="+context);
		sb.append(",origin="+origin);
		sb.append(",message_type="+message_type);
		sb.append(",message="+message);
		sb.append(",duration="+String.valueOf(duration));
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",run_id="+run_id);
		sb.append(",Jb_instnce_id="+Jb_instnce_id);
		sb.append(",object_id="+object_id);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(system_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(system_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(job_repository_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_repository_id);
            			}
            		
        			sb.append("|");
        		
        				if(job_version == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job_version);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message_type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message_type);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(duration == null){
        					sb.append("<null>");
        				}else{
            				sb.append(duration);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(Jb_instnce_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Jb_instnce_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row11Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFixedFlowInput_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFixedFlowInput_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row11Struct row11 = new row11Struct();




	
	/**
	 * [tMSSqlOutput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_5", false);
		start_Hash.put("tMSSqlOutput_5", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_5";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row11" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_5{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_5 = new StringBuilder();
            log4jParamters_tMSSqlOutput_5.append("Parameters:");
                    log4jParamters_tMSSqlOutput_5.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("TABLE" + " = " + "\"statcatcher\"");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                    log4jParamters_tMSSqlOutput_5.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + (log4jParamters_tMSSqlOutput_5) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_5().limitLog4jByte();



int nb_line_tMSSqlOutput_5 = 0;
int nb_line_update_tMSSqlOutput_5 = 0;
int nb_line_inserted_tMSSqlOutput_5 = 0;
int nb_line_deleted_tMSSqlOutput_5 = 0;
int nb_line_rejected_tMSSqlOutput_5 = 0;

int deletedCount_tMSSqlOutput_5=0;
int updatedCount_tMSSqlOutput_5=0;
int insertedCount_tMSSqlOutput_5=0;
int rejectedCount_tMSSqlOutput_5=0;
String dbschema_tMSSqlOutput_5 = null;
String tableName_tMSSqlOutput_5 = null;
boolean whetherReject_tMSSqlOutput_5 = false;

java.util.Calendar calendar_tMSSqlOutput_5 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_5 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_5 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_5 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_5;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_5 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_5 = null;
String dbUser_tMSSqlOutput_5 = null;
	dbschema_tMSSqlOutput_5 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_5 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_5.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_5.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_5.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_5 == null || dbschema_tMSSqlOutput_5.trim().length() == 0) {
    tableName_tMSSqlOutput_5 = "statcatcher";
} else {
    tableName_tMSSqlOutput_5 = dbschema_tMSSqlOutput_5 + "].[" + "statcatcher";
}
	int count_tMSSqlOutput_5=0;

        String insert_tMSSqlOutput_5 = "INSERT INTO [" + tableName_tMSSqlOutput_5 + "] ([moment],[pid],[father_pid],[root_pid],[system_pid],[project],[job],[job_repository_id],[job_version],[context],[origin],[message_type],[message],[duration],[src_sys_id],[sub_sys_id],[object_nm],[run_id],[Jb_instnce_id],[object_id]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_5 = conn_tMSSqlOutput_5.prepareStatement(insert_tMSSqlOutput_5);

 	boolean isShareIdentity_tMSSqlOutput_5 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_5 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_5", false);
		start_Hash.put("tFixedFlowInput_5", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_5";

	
		int tos_count_tFixedFlowInput_5 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_5{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_5().limitLog4jByte();

	    for (int i_tFixedFlowInput_5 = 0 ; i_tFixedFlowInput_5 < 1 ; i_tFixedFlowInput_5++) {
	                	            	
    	            		row11.moment = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row11.pid = pid;
    	            	        	            	
    	            		row11.father_pid = context.root_pid;
    	            	        	            	
    	            		row11.root_pid = context.root_pid;
    	            	        	            	
    	            		row11.system_pid = null;
    	            	        	            	
    	            		row11.project = projectName;
    	            	        	            	
    	            		row11.job = jobName;
    	            	        	            	
    	            		row11.job_repository_id = null;
    	            	        	            	
    	            		row11.job_version = jobVersion;
    	            	        	            	
    	            		row11.context = contextStr ;
    	            	        	            	
    	            		row11.origin = null;
    	            	        	            	
    	            		row11.message_type = "end";
    	            	        	            	
    	            		row11.message = "F".equals(((String)globalMap.get("LOAD_STATUS"))) ? "failure" : "C".equals(((String)globalMap.get("LOAD_STATUS"))) ? "success" : null;
    	            	        	            	
    	            		row11.duration = ("C".equals(((String)globalMap.get("LOAD_STATUS"))) || "F".equals(((String)globalMap.get("LOAD_STATUS")))) ? TalendDate.diffDate(TalendDate.getCurrentDate(), ((Date)globalMap.get("JOB_STARTTIME")), "SSS") : null;
    	            	        	            	
    	            		row11.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row11.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row11.object_nm = ((String)globalMap.get("OBJECT_NM"));
    	            	        	            	
    	            		row11.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row11.Jb_instnce_id = ((String)globalMap.get("JOB_INSTANCE_ID"));
    	            	        	            	
    	            		row11.object_id = ((String)globalMap.get("OBJECT_ID"));
    	            	
 



/**
 * [tFixedFlowInput_5 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_5 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_5";

	

 


	tos_count_tFixedFlowInput_5++;

/**
 * [tFixedFlowInput_5 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_5 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_5";

	

			//row11
			//row11


			
				if(execStat){
					runStat.updateStatOnConnection("row11"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row11 - " + (row11==null? "": row11.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_5 = false;
                    if(row11.moment != null) {
pstmt_tMSSqlOutput_5.setTimestamp(1, new java.sql.Timestamp(row11.moment.getTime()));
} else {
pstmt_tMSSqlOutput_5.setNull(1, java.sql.Types.DATE);
}

                    if(row11.pid == null) {
pstmt_tMSSqlOutput_5.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(2, row11.pid);
}

                    if(row11.father_pid == null) {
pstmt_tMSSqlOutput_5.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(3, row11.father_pid);
}

                    if(row11.root_pid == null) {
pstmt_tMSSqlOutput_5.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(4, row11.root_pid);
}

                    if(row11.system_pid == null) {
pstmt_tMSSqlOutput_5.setNull(5, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_5.setLong(5, row11.system_pid);
}

                    if(row11.project == null) {
pstmt_tMSSqlOutput_5.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(6, row11.project);
}

                    if(row11.job == null) {
pstmt_tMSSqlOutput_5.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(7, row11.job);
}

                    if(row11.job_repository_id == null) {
pstmt_tMSSqlOutput_5.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(8, row11.job_repository_id);
}

                    if(row11.job_version == null) {
pstmt_tMSSqlOutput_5.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(9, row11.job_version);
}

                    if(row11.context == null) {
pstmt_tMSSqlOutput_5.setNull(10, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(10, row11.context);
}

                    if(row11.origin == null) {
pstmt_tMSSqlOutput_5.setNull(11, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(11, row11.origin);
}

                    if(row11.message_type == null) {
pstmt_tMSSqlOutput_5.setNull(12, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(12, row11.message_type);
}

                    if(row11.message == null) {
pstmt_tMSSqlOutput_5.setNull(13, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(13, row11.message);
}

                    if(row11.duration == null) {
pstmt_tMSSqlOutput_5.setNull(14, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_5.setLong(14, row11.duration);
}

                    if(row11.src_sys_id == null) {
pstmt_tMSSqlOutput_5.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(15, row11.src_sys_id);
}

                    if(row11.sub_sys_id == null) {
pstmt_tMSSqlOutput_5.setNull(16, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(16, row11.sub_sys_id);
}

                    if(row11.object_nm == null) {
pstmt_tMSSqlOutput_5.setNull(17, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(17, row11.object_nm);
}

                    if(row11.run_id == null) {
pstmt_tMSSqlOutput_5.setNull(18, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(18, row11.run_id);
}

                    if(row11.Jb_instnce_id == null) {
pstmt_tMSSqlOutput_5.setNull(19, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(19, row11.Jb_instnce_id);
}

                    if(row11.object_id == null) {
pstmt_tMSSqlOutput_5.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_5.setString(20, row11.object_id);
}


            try {
                nb_line_tMSSqlOutput_5++;
                insertedCount_tMSSqlOutput_5 = insertedCount_tMSSqlOutput_5 + pstmt_tMSSqlOutput_5.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_5)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_5 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_5{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_5) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_5: pstmt_tMSSqlOutput_5.executeBatch()) {
							if(countEach_tMSSqlOutput_5 == -2 || countEach_tMSSqlOutput_5 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_5;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_5) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_5: pstmt_tMSSqlOutput_5.executeBatch()) {
							if(countEach_tMSSqlOutput_5 == -2 || countEach_tMSSqlOutput_5 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_5;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_5++;

/**
 * [tMSSqlOutput_5 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_5 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_5";

	

        }
        globalMap.put("tFixedFlowInput_5_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_5", true);
end_Hash.put("tFixedFlowInput_5", System.currentTimeMillis());




/**
 * [tFixedFlowInput_5 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_5 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_5";

	



        if(pstmt_tMSSqlOutput_5 != null) {
			
				pstmt_tMSSqlOutput_5.close();
			
        }


	nb_line_deleted_tMSSqlOutput_5=nb_line_deleted_tMSSqlOutput_5+ deletedCount_tMSSqlOutput_5;
	nb_line_update_tMSSqlOutput_5=nb_line_update_tMSSqlOutput_5 + updatedCount_tMSSqlOutput_5;
	nb_line_inserted_tMSSqlOutput_5=nb_line_inserted_tMSSqlOutput_5 + insertedCount_tMSSqlOutput_5;
	nb_line_rejected_tMSSqlOutput_5=nb_line_rejected_tMSSqlOutput_5 + rejectedCount_tMSSqlOutput_5;
	
        globalMap.put("tMSSqlOutput_5_NB_LINE",nb_line_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_5);
        globalMap.put("tMSSqlOutput_5_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_5);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_5)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row11"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_5 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_5", true);
end_Hash.put("tMSSqlOutput_5", System.currentTimeMillis());




/**
 * [tMSSqlOutput_5 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tFixedFlowInput_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk12", 0, "ok");
								} 
							
							tHashInput_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFixedFlowInput_5 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_5";

	

 



/**
 * [tFixedFlowInput_5 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_5 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_5";

	



	

 



/**
 * [tMSSqlOutput_5 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFixedFlowInput_5_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_14Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_14_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_14 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_14", false);
		start_Hash.put("tWarn_14", System.currentTimeMillis());
		
	
	currentComponent="tWarn_14";

	
		int tos_count_tWarn_14 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_14{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_14 = new StringBuilder();
            log4jParamters_tWarn_14.append("Parameters:");
                    log4jParamters_tWarn_14.append("MESSAGE" + " = " + "\"214|Insert Stats Catcher table failed\"");
                log4jParamters_tWarn_14.append(" | ");
                    log4jParamters_tWarn_14.append("CODE" + " = " + "999");
                log4jParamters_tWarn_14.append(" | ");
                    log4jParamters_tWarn_14.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_14.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + (log4jParamters_tWarn_14) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_14().limitLog4jByte();

 



/**
 * [tWarn_14 begin ] stop
 */
	
	/**
	 * [tWarn_14 main ] start
	 */

	

	
	
	currentComponent="tWarn_14";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_14", "", Thread.currentThread().getId() + "", "ERROR","","214|Insert Stats Catcher table failed","", "");
            log.error("tWarn_14 - "  + ("Message: ")  + ("214|Insert Stats Catcher table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_14", 5, "214|Insert Stats Catcher table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_14_WARN_MESSAGES", "214|Insert Stats Catcher table failed"); 
globalMap.put("tWarn_14_WARN_PRIORITY", 5);
globalMap.put("tWarn_14_WARN_CODE", 999);


 


	tos_count_tWarn_14++;

/**
 * [tWarn_14 main ] stop
 */
	
	/**
	 * [tWarn_14 end ] start
	 */

	

	
	
	currentComponent="tWarn_14";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_14 - "  + ("Done.") );

ok_Hash.put("tWarn_14", true);
end_Hash.put("tWarn_14", System.currentTimeMillis());




/**
 * [tWarn_14 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_14 finally ] start
	 */

	

	
	
	currentComponent="tWarn_14";

	

 



/**
 * [tWarn_14 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_14_SUBPROCESS_STATE", 1);
	}
	


public static class row10Struct implements routines.system.IPersistableRow<row10Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String Submtn_mode_id;

				public String getSubmtn_mode_id () {
					return this.Submtn_mode_id;
				}
				
			    public String batch_id;

				public String getBatch_id () {
					return this.batch_id;
				}
				
			    public String run_id;

				public String getRun_id () {
					return this.run_id;
				}
				
			    public String stg_id;

				public String getStg_id () {
					return this.stg_id;
				}
				
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public String src_sys_id;

				public String getSrc_sys_id () {
					return this.src_sys_id;
				}
				
			    public String sub_sys_id;

				public String getSub_sys_id () {
					return this.sub_sys_id;
				}
				
			    public String Status;

				public String getStatus () {
					return this.Status;
				}
				
			    public Long ld_record_cnt;

				public Long getLd_record_cnt () {
					return this.ld_record_cnt;
				}
				
			    public Long src_record_cnt;

				public Long getSrc_record_cnt () {
					return this.src_record_cnt;
				}
				
			    public Integer rjct_record_cnt;

				public Integer getRjct_record_cnt () {
					return this.rjct_record_cnt;
				}
				
			    public Integer err_record_cnt;

				public Integer getErr_record_cnt () {
					return this.err_record_cnt;
				}
				
			    public String crtd_by;

				public String getCrtd_by () {
					return this.crtd_by;
				}
				
			    public String updt_by;

				public String getUpdt_by () {
					return this.updt_by;
				}
				
			    public java.util.Date crtd_dttm;

				public java.util.Date getCrtd_dttm () {
					return this.crtd_dttm;
				}
				
			    public java.util.Date updt_dttm;

				public java.util.Date getUpdt_dttm () {
					return this.updt_dttm;
				}
				
			    public java.util.Date cdc_strt_dttm;

				public java.util.Date getCdc_strt_dttm () {
					return this.cdc_strt_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				
			    public String info_dtl;

				public String getInfo_dtl () {
					return this.info_dtl;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.Submtn_mode_id = readString(dis);
					
					this.batch_id = readString(dis);
					
					this.run_id = readString(dis);
					
					this.stg_id = readString(dis);
					
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
					this.src_sys_id = readString(dis);
					
					this.sub_sys_id = readString(dis);
					
					this.Status = readString(dis);
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.ld_record_cnt = null;
           				} else {
           			    	this.ld_record_cnt = dis.readLong();
           				}
					
			            length = dis.readByte();
           				if (length == -1) {
           	    			this.src_record_cnt = null;
           				} else {
           			    	this.src_record_cnt = dis.readLong();
           				}
					
						this.rjct_record_cnt = readInteger(dis);
					
						this.err_record_cnt = readInteger(dis);
					
					this.crtd_by = readString(dis);
					
					this.updt_by = readString(dis);
					
					this.crtd_dttm = readDate(dis);
					
					this.updt_dttm = readDate(dis);
					
					this.cdc_strt_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
					this.info_dtl = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Submtn_mode_id,dos);
					
					// String
				
						writeString(this.batch_id,dos);
					
					// String
				
						writeString(this.run_id,dos);
					
					// String
				
						writeString(this.stg_id,dos);
					
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// String
				
						writeString(this.src_sys_id,dos);
					
					// String
				
						writeString(this.sub_sys_id,dos);
					
					// String
				
						writeString(this.Status,dos);
					
					// Long
				
						if(this.ld_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.ld_record_cnt);
		            	}
					
					// Long
				
						if(this.src_record_cnt == null) {
			                dos.writeByte(-1);
						} else {
               				dos.writeByte(0);
           			    	dos.writeLong(this.src_record_cnt);
		            	}
					
					// Integer
				
						writeInteger(this.rjct_record_cnt,dos);
					
					// Integer
				
						writeInteger(this.err_record_cnt,dos);
					
					// String
				
						writeString(this.crtd_by,dos);
					
					// String
				
						writeString(this.updt_by,dos);
					
					// java.util.Date
				
						writeDate(this.crtd_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.updt_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_strt_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
					// String
				
						writeString(this.info_dtl,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Submtn_mode_id="+Submtn_mode_id);
		sb.append(",batch_id="+batch_id);
		sb.append(",run_id="+run_id);
		sb.append(",stg_id="+stg_id);
		sb.append(",object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",src_sys_id="+src_sys_id);
		sb.append(",sub_sys_id="+sub_sys_id);
		sb.append(",Status="+Status);
		sb.append(",ld_record_cnt="+String.valueOf(ld_record_cnt));
		sb.append(",src_record_cnt="+String.valueOf(src_record_cnt));
		sb.append(",rjct_record_cnt="+String.valueOf(rjct_record_cnt));
		sb.append(",err_record_cnt="+String.valueOf(err_record_cnt));
		sb.append(",crtd_by="+crtd_by);
		sb.append(",updt_by="+updt_by);
		sb.append(",crtd_dttm="+String.valueOf(crtd_dttm));
		sb.append(",updt_dttm="+String.valueOf(updt_dttm));
		sb.append(",cdc_strt_dttm="+String.valueOf(cdc_strt_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
		sb.append(",info_dtl="+info_dtl);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Submtn_mode_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Submtn_mode_id);
            			}
            		
        			sb.append("|");
        		
        				if(batch_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(batch_id);
            			}
            		
        			sb.append("|");
        		
        				if(run_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(run_id);
            			}
            		
        			sb.append("|");
        		
        				if(stg_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(stg_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(src_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(sub_sys_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(sub_sys_id);
            			}
            		
        			sb.append("|");
        		
        				if(Status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Status);
            			}
            		
        			sb.append("|");
        		
        				if(ld_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(ld_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(src_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(src_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(rjct_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(rjct_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(err_record_cnt == null){
        					sb.append("<null>");
        				}else{
            				sb.append(err_record_cnt);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_by);
            			}
            		
        			sb.append("|");
        		
        				if(updt_by == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_by);
            			}
            		
        			sb.append("|");
        		
        				if(crtd_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(crtd_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(updt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(updt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_strt_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_strt_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(info_dtl == null){
        					sb.append("<null>");
        				}else{
            				sb.append(info_dtl);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row10Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row18Struct implements routines.system.IPersistableRow<row18Struct> {
    final static byte[] commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];
    static byte[] commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[0];

	
			    public String object_id;

				public String getObject_id () {
					return this.object_id;
				}
				
			    public String object_nm;

				public String getObject_nm () {
					return this.object_nm;
				}
				
			    public Integer source_count;

				public Integer getSource_count () {
					return this.source_count;
				}
				
			    public Integer target_count;

				public Integer getTarget_count () {
					return this.target_count;
				}
				
			    public String file_name;

				public String getFile_name () {
					return this.file_name;
				}
				
			    public java.util.Date cdc_start_dttm;

				public java.util.Date getCdc_start_dttm () {
					return this.cdc_start_dttm;
				}
				
			    public java.util.Date cdc_end_dttm;

				public java.util.Date getCdc_end_dttm () {
					return this.cdc_end_dttm;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length) {
				if(length < 1024 && commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child.length == 0) {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[1024];
				} else {
   					commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length);
			strReturn = new String(commonByteArray_CEREBRO_Jb_Load_ORACLE_ADLS_Child, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_CEREBRO_Jb_Load_ORACLE_ADLS_Child) {

        	try {

        		int length = 0;
		
					this.object_id = readString(dis);
					
					this.object_nm = readString(dis);
					
						this.source_count = readInteger(dis);
					
						this.target_count = readInteger(dis);
					
					this.file_name = readString(dis);
					
					this.cdc_start_dttm = readDate(dis);
					
					this.cdc_end_dttm = readDate(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.object_id,dos);
					
					// String
				
						writeString(this.object_nm,dos);
					
					// Integer
				
						writeInteger(this.source_count,dos);
					
					// Integer
				
						writeInteger(this.target_count,dos);
					
					// String
				
						writeString(this.file_name,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_start_dttm,dos);
					
					// java.util.Date
				
						writeDate(this.cdc_end_dttm,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("object_id="+object_id);
		sb.append(",object_nm="+object_nm);
		sb.append(",source_count="+String.valueOf(source_count));
		sb.append(",target_count="+String.valueOf(target_count));
		sb.append(",file_name="+file_name);
		sb.append(",cdc_start_dttm="+String.valueOf(cdc_start_dttm));
		sb.append(",cdc_end_dttm="+String.valueOf(cdc_end_dttm));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(object_id == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_id);
            			}
            		
        			sb.append("|");
        		
        				if(object_nm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(object_nm);
            			}
            		
        			sb.append("|");
        		
        				if(source_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(source_count);
            			}
            		
        			sb.append("|");
        		
        				if(target_count == null){
        					sb.append("<null>");
        				}else{
            				sb.append(target_count);
            			}
            		
        			sb.append("|");
        		
        				if(file_name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(file_name);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_start_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_start_dttm);
            			}
            		
        			sb.append("|");
        		
        				if(cdc_end_dttm == null){
        					sb.append("<null>");
        				}else{
            				sb.append(cdc_end_dttm);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row18Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tHashInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tHashInput_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		row18Struct row18 = new row18Struct();
row10Struct row10 = new row10Struct();




	
	/**
	 * [tFlowToIterate_3 begin ] start
	 */

				
			int NB_ITERATE_tFixedFlowInput_4 = 0; //for statistics
			

	
		
		ok_Hash.put("tFlowToIterate_3", false);
		start_Hash.put("tFlowToIterate_3", System.currentTimeMillis());
		
	
	currentComponent="tFlowToIterate_3";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row18" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tFlowToIterate_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Start to work.") );
    	class BytesLimit65535_tFlowToIterate_3{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tFlowToIterate_3 = new StringBuilder();
            log4jParamters_tFlowToIterate_3.append("Parameters:");
                    log4jParamters_tFlowToIterate_3.append("DEFAULT_MAP" + " = " + "true");
                log4jParamters_tFlowToIterate_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + (log4jParamters_tFlowToIterate_3) );
    		}
    	}
    	
        new BytesLimit65535_tFlowToIterate_3().limitLog4jByte();

int nb_line_tFlowToIterate_3 = 0;
int counter_tFlowToIterate_3 = 0;

 



/**
 * [tFlowToIterate_3 begin ] stop
 */



	
	/**
	 * [tHashInput_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tHashInput_1", false);
		start_Hash.put("tHashInput_1", System.currentTimeMillis());
		
	
	currentComponent="tHashInput_1";

	
		int tos_count_tHashInput_1 = 0;
		
    	class BytesLimit65535_tHashInput_1{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tHashInput_1().limitLog4jByte();


int nb_line_tHashInput_1 = 0;
	
org.talend.designer.components.hashfile.common.MapHashFile mf_tHashInput_1=org.talend.designer.components.hashfile.common.MapHashFile.getMapHashFile();
org.talend.designer.components.hashfile.memory.AdvancedMemoryHashFile<row22Struct> tHashFile_tHashInput_1 = mf_tHashInput_1.getAdvancedMemoryHashFile("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
if(tHashFile_tHashInput_1==null) {
	throw new RuntimeException("The hash is not initialized : The hash must exist before you read from it");
}
java.util.Iterator<row22Struct> iterator_tHashInput_1 = tHashFile_tHashInput_1.iterator();
while (iterator_tHashInput_1.hasNext()) {
    row22Struct next_tHashInput_1 = iterator_tHashInput_1.next();

	row18.object_id = next_tHashInput_1.object_id;
	row18.object_nm = next_tHashInput_1.object_nm;
	row18.source_count = next_tHashInput_1.source_count;
	row18.target_count = next_tHashInput_1.target_count;
	row18.file_name = next_tHashInput_1.file_name;
	row18.cdc_start_dttm = next_tHashInput_1.cdc_start_dttm;
	row18.cdc_end_dttm = next_tHashInput_1.cdc_end_dttm;
 



/**
 * [tHashInput_1 begin ] stop
 */
	
	/**
	 * [tHashInput_1 main ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	

 


	tos_count_tHashInput_1++;

/**
 * [tHashInput_1 main ] stop
 */

	
	/**
	 * [tFlowToIterate_3 main ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

			//row18
			//row18


			
				if(execStat){
					runStat.updateStatOnConnection("row18"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row18 - " + (row18==null? "": row18.toLogString()));
    			}
    		


    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row18.object_id, value=")  + (row18.object_id)  + (".") );            
            globalMap.put("row18.object_id", row18.object_id);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row18.object_nm, value=")  + (row18.object_nm)  + (".") );            
            globalMap.put("row18.object_nm", row18.object_nm);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row18.source_count, value=")  + (row18.source_count)  + (".") );            
            globalMap.put("row18.source_count", row18.source_count);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row18.target_count, value=")  + (row18.target_count)  + (".") );            
            globalMap.put("row18.target_count", row18.target_count);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row18.file_name, value=")  + (row18.file_name)  + (".") );            
            globalMap.put("row18.file_name", row18.file_name);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row18.cdc_start_dttm, value=")  + (row18.cdc_start_dttm)  + (".") );            
            globalMap.put("row18.cdc_start_dttm", row18.cdc_start_dttm);
    	
                if(log.isTraceEnabled())
            log.trace("tFlowToIterate_3 - "  + ("Set global var, key=row18.cdc_end_dttm, value=")  + (row18.cdc_end_dttm)  + (".") );            
            globalMap.put("row18.cdc_end_dttm", row18.cdc_end_dttm);
    	
 
	   nb_line_tFlowToIterate_3++;  
       counter_tFlowToIterate_3++;
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Current iteration is: ")  + (counter_tFlowToIterate_3)  + (".") );
       globalMap.put("tFlowToIterate_3_CURRENT_ITERATION", counter_tFlowToIterate_3);
 


	tos_count_tFlowToIterate_3++;

/**
 * [tFlowToIterate_3 main ] stop
 */
	NB_ITERATE_tFixedFlowInput_4++;
	
	
					if(execStat){				
	       				runStat.updateStatOnConnection("row10", 3, 0);
					}           			
				
				if(execStat){
					runStat.updateStatOnConnection("iterate3", 1, "exec" + NB_ITERATE_tFixedFlowInput_4);
					//Thread.sleep(1000);
				}				
			


	
	/**
	 * [tMSSqlOutput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlOutput_4", false);
		start_Hash.put("tMSSqlOutput_4", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlOutput_4";

	
			if (execStat) {
				if(resourceMap.get("inIterateVComp") == null){
					
						runStat.updateStatOnConnection("row10" + iterateId, 0, 0);
					
				}
			} 

		
		int tos_count_tMSSqlOutput_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlOutput_4{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlOutput_4 = new StringBuilder();
            log4jParamters_tMSSqlOutput_4.append("Parameters:");
                    log4jParamters_tMSSqlOutput_4.append("USE_EXISTING_CONNECTION" + " = " + "true");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("TABLE" + " = " + "\"t_load_status_dtl\"");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("TABLE_ACTION" + " = " + "NONE");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("IDENTITY_INSERT" + " = " + "false");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("DATA_ACTION" + " = " + "INSERT");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("DIE_ON_ERROR" + " = " + "true");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("ADD_COLS" + " = " + "[]");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("USE_FIELD_OPTIONS" + " = " + "false");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("IGNORE_DATE_OUTOF_RANGE" + " = " + "false");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("ENABLE_DEBUG_MODE" + " = " + "false");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("SUPPORT_NULL_WHERE" + " = " + "false");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                    log4jParamters_tMSSqlOutput_4.append("USE_BATCH_SIZE" + " = " + "false");
                log4jParamters_tMSSqlOutput_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + (log4jParamters_tMSSqlOutput_4) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlOutput_4().limitLog4jByte();



int nb_line_tMSSqlOutput_4 = 0;
int nb_line_update_tMSSqlOutput_4 = 0;
int nb_line_inserted_tMSSqlOutput_4 = 0;
int nb_line_deleted_tMSSqlOutput_4 = 0;
int nb_line_rejected_tMSSqlOutput_4 = 0;

int deletedCount_tMSSqlOutput_4=0;
int updatedCount_tMSSqlOutput_4=0;
int insertedCount_tMSSqlOutput_4=0;
int rejectedCount_tMSSqlOutput_4=0;
String dbschema_tMSSqlOutput_4 = null;
String tableName_tMSSqlOutput_4 = null;
boolean whetherReject_tMSSqlOutput_4 = false;

java.util.Calendar calendar_tMSSqlOutput_4 = java.util.Calendar.getInstance();
long year1_tMSSqlOutput_4 = TalendDate.parseDate("yyyy-MM-dd","0001-01-01").getTime();
long year2_tMSSqlOutput_4 = TalendDate.parseDate("yyyy-MM-dd","1753-01-01").getTime();
long year10000_tMSSqlOutput_4 = TalendDate.parseDate("yyyy-MM-dd HH:mm:ss","9999-12-31 24:00:00").getTime();
long date_tMSSqlOutput_4;

java.util.Calendar calendar_datetimeoffset_tMSSqlOutput_4 = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));


	
java.sql.Connection conn_tMSSqlOutput_4 = null;
String dbUser_tMSSqlOutput_4 = null;
	dbschema_tMSSqlOutput_4 = (String)globalMap.get("dbschema_tMSSqlConnection_1");
	conn_tMSSqlOutput_4 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Uses an existing connection with username '")  + (conn_tMSSqlOutput_4.getMetaData().getUserName())  + ("'. Connection URL: ")  + (conn_tMSSqlOutput_4.getMetaData().getURL())  + (".") );
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Connection is set auto commit to '")  + (conn_tMSSqlOutput_4.getAutoCommit())  + ("'.") );

if(dbschema_tMSSqlOutput_4 == null || dbschema_tMSSqlOutput_4.trim().length() == 0) {
    tableName_tMSSqlOutput_4 = "t_load_status_dtl";
} else {
    tableName_tMSSqlOutput_4 = dbschema_tMSSqlOutput_4 + "].[" + "t_load_status_dtl";
}
	int count_tMSSqlOutput_4=0;

        String insert_tMSSqlOutput_4 = "INSERT INTO [" + tableName_tMSSqlOutput_4 + "] ([Submtn_mode_id],[batch_id],[run_id],[stg_id],[object_id],[object_nm],[src_sys_id],[sub_sys_id],[Status],[ld_record_cnt],[src_record_cnt],[rjct_record_cnt],[err_record_cnt],[crtd_by],[updt_by],[crtd_dttm],[updt_dttm],[cdc_strt_dttm],[cdc_end_dttm],[info_dtl]) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        java.sql.PreparedStatement pstmt_tMSSqlOutput_4 = conn_tMSSqlOutput_4.prepareStatement(insert_tMSSqlOutput_4);

 	boolean isShareIdentity_tMSSqlOutput_4 = globalMap.get("shareIdentitySetting_tMSSqlConnection_1") != null && (Boolean)globalMap.get("shareIdentitySetting_tMSSqlConnection_1") == true;

 



/**
 * [tMSSqlOutput_4 begin ] stop
 */



	
	/**
	 * [tFixedFlowInput_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tFixedFlowInput_4", false);
		start_Hash.put("tFixedFlowInput_4", System.currentTimeMillis());
		
	
	currentComponent="tFixedFlowInput_4";

	
		int tos_count_tFixedFlowInput_4 = 0;
		
    	class BytesLimit65535_tFixedFlowInput_4{
    		public void limitLog4jByte() throws Exception{
    			
    		}
    	}
    	
        new BytesLimit65535_tFixedFlowInput_4().limitLog4jByte();

	    for (int i_tFixedFlowInput_4 = 0 ; i_tFixedFlowInput_4 < 1 ; i_tFixedFlowInput_4++) {
	                	            	
    	            		row10.Submtn_mode_id = ((String)globalMap.get("SUBMTN_MODE_ID"));
    	            	        	            	
    	            		row10.batch_id = ((String)globalMap.get("BATCH_ID"));
    	            	        	            	
    	            		row10.run_id = ((String)globalMap.get("RUN_ID"));
    	            	        	            	
    	            		row10.stg_id = Relational.ISNULL(globalMap.get("STG_ID")) ? "1" : ((String)globalMap.get("STG_ID"));
    	            	        	            	
    	            		row10.object_id = ((String)globalMap.get("row18.object_id"));
    	            	        	            	
    	            		row10.object_nm = ((String)globalMap.get("row18.object_nm"));
    	            	        	            	
    	            		row10.src_sys_id = ((String)globalMap.get("SRC_SYS_ID"));
    	            	        	            	
    	            		row10.sub_sys_id = ((String)globalMap.get("SUB_SYS_ID"));
    	            	        	            	
    	            		row10.Status = Relational.ISNULL(globalMap.get("LOAD_STATUS")) ? "C" : ((String)globalMap.get("LOAD_STATUS"));
    	            	        	            	
    	            		row10.ld_record_cnt = Long.valueOf(Relational.ISNULL(globalMap.get("row18.target_count")) ? 0 : ((Integer)globalMap.get("row18.target_count")));
    	            	        	            	
    	            		row10.src_record_cnt = Long.valueOf(Relational.ISNULL(globalMap.get("row18.source_count")) ? 0 : (Integer)globalMap.get("row18.source_count"));
    	            	        	            	
    	            		row10.rjct_record_cnt = (Relational.ISNULL(globalMap.get("row18.source_count")) ? 0 : ((Integer)globalMap.get("row18.source_count"))) - (Relational.ISNULL(globalMap.get("row18.target_count")) ? 0 : ((Integer)globalMap.get("row18.target_count")));
    	            	        	            	
    	            		row10.err_record_cnt = "F".equals((String)globalMap.get("LOAD_STATUS")) ? (Relational.ISNULL(globalMap.get("row18.target_count")) ? 0 : (Integer)globalMap.get("row18.target_count")) : 0;
    	            	        	            	
    	            		row10.crtd_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row10.updt_by = ((String)globalMap.get("DB_USER"));
    	            	        	            	
    	            		row10.crtd_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row10.updt_dttm = TalendDate.getCurrentDate();
    	            	        	            	
    	            		row10.cdc_strt_dttm = ((java.util.Date)globalMap.get("row18.cdc_start_dttm"));
    	            	        	            	
    	            		row10.cdc_end_dttm = ((java.util.Date)globalMap.get("row18.cdc_end_dttm"));
    	            	        	            	
    	            		row10.info_dtl = ((String)globalMap.get("INFO_DTL"));
    	            	
 



/**
 * [tFixedFlowInput_4 begin ] stop
 */
	
	/**
	 * [tFixedFlowInput_4 main ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_4";

	

 


	tos_count_tFixedFlowInput_4++;

/**
 * [tFixedFlowInput_4 main ] stop
 */

	
	/**
	 * [tMSSqlOutput_4 main ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_4";

	

			//row10
			//row10


			
				if(execStat){
					runStat.updateStatOnConnection("row10"+iterateId,1, 1);
				} 
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row10 - " + (row10==null? "": row10.toLogString()));
    			}
    		



        whetherReject_tMSSqlOutput_4 = false;
                    if(row10.Submtn_mode_id == null) {
pstmt_tMSSqlOutput_4.setNull(1, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(1, row10.Submtn_mode_id);
}

                    if(row10.batch_id == null) {
pstmt_tMSSqlOutput_4.setNull(2, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(2, row10.batch_id);
}

                    if(row10.run_id == null) {
pstmt_tMSSqlOutput_4.setNull(3, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(3, row10.run_id);
}

                    if(row10.stg_id == null) {
pstmt_tMSSqlOutput_4.setNull(4, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(4, row10.stg_id);
}

                    if(row10.object_id == null) {
pstmt_tMSSqlOutput_4.setNull(5, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(5, row10.object_id);
}

                    if(row10.object_nm == null) {
pstmt_tMSSqlOutput_4.setNull(6, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(6, row10.object_nm);
}

                    if(row10.src_sys_id == null) {
pstmt_tMSSqlOutput_4.setNull(7, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(7, row10.src_sys_id);
}

                    if(row10.sub_sys_id == null) {
pstmt_tMSSqlOutput_4.setNull(8, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(8, row10.sub_sys_id);
}

                    if(row10.Status == null) {
pstmt_tMSSqlOutput_4.setNull(9, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(9, row10.Status);
}

                    if(row10.ld_record_cnt == null) {
pstmt_tMSSqlOutput_4.setNull(10, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_4.setLong(10, row10.ld_record_cnt);
}

                    if(row10.src_record_cnt == null) {
pstmt_tMSSqlOutput_4.setNull(11, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_4.setLong(11, row10.src_record_cnt);
}

                    if(row10.rjct_record_cnt == null) {
pstmt_tMSSqlOutput_4.setNull(12, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_4.setInt(12, row10.rjct_record_cnt);
}

                    if(row10.err_record_cnt == null) {
pstmt_tMSSqlOutput_4.setNull(13, java.sql.Types.INTEGER);
} else {pstmt_tMSSqlOutput_4.setInt(13, row10.err_record_cnt);
}

                    if(row10.crtd_by == null) {
pstmt_tMSSqlOutput_4.setNull(14, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(14, row10.crtd_by);
}

                    if(row10.updt_by == null) {
pstmt_tMSSqlOutput_4.setNull(15, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(15, row10.updt_by);
}

                    if(row10.crtd_dttm != null) {
pstmt_tMSSqlOutput_4.setTimestamp(16, new java.sql.Timestamp(row10.crtd_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_4.setNull(16, java.sql.Types.DATE);
}

                    if(row10.updt_dttm != null) {
pstmt_tMSSqlOutput_4.setTimestamp(17, new java.sql.Timestamp(row10.updt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_4.setNull(17, java.sql.Types.DATE);
}

                    if(row10.cdc_strt_dttm != null) {
pstmt_tMSSqlOutput_4.setTimestamp(18, new java.sql.Timestamp(row10.cdc_strt_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_4.setNull(18, java.sql.Types.DATE);
}

                    if(row10.cdc_end_dttm != null) {
pstmt_tMSSqlOutput_4.setTimestamp(19, new java.sql.Timestamp(row10.cdc_end_dttm.getTime()));
} else {
pstmt_tMSSqlOutput_4.setNull(19, java.sql.Types.DATE);
}

                    if(row10.info_dtl == null) {
pstmt_tMSSqlOutput_4.setNull(20, java.sql.Types.VARCHAR);
} else {pstmt_tMSSqlOutput_4.setString(20, row10.info_dtl);
}


            try {
                nb_line_tMSSqlOutput_4++;
                insertedCount_tMSSqlOutput_4 = insertedCount_tMSSqlOutput_4 + pstmt_tMSSqlOutput_4.executeUpdate();
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Inserting")  + (" the record ")  + (nb_line_tMSSqlOutput_4)  + (".") );
            } catch(java.lang.Exception e) {
                whetherReject_tMSSqlOutput_4 = true;
                    throw(e);
            }
            	//////////batch execute by batch size///////
            	class LimitBytesHelper_tMSSqlOutput_4{
            		public int limitBytePart1(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_4) throws Exception {
                try {
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_4: pstmt_tMSSqlOutput_4.executeBatch()) {
							if(countEach_tMSSqlOutput_4 == -2 || countEach_tMSSqlOutput_4 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_4;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
                		throw(e);
                	
               			 }
    				return counter;
            	}
            	
            	public int limitBytePart2(int counter,java.sql.PreparedStatement pstmt_tMSSqlOutput_4) throws Exception {
                try {
                		
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Executing the ")  + ("INSERT")  + (" batch.") );
						for(int countEach_tMSSqlOutput_4: pstmt_tMSSqlOutput_4.executeBatch()) {
							if(countEach_tMSSqlOutput_4 == -2 || countEach_tMSSqlOutput_4 == -3) {
								break;
							}
							counter += countEach_tMSSqlOutput_4;
						}
						
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("The ")  + ("INSERT")  + (" batch execution has succeeded.") );
                }catch (java.sql.BatchUpdateException e){
                	
						throw(e);
                	
                		}	
                	return counter;	
            	}
            }

    	////////////commit every////////////
    			

 


	tos_count_tMSSqlOutput_4++;

/**
 * [tMSSqlOutput_4 main ] stop
 */



	
	/**
	 * [tFixedFlowInput_4 end ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_4";

	

        }
        globalMap.put("tFixedFlowInput_4_NB_LINE", 1);        

 

ok_Hash.put("tFixedFlowInput_4", true);
end_Hash.put("tFixedFlowInput_4", System.currentTimeMillis());




/**
 * [tFixedFlowInput_4 end ] stop
 */

	
	/**
	 * [tMSSqlOutput_4 end ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_4";

	



        if(pstmt_tMSSqlOutput_4 != null) {
			
				pstmt_tMSSqlOutput_4.close();
			
        }


	nb_line_deleted_tMSSqlOutput_4=nb_line_deleted_tMSSqlOutput_4+ deletedCount_tMSSqlOutput_4;
	nb_line_update_tMSSqlOutput_4=nb_line_update_tMSSqlOutput_4 + updatedCount_tMSSqlOutput_4;
	nb_line_inserted_tMSSqlOutput_4=nb_line_inserted_tMSSqlOutput_4 + insertedCount_tMSSqlOutput_4;
	nb_line_rejected_tMSSqlOutput_4=nb_line_rejected_tMSSqlOutput_4 + rejectedCount_tMSSqlOutput_4;
	
        globalMap.put("tMSSqlOutput_4_NB_LINE",nb_line_tMSSqlOutput_4);
        globalMap.put("tMSSqlOutput_4_NB_LINE_UPDATED",nb_line_update_tMSSqlOutput_4);
        globalMap.put("tMSSqlOutput_4_NB_LINE_INSERTED",nb_line_inserted_tMSSqlOutput_4);
        globalMap.put("tMSSqlOutput_4_NB_LINE_DELETED",nb_line_deleted_tMSSqlOutput_4);
        globalMap.put("tMSSqlOutput_4_NB_LINE_REJECTED", nb_line_rejected_tMSSqlOutput_4);
    
	
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Has ")  + ("inserted")  + (" ")  + (nb_line_inserted_tMSSqlOutput_4)  + (" record(s).") );

			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row10"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tMSSqlOutput_4 - "  + ("Done.") );

ok_Hash.put("tMSSqlOutput_4", true);
end_Hash.put("tMSSqlOutput_4", System.currentTimeMillis());




/**
 * [tMSSqlOutput_4 end ] stop
 */



						if(execStat){
							runStat.updateStatOnConnection("iterate3", 2, "exec" + NB_ITERATE_tFixedFlowInput_4);
						}				
					







	
	/**
	 * [tHashInput_1 end ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	
    

		
			nb_line_tHashInput_1++;
		}	
    		
    		mf_tHashInput_1.clearCache("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
    	
		org.talend.designer.components.hashfile.common.MapHashFile.resourceLockMap.remove("tHashFile_Jb_Load_ORACLE_ADLS_Child_" + pid +"_tHashOutput_4");
	


	globalMap.put("tHashInput_1_NB_LINE", nb_line_tHashInput_1);       

 

ok_Hash.put("tHashInput_1", true);
end_Hash.put("tHashInput_1", System.currentTimeMillis());




/**
 * [tHashInput_1 end ] stop
 */

	
	/**
	 * [tFlowToIterate_3 end ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

globalMap.put("tFlowToIterate_3_NB_LINE",nb_line_tFlowToIterate_3);
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		runStat.updateStatOnConnection("row18"+iterateId,2, 0); 
			 	}
			}
		
 
                if(log.isDebugEnabled())
            log.debug("tFlowToIterate_3 - "  + ("Done.") );

ok_Hash.put("tFlowToIterate_3", true);
end_Hash.put("tFlowToIterate_3", System.currentTimeMillis());




/**
 * [tFlowToIterate_3 end ] stop
 */



				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tHashInput_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk11", 0, "ok");
								} 
							
							tOracleClose_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tHashInput_1 finally ] start
	 */

	

	
	
	currentComponent="tHashInput_1";

	

 



/**
 * [tHashInput_1 finally ] stop
 */

	
	/**
	 * [tFlowToIterate_3 finally ] start
	 */

	

	
	
	currentComponent="tFlowToIterate_3";

	

 



/**
 * [tFlowToIterate_3 finally ] stop
 */

	
	/**
	 * [tFixedFlowInput_4 finally ] start
	 */

	

	
	
	currentComponent="tFixedFlowInput_4";

	

 



/**
 * [tFixedFlowInput_4 finally ] stop
 */

	
	/**
	 * [tMSSqlOutput_4 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlOutput_4";

	



	

 



/**
 * [tMSSqlOutput_4 finally ] stop
 */









				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tHashInput_1_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_12Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_12_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_12 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_12", false);
		start_Hash.put("tWarn_12", System.currentTimeMillis());
		
	
	currentComponent="tWarn_12";

	
		int tos_count_tWarn_12 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_12 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_12{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_12 = new StringBuilder();
            log4jParamters_tWarn_12.append("Parameters:");
                    log4jParamters_tWarn_12.append("MESSAGE" + " = " + "\"215|Insert into Load Status table failed\"");
                log4jParamters_tWarn_12.append(" | ");
                    log4jParamters_tWarn_12.append("CODE" + " = " + "999");
                log4jParamters_tWarn_12.append(" | ");
                    log4jParamters_tWarn_12.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_12.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_12 - "  + (log4jParamters_tWarn_12) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_12().limitLog4jByte();

 



/**
 * [tWarn_12 begin ] stop
 */
	
	/**
	 * [tWarn_12 main ] start
	 */

	

	
	
	currentComponent="tWarn_12";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_12", "", Thread.currentThread().getId() + "", "ERROR","","215|Insert into Load Status table failed","", "");
            log.error("tWarn_12 - "  + ("Message: ")  + ("215|Insert into Load Status table failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_12 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_12", 5, "215|Insert into Load Status table failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_12_WARN_MESSAGES", "215|Insert into Load Status table failed"); 
globalMap.put("tWarn_12_WARN_PRIORITY", 5);
globalMap.put("tWarn_12_WARN_CODE", 999);


 


	tos_count_tWarn_12++;

/**
 * [tWarn_12 main ] stop
 */
	
	/**
	 * [tWarn_12 end ] start
	 */

	

	
	
	currentComponent="tWarn_12";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_12 - "  + ("Done.") );

ok_Hash.put("tWarn_12", true);
end_Hash.put("tWarn_12", System.currentTimeMillis());




/**
 * [tWarn_12 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_12 finally ] start
	 */

	

	
	
	currentComponent="tWarn_12";

	

 



/**
 * [tWarn_12 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_12_SUBPROCESS_STATE", 1);
	}
	

public void tOracleClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tOracleClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleClose_1", false);
		start_Hash.put("tOracleClose_1", System.currentTimeMillis());
		
	
	currentComponent="tOracleClose_1";

	
		int tos_count_tOracleClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tOracleClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tOracleClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tOracleClose_1 = new StringBuilder();
            log4jParamters_tOracleClose_1.append("Parameters:");
                    log4jParamters_tOracleClose_1.append("CONNECTION" + " = " + "tOracleConnection_1");
                log4jParamters_tOracleClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tOracleClose_1 - "  + (log4jParamters_tOracleClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tOracleClose_1().limitLog4jByte();

 



/**
 * [tOracleClose_1 begin ] stop
 */
	
	/**
	 * [tOracleClose_1 main ] start
	 */

	

	
	
	currentComponent="tOracleClose_1";

	

	java.sql.Connection conn_tOracleClose_1 = (java.sql.Connection)globalMap.get("conn_tOracleConnection_1");
	
	if(conn_tOracleClose_1 != null && !conn_tOracleClose_1.isClosed())
	{
		
	    		log.debug("tOracleClose_1 - Closing the connection 'tOracleConnection_1' to the database.");
			
			conn_tOracleClose_1.close();
			
	    		log.debug("tOracleClose_1 - Connection 'tOracleConnection_1' to the database closed.");
			
	}

 


	tos_count_tOracleClose_1++;

/**
 * [tOracleClose_1 main ] stop
 */
	
	/**
	 * [tOracleClose_1 end ] start
	 */

	

	
	
	currentComponent="tOracleClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tOracleClose_1 - "  + ("Done.") );

ok_Hash.put("tOracleClose_1", true);
end_Hash.put("tOracleClose_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk8", 0, "ok");
				}
				tMSSqlClose_2Process(globalMap);



/**
 * [tOracleClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleClose_1 finally ] start
	 */

	

	
	
	currentComponent="tOracleClose_1";

	

 



/**
 * [tOracleClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleClose_1_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tMSSqlClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlClose_2", false);
		start_Hash.put("tMSSqlClose_2", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlClose_2";

	
		int tos_count_tMSSqlClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlClose_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlClose_2 = new StringBuilder();
            log4jParamters_tMSSqlClose_2.append("Parameters:");
                    log4jParamters_tMSSqlClose_2.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_2 - "  + (log4jParamters_tMSSqlClose_2) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlClose_2().limitLog4jByte();

 



/**
 * [tMSSqlClose_2 begin ] stop
 */
	
	/**
	 * [tMSSqlClose_2 main ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_2";

	



	java.sql.Connection conn_tMSSqlClose_2 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	if(conn_tMSSqlClose_2 != null && !conn_tMSSqlClose_2.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_2 - "  + ("Closing the connection ")  + ("conn_tMSSqlConnection_1")  + (" to the database.") );
        conn_tMSSqlClose_2.close();
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_2 - "  + ("Connection ")  + ("conn_tMSSqlConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tMSSqlClose_2++;

/**
 * [tMSSqlClose_2 main ] stop
 */
	
	/**
	 * [tMSSqlClose_2 end ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_2 - "  + ("Done.") );

ok_Hash.put("tMSSqlClose_2", true);
end_Hash.put("tMSSqlClose_2", System.currentTimeMillis());




/**
 * [tMSSqlClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlClose_2 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_2";

	

 



/**
 * [tMSSqlClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlClose_2_SUBPROCESS_STATE", 1);
	}
	

public void tWarn_13Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tWarn_13_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tWarn_13 begin ] start
	 */

	

	
		
		ok_Hash.put("tWarn_13", false);
		start_Hash.put("tWarn_13", System.currentTimeMillis());
		
	
	currentComponent="tWarn_13";

	
		int tos_count_tWarn_13 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + ("Start to work.") );
    	class BytesLimit65535_tWarn_13{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tWarn_13 = new StringBuilder();
            log4jParamters_tWarn_13.append("Parameters:");
                    log4jParamters_tWarn_13.append("MESSAGE" + " = " + "\"213|Status updates to tracking tables failed\"");
                log4jParamters_tWarn_13.append(" | ");
                    log4jParamters_tWarn_13.append("CODE" + " = " + "999");
                log4jParamters_tWarn_13.append(" | ");
                    log4jParamters_tWarn_13.append("PRIORITY" + " = " + "5");
                log4jParamters_tWarn_13.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + (log4jParamters_tWarn_13) );
    		}
    	}
    	
        new BytesLimit65535_tWarn_13().limitLog4jByte();

 



/**
 * [tWarn_13 begin ] stop
 */
	
	/**
	 * [tWarn_13 main ] start
	 */

	

	
	
	currentComponent="tWarn_13";

	

		
	resumeUtil.addLog("USER_DEF_LOG", "NODE:tWarn_13", "", Thread.currentThread().getId() + "", "ERROR","","213|Status updates to tracking tables failed","", "");
            log.error("tWarn_13 - "  + ("Message: ")  + ("213|Status updates to tracking tables failed")  + (". Code: ")  + (999) );
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + ("Sending message to tLogCatcher_1.") );
	tLogCatcher_1.addMessage("tWarn", "tWarn_13", 5, "213|Status updates to tracking tables failed", 999);
	tLogCatcher_1Process(globalMap);
globalMap.put("tWarn_13_WARN_MESSAGES", "213|Status updates to tracking tables failed"); 
globalMap.put("tWarn_13_WARN_PRIORITY", 5);
globalMap.put("tWarn_13_WARN_CODE", 999);


 


	tos_count_tWarn_13++;

/**
 * [tWarn_13 main ] stop
 */
	
	/**
	 * [tWarn_13 end ] start
	 */

	

	
	
	currentComponent="tWarn_13";

	

 
                if(log.isDebugEnabled())
            log.debug("tWarn_13 - "  + ("Done.") );

ok_Hash.put("tWarn_13", true);
end_Hash.put("tWarn_13", System.currentTimeMillis());




/**
 * [tWarn_13 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tWarn_13 finally ] start
	 */

	

	
	
	currentComponent="tWarn_13";

	

 



/**
 * [tWarn_13 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tWarn_13_SUBPROCESS_STATE", 1);
	}
	

public void tOracleClose_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tOracleClose_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tOracleClose_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tOracleClose_2", false);
		start_Hash.put("tOracleClose_2", System.currentTimeMillis());
		
	
	currentComponent="tOracleClose_2";

	
		int tos_count_tOracleClose_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tOracleClose_2 - "  + ("Start to work.") );
    	class BytesLimit65535_tOracleClose_2{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tOracleClose_2 = new StringBuilder();
            log4jParamters_tOracleClose_2.append("Parameters:");
                    log4jParamters_tOracleClose_2.append("CONNECTION" + " = " + "tOracleConnection_1");
                log4jParamters_tOracleClose_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tOracleClose_2 - "  + (log4jParamters_tOracleClose_2) );
    		}
    	}
    	
        new BytesLimit65535_tOracleClose_2().limitLog4jByte();

 



/**
 * [tOracleClose_2 begin ] stop
 */
	
	/**
	 * [tOracleClose_2 main ] start
	 */

	

	
	
	currentComponent="tOracleClose_2";

	

	java.sql.Connection conn_tOracleClose_2 = (java.sql.Connection)globalMap.get("conn_tOracleConnection_1");
	
	if(conn_tOracleClose_2 != null && !conn_tOracleClose_2.isClosed())
	{
		
	    		log.debug("tOracleClose_2 - Closing the connection 'tOracleConnection_1' to the database.");
			
			conn_tOracleClose_2.close();
			
	    		log.debug("tOracleClose_2 - Connection 'tOracleConnection_1' to the database closed.");
			
	}

 


	tos_count_tOracleClose_2++;

/**
 * [tOracleClose_2 main ] stop
 */
	
	/**
	 * [tOracleClose_2 end ] start
	 */

	

	
	
	currentComponent="tOracleClose_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tOracleClose_2 - "  + ("Done.") );

ok_Hash.put("tOracleClose_2", true);
end_Hash.put("tOracleClose_2", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk16", 0, "ok");
				}
				tMSSqlClose_1Process(globalMap);



/**
 * [tOracleClose_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tOracleClose_2 finally ] start
	 */

	

	
	
	currentComponent="tOracleClose_2";

	

 



/**
 * [tOracleClose_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tOracleClose_2_SUBPROCESS_STATE", 1);
	}
	

public void tMSSqlClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tMSSqlClose_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {

			String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if( resumeEntryMethodName == null || resumeIt || globalResumeTicket){//start the resume
				globalResumeTicket = true;





	
	/**
	 * [tMSSqlClose_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMSSqlClose_1", false);
		start_Hash.put("tMSSqlClose_1", System.currentTimeMillis());
		
	
	currentComponent="tMSSqlClose_1";

	
		int tos_count_tMSSqlClose_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Start to work.") );
    	class BytesLimit65535_tMSSqlClose_1{
    		public void limitLog4jByte() throws Exception{
    			
            StringBuilder log4jParamters_tMSSqlClose_1 = new StringBuilder();
            log4jParamters_tMSSqlClose_1.append("Parameters:");
                    log4jParamters_tMSSqlClose_1.append("CONNECTION" + " = " + "tMSSqlConnection_1");
                log4jParamters_tMSSqlClose_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + (log4jParamters_tMSSqlClose_1) );
    		}
    	}
    	
        new BytesLimit65535_tMSSqlClose_1().limitLog4jByte();

 



/**
 * [tMSSqlClose_1 begin ] stop
 */
	
	/**
	 * [tMSSqlClose_1 main ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_1";

	



	java.sql.Connection conn_tMSSqlClose_1 = (java.sql.Connection)globalMap.get("conn_tMSSqlConnection_1");
	if(conn_tMSSqlClose_1 != null && !conn_tMSSqlClose_1.isClosed())
	{
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Closing the connection ")  + ("conn_tMSSqlConnection_1")  + (" to the database.") );
        conn_tMSSqlClose_1.close();
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Connection ")  + ("conn_tMSSqlConnection_1")  + (" to the database has closed.") );
	}

 


	tos_count_tMSSqlClose_1++;

/**
 * [tMSSqlClose_1 main ] stop
 */
	
	/**
	 * [tMSSqlClose_1 end ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tMSSqlClose_1 - "  + ("Done.") );

ok_Hash.put("tMSSqlClose_1", true);
end_Hash.put("tMSSqlClose_1", System.currentTimeMillis());




/**
 * [tMSSqlClose_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tMSSqlClose_1 finally ] start
	 */

	

	
	
	currentComponent="tMSSqlClose_1";

	

 



/**
 * [tMSSqlClose_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tMSSqlClose_1_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "PROD";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };



    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";

    public static void main(String[] args){
        final Jb_Load_ORACLE_ADLS_Child Jb_Load_ORACLE_ADLS_ChildClass = new Jb_Load_ORACLE_ADLS_Child();

        int exitCode = Jb_Load_ORACLE_ADLS_ChildClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Jb_Load_ORACLE_ADLS_Child' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";

        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'Jb_Load_ORACLE_ADLS_Child' - Start.");
    	

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Jb_Load_ORACLE_ADLS_Child.class.getClassLoader().getResourceAsStream("cerebro/jb_load_oracle_adls_child_0_1/contexts/"+contextStr+".properties");
            if(isDefaultContext && inContext ==null) {

            } else {
                if (inContext!=null) {
                    //defaultProps is in order to keep the original context value
                    defaultProps.load(inContext);
                    inContext.close();
                    context = new ContextProperties(defaultProps);
                }else{
                    //print info and job continue to run, for case: context_param is not empty.
                    System.err.println("Could not find the context " + contextStr);
                }
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
				    context.setContextType("batch_id", "id_String");
				
                context.batch_id=(String) context.getProperty("batch_id");
				    context.setContextType("object_id", "id_String");
				
                context.object_id=(String) context.getProperty("object_id");
				    context.setContextType("object_nm", "id_String");
				
                context.object_nm=(String) context.getProperty("object_nm");
				    context.setContextType("object_position", "id_String");
				
                context.object_position=(String) context.getProperty("object_position");
				    context.setContextType("root_pid", "id_String");
				
                context.root_pid=(String) context.getProperty("root_pid");
				    context.setContextType("src_sys_id", "id_String");
				
                context.src_sys_id=(String) context.getProperty("src_sys_id");
				    context.setContextType("sub_sys_id", "id_String");
				
                context.sub_sys_id=(String) context.getProperty("sub_sys_id");
				    context.setContextType("keyfile_path", "id_String");
				
                context.keyfile_path=(String) context.getProperty("keyfile_path");
				    context.setContextType("prop_file_path", "id_String");
				
                context.prop_file_path=(String) context.getProperty("prop_file_path");
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }


        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("batch_id")) {
                context.batch_id = (String) parentContextMap.get("batch_id");
            }if (parentContextMap.containsKey("object_id")) {
                context.object_id = (String) parentContextMap.get("object_id");
            }if (parentContextMap.containsKey("object_nm")) {
                context.object_nm = (String) parentContextMap.get("object_nm");
            }if (parentContextMap.containsKey("object_position")) {
                context.object_position = (String) parentContextMap.get("object_position");
            }if (parentContextMap.containsKey("root_pid")) {
                context.root_pid = (String) parentContextMap.get("root_pid");
            }if (parentContextMap.containsKey("src_sys_id")) {
                context.src_sys_id = (String) parentContextMap.get("src_sys_id");
            }if (parentContextMap.containsKey("sub_sys_id")) {
                context.sub_sys_id = (String) parentContextMap.get("sub_sys_id");
            }if (parentContextMap.containsKey("keyfile_path")) {
                context.keyfile_path = (String) parentContextMap.get("keyfile_path");
            }if (parentContextMap.containsKey("prop_file_path")) {
                context.prop_file_path = (String) parentContextMap.get("prop_file_path");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}



this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tJava_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tJava_1) {
globalMap.put("tJava_1_SUBPROCESS_STATE", -1);

e_tJava_1.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Jb_Load_ORACLE_ADLS_Child");
        }





if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tMSSqlConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tOracleConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tMSSqlConnection_1", globalMap.get("conn_tMSSqlConnection_1"));
            connections.put("conn_tOracleConnection_1", globalMap.get("conn_tOracleConnection_1"));







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        }else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		}

    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     980827 characters generated by Talend Real-time Big Data Platform 
 *     on the November 13, 2018 12:05:58 PM EST
 ************************************************************************************************/